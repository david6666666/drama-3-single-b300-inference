import json
import os
import torch
print(json.dumps({'pid': os.getpid(), 'purpose': 'counter-permission-only; not a performance result'}), flush=True)
x = torch.ones(1024, device='cuda')
torch.cuda.synchronize()
torch.cuda.cudart().cudaProfilerStart()
x.add_(1)
torch.cuda.synchronize()
torch.cuda.cudart().cudaProfilerStop()
print('permission probe finished', flush=True)
