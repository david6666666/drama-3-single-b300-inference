"""Six unchanged MajorK FP8 expert GEMMs from real D64/P1280 mixed activations."""
import hashlib
import json
import os
from pathlib import Path
from types import SimpleNamespace

import torch
import torch.nn.functional as F
import triton
from fish_speech.models.text2semantic.fish_omni.generate import build_drama3_prompt
import drama3.model as model_module
from drama3.engine import BatchedPrefillGraph, DecodeGraph, state_pool_size
from drama3.mixed_graph import MixedGraph
from drama3.model import DramaModel
from drama3.runtime_state import DeviceRequests

OUT = Path(__file__).resolve().parent
SOURCE = OUT.parents[1] / 'source-span-service'
CORPUS = Path('/home/zjy/code/hsliu/artifacts/drama3-b300-20261014/seedtts-en1088-codes/requests.jsonl')
CHECKPOINT = '/home/zjy/.cache/huggingface/hub/models--fishaudio--drama-3/snapshots/e0a9218aa48888270f06ef1ed9ea67622c0e17d2'
LAYERS = (0, 19, 39)

def flush(report):
    (OUT/'mixed-moe-metadata.json').write_text(json.dumps(report, indent=2)+'\n')

@torch.inference_mode()
def main():
    print(json.dumps({'pid':os.getpid(), 'stage':'initialization'}), flush=True)
    assert Path(model_module.__file__).is_relative_to(SOURCE), model_module.__file__
    raw = CORPUS.read_bytes()
    properties = torch.cuda.get_device_properties(0)
    report = dict(pid=os.getpid(), source=str(SOURCE), source_files_sha256={str(p.relative_to(SOURCE)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((SOURCE/'src/drama3').glob('*.py'))}, driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), checkpoint=CHECKPOINT, corpus_sha256=hashlib.sha256(raw).hexdigest(), cuda_visible_devices=os.environ.get('CUDA_VISIBLE_DEVICES'), gpu_name=properties.name, gpu_uuid=str(properties.uuid), torch_version=torch.__version__, env={k:v for k,v in os.environ.items() if k.startswith('DRAMA3_')}, native_contract='BF16 dense/GDN; original 128-block FP8 expert scales; full top-8 MajorK; no precision change', status='INITIALIZING')
    flush(report)
    try:
        samples=[json.loads(row) for row in raw.splitlines()][:64]
        model=DramaModel(CHECKPOINT,slots=state_pool_size(64),max_length=2048)
        assert model.moe_layout == 'major_k' and model.prefill_moe == 'flashinfer'
        assert model.moe_shared_stream is None and not model.tuned_prefill_moe
        prompts=[build_drama3_prompt(s['text'],model.weights.tokenizer,model.config,[s['reference_text']],[torch.tensor(s['reference_codes'])]) for s in samples]
        capacity=triton.cdiv(sum(map(len,prompts[58:])),256)*256
        assert capacity == 1280, capacity
        device=DeviceRequests(model.slots,model.config.eos_token_id,model.max_length)
        prefill=BatchedPrefillGraph(model,8,triton.next_power_of_2(max(map(len,prompts))))
        first=DecodeGraph(model,8,first_frame=True,requests=device)
        decode=DecodeGraph(model,64,requests=device)
        original=model.moe
        indices={id(layer.mlp):i for i,layer in enumerate(model.backbone.layers)}
        captured={}
        def capture(x,layer,decode=False):
            if decode and indices[id(layer)] in LAYERS:
                assert x.shape == (1344,2048), x.shape
                captured[indices[id(layer)]]=x
            return original(x,layer,decode)
        model.moe=capture
        mixed=MixedGraph(model,device,64,8,capacity,max_length=256)
        model.moe=original
        assert set(captured) == set(LAYERS)
        requests=[SimpleNamespace(slot=i,position=len(p)-1) for i,p in enumerate(prompts)]
        def initialize(i):
            prompt=prompts[i]
            history=F.pad(prompt[-16:,0],(max(0,16-len(prompt)),0),value=-1).cuda()
            device.initialize(i,prompt[-1].cuda(),history,len(prompt)-1,500)
        # Captures can modify persistent states. Real initialization happens last.
        for i in range(64):
            initialize(i)
        for start in range(0,64,8):
            hidden=prefill.run(prompts[start:start+8],list(range(start,start+8)))
            first.run(requests[start:start+8],hidden)
        decode.run(requests)
        for _ in range(7):
            decode.graph.replay()
        torch.cuda.synchronize()
        report['metadata_before_arrival']=device.metadata[:64].cpu().tolist()
        # Simulate physical-slot reuse by six arriving actual corpus prompts.
        for i in range(58,64):
            initialize(i)
        mixed.run(requests[:58],prompts[58:],list(range(58,64)))
        torch.cuda.synchronize()
        inputs={index:x.clone() for index,x in captured.items()}
        report.update(status='ROUTING', prompt_lengths=list(map(len,prompts)), capacity=capacity, max_span=mixed.layout.max_length, decode_slots=mixed.slots[:64].cpu().tolist(), prefill_sequence_slots=mixed.layout.sequence_slots.cpu().tolist(), prefill_boundaries=mixed.layout.boundaries.cpu().tolist(), request_metadata=device.metadata[:64].cpu().tolist(), sampling_step=int(model.sampling_step), layers=[])
        flush(report)
        fi=model_module.trtllm_fp8_block_scale_moe
        for index in LAYERS:
            x=inputs[index]
            layer=model.backbone.layers[index].mlp
            reference=original(x,layer,True)
            ids=torch.full((len(x),8),-1,dtype=torch.int16,device='cuda')
            def record_routing(*args,**kwargs):
                return fi(*args,**kwargs,routing_replay_out=ids)
            model_module.trtllm_fp8_block_scale_moe=record_routing
            try:
                replay_output=original(x,layer,True)
            finally:
                model_module.trtllm_fp8_block_scale_moe=fi
            valid=bool(((ids>=0)&(ids<256)).all())
            exact=bool(torch.equal(reference,replay_output))
            if not valid or not exact:
                raise AssertionError(f'FI routing capture failed validity/exact-output at layer{index}: {valid}/{exact}')
            counts=torch.bincount(ids.long().flatten(),minlength=256)
            active_decode=torch.bincount(ids[:58].long().flatten(),minlength=256)
            real_prefill=sum(map(len,prompts[58:]))
            prefill_counts=torch.bincount(ids[64:64+real_prefill].long().flatten(),minlength=256)
            torch.save(inputs[index].cpu(), OUT/f'layer{index}-input.pt')
            torch.save(ids.cpu(), OUT/f'layer{index}-routing.pt')
            report['layers'].append(dict(layer=index,shape=list(x.shape),dtype=str(x.dtype),input_sha256=hashlib.sha256(x.view(torch.uint8).cpu().numpy().tobytes()).hexdigest(),experts_used=int((counts>0).sum()),expert_token_counts=counts.cpu().tolist(),active_decode_expert_token_counts=active_decode.cpu().tolist(),actual_prefill_expert_token_counts=prefill_counts.cpu().tolist(),routing_source='FlashInfer routing_replay_out on identical input, int16[M,8]; output equals call without replay exactly',routing_capture_output_exact=exact))
            flush(report)
        report.update(status='PROFILING',launch_order='layer0 FC1, layer0 FC2, layer19 FC1, layer19 FC2, layer39 FC1, layer39 FC2',limitations=['Isolated actual mixed-input MoE launches, not an end-to-end model timing.','Nsight profiling can serialize PDL and change cache history; cache-control=none and clocks unchanged.','Only three layers and one actual mixed state; not an all-layer mean or formal performance claim.','Six decode padding rows and 159 prompt padding rows are included, exactly as in the captured D64/P1280 graph.'])
        flush(report)
        print(json.dumps({'stage':'profile_start','layers':list(LAYERS),'shape':[1344,2048]}),flush=True)
        torch.cuda.synchronize()
        torch.cuda.cudart().cudaProfilerStart()
        results=[]
        for index in LAYERS:
            torch.cuda.nvtx.range_push(f'mixed_moe_layer_{index}')
            results.append(original(inputs[index],model.backbone.layers[index].mlp,True))
            torch.cuda.nvtx.range_pop()
        torch.cuda.synchronize()
        torch.cuda.cudart().cudaProfilerStop()
        report.update(status='COMPLETE',outputs_finite=[bool(x.isfinite().all()) for x in results])
        flush(report)
        print(json.dumps({'stage':'complete','outputs_finite':report['outputs_finite']}),flush=True)
    except Exception as exc:
        report.update(status='FAILED',error=repr(exc))
        flush(report)
        raise

if __name__=='__main__':
    main()
