"""Six native FP8 GEMM launches from actual B64 autoregressive activations.

Profiling begins only after model loading, graph capture, real 64-prompt prefill
and eight autoregressive decode steps. This isolated counter probe is not a
service benchmark or a throughput claim. Existing scales and top-8 are unchanged.
"""
import hashlib
import json
import os
from pathlib import Path
from types import SimpleNamespace

import torch
import torch.nn.functional as F
import triton
from fish_speech.models.text2semantic.fish_omni.generate import build_drama3_prompt
import drama3.model as model_module
from drama3.engine import BatchedPrefillGraph, DecodeGraph, state_pool_size
from drama3.kernels import linear
from drama3.model import DramaModel
from drama3.runtime_state import DeviceRequests

OUT = Path(__file__).resolve().parent
SOURCE = OUT.parent / 'source-validation'
CORPUS = Path('/home/zjy/code/hsliu/artifacts/drama3-b300-20261014/seedtts-en1088-codes/requests.jsonl')
CHECKPOINT = '/home/zjy/.cache/huggingface/hub/models--fishaudio--drama-3/snapshots/e0a9218aa48888270f06ef1ed9ea67622c0e17d2'

@torch.inference_mode()
def main():
    print(json.dumps({'pid': os.getpid(), 'stage': 'initialization'}), flush=True)
    assert Path(model_module.__file__).is_relative_to(SOURCE), model_module.__file__
    raw = CORPUS.read_bytes()
    properties = torch.cuda.get_device_properties(0)
    report = dict(pid=os.getpid(), source=str(SOURCE), source_files_sha256={str(p.relative_to(SOURCE)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((SOURCE/'src/drama3').glob('*.py'))}, driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), checkpoint=CHECKPOINT, corpus_sha256=hashlib.sha256(raw).hexdigest(), cuda_visible_devices=os.environ.get('CUDA_VISIBLE_DEVICES'), gpu_name=properties.name, gpu_uuid=str(properties.uuid), torch_version=torch.__version__, env={k:v for k,v in os.environ.items() if k.startswith('DRAMA3_')}, native_contract='BF16 dense/GDN; original 128-block FP8 expert scales; full top-8; no precision change', status='INITIALIZING')
    (OUT/'real-moe-metadata.json').write_text(json.dumps(report,indent=2)+'\n')
    samples=[json.loads(row) for row in raw.splitlines()][:64]
    model=DramaModel(CHECKPOINT,slots=state_pool_size(64),max_length=2048)
    prompts=[build_drama3_prompt(s['text'],model.weights.tokenizer,model.config,[s['reference_text']],[torch.tensor(s['reference_codes'])]) for s in samples]
    device=DeviceRequests(model.slots,model.config.eos_token_id,model.max_length)
    original=model.moe
    indices={id(layer.mlp):i for i,layer in enumerate(model.backbone.layers)}
    captured={}
    def capture(x,layer,decode=False):
        if decode and indices[id(layer)] in (0,19,39):
            captured[indices[id(layer)]]=x
        return original(x,layer,decode)
    model.moe=capture
    graph=DecodeGraph(model,64,requests=device)
    model.moe=original
    first=DecodeGraph(model,8,first_frame=True,requests=device)
    prefill=BatchedPrefillGraph(model,8,triton.next_power_of_2(max(map(len,prompts))))
    requests=[SimpleNamespace(slot=i,position=len(p)-1) for i,p in enumerate(prompts)]
    for i,prompt in enumerate(prompts):
        history=F.pad(prompt[-16:,0],(max(0,16-len(prompt)),0),value=-1).cuda()
        device.initialize(i,prompt[-1].cuda(),history,len(prompt)-1,500)
    for start in range(0,64,8):
        hidden=prefill.run(prompts[start:start+8],list(range(start,start+8)))
        first.run(requests[start:start+8],hidden)
    graph.run(requests)
    for _ in range(7):
        graph.graph.replay()
    torch.cuda.synchronize()
    inputs={index:x.clone() for index,x in captured.items()}
    layers=[]
    for index in (0,19,39):
        x=inputs[index]
        layer=model.backbone.layers[index].mlp
        router=linear(x,layer.packed_input_projection)[:,1024:1280]
        ids=router.float().topk(8,dim=-1).indices
        counts=torch.bincount(ids.flatten(),minlength=256)
        layers.append(dict(layer=index,shape=list(x.shape),dtype=str(x.dtype),input_sha256=hashlib.sha256(x.view(torch.uint8).cpu().numpy().tobytes()).hexdigest(),experts_used=int((counts>0).sum()),expert_token_counts=counts.cpu().tolist()))
    report.update(status='PROFILING',layers=layers,prompt_lengths=list(map(len,prompts)),request_metadata=device.metadata[:64].cpu().tolist(),sampling_step=int(model.sampling_step),launch_order='layer0 FC1, layer0 FC2, layer19 FC1, layer19 FC2, layer39 FC1, layer39 FC2',limitations=['Isolated actual-input MoE launches, not an end-to-end model timing.', 'Nsight kernel replay can serialize PDL and change cache history; cache-control=none and clocks unchanged.', 'Only three layers and one real decode position; no inference about all-layer averages without qualification.'])
    (OUT/'real-moe-metadata.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'stage':'profile_start','layers':[0,19,39],'counts':report['request_metadata'][0]}),flush=True)
    torch.cuda.synchronize()
    torch.cuda.cudart().cudaProfilerStart()
    results=[]
    for index in (0,19,39):
        torch.cuda.nvtx.range_push(f'real_moe_layer_{index}')
        results.append(original(inputs[index],model.backbone.layers[index].mlp,True))
        torch.cuda.nvtx.range_pop()
    torch.cuda.synchronize()
    torch.cuda.cudart().cudaProfilerStop()
    report.update(status='COMPLETE',outputs_finite=[bool(x.isfinite().all()) for x in results])
    (OUT/'real-moe-metadata.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'stage':'complete','outputs_finite':report['outputs_finite']}),flush=True)

if __name__=='__main__':
    main()
