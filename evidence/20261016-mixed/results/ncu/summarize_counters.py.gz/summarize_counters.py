import csv
import hashlib
import json
import re
from pathlib import Path

root=Path(__file__).resolve().parent
metadata=json.loads((root/'real-moe-metadata.json').read_text())
source=json.loads((root/'source-provenance.json').read_text())
rows=list(csv.DictReader((root/'real-moe-metrics-base.csv').open()))
records=[]
for row in rows:
    if not row['ID']:
        continue
    identifier=int(row['ID'])
    layer_id=int(re.search(r'real_moe_layer_(\d+)',row['thread Domain:Push/Pop_Range:PL_Type:PL_Value:CLR_Type:Color:Msg_Type:Msg']).group(1))
    layer=next(x for x in metadata['layers'] if x['layer']==layer_id)
    fc=1 if row['Kernel Name'].startswith('bmm_E4m3_') else 2
    def number(key): return float(row[key].replace(',',''))
    read=number('dram__bytes_read.sum'); write=number('dram__bytes_write.sum'); ns=number('gpu__time_duration.sum')
    footprint=layer['experts_used']*2048*(1024 if fc==1 else 512)
    records.append(dict(id=identifier,layer=layer_id,projection=f'FC{fc}',kernel=row['Kernel Name'],gpu_duration_us=ns/1000,dram_read_bytes=read,dram_write_bytes=write,dram_read_write_TBps=(read+write)/ns/1000,dram_peak_pct=number('dram__throughput.avg.pct_of_peak_sustained_elapsed'),sm_has_warps_active_pct=number('sm__cycles_active.avg.pct_of_peak_sustained_elapsed'),tensor_pipe_active_pct=number('sm__pipe_tensor_cycles_active.avg.pct_of_peak_sustained_elapsed'),profiler_passes=number('profiler__replayer_passes'),router_top8_unique_experts=layer['experts_used'],logical_active_fp8_weight_bytes=footprint,dram_read_to_active_weight_ratio=read/footprint))
report=dict(status='COMPLETE',source_sha=source['commit'],source_snapshot=source['snapshot'],all_runtime_modules_match_source_sha=source['all_runtime_modules_match'],gpu_uuid=metadata['gpu_uuid'],corpus_sha256=metadata['corpus_sha256'],launches=records,interpretation='The sampled actual-input B64 native FP8 expert GEMMs show substantial DRAM traffic/throughput and low tensor-pipe activity, consistent with memory movement limiting these kernels more than tensor arithmetic. This is not a serving throughput measurement.',limitations=metadata['limitations']+['SM active means cycles with a warp in flight, not achieved arithmetic throughput.','Active-expert counts are recomputed by torch.topk from identical BF16 router logits, not directly captured from FlashInfer routing; tie ordering is not proven equal.','Six kernel launches in one diagnostic run do not establish an all-layer mean or formal speedup.','Other users were running jobs on separate GPUs; no affinity, GPU clocks, cache flush or driver permission changes were performed.'],files_sha256={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in ['real_moe_driver.py','real-moe-command.json','real-moe-metadata.json','real-moe-metrics-base.csv','real-moe.ncu-repz','real-moe.log','source-provenance.json']})
(root/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
lines=['# Native B64 MoE hardware counters','','GPU2 counter diagnostic only; native full top-8 FP8 experts, unchanged scales and BF16 dense/GDN. Source '+source['commit']+'. No service speedup claim.','','| Layer | Projection | Duration us | DRAM read MB | DRAM write MB | Read+write TB/s | DRAM peak % | SM warp-active % | Tensor pipe active % |','|---|---|---|---|---|---|---|---|---|']
for x in records:
    lines.append(f"| {x['layer']} | {x['projection']} | {x['gpu_duration_us']:.3f} | {x['dram_read_bytes']/1e6:.3f} | {x['dram_write_bytes']/1e6:.3f} | {x['dram_read_write_TBps']:.3f} | {x['dram_peak_pct']:.2f} | {x['sm_has_warps_active_pct']:.2f} | {x['tensor_pipe_active_pct']:.2f} |")
lines.extend(['','All six launches required one profiler pass. Real 64-prompt prefill, first frames and eight decode steps ran before cudaProfilerStart. Layers 0, 19 and 39 use saved actual decode activations. All three outputs were finite.','','Measured DRAM reads are 1.00052–1.00138 times the logical active-expert weight footprint computed from the same router logits. This suggests little repeated expert-weight traffic in these samples; it does not prove identical tie-breaking between torch.topk and FlashInfer. The low tensor active percentages do not translate to an available 20x speedup: the weight bytes still need to be read.','','Cache control is none and clocks are unchanged. Nsight kernel profiling may serialize PDL; these durations must not be compared directly to unprofiled service/graph timing. Three layers at one decode position are insufficient for all-layer or all-concurrency claims.','','Commands, executable driver, source hashes, corpus hash, per-request input positions/counts, expert count distributions, raw CSV, profiler log, and .ncu-repz are retained in this directory. GPU2 and both task-owned processes were released after completion.'])
(root/'README.md').write_text('\n'.join(lines)+'\n')
print(json.dumps({'launches':len(records),'duration_us':sum(x['gpu_duration_us'] for x in records),'all_single_pass':all(x['profiler_passes']==1 for x in records),'source_verified':source['all_runtime_modules_match']},indent=2))
