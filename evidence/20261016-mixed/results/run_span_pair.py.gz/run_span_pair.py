import datetime,json,os,subprocess,threading,time
from pathlib import Path
root=Path('/home/zjy/code/hsliu/artifacts/drama3-mixed-20261016')
source=root/'source-span-service'
venv=Path('/home/zjy/code/hsliu/venvs/codex-drama3-standalone')
env=dict(os.environ,DRAMA3_GDN_STATE_DTYPE='bfloat16',DRAMA3_PACKED_MOE_PROJECTION='1',DRAMA3_PREFILL_CONV='triton',DRAMA3_PREFILL_MOE_TUNED='0',DRAMA3_PREFILL_MOE='flashinfer',DRAMA3_ADMISSION_MIN_BATCH='6',DRAMA3_PREFILL_BUCKET_192='1',DRAMA3_PACKED_PREFILL='1',DRAMA3_ASYNC_CODEC='0',DRAMA3_AUDIO_DELIVERY_THREAD='0',DRAMA3_FUSED_MOE_INPUT='1')
stop=threading.Event()
def audit():
 with (root/'span-gpu0-process-audit.jsonl').open('w') as f:
  while not stop.is_set():
   p=subprocess.run(['nvidia-smi','--query-compute-apps=gpu_uuid,pid,process_name,used_gpu_memory','--format=csv,noheader'],capture_output=True,text=True)
   f.write(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'processes':p.stdout.splitlines()})+'\n');f.flush();stop.wait(1)
t=threading.Thread(target=audit);t.start()
try:
 for enabled,name in [('0','span-control-gpu0'),('1','span-candidate-gpu0')]:
  cmd=[str(venv/'bin/python'),str(source/'scripts/run_baseline.py'),'--backend','standalone','--source',str(source),'--venv',str(venv),'--bench-python',str(venv/'bin/python'),'--checkpoint','/home/zjy/.cache/huggingface/hub/models--fishaudio--drama-3/snapshots/e0a9218aa48888270f06ef1ed9ea67622c0e17d2','--fish-source','/home/zjy/code/hsliu/drama3-sources/fish-speech','--corpus','/home/zjy/code/hsliu/artifacts/drama3-b300-20261014/seedtts-en1088-codes/requests.jsonl','--output',str(root/name),'--gpu','0','--port','18130','--capacity','64','--requests','1088','--repeats','1','--concurrency','64','--skip-reference-warmup']
  print('Starting',name,flush=True)
  subprocess.run(cmd,env=dict(env,DRAMA3_MIXED_BACKBONE='1',DRAMA3_MIXED_SPAN256=enabled),check=True)
  print('Finished',name,flush=True)
finally:
 stop.set();t.join()
