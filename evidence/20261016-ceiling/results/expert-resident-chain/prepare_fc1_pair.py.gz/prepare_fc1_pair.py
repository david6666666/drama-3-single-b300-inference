"""CPU-only actual AOT integration gate for two native shared-output FC1 phases."""
import sys,os,json,traceback,hashlib,subprocess
from pathlib import Path
OUT=Path(__file__).resolve().parent;ROOT=OUT.parent
os.environ.update(CUTE_DSL_ARCH='sm_103a',CUTE_DSL_KEEP='ptx,cubin',CUTE_DSL_DUMP_DIR=str(OUT/'fc1-pair-cpu-compile'))
(OUT/'fc1-pair-cpu-compile').mkdir(exist_ok=True)
sys.path.insert(0,str(ROOT/'expert-fc1-native-v3'));import common as c
import torch,cutlass,cutlass.cute as cute
import cuda.bindings.driver as cuda_drv
from flashinfer.prims_ts.batched_gemm.batched_gemm_config import make_config,TileScheduler
from flashinfer.prims_ts.batched_gemm.batched_gemm_run import _compile_arg_tuple
from flashinfer.prims_ts.cutlass_dsl import task_scheduling_scope
from cutlass.cutlass_dsl import BaseDSL
from resident_fc1_host import resident_fc1_pair_host
report={'status':'PREPARING','gpu_launched':False,'source_sha':'95fcb0ef2662f2caf9bfb7fe6863dc3ad7805b1b','scope':'Actual shared FC1 up/gate phase integration; not yet complete resident chain','timings_allowed':False}
def flush():(OUT/'fc1-pair-aot-result.json').write_text(json.dumps(report,indent=2)+'\n')
try:
 assert os.environ.get('CUDA_VISIBLE_DEVICES')=='' and not torch.cuda.is_initialized()
 _,info=c.config();candidate={**info['candidate'],'tile_scheduler':int(TileScheduler.STATIC),'use_clc_fast_drain':0,'num_stages_workid':1}
 cfg=make_config(**candidate);data=c.cpu_data();io,x=c.io_for(cfg,data,'cpu')
 report['candidate_config']=candidate;flush()
 with task_scheduling_scope(),BaseDSL.enable_pyir():
  fn=cute.compile(resident_fc1_pair_host,*_compile_arg_tuple(io,cuda_drv.CUstream(0)),options='--opt-level 2 --gpu-arch sm_103a')
 (OUT/'fc1-pair-cpu-compile/host-module.mlir').write_text(str(fn.ir_module))
 bins=list((OUT/'fc1-pair-cpu-compile').glob('*.cubin'));assert len(bins)==1
 usage=subprocess.check_output(['/usr/local/cuda/bin/cuobjdump','--dump-resource-usage',str(bins[0])],text=True);(OUT/'fc1-pair-resource-usage.txt').write_text(usage)
 report.update(status='CPU_AOT_PASS',cuda_initialized=torch.cuda.is_initialized(),cubin_sha256=c.sha(bins[0]),resource_usage=usage)
 assert report['cuda_initialized'] is False
except BaseException as e:report.update(status='CPU_AOT_FAIL',error=repr(e),traceback=traceback.format_exc());raise
finally:flush()
