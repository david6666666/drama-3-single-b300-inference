"""Causal stage diagnostic; retains original FAIL, no timing or pass substitution."""
import json,sys,os,hashlib
from pathlib import Path
ROOT=Path('/home/zjy/code/hsliu/artifacts/drama3-ceiling-20261016')
SOURCE=ROOT/'source-moe-residual-da91321'
sys.path.insert(0,str(SOURCE/'src'))
import torch
import triton
import triton.language as tl
from safetensors import safe_open
from drama3.kernels import add_norm,combine_experts,combine_experts_add_norm

@triton.jit
def stages(ROUTED,SHARED,GATE,RESIDUAL,W,OUT,COMBINED,WEIGHTED,SCALES,EPS:tl.constexpr,WIDTH:tl.constexpr):
 row=tl.program_id(0)
 col=tl.arange(0,WIDTH)
 routed=tl.load(ROUTED+row*WIDTH+col).to(tl.float32)
 shared=tl.load(SHARED+row*WIDTH+col).to(tl.float32)
 gate=tl.sigmoid(tl.load(GATE+row).to(tl.float32)).to(SHARED.dtype.element_ty).to(tl.float32)
 weighted=(shared*gate).to(SHARED.dtype.element_ty).to(tl.float32)
 combined=(routed+weighted).to(ROUTED.dtype.element_ty).to(tl.float32)
 value=combined+tl.load(RESIDUAL+row*WIDTH+col).to(tl.float32)
 value=value.to(ROUTED.dtype.element_ty).to(tl.float32)
 tl.store(RESIDUAL+row*WIDTH+col,value)
 reciprocal=tl.rsqrt(tl.sum(value*value,0)/WIDTH+EPS)
 value*=reciprocal
 value*=1.+tl.load(W+col).to(tl.float32)
 tl.store(OUT+row*WIDTH+col,value)
 tl.store(COMBINED+row*WIDTH+col,combined)
 tl.store(WEIGHTED+row*WIDTH+col,weighted)
 tl.store(SCALES+row*2,gate)
 tl.store(SCALES+row*2+1,reciprocal)

def metrics(a,b):
 delta=(a.float()-b.float())
 indices=(a!=b).nonzero()
 return dict(equal=torch.equal(a,b),different=len(indices),max_abs=float(delta.abs().max()),rrms=float(delta.square().mean().sqrt()/b.float().square().mean().sqrt().clamp_min(1e-12)),examples=[dict(index=i.tolist(),actual=float(a[tuple(i)]),expected=float(b[tuple(i)])) for i in indices[:6]])

checkpoint=Path('/home/zjy/.cache/huggingface/hub/models--fishaudio--drama-3/snapshots/e0a9218aa48888270f06ef1ed9ea67622c0e17d2')
with safe_open(checkpoint/'model-00001-of-00008.safetensors',framework='pt',device='cpu') as f:
 weight=f.get_tensor('model.language_model.layers.1.input_layernorm.weight').bfloat16().cuda()
report=dict(source_sha='da9132185ed2c503a1e392754e26ff8916d163fa',original_failure_sha256=hashlib.sha256((ROOT/'moe-residual-validation.json').read_bytes()).hexdigest(),scope='Causal stage diagnostic. Routed/shared/gate generator matches first failed trial; original global residual RNG was not saved, so new residual has explicit seed. Original FAIL is unchanged.',cases=[])
for rows in (1,64):
 generator=torch.Generator(device='cuda').manual_seed(93741)
 routed=(torch.randn(rows,2048,device='cuda',generator=generator)*.01).bfloat16()
 shared=(torch.randn(rows,2048,device='cuda',generator=generator)*.01).bfloat16()
 gate=torch.randn(rows,1,device='cuda',generator=generator,dtype=torch.bfloat16)
 residual=torch.randn(rows,2048,device='cuda',generator=torch.Generator(device='cuda').manual_seed(7261),dtype=torch.bfloat16)
 expected_residual=residual.clone()
 combined=combine_experts(routed,shared,gate)
 expected=add_norm(combined,expected_residual,weight,1e-6)
 actual_residual=residual.clone()
 actual=combine_experts_add_norm(routed,shared,gate,actual_residual,weight,1e-6)
 debug_residual=residual.clone()
 debug_output,debug_combined,debug_weighted=(torch.empty_like(routed) for _ in range(3))
 debug_scales=torch.empty(rows,2,device='cuda',dtype=torch.float32)
 kernel=stages[(rows,)](routed,shared,gate,debug_residual,weight,debug_output,debug_combined,debug_weighted,debug_scales,1e-6,2048,num_warps=4,enable_fp_fusion=False)
 norm_only=add_norm(torch.zeros_like(routed),actual_residual.clone(),weight,1e-6)
 comparison=dict(output=metrics(actual,expected),residual=metrics(actual_residual,expected_residual),debug_vs_original_fusion=metrics(debug_output,actual),debug_combined_vs_baseline=metrics(debug_combined,combined),debug_residual_vs_original=metrics(debug_residual,actual_residual),norm_only_vs_fused=metrics(norm_only,actual))
 report['cases'].append(dict(rows=rows,comparisons=comparison))
 torch.save(dict(routed=routed.cpu(),shared=shared.cpu(),gate=gate.cpu(),residual=residual.cpu(),weight=weight.cpu(),combined=combined.cpu(),actual=actual.cpu(),expected=expected.cpu(),debug_combined=debug_combined.cpu(),debug_scales=debug_scales.cpu()),ROOT/f'moe-residual-diagnostic-inputs-b{rows}.pt')
 for kind in ('ptx','ttgir'):
  (ROOT/f'moe-residual-debug-b{rows}.{kind}').write_text(kernel.asm[kind])
 (ROOT/'moe-residual-diagnostic.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(report['cases'][-1]),flush=True)
