"""Fixed 45-tensor CPU byte-structure audit; no CUDA, decoding, or weight edits."""
import hashlib
import json
import struct
from pathlib import Path

import numpy as np

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
CHECKPOINT = Path('/home/zjy/.cache/huggingface/hub/models--fishaudio--drama-3/snapshots/e0a9218aa48888270f06ef1ed9ea67622c0e17d2')
LAYERS = (0, 1, 2, 19, 39)
EXPERTS = (0, 127, 255)
KINDS = ('gate', 'up', 'down')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def entropy(counts):
    p = np.asarray(counts, dtype=np.float64)
    p = p[p > 0] / p.sum()
    return float(-(p * np.log2(p)).sum())


def distribution(values):
    return {'min': int(values.min()), 'max': int(values.max()), 'mean': float(values.mean()),
            'p50': float(np.quantile(values, .5)), 'p95': float(np.quantile(values, .95))}


def runs(indices):
    result = []
    for i in indices:
        if result and result[-1][1] == i:
            result[-1][1] = i + 1
        else:
            result.append([i, i + 1])
    return result


def encode_channels(a, channels, axis):
    """A diagnostic format, never a GPU format: bitmap + exact sign bits + raw rows."""
    moved = np.moveaxis(a, axis, 0)
    zero_rows = moved[channels]
    mask = np.zeros(moved.shape[0], dtype=np.uint8)
    mask[channels] = 1
    bitmap = np.packbits(mask, bitorder='little')
    signs = np.packbits((zero_rows >> 7).reshape(-1), bitorder='little')
    dense = moved[mask == 0].copy()
    recovered = np.empty_like(moved)
    decoded_mask = np.unpackbits(bitmap, bitorder='little', count=len(mask)).astype(bool)
    recovered[~decoded_mask] = dense
    recovered[decoded_mask] = (np.unpackbits(signs, bitorder='little', count=zero_rows.size).reshape(zero_rows.shape) << 7)
    recovered = np.moveaxis(recovered, 0, axis)
    assert recovered.tobytes() == a.tobytes()
    return {'format': '512bit channel bitmap + one sign bit per zero-channel byte + unchanged other bytes',
            'bytes': int(bitmap.nbytes + signs.nbytes + dense.nbytes),
            'fraction': float((bitmap.nbytes + signs.nbytes + dense.nbytes) / a.nbytes),
            'bitmap_bytes': int(bitmap.nbytes), 'zero_sign_bytes': int(signs.nbytes),
            'dense_payload_bytes': int(dense.nbytes), 'roundtrip_byte_exact': True,
            'decoder_or_GPU_measured': False}


def main():
    index_path = CHECKPOINT / 'model.safetensors.index.json'
    index = json.loads(index_path.read_text())['weight_map']
    previous = json.loads((ROOT / 'native-lossless-weight-audit/result.json').read_text())
    old = {r['key']: r['raw_sha256'] for r in previous['tensors']}
    headers = {}
    tensors = []
    grouped = {}
    raw_dir = OUT / 'raw'
    raw_dir.mkdir(exist_ok=True)
    for layer in LAYERS:
        for expert in EXPERTS:
            group = {}
            for kind in KINDS:
                key = f'model.language_model.layers.{layer}.mlp.experts.{expert}.{kind}_proj.weight'
                file = CHECKPOINT / index[key]
                with file.open('rb') as handle:
                    if file not in headers:
                        size = struct.unpack('<Q', handle.read(8))[0]
                        header_bytes = handle.read(size)
                        headers[file] = (size, json.loads(header_bytes), sha(header_bytes))
                    size, header, header_hash = headers[file]
                    descriptor = header[key]
                    start, end = descriptor['data_offsets']
                    handle.seek(8 + size + start)
                    raw = handle.read(end - start)
                assert descriptor['dtype'] == 'F8_E4M3'
                assert len(raw) == end - start == 1048576
                if key in old:
                    assert sha(raw) == old[key], key
                name = f'L{layer}-E{expert}-{kind}.bin'
                target = raw_dir / name
                if target.exists():
                    assert target.read_bytes() == raw
                else:
                    target.write_bytes(raw)
                a = np.frombuffer(raw, np.uint8).reshape(descriptor['shape'])
                zero = (a & 127) == 0
                zero_rows = np.flatnonzero(zero.all(axis=1))
                zero_columns = np.flatnonzero(zero.all(axis=0))
                axis = 1 if kind == 'down' else 0
                channel_ids = zero_columns if kind == 'down' else zero_rows
                moved = np.moveaxis(a, axis, 0)
                signs = (moved[channel_ids] >> 7).reshape(-1)
                structured = len(channel_ids) * moved.shape[1]
                z4 = zero.reshape(a.shape[0], -1, 4).sum(axis=-1)
                z4_hist = np.bincount(z4.reshape(-1).astype(np.int64), minlength=5)
                flat_blocks = {}
                for block in (4, 16, 32, 64, 128, 256):
                    b = a.reshape(-1, block)
                    flat_blocks[str(block)] = {'blocks': len(b), 'all_numeric_zero': int(((b & 127) == 0).all(axis=1).sum()),
                                               'all_positive_zero_bytes': int((b == 0).all(axis=1).sum()),
                                               'all_negative_zero_bytes': int((b == 128).all(axis=1).sum())}
                tiles = zero.reshape(a.shape[0] // 128, 128, a.shape[1] // 128, 128).transpose(0, 2, 1, 3)
                tile_sums = tiles.sum(axis=(2, 3))
                # Exclude coherent hidden channels before characterizing remaining zeros.
                active = np.ones(512, dtype=bool)
                active[channel_ids] = False
                remaining = moved[active]
                row = {'key': key, 'layer': layer, 'expert': expert, 'projection': kind,
                       'file': str(file), 'file_data_offset': 8 + size + start, 'shape': list(a.shape),
                       'dtype': descriptor['dtype'], 'bytes': len(raw), 'raw_sha256': sha(raw),
                       'raw_copy': str(target.relative_to(OUT)), 'header_sha256': header_hash,
                       'positive_zero_count': int((a == 0).sum()), 'negative_zero_count': int((a == 128).sum()),
                       'numeric_zero_count': int(zero.sum()), 'numeric_zero_fraction': float(zero.mean()),
                       'zero_hidden_channel_count': len(channel_ids), 'zero_hidden_channel_indices': channel_ids.tolist(),
                       'zero_hidden_channel_runs_half_open': runs(channel_ids.tolist()),
                       'zero_rows': zero_rows.tolist(), 'zero_columns': zero_columns.tolist(),
                       'coherent_channel_zero_count': structured,
                       'zero_count_outside_coherent_channels': int(zero.sum()) - structured,
                       'zero_fraction_outside_coherent_channels': float(((remaining & 127) == 0).mean()),
                       'zero_channel_sign_one_fraction': float(signs.mean()) if signs.size else None,
                       'zero_channel_sign_marginal_entropy_bits': entropy(np.bincount(signs, minlength=2)) if signs.size else None,
                       'row_zero_counts': distribution(zero.sum(axis=1)), 'column_zero_counts': distribution(zero.sum(axis=0)),
                       'aligned_4_K_zero_count_histogram': z4_hist.tolist(),
                       'exactly_two_zeros_per_four_K_fraction': float((z4 == 2).mean()),
                       'at_least_two_zeros_per_four_K_fraction': float((z4 >= 2).mean()),
                       'entire_tensor_at_most_two_nonzeros_per_four_K': bool((z4 >= 2).all()),
                       'aligned_flat_zero_blocks': flat_blocks,
                       'tiles128x128': {'tiles': int(tile_sums.size), 'all_numeric_zero': int((tile_sums == 16384).sum()), 'all_nonzero': int((tile_sums == 0).sum()), 'zero_counts': tile_sums.tolist()},
                       'nonzero_subnormal_count': int((((a & 120) == 0) & ((a & 7) != 0)).sum()),
                       'byte_entropy_bits': entropy(np.bincount(a.reshape(-1), minlength=256)),
                       'channel_storage_roundtrip': encode_channels(a, channel_ids, axis)}
                tensors.append(row)
                group[kind] = row
            grouped[f'L{layer}-E{expert}'] = {
                'same_hidden_zero_indices_in_all_three': group['gate']['zero_hidden_channel_indices'] == group['up']['zero_hidden_channel_indices'] == group['down']['zero_hidden_channel_indices'],
                'original_bytes': sum(x['bytes'] for x in group.values()),
                'diagnostic_channel_storage_bytes': sum(x['channel_storage_roundtrip']['bytes'] for x in group.values()),
                'numeric_zero_channels': {k: x['zero_hidden_channel_count'] for k, x in group.items()},
                'zero_bytes_outside_channels': sum(x['zero_count_outside_coherent_channels'] for x in group.values()),
            }
    per_layer = {}
    for layer in LAYERS:
        subset = [r for r in tensors if r['layer'] == layer]
        per_layer[str(layer)] = {'tensors': len(subset), 'bytes': sum(r['bytes'] for r in subset),
                                 'numeric_zero_bytes': sum(r['numeric_zero_count'] for r in subset),
                                 'structured_channel_zero_bytes': sum(r['coherent_channel_zero_count'] for r in subset),
                                 'diagnostic_channel_storage_bytes': sum(r['channel_storage_roundtrip']['bytes'] for r in subset)}
    result = {'status': 'CPU_FIXED_SAMPLE_BYTE_STRUCTURE_COMPLETE', 'gpu_initialized': False, 'runtime_changed': False,
              'runtime_sha': previous['runtime_sha'], 'scope': {'layers': LAYERS, 'experts': EXPERTS, 'projections': KINDS, 'tensors': 45, 'source_bytes_read': sum(r['bytes'] for r in tensors)},
              'index_sha256': sha(index_path.read_bytes()), 'script_sha256': sha(Path(__file__).read_bytes()),
              'tensors': tensors, 'groups': grouped, 'per_layer': per_layer,
              'limitations': ['Fixed samples, not an all-layer/all-expert or live-route-weighted census.',
                              'Signed zeros remain distinct original bytes; no canonicalization/pruning/skipping or sparse MMA is authorized.',
                              'Coherent zeros establish spatial structure, not its training/quantization/underflow cause.',
                              'Diagnostic roundtrip format is CPU-only and is not a measured GPU decoder or throughput result.',
                              'Zero probability and sign entropy do not prove statistical independence.']}
    (OUT / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'status': result['status'], 'scope': result['scope'], 'groups': grouped, 'per_layer': per_layer}, indent=2))


if __name__ == '__main__':
    main()
