"""CPU-only reproduction of historical tower trace accounting; no Torch/CUDA import."""
from collections import Counter, defaultdict
import gzip
import hashlib
import json
from pathlib import Path
import statistics

ROOT = Path('/home/zjy/code/hsliu')
ART = ROOT / 'artifacts/drama3-ceiling-20261016'
OLD = ROOT / 'artifacts/drama3-scale150-20261015'
OUT = ART / 'native-tower-budget-audit'
TRACE = OLD / 'native-bf16-projections-b64/trace.json.gz'
LT = ART / 'native-lt-real-contract/result.json'
MODEL = ROOT / 'drama-3-single-b300-inference/src/drama3/model.py'
KERNELS = ROOT / 'drama-3-single-b300-inference/src/drama3/kernels.py'

def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def classify(name):
    if name.startswith('nvjet_'):
        return 'dense_gemm'
    if 'splitKreduce' in name:
        return 'dense_splitk_reduce'
    if name.startswith('bmm_') or 'moe::dev::' in name:
        return 'native_moe_routing_fc1_activation_fc2_finalize'
    if name in ('conv_update_kernel', 'gated_norm_kernel') or 'gated_delta_rule' in name:
        return 'gdn_recurrence_conv_norm'
    if name == 'add_norm_kernel' or 'rmsnormRMSNormKernel' in name:
        return 'norm_residual'
    if name == 'attention_prepare_kernel':
        return 'attention_prepare'
    if 'GroupedQueryAttentionDecodePaged' in name or name.startswith('kernel_cutlass_reduction_kernel'):
        return 'attention_decode_reduce'
    if 'sigmoid_kernel_cuda' in name or 'BinaryFunctor<c10::BFloat16, c10::BFloat16, c10::BFloat16, at::native::binary_internal::MulFunctor' in name:
        return 'attention_gate_sigmoid_mul'
    if name.startswith('sample_'):
        return 'sampling'
    if name == 'silu_mul_kernel':
        return 'ffn_silu'
    return 'other'

def intervals(events):
    ranges = sorted((x['ts'], x['ts'] + x['dur']) for x in events)
    lo, hi = ranges[0]
    union = 0
    for a, b in ranges[1:]:
        if a <= hi:
            hi = max(hi, b)
        else:
            union += hi - lo
            lo, hi = a, b
    union += hi - lo
    span = ranges[-1][1] - ranges[0][0]
    # End time is max(end), not necessarily final start+duration.
    span = max(b for _, b in ranges) - ranges[0][0]
    return {'span_us': span, 'kernel_interval_union_us': union,
            'uncovered_gap_us': span-union, 'kernel_duration_sum_us': sum(x['dur'] for x in events)}

def summarize(events):
    groups = defaultdict(lambda: {'count': 0, 'kernel_sum_us': 0.0})
    for x in events:
        c = groups[classify(x['name'])]
        c['count'] += 1
        c['kernel_sum_us'] += x['dur']
    return {'kernels': len(events), **intervals(events), 'groups': dict(groups)}

with gzip.open(TRACE, 'rt') as f:
    trace = json.load(f)
events = [x for x in trace['traceEvents'] if x.get('cat') == 'kernel']
assert len(events) == 3*1298
assert [i for i,x in enumerate(events) if x['name']=='_load'] == [0,1298,2596]
roles = ['semantic_head', 'first_embedding_hidden_projection']
for layer in range(13):
    if layer:
        roles.append('table_hidden_projection')
    roles += ['qkv_projection', 'attention_output_projection', 'ffn_gate_up', 'ffn_down']
    if layer >= 4:
        roles.append('residual_codebook_head')
assert len(roles)==75
steps=[]
for step in range(3):
    e=events[step*1298:(step+1)*1298]
    assert e[924]['name']=='add_norm_kernel' and 'CUDAFunctorOnSelf_add<long>' in e[925]['name']
    assert e[926]['name'].startswith('nvjet_') and e[927]['name']=='sample_partition_kernel'
    tower=e[925:]
    assert e[-1]['name']=='_save'
    assert sum(x['name']=='attention_prepare_kernel' for x in tower)==13
    assert sum(x['name']=='silu_mul_kernel' for x in tower)==13
    dense_indices=[i for i,x in enumerate(tower) if x['name'].startswith('nvjet_')]
    assert len(dense_indices)==len(roles)
    role_times=defaultdict(lambda:{'calls':0,'gemm_us':0.0,'following_splitk_us':0.0})
    for role,i in zip(roles,dense_indices,strict=True):
        z=role_times[role];z['calls']+=1;z['gemm_us']+=tower[i]['dur']
        if 'splitKreduce' in tower[i+1]['name']:
            z['following_splitk_us']+=tower[i+1]['dur']
    ffn=[]
    for i,x in enumerate(tower):
        if x['name']!='silu_mul_kernel': continue
        assert tower[i-2]['name']=='add_norm_kernel'
        assert tower[i-1]['name'].startswith('nvjet_')
        assert tower[i+1]['name'].startswith('nvjet_')
        assert 'splitKreduce' in tower[i+2]['name']
        assert tower[i+3]['name']=='add_norm_kernel'
        ffn.append(sum(y['dur'] for y in tower[i-2:i+4]))
    steps.append({'step':step,'full':summarize(e),'backbone_and_inputs':summarize(e[:925]),
                  'tower_and_output':summarize(tower),'tower_dense_by_role':dict(role_times),
                  'tower_ffn_two_gemms_silu_two_norms_sum_us':sum(ffn)})
lt=json.loads(LT.read_text());shapes=lt['call_shapes'];assert len(shapes)==223
assert shapes[160]['w']==[4224,2048]
assert Counter(tuple(x['w']) for x in shapes[160:])==Counter({(4224,2048):1,(2048,4096):14,(9216,2048):13,(12288,2048):13,(2048,6144):13,(4096,2048):9})
mean_groups={k:{'count': steps[0]['tower_and_output']['groups'][k]['count'], 'kernel_sum_us':statistics.mean(s['tower_and_output']['groups'][k]['kernel_sum_us'] for s in steps)} for k in steps[0]['tower_and_output']['groups']}
mean_roles={k:{'calls':steps[0]['tower_dense_by_role'][k]['calls'], **{j:statistics.mean(s['tower_dense_by_role'][k][j] for s in steps) for j in ('gemm_us','following_splitk_us')}} for k in steps[0]['tower_dense_by_role']}
result={'status':'CPU_AUDIT_COMPLETE_NO_NEW_GPU_CANDIDATE_JUSTIFIED','gpu_used':False,
        'runtime_changed':False,'service_claim':False,
        'provenance':{str(p):digest(p) for p in (TRACE,LT,MODEL,KERNELS,OLD/'experiments/native-bf16-projections.json',OLD/'native-bf16-projections-b64/timing.json',ART/'frame-pipeline-results.md')},
        'historical_trace_source_sha':'e2d5d61c7b9e6cb5524c954605f331b3860e7eca',
        'dense_contract_source_sha':lt['source_sha'],'reviewed_runtime_head':'22403f7589a1c9ca6264b003199d078c636196ed',
        'steps':steps,'tower_mean':{k:statistics.mean(s['tower_and_output'][k] for s in steps) for k in ('span_us','kernel_interval_union_us','uncovered_gap_us','kernel_duration_sum_us')},
        'tower_mean_groups':mean_groups,'tower_mean_dense_roles':mean_roles,
        'tower_ffn_whole_stage_mean_us':statistics.mean(s['tower_ffn_two_gemms_silu_two_norms_sum_us'] for s in steps),
        'logical_dense_weight_bytes':{'backbone_160_intercepted':sum(x['w'][0]*x['w'][1]*2 for x in shapes[:160]),'tower_63_intercepted':sum(x['w'][0]*x['w'][1]*2 for x in shapes[160:]),'tower_12_direct_table_mm':12*2048*2048*2},
        'lt_diagnostic':{k:lt[k] for k in ('status','all_projection_baseline_ms','selected_baseline_ms','replaced_calls','saved_ms','native_runtime_qualification')},
        'limitations':['Historical full trace is not a current production timing or service roofline.', 'Kernel duration sums overlap; only interval union and span are wall-time quantities.', 'Uncovered intervals bound visible idle gaps only; fusion could also reduce in-kernel setup/memory work.', 'Logical weight bytes are not measured DRAM traffic.', 'A large persistent rewrite is not proven impossible, but no credible >0.3ms/step implementation budget is established.']}
OUT.mkdir(exist_ok=True)
(OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n')
(OUT/'analyze.py').write_text(Path(__file__).read_text())
print(json.dumps({k:result[k] for k in ('tower_mean','tower_mean_dense_roles','tower_ffn_whole_stage_mean_us','logical_dense_weight_bytes')},indent=2))
