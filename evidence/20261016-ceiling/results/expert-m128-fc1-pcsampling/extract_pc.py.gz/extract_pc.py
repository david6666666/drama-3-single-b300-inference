"""Read one PC-sampling report on CPU; never guess address bases or fuzzy-match PCs."""
import hashlib
import json
from pathlib import Path
import re
import sys

SAMPLE_METRICS = ('smsp__pcsamp_sample_count',
                  'smsp__pcsamp_warps_issue_stalled_long_scoreboard',
                  'smsp__pcsamp_warps_issue_stalled_long_scoreboard_not_issued',
                  'smsp__pcsamp_warps_issue_stalled_selected')
STATS = ('profiler__replayer_passes', 'smsp__pcsamp_aggregated_passes',
         'smsp__pcsamp_buffer_overflow', 'smsp__pcsamp_dropped_bytes',
         'smsp__pcsamp_buffer_size_bytes', 'smsp__pcsamp_interval',
         'smsp__pcsamp_interval_cycles')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def normalize(instruction):
    # Ignore only printed address prefixes, spaces and the terminal semicolon.
    # Keep predicates, opcodes, operand modifiers, registers and immediates.
    instruction = re.sub(r'^\s*/\*[0-9a-fA-F]+\*/\s*', '', instruction)
    return re.sub(r'\s+', '', instruction).rstrip(';')


def validate_sample_data(reference, by_metric, instructions, stats,
                         minimum_total=1000, minimum_long=100):
    reasons = []
    for name in STATS:
        if name not in stats:
            reasons.append('missing_stat:' + name)
    if stats.get('profiler__replayer_passes') != 1:
        reasons.append('not_one_total_replay_pass')
    if stats.get('smsp__pcsamp_aggregated_passes') != 1:
        reasons.append('not_one_warp_sampling_pass')
    for name in ('smsp__pcsamp_buffer_overflow', 'smsp__pcsamp_dropped_bytes'):
        if stats.get(name) != 0:
            reasons.append('sample_loss_or_missing:' + name)
    if stats.get('smsp__pcsamp_interval_cycles', 0) <= 0:
        reasons.append('sampling_interval_unknown')
    known = {x['pc_offset']: x['sass'] for x in reference['instructions']}
    pcs = sorted({pc for values in by_metric.values() for pc, count in values.items() if count > 0})
    rows = []
    for pc in pcs:
        sample = {name: by_metric.get(name, {}).get(pc, 0) for name in SAMPLE_METRICS}
        reported = instructions.get(pc, '')
        expected = known.get(pc, '')
        mapped = bool(reported and expected and normalize(reported) == normalize(expected))
        if not mapped:
            reasons.append('unmapped_pc:' + hex(pc))
        if sample[SAMPLE_METRICS[1]] > sample[SAMPLE_METRICS[0]]:
            reasons.append('long_samples_exceed_total:' + hex(pc))
        rows.append({'pc': pc, 'pc_hex': hex(pc), 'samples': sample,
                     'report_sass': reported, 'frozen_sass': expected,
                     'exact_offset_and_sass_match': mapped,
                     'attribution': 'unclassified; register/source dependency review still required'})
    total = sum(by_metric.get(SAMPLE_METRICS[0], {}).values())
    long_count = sum(by_metric.get(SAMPLE_METRICS[1], {}).values())
    if total < minimum_total:
        reasons.append('insufficient_total_samples')
    if long_count < minimum_long:
        reasons.append('insufficient_long_scoreboard_samples')
    return {'status': 'PC_SAMPLING_ADEQUATE_MAPPED' if not reasons else 'INCONCLUSIVE',
            'reasons': reasons, 'total_samples': total, 'long_scoreboard_samples': long_count,
            'statistics': stats, 'pcs': sorted(rows, key=lambda row: row['samples'][SAMPLE_METRICS[1]], reverse=True),
            'no_microsecond_or_service_attribution': True}


def extract_report(path, arm, reference_path, protocol):
    sys.path.insert(0, '/opt/nvidia/nsight-compute/2026.3.0/extras/python')
    import ncu_report
    refs = json.loads(Path(reference_path).read_text())
    reference = refs[arm]
    assert sha(reference['cubin']) == reference['cubin_sha256']
    assert sha(reference['sass']) == reference['sass_sha256']
    report = ncu_report.load_report(str(path))
    actions = [report.range_by_idx(i).action_by_idx(j)
               for i in range(report.num_ranges())
               for j in range(report.range_by_idx(i).num_actions())]
    if len(actions) != 1 or actions[0].name() != reference['kernel']:
        raise RuntimeError('Expected exactly the frozen FC1 kernel record')
    action = actions[0]
    by_metric = {}
    for name in SAMPLE_METRICS:
        metric = action.metric_by_name(name)
        if metric is None or metric.num_instances() == 0 or not metric.has_correlation_ids():
            return {'status': 'INCONCLUSIVE', 'reasons': ['missing_per_pc_metric:' + name],
                    'record_count': 1, 'kernel': action.name(), 'report_sha256': sha(path)}
        ids = metric.correlation_ids()
        if ids.num_instances() != metric.num_instances():
            raise RuntimeError('PC correlation cardinality mismatch: ' + name)
        values = {}
        for index in range(metric.num_instances()):
            pc = ids.as_uint64(index)
            count = metric.as_uint64(index)
            if pc in values:
                raise RuntimeError('Duplicate PC correlation ID: ' + name)
            values[pc] = count
        by_metric[name] = values
    stats = {}
    for name in STATS:
        metric = action.metric_by_name(name)
        if metric is not None:
            stats[name] = metric.as_uint64()
    instructions = {pc: action.sass_by_pc(pc)
                    for values in by_metric.values() for pc in values}
    result = validate_sample_data(reference, by_metric, instructions, stats,
                                  protocol['adequacy']['minimum_total_samples_per_kernel'],
                                  protocol['adequacy']['minimum_long_scoreboard_samples_per_kernel'])
    for row in result['pcs']:
        info = action.source_info(row['pc'])
        row['source_info'] = None if info is None else {'file': info.file_name(), 'line': info.line()}
    result.update(record_count=1, kernel=action.name(), arm=arm, report_sha256=sha(path),
                  reference_cubin_sha256=reference['cubin_sha256'],
                  reference_sass_sha256=reference['sass_sha256'])
    return result


def cpu_test():
    ref = {'instructions': [{'pc_offset': 16, 'sass': '@P0 LDG.E R3, [R4]'}]}
    by = {name: {16: count} for name, count in zip(SAMPLE_METRICS, (1200, 200, 180, 50))}
    stats = dict(zip(STATS, (1, 1, 0, 0, 33554432, 5, 1024)))
    assert validate_sample_data(ref, by, {16: '@P0 LDG.E R3, [R4];'}, stats)['status'] == 'PC_SAMPLING_ADEQUATE_MAPPED'
    assert validate_sample_data(ref, by, {16: '@P0 LDG.E R3, [R5];'}, stats)['status'] == 'INCONCLUSIVE'
    assert validate_sample_data(ref, by, {16: ''}, stats)['status'] == 'INCONCLUSIVE'
    assert validate_sample_data(ref, by, {16: '@P0 LDG.E R3, [R4];'}, {**stats, 'smsp__pcsamp_dropped_bytes': 1})['status'] == 'INCONCLUSIVE'
    shifted = {name: {32: count[16]} for name, count in by.items()}
    assert validate_sample_data(ref, shifted, {32: '@P0 LDG.E R3, [R4];'}, stats)['status'] == 'INCONCLUSIVE'
    assert validate_sample_data(ref, by, {16: '@P0 LDG.E R3, [R4];'}, stats, minimum_total=2000)['status'] == 'INCONCLUSIVE'
    assert validate_sample_data(ref, by, {16: '@P0 LDG.E R3, [R4];'}, {**stats, 'profiler__replayer_passes': 2})['status'] == 'INCONCLUSIVE'
    return {'status': 'CPU_PC_VALIDATOR_PASS', 'checks': 7, 'gpu_used': False}


if __name__ == '__main__':
    print(json.dumps(cpu_test()))
