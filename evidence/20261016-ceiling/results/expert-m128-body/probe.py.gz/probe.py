"""Frozen artifact: global-buffer M128 FC1/native activation/M128 FC2/native finalize.
The vendor prepared full body is an independent reference. No runtime edits.
"""
import os,sys,json,subprocess,traceback,gc
from pathlib import Path
OUT=Path(__file__).resolve().parent;ROOT=OUT.parent
MODE=sys.argv[1]
os.environ.update(CUTE_DSL_ARCH='sm_103a',CUTE_DSL_KEEP='ptx,cubin',FLASHINFER_PRIMS_TS_COMPILE_OPTIONS='--opt-level 2 --gpu-arch sm_103a',CUTE_DSL_DUMP_DIR=str(OUT/('cpu-compile' if MODE=='prepare' else 'gpu-compile')))
Path(os.environ['CUTE_DSL_DUMP_DIR']).mkdir(exist_ok=True)
import body_common as c
import torch
from flashinfer.prims_ts.batched_gemm.batched_gemm_run import _compile_for_launch,_launch_arg_tuple
from flashinfer.prims_ts.batched_gemm.batched_gemm_config import make_config
from flashinfer.prims_ts.moe.tensor_adapter import build_fp8_block_scale_launch_io
from flashinfer.tllm_enums import Fp8QuantizationType,ActivationType,DtypeTrtllmGen,RoutingInputMode
import cuda.bindings.driver as drv
from types import SimpleNamespace
ORACLES=sorted((ROOT/'expert-metadata-rebase').glob('oracle-layer*.pt'))
OUTPUTS=('fc1','fc1scale','act','actscale','fc2','out')
SENTINELS=dict(fc1=173,fc1scale=-17.,act=91,actscale=-19.,fc2=7.,out=11.)
report=dict(status='PREPARING',mode=MODE,checks=[],timing_allowed=False,source_sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=c.SOURCE,text=True).strip(),source_status=subprocess.check_output(['git','status','--porcelain'],cwd=c.SOURCE,text=True),pid=os.getpid())
def flush():(OUT/('prepare.json' if MODE=='prepare' else 'result.json')).write_text(json.dumps(report,indent=2)+'\n')
def req(name,value,detail=None):
 report['checks'].append(dict(name=name,exact=bool(value),detail=detail));flush()
 if not value:raise AssertionError(name)
def chk(name,a,b):
 a=a.contiguous();b=b.contiguous();ok=a.shape==b.shape and a.dtype==b.dtype and torch.equal(a.view(torch.uint8),b.view(torch.uint8))
 report['checks'].append(dict(name=name,exact=ok,shape=list(a.shape),dtype=str(a.dtype)));flush()
 if not ok:
  torch.save(dict(actual=a.cpu(),expected=b.cpu()),OUT/(name.replace('/','_')+'-mismatch.pt'));raise AssertionError(name)
def configs():
 return {fc:make_config(**json.loads((ROOT/f'expert-m128-{fc}-expanded/prepare.json').read_text())['config']['candidate']) for fc in ('fc1','fc2')}
def reset(x):
 for name in OUTPUTS:x[name].fill_(SENTINELS[name])
def update(x,d):
 md,_=c.metadata(d)
 for key,t in md.items():x[key].copy_(t)
 x['expanded'].copy_(md['mapping'].to(torch.int32))
 for dst,src in [('q','q'),('s','input_scale'),('ids','ids'),('weights','weights')]:x[dst].copy_(d[src])
 reset(x)
def allocate(d,w,device):
 md,_=c.metadata(d);x={key:t.to(device) for key,t in md.items()}
 x.update(expanded=md['mapping'].to(device=device,dtype=torch.int32),q=d['q'].to(device),s=d['input_scale'].to(device),ids=d['ids'].to(device),weights=d['weights'].to(device),w1=w[0],s1=w[1],w2=w[2],s2=w[3])
 specs={'fc1':((c.CAP,1024),torch.uint8),'fc1scale':((8*c.CAP,),torch.float32),'act':((c.CAP,512),torch.uint8),'actscale':((4*c.CAP,),torch.float32),'fc2':((c.CAP,2048),torch.bfloat16),'out':((64,2048),torch.bfloat16)}
 for name,(shape,dtype) in specs.items():
  count=1
  for dim in shape:count*=dim
  raw=torch.full((count+128,),37,dtype=dtype,device=device);x['guard_'+name]=raw;x[name]=raw[64:-64].view(shape)
 reset(x);return x

def io_for(fc,cfg,x):
 return build_fp8_block_scale_launch_io(fc=fc,cfg=cfg,fp8_quantization_type=Fp8QuantizationType.DeepSeekFp8,hidden_states=x['q'],hidden_states_scale=x['s'],gemm1_weights=x['w1'],gemm1_weights_scale=x['s1'],gemm2_weights=x['w2'],gemm2_weights_scale=x['s2'],gemm1_output=x['fc1'],gemm1_output_scale=x['fc1scale'],activation_output=x['act'],activation_output_scale=x['actscale'],gemm2_output=x['fc2'],tile_idx=x.get('live_tile',x['tile']),mn_limit=x.get('live_mn',x['mn']),route_map=x.get('live_route',x['route']),num_non_exiting_ctas=x.get('live_ncta',x['ncta']),total_num_padded_tokens=x.get('live_padded',x['padded']),routed_token_capacity=c.CAP,activation_type=int(ActivationType.Swiglu),num_experts=256,num_tokens=64,top_k=8,intermediate_size=512,hidden_size=2048)

def compile_pair(x):
 ios={fc:io_for(fc,v,x) for fc,v in configs().items()};fns={};records={}
 dump=Path(os.environ['CUTE_DSL_DUMP_DIR'])
 for fc,io in ios.items():
  before=set(dump.glob('*.cubin'));stream=drv.CUstream(0 if MODE=='prepare' else torch.cuda.current_stream().cuda_stream)
  fns[fc]=_compile_for_launch(io,stream);after=set(dump.glob('*.cubin'));new=after-before
  # Each config has a unique typed kernel. One fresh compile directory is required.
  req(fc+'/one_new_cubin',len(new)==1);binary=new.pop();host=dump/(fc+'-host.mlir');host.write_text(str(fns[fc].ir_module))
  records[fc]=dict(cubin=str(binary),sha256=c.sha(binary),host=str(host))
 return ios,fns,records

def candidate_call(runtime,x,ios,fns):
 stream=drv.CUstream(torch.cuda.current_stream().cuda_stream)
 fns['fc1'](*_launch_arg_tuple(ios['fc1'],stream))
 runtime.moe_op.trtllm_moe_run_deepseek_fp8_activation(x['fc1'],x['fc1scale'],x['act'],x['actscale'],x.get('live_expanded',x['expanded']),x.get('live_padded',x['padded']),64,8,512,int(ActivationType.Swiglu),False)
 fns['fc2'](*_launch_arg_tuple(ios['fc2'],stream))
 runtime.moe_op.trtllm_moe_run_finalize(x['fc2'],x['out'],x['weights'],x.get('live_expanded',x['expanded']),x.get('live_padded',x['padded']),64,256,8,2048,False,False)

def native_body(runtime,x):
 from flashinfer.fused_moe import core as fi
 from flashinfer.fused_moe.shared.inputs import MoeRunnerInputs
 runner=runtime.MoERunner(runtime.moe_op,top_k=8,num_local_experts=256,dtype_act=DtypeTrtllmGen.E4m3,dtype_weights=DtypeTrtllmGen.E4m3,fp8_quantization_type=Fp8QuantizationType.DeepSeekFp8,hidden_size=2048,intermediate_size=512,num_experts=256)
 output=torch.empty((64,2048),dtype=torch.bfloat16,device='cuda')
 inp=MoeRunnerInputs(output,None,x['ids'],x['weights'],x['q'],x['s'],None,None).to_list()
 kw=dict(routing_bias=None,num_experts=256,n_group=None,topk_group=None,routed_scaling_factor=1.,routing_method_type=4,use_shuffled_weight=False,weight_layout=0,enable_pdl=True,local_expert_offset=0,do_finalize=True,routing_input_mode=RoutingInputMode.UnpackedPrecomputed,gemm1_weights=x['w1'],gemm1_weights_scale=x['s1'],gemm2_weights=x['w2'],gemm2_weights_scale=x['s2'])
 meta=fi.trtllm_moe_allocate_routing_metadata_multi_tile(x['ids'],num_experts=256,top_k=8,local_expert_offset=0,num_local_experts=256,tile_ns=[8],routing_input_mode=RoutingInputMode.UnpackedPrecomputed,topk_weights=x['weights'])
 fi.populate_trtllm_moe_routing_metadata_(meta,x['ids'],x['weights']);slot=meta.slots[0];body=SimpleNamespace(tile_n=8,tactic=5);runner=runtime.DABodyRunner(runner)
 ws=tuple(t if isinstance(t,torch.Tensor) else torch.from_dlpack(t) for t in runner.prepare_body(inp,body,slot,**kw))
 def populate():fi.populate_trtllm_moe_routing_metadata_(meta,x['ids'],x['weights'])
 def call():
  populate();runner.forward_from_metadata(inp,body,slot,ws,**kw)
 return dict(output=output,slot=slot,ws=ws,populate=populate,call=call,inputs=inp,runner=runner,meta=meta)

def check_outputs(name,x,expected):
 p=int(x['padded']);mapping=x['mapping'];valid=x['valid']
 for key,oracle,channels in [('fc1','fc1_bytes',1024),('act','activation_bytes',512),('fc2','fc2_bf16',2048)]:
  chk(name+'/'+key,x[key][mapping],expected[oracle].to('cuda'))
  chk(name+'/'+key+'_padding',x[key][~valid],torch.full_like(x[key][~valid],SENTINELS[key]))
 for key,oracle,blocks in [('fc1scale','fc1_scale',8),('actscale','activation_scale',4)]:
  active=x[key][:p*blocks].reshape(blocks,p)
  chk(name+'/'+key,active.T[mapping],expected[oracle].to('cuda'))
  chk(name+'/'+key+'_padding',active[:,~valid[:p]],torch.full_like(active[:,~valid[:p]],SENTINELS[key]))
  chk(name+'/'+key+'_tail',x[key][p*blocks:],torch.full_like(x[key][p*blocks:],SENTINELS[key]))
 for key in OUTPUTS:
  raw=x['guard_'+key];chk(name+'/'+key+'_guards',torch.cat((raw[:64],raw[-64:])),torch.full_like(raw[:128],37))

def check_native(name,native,x,d):
 slot=native['slot'];ws=native['ws'];p=int(slot.total_num_padded_tokens);mp=slot.expanded_idx_to_permuted_idx.long()
 chk(name+'/native_mapping',slot.expanded_idx_to_permuted_idx,x['expanded']);chk(name+'/native_padded',slot.total_num_padded_tokens,x['padded'])
 for key,i,ch in [('fc1_bytes',0,1024),('activation_bytes',2,512),('fc2_bf16',4,2048)]:chk(name+'/native_'+key,ws[i].reshape(-1,ch)[mp],d['intermediates'][key].to('cuda'))
 for key,i,blocks in [('fc1_scale',1,8),('activation_scale',3,4)]:chk(name+'/native_'+key,ws[i].flatten()[:p*blocks].reshape(blocks,p).T[mp],d['intermediates'][key].to('cuda'))
 chk(name+'/native_routed',native['output'],d['routed'].to('cuda'))

@torch.inference_mode()
def prepare():
 req('cuda_hidden',os.environ.get('CUDA_VISIBLE_DEVICES')=='')
 req('source_frozen',report['source_sha']=='95fcb0ef2662f2caf9bfb7fe6863dc3ad7805b1b' and report['source_status']=='')
 for fc in ('fc1','fc2'):req(fc+'/expanded_pass','EXACT_PASS' in json.loads((ROOT/f'expert-m128-{fc}-expanded/result.json').read_text())['status'])
 d=torch.load(ORACLES[0],map_location='cpu',weights_only=False);x=allocate(d,c.weights(0,'cpu',empty=True),'cpu');ios,fns,records=compile_pair(x)
 sys.path.insert(0,str(ROOT/'expert-resident-chain'));from resource_audit import audit
 report['kernels']=records;report['resources']={}
 for fc,v in records.items():
  binary=Path(v['cubin']);report['resources'][fc]=audit(binary,binary.with_suffix('.ptx'),v['host'],OUT/('resource-'+fc),cluster_size=1)
  previous=json.loads((ROOT/f'expert-m128-{fc}-expanded/prepare.json').read_text())['cpu_cubin_sha256']
  req(fc+'/merged_cubin_identical_to_component',v['sha256']==previous)
 report['coverage']=[c.metadata(torch.load(p,map_location='cpu',weights_only=False))[1] for p in ORACLES]
 req('fifteen_oracles',len(ORACLES)==15);req('cuda_uninitialized',not torch.cuda.is_initialized());report['status']='CPU_AOT_PASS';flush()

@torch.inference_mode()
def run():
 prep=json.loads((OUT/'prepare.json').read_text());req('CPU_AOT_PASS',prep['status']=='CPU_AOT_PASS')
 req('frozen_hashes',all(c.sha(k)==v for k,v in json.loads((OUT/'frozen-inputs.json').read_text()).items()))
 req('source_frozen',report['source_sha']==prep['source_sha'] and report['source_status']=='')
 req('GPU0_selected',os.environ['CUDA_VISIBLE_DEVICES']=='GPU-53ed8fd9-9f5a-9c77-430d-095ad4fc860d');report['gpu_uuid']=str(torch.cuda.get_device_properties(0).uuid)
 from flashinfer.fused_moe import core as fi
 runtime=fi.get_trtllm_moe_sm100_module();rng=torch.cuda.get_rng_state().clone();compiled=None
 for layer in (0,19,39):
  datasets=[torch.load(p,map_location='cpu',weights_only=False) for p in ORACLES if p.name.startswith(f'oracle-layer{layer}-')]
  w=c.weights(layer,'cuda');wbefore=[t.clone() for t in w];x=allocate(datasets[0],w,'cuda')
  native=native_body(runtime,x);slot=native['slot']
  for key,field in [('tile','cta_idx_xy_to_batch_idx'),('mn','cta_idx_xy_to_mn_limit'),('route','permuted_idx_to_token_idx'),('ncta','num_non_exiting_ctas'),('padded','total_num_padded_tokens'),('expanded','expanded_idx_to_permuted_idx')]:x['live_'+key]=getattr(slot,field)
  # Recreate descriptors per layer; first compilation supplies immutable binaries.
  if layer==0:
   ios,fns,records=compile_pair(x)
   for fc,v in records.items():req(fc+'/CPU_GPU_cubin_identical',v['sha256']==prep['kernels'][fc]['sha256'])
  else:
   ios={fc:io_for(fc,v,x) for fc,v in configs().items()};fns={fc:_compile_for_launch(io,drv.CUstream(torch.cuda.current_stream().cuda_stream)) for fc,io in ios.items()}
  def call():
   native['populate']();candidate_call(runtime,x,ios,fns)
  native['call']();call();torch.cuda.synchronize()
  graphs={}
  for name,fn in [('native',native['call']),('candidate',call)]:
   graph=torch.cuda.CUDAGraph()
   with torch.cuda.graph(graph):fn()
   graphs[name]=graph
  for d in datasets:
   name=f"L{layer}/{d['scenario']}";update(x,d);native['populate']();torch.cuda.synchronize()
   before={k:t.clone() for k,t in x.items() if k not in OUTPUTS and not k.startswith(('guard_','live_')) and k not in ('w1','s1','w2','s2')}
   native['call']();call();torch.cuda.synchronize();check_native(name+'/eager',native,x,d);check_outputs(name+'/eager',x,d['intermediates']);chk(name+'/eager/routed',x['out'],native['output'])
   reset(x);graphs['native'].replay();graphs['candidate'].replay();torch.cuda.synchronize();check_native(name+'/graph',native,x,d);check_outputs(name+'/graph',x,d['intermediates']);chk(name+'/graph/routed',x['out'],native['output'])
   for k,t in before.items():chk(name+'/untouched/'+k,x[k],t)
   print(name+' PASS',flush=True)
  for i,(a,b) in enumerate(zip(w,wbefore)):chk(f'L{layer}/weights_unchanged/{i}',a,b)
  chk(f'L{layer}/RNG_unchanged',torch.cuda.get_rng_state(),rng)
  del graphs,graph,native,call,ios,fns,x,w,wbefore,before;gc.collect()
 report['status']='FULL_NATIVE_M128_BODY_EXACT_PASS';flush()
try:prepare() if MODE=='prepare' else run()
except BaseException as e:report.update(status='CPU_AOT_FAIL' if MODE=='prepare' else 'EXACT_FAIL',error=repr(e),traceback=traceback.format_exc());flush();raise
finally:flush()
