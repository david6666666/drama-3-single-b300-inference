"""Artifact-only FC1 native-contract probe; never modifies installed packages."""
import sys
from pathlib import Path
CUTLASS_ROOT=Path('/home/zjy/code/hsliu/venvs/codex-drama3-vllm/lib/python3.12/site-packages/nvidia_cutlass_dsl/dsl_packages')
sys.path.insert(0,str(CUTLASS_ROOT))
import dataclasses,json,hashlib
import torch
from safetensors import safe_open
from contextlib import ExitStack
from flashinfer.prims_ts.moe.config_mapper import map_trtllm_deepseek_fp8_moe_tactic
from flashinfer.prims_ts.batched_gemm.batched_gemm_config import make_config
from flashinfer.prims_ts.batched_gemm.batched_gemm_kernel import build_batched_gemm_task_manager
from flashinfer.prims_ts.moe.tensor_adapter import build_fp8_block_scale_launch_io
from flashinfer.tllm_enums import Fp8QuantizationType,ActivationType
# Artifact-local class replacement; installed FI source is never modified.
import importlib.util
import flashinfer.prims_ts.batched_gemm.batched_gemm_kernel as _bg_kernel
_module_path=Path(__file__).resolve().parent/'gmem_c_resources_m128_body.py'
_module_name='flashinfer.prims_ts.batched_gemm.gmem_c_resources_m128_body'
_spec=importlib.util.spec_from_file_location(_module_name,_module_path)
_module=importlib.util.module_from_spec(_spec)
sys.modules[_module_name]=_module
_spec.loader.exec_module(_module)
_bg_kernel.GmemCResource=_module.GmemCResource
ROOT=Path('/home/zjy/code/hsliu/artifacts/drama3-ceiling-20261016')
OUT=Path(__file__).resolve().parent
SOURCE=ROOT/'source-metadata-rebase-95fcb0e'
ORACLE=ROOT/'expert-metadata-rebase/oracle-layer0-real.pt'
CKPT=Path('/home/zjy/.cache/huggingface/hub/models--fishaudio--drama-3/snapshots/e0a9218aa48888270f06ef1ed9ea67622c0e17d2')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def weights(layer,device,empty=False):
 if empty:return [torch.empty(sh,dtype=dt,device=device) for sh,dt in [((256,1024,2048),torch.float8_e4m3fn),((256,8,16),torch.float32),((256,2048,512),torch.float8_e4m3fn),((256,16,4),torch.float32)]]
 index=json.loads((c.CKPT/'model.safetensors.index.json').read_text())['weight_map']
 def key(e,p,s):return f'model.language_model.layers.{layer}.mlp.experts.{e}.{p}.{s}'
 keys=[key(e,p,s) for e in range(256) for p in ('up_proj','gate_proj','down_proj') for s in ('weight','weight_scale_inv')]
 with ExitStack() as stack:
  handles={f:stack.enter_context(safe_open(str(c.CKPT/f),framework='pt',device='cpu')) for f in sorted({index[k] for k in keys})}
  def t(e,p,s):k=key(e,p,s);return handles[index[k]].get_tensor(k)
  a=torch.stack([torch.cat((t(e,'up_proj','weight'),t(e,'gate_proj','weight')),0) for e in range(256)])
  sa=torch.stack([torch.cat((t(e,'up_proj','weight_scale_inv'),t(e,'gate_proj','weight_scale_inv')),0) for e in range(256)])
  b=torch.stack([t(e,'down_proj','weight') for e in range(256)]);sb=torch.stack([t(e,'down_proj','weight_scale_inv') for e in range(256)])
 return [v.to(device) for v in (a,sa,b,sb)]

def metadata(d):
 n=int(d['global_meta']['ncta']);p=int(d['global_meta']['padded']);mp=d['global_meta']['expanded'].long();ids=d['ids'].long().flatten()
 assert 0<n<=CTA and p==n*8 and len(mp)==512 and mp.unique().numel()==512 and int(mp.min())>=0 and int(mp.max())<p
 assert torch.equal(d['cta'][mp//8].long(),ids)
 tile=torch.zeros(CTA,dtype=torch.int32);tile[:n]=d['cta'];mn=torch.zeros(CTA,dtype=torch.int32);mn[:n]=d['mn']
 route=torch.zeros(CAP+1,dtype=torch.int32);route[mp]=torch.arange(512,dtype=torch.int32)//8
 valid=torch.zeros(CAP,dtype=torch.bool);valid[mp]=True
 for i in range(n):
  rows=torch.where(valid[i*8:(i+1)*8])[0]+i*8
  assert len(rows)>0 and torch.equal(rows,torch.arange(i*8,int(mn[i])))
 hist=torch.bincount(ids,minlength=256)
 return dict(tile=tile,mn=mn,route=route,ncta=torch.tensor([n],dtype=torch.int32),padded=torch.tensor([p],dtype=torch.int32),valid=valid,mapping=mp),{'name':f"L{d['layer']}/{d['scenario']}",'ncta':n,'padded':p,'inactive_experts':int((hist==0).sum()),'count_histogram':{str(i):int((hist==i).sum()) for i in hist.unique().tolist()},'max_routes':int(hist.max()),'fp32_scale_min':float(d['intermediates']['fc1_scale'].min())}

CAP=2304
CTA=288
