import os,subprocess
from pathlib import Path
r=Path('/home/zjy/code/hsliu/artifacts/drama3-ceiling-20261016')
env=dict(os.environ,CUDA_VISIBLE_DEVICES='0',OMP_NUM_THREADS='4',HF_MODULES_CACHE='/home/zjy/code/hsliu/artifacts/drama3-b300-20261014/quality-hf-modules')
for name in ['layout-control-gpu0','layout-combined-gpu0']:
 with (r/f'{name}-quality.log').open('w') as out:
  subprocess.run(['/home/zjy/code/hsliu/venvs/codex-drama3-standalone/bin/python',str(r/'source-layout/scripts/evaluate_audio.py'),'--upstream','/home/zjy/code/hsliu/drama3-sources/sglang-omni','--assets','/home/zjy/code/hsliu/artifacts/drama3-b300-20261014/quality-models.json','--corpus','/home/zjy/code/hsliu/artifacts/drama3-b300-20261014/seedtts-en1088-codes/requests.jsonl','--benchmark',str(r/name/'benchmark'),'--labels','c64-r0','--output',str(r/f'{name}-quality.json')],env=env,stdout=out,stderr=subprocess.STDOUT,check=True)
 print(name,'quality complete',flush=True)
