"""CPU-only native prompt64-aligned within-batch prefix-DAG census."""
import collections, hashlib, json, os
from pathlib import Path
import torch
from tokenizers import Tokenizer
from fish_speech.models.text2semantic.fish_omni.config import FishOmniConfig
from fish_speech.models.text2semantic.fish_omni.generate import build_drama3_prompt
r=Path('/home/zjy/code/hsliu/artifacts/drama3-ceiling-20261016')
c=Path('/home/zjy/.cache/huggingface/hub/models--fishaudio--drama-3/snapshots/e0a9218aa48888270f06ef1ed9ea67622c0e17d2')
p=Path('/home/zjy/code/hsliu/artifacts/drama3-b300-20261014/seedtts-en1088-codes/requests.jsonl')
samples=[json.loads(line) for line in p.read_bytes().splitlines()]
config=FishOmniConfig.from_dict(json.loads((c/'config.json').read_text())); tok=Tokenizer.from_file(str(c/'tokenizer.json'))
prompts=[build_drama3_prompt(s['text'],tok,config,[s['reference_text']],[torch.tensor(s['reference_codes'])]) for s in samples]
keys=[[(n,hashlib.sha256(a[:n+1].numpy().tobytes()).hexdigest()) for n in range(64,len(a)-1,64)] for a in prompts]
rows=sum(map(len,prompts)); cases=[]
for width in (2,4,6,8):
 for offset in range(width):
  groups=([list(range(offset))] if offset else [])+[list(range(i,min(i+width,len(prompts)))) for i in range(offset,len(prompts),width)]
  saved=[]; original_capacity=unique_capacity=0; hits=collections.Counter(); batch_records=[]
  for group in groups:
   seen=set();dup=0; branches=0
   for i in group:
    n=max((n for n,k in keys[i] if (n,k) in seen),default=0)
    saved.append(n);dup+=n;branches+=bool(n);hits[n]+=1;seen.update(keys[i])
   original=sum(len(prompts[i]) for i in group); oc=(original+255)//256*256; uc=(original-dup+255)//256*256
   original_capacity+=oc;unique_capacity+=uc
   batch_records.append(dict(first=group[0],requests=len(group),prompt_rows=original,duplicate_rows=dup,branches=branches,old_capacity=oc,unique_capacity=uc))
  cases.append(dict(group_size=width,offset=offset,groups=len(groups),hit_requests=sum(v>0 for v in saved),saved_rows=sum(saved),saved_fraction=sum(saved)/rows,matched_prefix_rows_histogram=dict(hits),old_rounded_capacity=original_capacity,unique_rounded_capacity=unique_capacity,rounded_capacity_saved_fraction=1-unique_capacity/original_capacity,max_branches=max(b['branches'] for b in batch_records),batch_records=batch_records if width==6 and offset==0 else None))
result=dict(source='69d636ef11875add6e4edf7c9bb028b9574143a3; unchanged fish prompt builder',cpu_only=True,cuda_initialized=torch.cuda.is_initialized(),corpus_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),requests=len(prompts),prompt_rows=rows,cases=cases,limitations=['Actual corpus prompt tensors, but synthetic FIFO groups. Existing rich timeline gives count/token totals, not request membership; this is NOT measured C64 admission reuse.','Useall11columns andn+1rows for teacherlookahead. Only64-aligned prefixes with nonempty suffix counted.','Same-batch DAG requires per-layer prefix→suffix recurrent dependency and non-square cached-prefix attention; saved rowcount does not imply proportional GEMM or service time.','Capacity rounding assumes graph support can be added for unique layout; extra branch padding/workspace unaccounted.','No model arithmetic,precision,expertcount or benchmark corpus altered.'])
(r/'prefix-intrabatch-probe.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='cases'},indent=2))
for c in cases:print({k:v for k,v in c.items() if k!='batch_records'})
