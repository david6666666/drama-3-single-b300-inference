"""Reproduce recorded CUBIN resource and SASS facts without CUDA initialization."""
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess

root=Path(__file__).resolve().parent
original=json.loads((root/'result.json').read_text())
tool=shutil.which('cuobjdump') or '/usr/local/cuda/bin/cuobjdump'
checks=[]
for entry in original['entries']:
    cubin=Path(entry['cubin'])
    assert hashlib.sha256(cubin.read_bytes()).hexdigest()==entry['cubin_sha256']
    sass=subprocess.check_output([tool,'--dump-sass',str(cubin)],text=True)
    usage=subprocess.check_output([tool,'--dump-resource-usage',str(cubin)],text=True)
    instructions=re.findall(r'\b(?:U?SETMAXN?REG)\.[^;]+',sass)
    highest=max(map(int,re.findall(r'\bR(\d+)\b',sass)),default=-1)
    assert len(instructions)==entry['sass_register_reconfiguration_count']
    assert highest==entry['max_sass_general_register_index']
    assert usage.strip()==entry['usage'].strip()
    checks.append(dict(artifact=entry['artifact'],cubin_sha256=entry['cubin_sha256'],
        register_reconfiguration_instructions=len(instructions),highest_R=highest,pass_all=True))
(root/'reproduced.json').write_text(json.dumps(dict(gpu_used=False,checks=checks),indent=2)+'\n')
print(f'{len(checks)} CUBIN SHA/resource/SASS checks passed; no GPU used')
