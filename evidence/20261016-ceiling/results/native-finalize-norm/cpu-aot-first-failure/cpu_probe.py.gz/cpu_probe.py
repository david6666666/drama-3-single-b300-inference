"""No-CUDA import, shape contracts, and offline SM103 compilation."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path

P = Path(__file__).resolve().parent
os.environ['CUDA_VISIBLE_DEVICES'] = ''
os.environ['TRITON_CACHE_DIR'] = str(P / 'triton-cache')
import torch
import triton
from triton.backends.compiler import GPUTarget
from triton.compiler import ASTSource

spec = importlib.util.spec_from_file_location('fused_finalize', P / 'fused_finalize.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
checks = []
for rows in (1, 64, 1344):
    fc2 = torch.empty((max(rows * 8, 2304), 2048), dtype=torch.bfloat16)
    mapping = torch.empty(rows * 8, dtype=torch.int32)
    probs = torch.empty((rows, 8), dtype=torch.bfloat16)
    shared = torch.empty((rows, 2048), dtype=torch.bfloat16)
    gate = torch.empty((rows, 256), dtype=torch.bfloat16)[:, :1]
    residual = torch.empty_like(shared)
    weight = torch.empty((2048,), dtype=torch.bfloat16)
    out = torch.empty_like(shared)
    args = [fc2, mapping, probs, shared, gate, residual, weight, out]
    m.validate(*args)
    checks.append(f'valid_rows{rows}')
    for index, replacement in ((1, mapping.long()), (2, probs.float()), (4, gate[:, :0]), (5, residual[:, ::2])):
        bad = args.copy(); bad[index] = replacement
        try:
            m.validate(*bad)
        except AssertionError:
            checks.append(f'invalid_rows{rows}_arg{index}')
        else:
            raise AssertionError('invalid shape/dtype was accepted')
constants = dict(GATE_STRIDE=256, FC2_STRIDE=2048, WIDTH=2048, EPS=1e-6, PDL=True)
signature = {name: '*bf16' for name in ('FC2', 'PROBS', 'SHARED', 'GATE', 'RESIDUAL', 'W', 'OUT')}
signature['MAP'] = '*i32'
compiled = triton.compile(ASTSource(m.fused_kernel, signature=signature, constexprs=constants), target=GPUTarget('cuda', 103, 32), options=dict(num_warps=4, enable_fp_fusion=False, launch_pdl=True))
(P / 'kernel.ptx').write_text(compiled.asm['ptx'])
(P / 'kernel.cubin').write_bytes(compiled.asm['cubin'])
assert 'griddepcontrol.wait' in compiled.asm['ptx']
assert 'fma.rn.bf16' in compiled.asm['ptx']
assert 'fma.rn.f32' in compiled.asm['ptx']
assert not torch.cuda.is_initialized()
report = dict(status='PASS', checks=checks, cuda_initialized=False, metadata=compiled.metadata._asdict(), kernel_sha256=hashlib.sha256(compiled.asm['cubin']).hexdigest(), source_sha256=hashlib.sha256((P/'fused_finalize.py').read_bytes()).hexdigest())
(P/'cpu-probe.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
