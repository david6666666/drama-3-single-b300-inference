"""One bounded GPU0 process; sampled ownership, own-process-group cleanup."""

import hashlib
import json
import os
import signal
import subprocess
import time
from pathlib import Path

P = Path(__file__).resolve().parent
GPU = "GPU-53ed8fd9-9f5a-9c77-430d-095ad4fc860d"
PY = "/home/zjy/code/hsliu/venvs/codex-drama3-standalone/bin/python"


def apps():
    output = subprocess.check_output(
        [
            "nvidia-smi",
            "--query-compute-apps=gpu_uuid,pid,process_name,used_gpu_memory",
            "--format=csv,noheader",
        ],
        text=True,
    )
    return [line for line in output.splitlines() if GPU in line]


def same_group(line, leader):
    try:
        return os.getpgid(int(line.split(",")[1])) == leader
    except ProcessLookupError:
        return False


def main():
    protocol = json.loads((P / "protocol.json").read_text())
    for path, digest in protocol["frozen_files"].items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == digest, path
    assert not (P / "result.json").exists(), "do not overwrite executed experiment"
    pre = apps()
    assert not pre, pre
    env = os.environ.copy()
    env.update(protocol["environment"])
    env.update(
        CUDA_VISIBLE_DEVICES=GPU,
        PYTHONUNBUFFERED="1",
        TRITON_CACHE_DIR=str(P / "triton-cache"),
    )
    command = [PY, str(P / "driver.py")]
    report = {
        "status": "PREPARING",
        "command": command,
        "gpu_uuid": GPU,
        "pre": pre,
        "audit": "2-second GPU ownership samples; not continuous exclusivity proof",
    }

    def save():
        (P / "launch-result.json").write_text(json.dumps(report, indent=2) + "\n")

    with (
        (P / "stdout.log").open("x") as log,
        (P / "process-audit.jsonl").open("x") as audit,
    ):
        child = subprocess.Popen(
            command,
            env=env,
            stdout=log,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
        report.update(status="RUNNING", pid=child.pid)
        save()
        start = time.monotonic()
        try:
            while child.poll() is None:
                rows = apps()
                elapsed = time.monotonic() - start
                audit.write(
                    json.dumps({"elapsed_seconds": elapsed, "rows": rows}) + "\n"
                )
                audit.flush()
                foreign = [line for line in rows if not same_group(line, child.pid)]
                if foreign or elapsed > 600:
                    report.update(status="STOPPED_FOREIGN_OR_TIMEOUT", foreign=foreign)
                    break
                time.sleep(2)
        except BaseException as error:
            report.update(status="LAUNCHER_ERROR", exception=repr(error))
            raise
        finally:
            # Always address only the recorded process group, even if its leader
            # exited while descendants remained. Never kill foreign GPU work.
            try:
                os.killpg(child.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            try:
                child.wait(timeout=3)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait()
            report.update(
                returncode=child.returncode, elapsed_seconds=time.monotonic() - start
            )
            for _ in range(5):
                post = apps()
                if not any(same_group(line, child.pid) for line in post):
                    break
                time.sleep(1)
            report["post"] = post
            if report["status"] == "RUNNING":
                report["status"] = "EXITED" if child.returncode == 0 else "DRIVER_FAIL"
            save()
    assert child.returncode == 0 and report["status"] == "EXITED", report


if __name__ == "__main__":
    main()
