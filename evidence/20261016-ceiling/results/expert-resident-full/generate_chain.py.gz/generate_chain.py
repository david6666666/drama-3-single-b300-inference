"""Compose preserved native stage bodies into one bounded resident kernel."""
import ast
from pathlib import Path
OUT=Path(__file__).resolve().parent
FI=Path('/home/zjy/code/hsliu/venvs/codex-drama3-standalone/lib/python3.12/site-packages/flashinfer/prims_ts/batched_gemm/batched_gemm_kernel.py')
s=FI.read_text()
def fn(name):
 n=next(x for x in ast.parse(s).body if isinstance(x,ast.FunctionDef) and x.name==name)
 start=min([n.lineno]+[x.lineno for x in n.decorator_list])
 return n,''.join(s.splitlines(True)[start-1:n.end_lineno])
def signature(n,prefix='',name=None):
 args=[]
 for a in n.args.args:
  args.append('    '+prefix+a.arg+(': '+ast.unparse(a.annotation) if a.annotation else ''))
 return args
# Second phase uses the same original stage, with explicit shared operands and
# matching AsyncThread publication pipelines. No installed class is modified.
stage=(OUT/'resident_stage.py').read_text()
stage=stage.replace('def resident_stage_body(', 'def resident_fc2_stage_body(')
stage=stage.replace('    resident_tmem_base: cutlass.Int32,\n)', '    resident_tmem_base: cutlass.Int32,\n    shared_act,\n    shared_sf,\n)')
stage=stage.replace('    pcfgs = _make_pipeline_configs(cfg)', '    pcfgs = resident_pipeline_configs(cfg, _make_pipeline_configs(cfg))')
stage=stage.replace('SmemBResource(\n', 'ResidentSmemBResource(\n            shared_act=shared_act,\n')
stage=stage.replace('SmemDeepSeekSfAbResource(\n', 'ResidentDeepSeekSfAbResource(\n            shared_sf=shared_sf,\n')
stage=stage.replace('@cute.jit\ndef resident_fc2_stage_body(', 'from resident_shared_b import ResidentSmemBResource, ResidentDeepSeekSfAbResource, resident_pipeline_configs\n\n@cute.jit\ndef resident_fc2_stage_body(')
(OUT/'resident_fc2_stage.py').write_text(stage)
# Descriptor builder is original Apache FI host body. Return its complete
# native kernel argument tuple instead of launching a separate GEMM.
hn,host=fn('gemm');host=host.replace('def gemm(', 'def resident_native_descriptors(')
call=next(x for x in ast.walk(hn) if isinstance(x,ast.Call) and isinstance(x.func,ast.Name) and x.func.id=='batched_gemm_kernel_bf16')
kn,_=fn('batched_gemm_kernel_bf16')
kargs=[ast.unparse(x) for x in call.args]
launch=host.index('    batched_gemm_kernel_bf16(\n')
host=host[:launch]+'    return (\n'+''.join('        '+x+',\n' for x in kargs)+'    )\n'
header='''# SPDX-License-Identifier: Apache-2.0
import flashinfer.prims_ts.batched_gemm.batched_gemm_kernel as _native
globals().update({k:v for k,v in vars(_native).items() if not k.startswith('__')})
'''
(OUT/'resident_descriptors.py').write_text(header+'\n'+host)
# Host signature retains explicit constexpr cfg types for both stages.
hargs=hn.args.args[:-1]
def host_args(prefix):
 return ['    '+prefix+a.arg+(': '+ast.unparse(a.annotation) if a.annotation else '') for a in hargs]
hostchain=header+'from resident_descriptors import resident_native_descriptors\nfrom resident_chain_kernel import resident_chain_kernel\n\n@cute.jit\ndef resident_chain_host(\n'+',\n'.join(host_args('')+host_args('fc2_')+['    stream'])+'\n):\n'
for p in ('','fc2_'):
 hostchain+='    '+('fc1_args' if p=='' else 'fc2_args')+' = resident_native_descriptors(\n'+''.join('        '+p+a.arg+',\n' for a in hargs)+'        stream,\n    )\n'
hostchain+='''    activation_out = cute.make_tensor(cute.recast_ptr(fc2_b_raw_ptr, dtype=cutlass.Uint8), cute.make_layout((4096,), stride=(1,)))
    activation_sf_out = cute.make_tensor(cute.recast_ptr(fc2_sfb_raw_ptr, dtype=cutlass.Float32), cute.make_layout((32,), stride=(1,)))
    resident_chain_kernel(*fc1_args, *fc2_args, activation_out, activation_sf_out).launch(
        grid=[4,1,1], block=[512,1,1], cluster=[4,1,1], stream=stream, use_pdl=False)
'''
(OUT/'resident_chain_host.py').write_text(hostchain)
# Start from already AOT-passed two-stage shared FC1 pair.
pair=(OUT/'resident_fc1_pair.py').read_text()
node=next(x for x in ast.parse(pair).body if isinstance(x,ast.FunctionDef) and x.name=='resident_fc1_pair_kernel')
body=''.join(pair.splitlines(True)[node.body[0].lineno-1:node.end_lineno])
# Keep only pre-epilogue deallocation block to move it after full FC2 drain.
start=body.index('    prims.barrier_cta_sync()\n    prims.tcgen05_fence',body.index('    # Debug boundary export'))
dealloc=body[start:];body=body[:start]
body+='''    prims.barrier_cta_sync()
    # Existing FP8 bytes and FP32 scale boundaries are consumed directly from
    # pinned shared memory, before the full activation aliases FC1 storage.
    local_act = cutlass.Array(resident_base.data_ptr()+76928,dtype=cutlass.Uint8,shape=(1024,),addrspace=3)
    local_sf = cutlass.Array(resident_base.data_ptr()+77952,dtype=cutlass.Float32,shape=(8,),addrspace=3)
    full_act = cutlass.Array(resident_base.data_ptr()+72704,dtype=cutlass.Uint8,shape=(4096,),addrspace=3)
    full_sf = cutlass.Array(resident_base.data_ptr()+76800,dtype=cutlass.Float32,shape=(32,),addrspace=3)
    x = cute.make_tensor(cute.make_ptr(cutlass.Uint8,resident_base.data_ptr()+72704,cutlass.AddressSpace.smem),cute.make_layout((8,256),stride=(256,1)))
    xs = cute.make_tensor(cute.make_ptr(cutlass.Float32,resident_base.data_ptr()+74752,cutlass.AddressSpace.smem),cute.make_layout((2,8),stride=(8,1)))
    y = cute.make_tensor(cute.make_ptr(cutlass.Uint8,resident_base.data_ptr()+76928,cutlass.AddressSpace.smem),cute.make_layout((8,128),stride=(128,1)))
    ys = cute.make_tensor(cute.make_ptr(cutlass.Float32,resident_base.data_ptr()+77952,cutlass.AddressSpace.smem),cute.make_layout((8,),stride=(1,)))
    activation_shared_8x128(x,xs,y,ys,valid_rows,tid)
    resident_dsm_gather(local_act,local_sf,full_act,full_sf,valid_rows,tid)
    # Debug activation output is never the FC2 input. Each rank publishes its
    # disjoint K128 fragment; FC2 consumes its gathered shared full activation.
    ao = cutlass.make_array_view(activation_out)
    aso = cutlass.make_array_view(activation_sf_out)
    for segment in cutlass.range_constexpr(2):
        i = tid + Int32(segment*512)
        row = i // Int32(128)
        channel = i % Int32(128)
        if row < valid_rows:
            ao.store(local_act.subview(i).load(),idx=row*Int32(512)+rank*Int32(128)+channel,vector_size=1)
    if tid < valid_rows:
        aso.store(local_sf.subview(tid).load(),idx=rank*Int32(8)+tid,vector_size=1)
    prims.barrier_cta_sync()
    for phase in cutlass.range_constexpr(4):
        resident_fc2_stage_body(
'''
body+=''.join('            fc2_'+a.arg+',\n' for a in kn.args.args)
body+='''            resident_base, phase, tmem_value, full_act, full_sf,
        )
        prims.tcgen05_fence(prims.Tcgen05Fence.BEFORE_THREAD_SYNC)
        prims.barrier_cta_sync()
'''+dealloc
kernel=header+'''from resident_stage import resident_stage_body
from resident_fc2_stage import resident_fc2_stage_body
from activation_shared_dsl import activation_shared_8x128
from resident_dsm_gather import resident_dsm_gather

@cute.kernel
def resident_chain_kernel(
'''+',\n'.join(signature(kn)+signature(kn,'fc2_')+['    activation_out: cute.Tensor','    activation_sf_out: cute.Tensor'])+'\n):\n'+body
(OUT/'resident_chain_kernel.py').write_text(kernel)
for p in ('resident_fc2_stage.py','resident_descriptors.py','resident_chain_host.py','resident_chain_kernel.py'):
 ast.parse((OUT/p).read_text())
print('GENERATED', ', '.join(('resident_fc2_stage','resident_descriptors','resident_chain_host','resident_chain_kernel')))
