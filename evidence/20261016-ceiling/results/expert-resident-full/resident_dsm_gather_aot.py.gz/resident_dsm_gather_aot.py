"""CPU-only actual 4-CTA/512-thread DSM gather with complete outer allocation."""
import os,sys,json,hashlib,traceback,re,subprocess
from pathlib import Path
OUT=Path(__file__).resolve().parent
os.environ['CUTE_DSL_ARCH']='sm_103a'
os.environ['CUTE_DSL_CACHE_DIR']=str(OUT/'dsm-gather-cache')
sys.path.insert(0,'/home/zjy/code/hsliu/venvs/codex-drama3-vllm/lib/python3.12/site-packages/nvidia_cutlass_dsl/dsl_packages')
import torch,cutlass
import cutlass.cute as cute
from cutlass import Uint8,Float32,Int32
from cutlass.cute.runtime import make_fake_tensor
import cuda.bindings.driver as cuda_drv
from resident_dsm_gather import resident_dsm_gather

class Probe:
 @cute.kernel
 def kernel(self,q:cute.Tensor,s:cute.Tensor,n:cute.Tensor,y:cute.Tensor,ys:cute.Tensor):
  base=cutlass.Array(Uint8,78080,space=cutlass.AddressSpace.smem,alignment=1024)
  tid,_,_=cute.arch.thread_idx();rank=cute.arch.block_idx_in_cluster()
  local=cutlass.Array(base.data_ptr()+76928,dtype=Uint8,shape=(1024,),addrspace=3)
  local_sf=cutlass.Array(base.data_ptr()+77952,dtype=Float32,shape=(8,),addrspace=3)
  full=cutlass.Array(base.data_ptr()+72704,dtype=Uint8,shape=(4096,),addrspace=3)
  full_sf=cutlass.Array(base.data_ptr()+76800,dtype=Float32,shape=(32,),addrspace=3)
  for i in cutlass.range_constexpr(2):
   index=tid+Int32(512*i);local.store(q[rank,index],idx=index)
  if tid<Int32(8):local_sf.store(s[rank,tid],idx=tid)
  resident_dsm_gather(local,local_sf,full,full_sf,n[0],tid)
  for i in cutlass.range_constexpr(8):
   index=tid+Int32(512*i);y[rank,index]=full.load(idx=index,vector_size=1)[0]
  if tid<Int32(32):ys[rank,tid]=full_sf.load(idx=tid,vector_size=1)[0]
 @cute.jit
 def __call__(self,q:cute.Tensor,s:cute.Tensor,n:cute.Tensor,y:cute.Tensor,ys:cute.Tensor,stream:cuda_drv.CUstream):
  self.kernel(q,s,n,y,ys).launch(grid=(4,1,1),cluster=(4,1,1),block=(512,1,1),stream=stream)

report=dict(status='PREPARING',gpu_launched=False,source_sha256=hashlib.sha256((OUT/'resident_dsm_gather.py').read_bytes()).hexdigest(),scope='Actual DSM helper at full outer78080-byte allocation/alignment; no GEMM stage or GPU execution.')
def save():(OUT/'dsm-gather-aot-result.json').write_text(json.dumps(report,indent=2)+'\n')
try:
 assert os.environ.get('CUDA_VISIBLE_DEVICES')=='' and not torch.cuda.is_initialized()
 ranges=dict(stage=(0,72704),fc1=(72704,74752),fc1_sf=(74752,74816),full=(72704,76800),full_sf=(76800,76928),local=(76928,77952),local_sf=(77952,77984),tmem_ptr=(78016,78020),outer=(0,78080))
 def overlap(a,b):return max(a[0],b[0])<min(a[1],b[1])
 for live in ('local','local_sf'):
  for forbidden in ('stage','fc1','fc1_sf','full','full_sf','tmem_ptr'):assert not overlap(ranges[live],ranges[forbidden])
 assert ranges['full'][0]%128==0 and ranges['local'][0]%128==0
 assert all(0<=a<b<=78080 for a,b in ranges.values())
 report['ranges']=ranges
 for valid_rows in range(9):
  indices=[(t//32,t%32//8,(t%8)*16,t*16) for t in range(256)]
  written=[dest+i for token,peer,src,dest in indices for i in range(16)]
  assert sorted(written)==list(range(4096))
  assert all(0<=peer<4 and 0<=token<8 and 0<=src<128 for token,peer,src,dest in indices)
  assert sum(16 for token,peer,src,dest in indices if token<valid_rows)==512*valid_rows
 report['cpu_geometry_cases']=9
 args=[make_fake_tensor(Uint8,(4,1024),(1024,1),assumed_align=16),make_fake_tensor(Float32,(4,8),(8,1),assumed_align=16),make_fake_tensor(Int32,(1,),(1,),assumed_align=4),make_fake_tensor(Uint8,(4,4096),(4096,1),assumed_align=16),make_fake_tensor(Float32,(4,32),(32,1),assumed_align=16)]
 fn=cute.compile(Probe(),*args,cuda_drv.CUstream(0),options='--gpu-arch sm_103a --opt-level 2')
 folder=OUT/'dsm-gather-aot';folder.mkdir(exist_ok=True);ir=str(fn.ir_module);(folder/'host.mlir').write_text(ir)
 match=re.search(r'@kernels_binary\("((?:[^"\\]|\\.)*)"\)',ir);assert match
 encoded=match.group(1);blob=bytearray();i=0
 while i<len(encoded):
  if encoded[i]=='\\':
   if re.fullmatch('[0-9A-Fa-f]{2}',encoded[i+1:i+3]):blob.append(int(encoded[i+1:i+3],16));i+=3
   else:blob.append(ord(encoded[i+1]));i+=2
  else:blob.append(ord(encoded[i]));i+=1
 assert blob[:4]==bytes.fromhex('50ed55ba');(folder/'kernel.fatbin').write_bytes(blob)
 for flag,name in [('--dump-resource-usage','resources.txt'),('--dump-sass','kernel.sass'),('--dump-ptx','kernel.ptx')]:
  p=subprocess.run(['/usr/local/cuda/bin/cuobjdump',flag,str(folder/'kernel.fatbin')],capture_output=True,text=True);(folder/name).write_text(p.stdout+p.stderr);assert p.returncode==0
 usage=(folder/'resources.txt').read_text();shared=int(re.search(r'\bSHARED:(\d+)',usage).group(1))
 assert 'llvm.mlir.constant(78080 : i64)' in ir
 total=shared+78080;assert total<=81920,usage
 report.update(status='CPU_AOT_PASS',cuda_initialized=torch.cuda.is_initialized(),resource_output=usage,static_smem_bytes=shared,dynamic_outer_smem_bytes=78080,total_smem_bytes=total,budget_bytes=81920,artifacts={str(p.relative_to(OUT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.iterdir()})
 assert not report['cuda_initialized']
except BaseException:
 report.update(status='CPU_AOT_FAIL',error=traceback.format_exc());save();raise
save();print(json.dumps(report,indent=2))
