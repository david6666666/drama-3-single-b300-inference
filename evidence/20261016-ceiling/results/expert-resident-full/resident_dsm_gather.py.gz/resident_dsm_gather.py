"""Artifact-only four-rank native activation gather with explicit lifetimes.

All 512 threads in all four CTAs must call, including valid_rows=0. The outer
launch is cluster=(4,1,1); native GEMM cfg.cluster_m remains1. Caller supplies
shared Arrays at identical offsets on every rank. local_act Uint8[1024] and
local_sf Float32[8] MUST NOT alias live FC1 input or full_act/full_sf; full_act
Uint8[4096], full_sf Float32[32] may reuse FC1 storage only after this helper's
opening full-CTA convergence. No allocation, async MMA, or TMEM operation.
"""
# SPDX-License-Identifier: Apache-2.0
import cutlass
import cutlass.cute as cute
from cutlass import Int32, Uint32
from cutlass.experimental import primitives as prims


@cute.jit
def resident_dsm_gather(local_act, local_sf, full_act, full_sf,
                         valid_rows: Int32, tid: Int32):
    # Every activation warp must finish reading all original FC1 bytes/scales.
    # This CTA barrier is mandatory before any aliased full-gather store,
    # even though all eight warp-local activation reductions have completed.
    prims.barrier_cta_sync()
    prims.barrier_cluster_arrive_aligned()
    prims.barrier_cluster_wait_aligned()

    full_words = cutlass.Array(full_act.data_ptr(), dtype=Uint32,
                              shape=(1024,), addrspace=3)
    full_scale_bits = cutlass.Array(full_sf.data_ptr(), dtype=Uint32,
                                   shape=(32,), addrspace=3)
    # Each of warps0..7 writes one complete token row. Four groups of8 lanes
    # read the four peers'128-channel fragments, 16 bytes per lane.
    if tid < Int32(256):
        token = tid // Int32(32)
        column_chunk = tid % Int32(32)
        peer = column_chunk // Int32(8)
        peer_chunk = column_chunk % Int32(8)
        words = cutlass.vector.full([4], 0, Uint32)
        if token < valid_rows:
            peer_pointer = prims.mapa(
                local_act.data_ptr() + token * Int32(128)
                + peer_chunk * Int32(16), peer)
            remote = cutlass.Array(peer_pointer, dtype=Uint32,
                                   shape=(4,), addrspace=7)
            words = remote.load(idx=0, vector_size=4, alignment=16)
        full_words.store(words, idx=tid * Int32(4), vector_size=4, alignment=16)
    if tid < Int32(32):
        peer = tid // Int32(8)
        token = tid % Int32(8)
        bits = Uint32(0)
        if token < valid_rows:
            peer_pointer = prims.mapa(local_sf.data_ptr() + token, peer)
            remote_scale = cutlass.Array(peer_pointer, dtype=Uint32,
                                         shape=(1,), addrspace=7)
            bits = Uint32(remote_scale.load(idx=0, vector_size=1)[0])
        full_scale_bits.store(bits, idx=tid)

    # Full-CTA completion includes every DSM reader, not only the publishing
    # warp. The second ordered cluster rendezvous keeps local fragments alive
    # until every other rank has consumed them and publishes the full arrays.
    prims.barrier_cta_sync()
    prims.barrier_cluster_arrive_aligned()
    prims.barrier_cluster_wait_aligned()
