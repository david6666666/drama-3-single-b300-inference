"""CPU-only codegen/geometry check of the two real shared-B staging bodies."""
import os,sys,json,hashlib,traceback,re,subprocess
from pathlib import Path
OUT=Path(__file__).resolve().parent
os.environ['CUTE_DSL_ARCH']='sm_103a'
os.environ['CUTE_DSL_CACHE_DIR']=str(OUT/'shared-b-cache')
sys.path.insert(0,'/home/zjy/code/hsliu/venvs/codex-drama3-vllm/lib/python3.12/site-packages/nvidia_cutlass_dsl/dsl_packages')
import torch,cutlass
import cutlass.cute as cute
from cutlass import Uint8,Float32,Int32
from cutlass.utils import SmemAllocator
from cutlass.cute.runtime import make_fake_tensor
import cuda.bindings.driver as cuda_drv
from resident_shared_b import stage_resident_b_tile,stage_resident_sf_tile,resident_pipeline_configs
from flashinfer.prims_ts.moe.config_mapper import map_trtllm_deepseek_fp8_moe_tactic
from flashinfer.prims_ts.batched_gemm.batched_gemm_config import make_config
from flashinfer.prims_ts.batched_gemm.batched_gemm_kernel import _make_pipeline_configs

class Probe:
 @cute.kernel
 def kernel(self,q:cute.Tensor,s:cute.Tensor,w:cute.Tensor,n:cute.Tensor,y:cute.Tensor,ys:cute.Tensor):
  tid,_,_=cute.arch.thread_idx();k,_,_=cute.arch.block_idx()
  allocator=SmemAllocator()
  sq=allocator.allocate_tensor(Uint8,cute.make_layout((4096,)),16)
  ss=allocator.allocate_tensor(Float32,cute.make_layout((32,)),16)
  dst=allocator.allocate_tensor(Uint8,cute.make_layout((1024,)),1024)
  dsf=allocator.allocate_tensor(Float32,cute.make_layout((33,)),16)
  for i in cutlass.range_constexpr(8):
   ix=tid+Int32(i*512);sq[ix]=q[ix]
  if tid<Int32(32):ss[tid]=s[tid]
  cute.arch.sync_threads()
  if tid<Int32(32):
   stage_resident_b_tile(cutlass.make_array_view(sq),cutlass.make_array_view(dst),k*Int32(128),n[0],tid)
   stage_resident_sf_tile(cutlass.make_array_view(ss),cutlass.make_array_view(dsf),cutlass.make_array_view(w),k,k,n[0],tid)
  cute.arch.sync_threads()
  for i in cutlass.range_constexpr(2):
   ix=tid+Int32(i*512);y[k,ix]=dst[ix]
  if tid<Int32(33):ys[k,tid]=dsf[tid]
 @cute.jit
 def __call__(self,q:cute.Tensor,s:cute.Tensor,w:cute.Tensor,n:cute.Tensor,y:cute.Tensor,ys:cute.Tensor,stream:cuda_drv.CUstream):
  self.kernel(q,s,w,n,y,ys).launch(grid=(4,1,1),block=(512,1,1),stream=stream)

report=dict(status='PREPARING',gpu_launched=False,source_sha256=hashlib.sha256((OUT/'resident_shared_b.py').read_bytes()).hexdigest(),scope='Component staging-body AOT + CPU layout/config contract; full task-pipeline composite not executed.')
def save():(OUT/'shared-b-aot-result.json').write_text(json.dumps(report,indent=2)+'\n')
try:
 assert os.environ.get('CUDA_VISIBLE_DEVICES')=='' and not torch.cuda.is_initialized()
 pair=map_trtllm_deepseek_fp8_moe_tactic((8,5),num_tokens=64,top_k=8,num_local_experts=256,enable_pdl=False,weight_layout=0)
 cfg=make_config(**{**pair.fc2.cfg.kwargs,**{x:4 for x in ('num_stages_a','num_stages_b','num_stages_smem_sfa','num_stages_smem_sfb','num_stages_tmem_sfa','num_stages_tmem_sfb')}})
 pcfg=resident_pipeline_configs(cfg,_make_pipeline_configs(cfg))
 report['resolved_contract']={k:getattr(cfg,k) for k in ('tile_n','tile_k','num_bytes_b_smem_per_stage','num_load_b_warps','load_b_warp_idx','num_load_sfab_warps','load_sfab_warp_idx','num_epilogue_warps','cluster_m')}
 report['new_pipeline_types']={k:str(pcfg[k].pipeline_type) for k in ('smem_b','smem_dsfp8_sfab')}
 destinations=[(r*128+c)^(r*16) for r in range(8) for c in range(128)]
 assert sorted(destinations)==list(range(1024))
 # Each lane owns exactly two 16-byte chunks. Channel-zero padding never
 # overlaps valid row ownership under the row-local XOR swizzle.
 by_lane=[((i//8)*128+(i%8)*16)^((i//8)*16) for i in range(64)]
 assert sorted(j+b for j in by_lane for b in range(16))==list(range(1024))
 report['cpu_geometry_cases']=9*4
 for rows in range(9):
  for k in range(4):
   valid=[(r*512+k*128+c,(r*128+c)^(r*16)) for r in range(rows) for c in range(128)]
   assert len(set(d for _,d in valid))==rows*128
   assert all(0<=src<4096 and 0<=dst<1024 for src,dst in valid)
 args=[make_fake_tensor(Uint8,(4096,),(1,),assumed_align=16),make_fake_tensor(Float32,(32,),(1,),assumed_align=16),make_fake_tensor(Float32,(4,),(1,),assumed_align=16),make_fake_tensor(Int32,(1,),(1,),assumed_align=16),make_fake_tensor(Uint8,(4,1024),(1024,1),assumed_align=16),make_fake_tensor(Float32,(4,33),(33,1),assumed_align=4)]
 fn=cute.compile(Probe(),*args,cuda_drv.CUstream(0),options='--gpu-arch sm_103a --opt-level 2')
 folder=OUT/'shared-b-aot';folder.mkdir(exist_ok=True)
 ir=str(fn.ir_module);(folder/'host.mlir').write_text(ir)
 match=re.search(r'@kernels_binary\("((?:[^"\\]|\\.)*)"\)',ir)
 assert match,'embedded fatbin not found'
 encoded=match.group(1);blob=bytearray();i=0
 while i<len(encoded):
  if encoded[i]=='\\':
   if re.fullmatch('[0-9A-Fa-f]{2}',encoded[i+1:i+3]):blob.append(int(encoded[i+1:i+3],16));i+=3
   else:blob.append(ord(encoded[i+1]));i+=2
  else:blob.append(ord(encoded[i]));i+=1
 assert blob[:4]==bytes.fromhex('50ed55ba')
 (folder/'kernel.fatbin').write_bytes(blob)
 for flag,name in [('--dump-resource-usage','resources.txt'),('--dump-sass','kernel.sass')]:
  p=subprocess.run(['/usr/local/cuda/bin/cuobjdump',flag,str(folder/'kernel.fatbin')],capture_output=True,text=True);(folder/name).write_text(p.stdout+p.stderr);assert p.returncode==0
 report.update(status='CPU_AOT_PASS',cuda_initialized=torch.cuda.is_initialized(),artifacts={str(p.relative_to(OUT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.iterdir()})
 assert not report['cuda_initialized']
except BaseException:
 report.update(status='CPU_AOT_FAIL',error=traceback.format_exc());save();raise
save();print(json.dumps(report,indent=2))
