"""Artifact-only full256 resident wrapper; fixed-address native metadata ABI."""
import json
import sys
from contextlib import ExitStack
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OVERLAY = '/home/zjy/code/hsliu/venvs/codex-drama3-vllm/lib/python3.12/site-packages/nvidia_cutlass_dsl/dsl_packages'
sys.path.insert(0, OVERLAY)
import cuda.bindings.driver as cuda_drv
import torch
import validation_contract as contract
from cutlass import cute
from cutlass.cutlass_dsl import BaseDSL
from flashinfer.prims_ts.batched_gemm.batched_gemm_config import (
    TileScheduler,
    make_config,
)
from flashinfer.prims_ts.batched_gemm.batched_gemm_run import (
    _compile_arg_tuple,
    _launch_arg_tuple,
)
from flashinfer.prims_ts.cutlass_dsl import task_scheduling_scope
from flashinfer.prims_ts.moe.config_mapper import map_trtllm_deepseek_fp8_moe_tactic
from flashinfer.prims_ts.moe.tensor_adapter import build_fp8_block_scale_launch_io
from flashinfer.tllm_enums import ActivationType, Fp8QuantizationType
from resident_chain_host import resident_chain_host
from safetensors import safe_open

CAP, CTA = contract.CAP, contract.CTA
WEIGHT_SPECS = {
    'w1': ((256, 1024, 2048), torch.float8_e4m3fn),
    'sf1': ((256, 8, 16), torch.float32),
    'w2': ((256, 2048, 512), torch.float8_e4m3fn),
    'sf2': ((256, 16, 4), torch.float32),
}


def configs():
    pair = map_trtllm_deepseek_fp8_moe_tactic(
        (8, 5), num_tokens=64, top_k=8, num_local_experts=256,
        enable_pdl=False, weight_layout=0)
    result = []
    for original in (pair.fc1.cfg.kwargs, pair.fc2.cfg.kwargs):
        values = dict(original)
        values.update({name: 4 for name in (
            'num_stages_a', 'num_stages_b', 'num_stages_smem_sfa',
            'num_stages_smem_sfb', 'num_stages_tmem_sfa', 'num_stages_tmem_sfb')})
        values.update(tile_scheduler=int(TileScheduler.STATIC),
                      use_clc_fast_drain=0, num_stages_workid=1)
        result.append((make_config(**values), values))
    return result


def load_weights(layer):
    """All original experts, original up/gate order and scale bits; CPU only."""
    index = json.loads((contract.CKPT / 'model.safetensors.index.json').read_text())['weight_map']
    def key(expert, projection, suffix):
        return f'model.language_model.layers.{layer}.mlp.experts.{expert}.{projection}.{suffix}'
    names = [key(e, projection, suffix) for e in range(256)
             for projection in ('up_proj', 'gate_proj', 'down_proj')
             for suffix in ('weight', 'weight_scale_inv')]
    with ExitStack() as stack:
        readers = {name: stack.enter_context(safe_open(
            str(contract.CKPT / name), framework='pt', device='cpu'))
            for name in sorted({index[name] for name in names})}
        def tensor(expert, projection, suffix):
            name = key(expert, projection, suffix)
            return readers[index[name]].get_tensor(name)
        return {
            'w1': torch.stack([torch.cat([tensor(e, projection, 'weight')
                for projection in ('up_proj', 'gate_proj')]) for e in range(256)]),
            'sf1': torch.stack([torch.cat([tensor(e, projection, 'weight_scale_inv')
                for projection in ('up_proj', 'gate_proj')]) for e in range(256)]),
            'w2': torch.stack([tensor(e, 'down_proj', 'weight') for e in range(256)]),
            'sf2': torch.stack([tensor(e, 'down_proj', 'weight_scale_inv') for e in range(256)]),
        }


def cpu_data():
    d = contract.load_oracle(contract.ORACLE_DIR / 'oracle-layer0-real.pt')
    metadata = contract.metadata(d)
    metadata['mapping'] = metadata['mapping'].to(torch.int32)
    # Values are never read by CPU AOT; no CUDA and no future benchmark input.
    weights = {key: torch.empty(shape, dtype=dtype)
               for key, (shape, dtype) in WEIGHT_SPECS.items()}
    return dict(q=d['q'], input_sf=d['input_scale'], ids=d['ids'],
                route_weights=d['weights'], **metadata, **weights)


def prepare(data):
    required = dict(WEIGHT_SPECS,
        q=((64, 2048), torch.float8_e4m3fn), input_sf=((16, 64), torch.float32),
        ids=((64, 8), torch.int32), route_weights=((64, 8), torch.bfloat16),
        tile=((CTA,), torch.int32), mn=((CTA,), torch.int32),
        route=((CAP + 1,), torch.int32), ncta=((1,), torch.int32),
        padded=((1,), torch.int32), mapping=((512,), torch.int32),
        valid=((CAP,), torch.bool))
    for key, (shape, dtype) in required.items():
        value = data[key]
        assert tuple(value.shape) == shape and value.dtype == dtype, key
        assert value.is_contiguous() and value.device == data['q'].device, key
    # All metadata aliases the caller payload; no host snapshot of ncta/padded.
    x = {'q': data['q'], 's': data['input_sf'], 'w1': data['w1'], 's1': data['sf1'],
         'w2': data['w2'], 's2': data['sf2']}
    x.update({key: data[key] for key in ('tile', 'mn', 'route', 'ncta', 'padded')})
    device = data['q'].device
    x.update(fc1=torch.full((CAP, 1024), 173, dtype=torch.uint8, device=device),
             fc1scale=torch.full((8 * CAP,), -17., dtype=torch.float32, device=device),
             act=torch.full((CAP, 512), 91, dtype=torch.uint8, device=device),
             actscale=torch.full((4 * CAP,), -19., dtype=torch.float32, device=device),
             fc2=torch.full((CAP, 2048), 7., dtype=torch.bfloat16, device=device))
    ios, cfgs = [], configs()
    for fc, (cfg, _) in zip(('fc1', 'fc2'), cfgs):
        ios.append(build_fp8_block_scale_launch_io(
            fc=fc, cfg=cfg, fp8_quantization_type=Fp8QuantizationType.DeepSeekFp8,
            hidden_states=x['q'], hidden_states_scale=x['s'],
            gemm1_weights=x['w1'], gemm1_weights_scale=x['s1'],
            gemm2_weights=x['w2'], gemm2_weights_scale=x['s2'],
            gemm1_output=x['fc1'], gemm1_output_scale=x['fc1scale'],
            activation_output=x['act'], activation_output_scale=x['actscale'],
            gemm2_output=x['fc2'], tile_idx=x['tile'], mn_limit=x['mn'],
            route_map=x['route'], num_non_exiting_ctas=x['ncta'],
            total_num_padded_tokens=x['padded'], routed_token_capacity=CAP,
            activation_type=int(ActivationType.Swiglu), num_experts=256,
            num_tokens=64, top_k=8, intermediate_size=512, hidden_size=2048))
    return ios, x, dict(data), cfgs


def compile_arguments(ios, stream):
    return (*_compile_arg_tuple(ios[0], stream)[:-1],
            *_compile_arg_tuple(ios[1], stream)[:-1], stream)


class ResidentFullChain:
    def __init__(self, data, debug_boundaries=True):
        assert debug_boundaries, 'First full gate requires all native boundaries'
        self.ios, self.owned_tensors, self.immutable_tensors, self.configs = prepare(data)
        self.outputs = {key: self.owned_tensors[value] for key, value in {
            'fc1_bytes': 'fc1', 'fc1_sf': 'fc1scale', 'act_bytes': 'act',
            'act_sf': 'actscale', 'fc2': 'fc2'}.items()}
        with task_scheduling_scope(), BaseDSL.enable_pyir():
            self.fn = cute.compile(resident_chain_host,
                *compile_arguments(self.ios, cuda_drv.CUstream(0)),
                options='--opt-level 2 --gpu-arch sm_103a')

    def launch(self, stream):
        handle = cuda_drv.CUstream(int(stream.cuda_stream)) if hasattr(stream, 'cuda_stream') else stream
        # Runtime native ABI omits constexpr cfg; never reuse compile arguments.
        self.fn(*_launch_arg_tuple(self.ios[0], handle)[:-1],
                *_launch_arg_tuple(self.ios[1], handle)[:-1], handle)


def build_full_chain(data, debug_boundaries=True):
    return ResidentFullChain(data, debug_boundaries)
