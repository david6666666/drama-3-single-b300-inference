from pathlib import Path
import os,json,subprocess,hashlib,sys
out=Path(__file__).resolve().parent;root=out.parent;v2=root/'expert-fc2-native-v2';source=root/'source-metadata-rebase-95fcb0e';ckpt=Path('/home/zjy/.cache/huggingface/hub/models--fishaudio--drama-3/snapshots/e0a9218aa48888270f06ef1ed9ea67622c0e17d2')
prep=json.loads((out/'prepare.json').read_text());assert prep['status']=='CPU_AOT_PASS'
gpu='GPU-40e00845-d89c-1393-2c32-a2dca3ee9442';apps=subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid,pid,process_name,used_memory','--format=csv,noheader'],text=True);assert not any(gpu in line for line in apps.splitlines()),apps
(out/'gpu-before.txt').write_text(apps+subprocess.check_output(['nvidia-smi','--query-gpu=index,uuid,utilization.gpu,memory.used','--format=csv,noheader'],text=True))
env=os.environ.copy();env.update(CUDA_VISIBLE_DEVICES=gpu,PYTHONPATH=str(source/'src'),PYTHONUNBUFFERED='1',OMP_NUM_THREADS='4',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
for k in list(env):
 if k.startswith('DRAMA3_'):del env[k]
argv=['/home/zjy/code/hsliu/venvs/codex-drama3-standalone/bin/python',str(out/'probe.py'),'run']
protocol={'hypothesis':'FC2 v2 native BF16 logical-store correction generalizes over all256experts and15archived native routing distributions, includingpartialtiles,multitileexperts,inactiveexperts,andworst288tiles; no timing or performance claim.',
 'source_sha':'95fcb0ef2662f2caf9bfb7fe6863dc3ad7805b1b','candidate_cubin_sha256':prep['cpu_cubin_sha256'],
 'fixed':{'checkpoint':'fishaudio/drama-3 e0a9218aa48888270f06ef1ed9ea67622c0e17d2','layers':[0,19,39],'topk':8,'experts':256,'mma':[64,8,32],'tile':[128,8,128],'scale_K_block':128,'input':'Archived native activation E4M3 bytes and FP32 scales; original down_proj E4M3 weights and FP32scales; noFC1oractivationcandidate,no rerouting','output':'Native BF16 [padded_rows,2048], compare expanded512rows to archivednative','staging':4,'shared_bytes':74664,'capacity':2304,'max_tiles':288,'PDL':False,'only_source_patch':'DSFP8 BF16 SMEMpair helper scatters logicalrow0 and+8 before original TMAcommit; arithmetic/conversion/barriers unchanged'},
 'real_oracle_coverage':prep['coverage'],'synthetic':[],
 'gates':['CPU/AOT CUDA-uninitialized shared<=80KiB,LOCAL/STACK0; original15metadata bijection/expert/count consistency','Frozen source,oracle,checkpoint,artifact hashes and CPU/GPU sameCUBIN','All valid512x2048BF16 values exact to archivednative percase','Padding and tail outputcapacity retain sentinel','One retained graph perlayer replays allfive changingnative metadata/activation distributions','Allinput,metadata,otheroutputs,weights andRNG unchanged'],
 'stop':'First mismatch archives actual/reference and stops; no tolerance/gate change, timing orruntimepromotion',
 'limitations':'Component arithmetic gate only; no fullMoE integration, final route reduction, resident scheduling orservice quality claimed.',
 'argv':argv,'environment':{k:env[k] for k in ('CUDA_VISIBLE_DEVICES','PYTHONPATH','OMP_NUM_THREADS')},'owner':'/root/engine_audit'}
(out/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
index=json.loads((ckpt/'model.safetensors.index.json').read_text())['weight_map'];shards={f for k,f in index.items() if any(k.startswith(f'model.language_model.layers.{layer}.mlp.experts.') for layer in (0,19,39))}
paths=[out/'probe.py',out/'launch.py',out/'protocol.json',out/'prepare.json',out/'resource-usage.txt',*list((out/'cpu-compile').glob('*')),*list((root/'expert-metadata-rebase').glob('oracle-layer*.pt')),v2/'common.py',v2/'gmem_c_resources_native_v2.py',v2/'result.json',ckpt/'model.safetensors.index.json',*[ckpt/f for f in sorted(shards)]]
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(8*1024*1024),b''):h.update(block)
 return h.hexdigest()
(out/'frozen-inputs.json').write_text(json.dumps({str(p):sha(p) for p in paths if p.is_file()},indent=2)+'\n')
with (out/'run.log').open('w') as f:
 p=subprocess.Popen(argv,env=env,stdout=f,stderr=subprocess.STDOUT);(out/'process.json').write_text(json.dumps({'pid':p.pid,'gpu_uuid':gpu,'owner':'/root/engine_audit'},indent=2)+'\n');code=p.wait()
(out/'gpu-after.txt').write_text(subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid,pid,process_name,used_memory','--format=csv,noheader'],text=True))
print(json.dumps({'exit_code':code,'log':str(out/'run.log')}));sys.exit(code)
