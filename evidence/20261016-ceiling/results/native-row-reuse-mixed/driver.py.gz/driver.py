"""Full native mixed compact/expand exact gate, then one fixed-state AB100."""
import hashlib
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys
from types import SimpleNamespace
import torch

OUT=Path(__file__).resolve().parent
ROOT=OUT.parent
sys.path[:0]=[str(ROOT/'native-row-reuse-exact-v2')]
import capture_inputs as prior
from check_mapping import build_mapping,COMPACT,FULL
sys.path[:0]=[str(prior.SOURCE/'src'),str(prior.SOURCE/'scripts')]


def exact(a,b):
    return a.shape==b.shape and a.dtype==b.dtype and torch.equal(a.contiguous().reshape(-1).view(torch.uint8),b.contiguous().reshape(-1).view(torch.uint8))


def cpu_check():
    cases=json.loads((ROOT/'native-row-reuse-exact-v2/capture-result.json').read_text())['cases']
    out=[]
    for case in cases:
        keep,inverse,n=build_mapping(case)
        assert len(keep)==COMPACT and len(inverse)==FULL
        assert int(keep.max())<FULL and int(inverse.max())<COMPACT
        out.append(dict(case=case['case'],unique=n,capacity=COMPACT))
    assert exact(torch.tensor(7),torch.tensor(7)) and not torch.cuda.is_initialized()
    return dict(status='CPU_PASS',cuda_initialized=False,cases=out,full_rows=FULL,compact_rows=COMPACT)


@torch.inference_mode()
def main():
    import torch.nn.functional as F
    import triton
    from fish_speech.models.text2semantic.fish_omni.generate import build_drama3_prompt
    from drama3.engine import BatchedPrefillGraph,DecodeGraph,state_pool_size
    from drama3.mixed_graph import MixedGraph
    from drama3.model import DramaModel
    from drama3.runtime_state import DeviceRequests
    from validate_mixed_layers import state_tensors
    report=dict(status='RUNNING',checks=[],cases=[],timings=[],pid=os.getpid(),
        source_sha=prior.SOURCE_SHA,driver_sha256=prior.sha(__file__),
        scope='Complete mixed graph including gather/expand, backbone state and teacher; no service or quality claim')
    def flush(): (OUT/'result.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    def check(name,a,b):
        ok=exact(a,b);entry=dict(name=name,byte_exact=ok,shape=list(a.shape),dtype=str(a.dtype))
        if not ok:
            if a.shape==b.shape:
                diff=a.float()-b.float();entry.update(changed=int((a!=b).sum()),max_abs=float(diff.abs().max()),rrms=float((diff.square().mean()/b.float().square().mean().clamp_min(1e-30)).sqrt()))
            path=OUT/(name.replace('/','_')+'-failure.pt');torch.save(dict(actual=a.cpu(),expected=b.cpu()),path);entry['tensors']=path.name
        report['checks'].append(entry);flush()
        if not ok:raise AssertionError(entry)
    flush()
    try:
        protocol=json.loads((OUT/'protocol.json').read_text())
        for path,digest in protocol['frozen_files'].items():assert prior.sha(path)==digest,path
        assert subprocess.check_output(['git','status','--porcelain'],cwd=prior.SOURCE,text=True)==''
        model=DramaModel(prior.CHECKPOINT,slots=state_pool_size(64),max_length=2048)
        assert model.fused_moe_residual and model.moe_shared_stream is None
        device=DeviceRequests(model.slots,model.config.eos_token_id,model.max_length)
        samples=[json.loads(x) for x in prior.CORPUS.read_bytes().splitlines()]
        prefix_rows=json.loads((ROOT/'reference-prefix/per-request.json').read_text())
        indices=sorted(set(range(56))|{i for _,group,_ in prior.CASES for i in group})
        prompts={i:build_drama3_prompt(samples[i]['text'],model.weights.tokenizer,model.config,[samples[i]['reference_text']],[torch.tensor(samples[i]['reference_codes'])]) for i in indices}
        prefill=BatchedPrefillGraph(model,8,triton.next_power_of_2(max(len(prompts[i]) for i in range(56))))
        first=DecodeGraph(model,8,first_frame=True,requests=device)
        reference_cases=json.loads((ROOT/'native-row-reuse-exact-v2/capture-result.json').read_text())['cases']
        keep_storage=torch.full((COMPACT+2,),-1,dtype=torch.int64,device='cuda')
        inverse_storage=torch.full((FULL+2,),-1,dtype=torch.int64,device='cuda')
        keep,inverse=keep_storage[1:-1],inverse_storage[1:-1]
        k,iv,_=build_mapping(reference_cases[0]);keep.copy_(k);inverse.copy_(iv)
        layer_ids={id(layer.mlp):i for i,layer in enumerate(model.backbone.layers)}
        guarded=[]
        for _ in range(40):
            compact=torch.full((COMPACT+2,2048),-71.,dtype=torch.bfloat16,device='cuda')
            slots=torch.full((COMPACT+2,),-2,dtype=torch.int64,device='cuda')
            outputs=[torch.full((FULL+2,w),-79.,dtype=torch.bfloat16,device='cuda') for w in (2048,2048,1)]
            guarded.append((compact,slots,outputs))
        original=model.moe_parts
        def candidate_parts(x,layer,decode=False,*,row_slots=None):
            assert decode and x.shape==(FULL,2048) and row_slots is not None
            buffer,slot_buffer,outputs=guarded[layer_ids[id(layer)]]
            torch.index_select(x,0,keep,out=buffer[1:-1])
            torch.index_select(row_slots,0,keep,out=slot_buffer[1:-1])
            parts=original(buffer[1:-1],layer,decode=True,row_slots=slot_buffer[1:-1])
            for part,storage in zip(parts,outputs,strict=True):torch.index_select(part,0,inverse,out=storage[1:-1])
            return tuple(storage[1:-1] for storage in outputs)
        control=MixedGraph(model,device,64,8,1536,max_length=256)
        model.moe_parts=candidate_parts
        try:candidate=MixedGraph(model,device,64,8,1536,max_length=256)
        finally:model.moe_parts=original
        report['candidate_fixed_buffer_bytes']=sum(t.numel()*t.element_size() for c,s,oo in guarded for t in (c,s,*oo))+keep_storage.numel()*8+inverse_storage.numel()*8
        report['gpu_uuid']=str(torch.cuda.get_device_properties(0).uuid)
        tensors=state_tensors(model,device)
        cases=[]
        for (name,group,slots),reference in zip(prior.CASES,reference_cases,strict=True):
            print(json.dumps(dict(stage='exact',case=name)),flush=True)
            selected=[prompts[i] for i in group]
            aliases,negatives,conditioning=prior.alias_plan(selected,group,prefix_rows)
            assert aliases==[tuple(x) for x in reference['aliases']]
            k,iv,unique=build_mapping(reference);keep.copy_(k);inverse.copy_(iv)
            for pair in model.states.values():
                for value in pair:value.zero_()
            for pair in model.kv.values():
                for value in pair:value.zero_()
            device.last.zero_();device.last[:,0]=model.config.eos_token_id;device.history.fill_(-1)
            device.metadata.zero_();device.metadata[:,0]=model.max_length-1;device.metadata[:,2]=500;device.codes.zero_()
            active=[SimpleNamespace(slot=i,position=len(prompts[i])-1) for i in range(56)]
            for i in range(56):
                prompt=prompts[i];history=F.pad(prompt[-16:,0],(max(0,16-len(prompt)),0),value=-1).cuda()
                device.initialize(i,prompt[-1].cuda(),history,len(prompt)-1,500)
            for start in range(0,56,8):
                end=min(start+8,56);hidden=prefill.run([prompts[i] for i in range(start,end)],list(range(start,end)));first.run(active[start:end],hidden)
            for graph in (control,candidate):graph.prepare(active,selected,slots)
            initial=[x.clone() for x in tensors.values()]
            rng=torch.cuda.get_rng_state().clone();cpu_rng=torch.get_rng_state().clone()
            def restore():
                for x,b in zip(tensors.values(),initial,strict=True):x.copy_(b)
            control.graph.replay();expected_outputs=tuple(x.clone() for x in control.output);expected_states=[x.clone() for x in tensors.values()]
            restore();candidate.graph.replay()
            for i,(a,b) in enumerate(zip(candidate.output,expected_outputs,strict=True)):check(f'{name}/output{i}',a,b)
            for (key,value),expected in zip(tensors.items(),expected_states,strict=True):check(f'{name}/state/{key}',value,expected)
            check(f'{name}/cuda_RNG',torch.cuda.get_rng_state(),rng);check(f'{name}/cpu_RNG',torch.get_rng_state(),cpu_rng)
            check(f'{name}/keep',keep,k.cuda());check(f'{name}/inverse',inverse,iv.cuda())
            for key,storage,fill in [('keep',keep_storage,-1),('inverse',inverse_storage,-1)]:check(f'{name}/guard/{key}',storage[[0,-1]],torch.full_like(storage[[0,-1]],fill))
            for index,(c,s,outputs) in enumerate(guarded):
                for key,storage,fill in [('compact',c,-71.),('slots',s,-2),*[(f'output{i}',x,-79.) for i,x in enumerate(outputs)]]:
                    ends=storage[[0,-1]];check(f'{name}/guard/L{index}/{key}',ends,torch.full_like(ends,fill))
            # Wholegraph equality includes nonparticipating slots; the original graph is the ownership reference.
            cases.append(dict(name=name,active=active,prompts=selected,slots=slots,keep=k.cuda(),inverse=iv.cuda(),initial=initial))
            report['cases'].append(dict(case=name,alias_count=len(aliases),unique_rows=unique,compact_rows=COMPACT,all111_states=True,all_output_rows=True,passed=True));flush()
            del expected_states,expected_outputs
        report['exact_passed']=True;flush()
        # Only after every case passes: one AB screen,100 individually restored replays per arm.
        for case in cases:
            name=case['name'];keep.copy_(case['keep']);inverse.copy_(case['inverse'])
            for graph in (control,candidate):graph.prepare(case['active'],case['prompts'],case['slots'])
            def restore_case():
                for value,initial in zip(tensors.values(),case['initial'],strict=True):value.copy_(initial)
            for graph in (control,candidate):
                for _ in range(3):restore_case();graph.graph.replay()
            measurements={}
            for arm,graph in (('control',control),('candidate',candidate)):
                events=[]
                for _ in range(100):
                    restore_case()
                    start=torch.cuda.Event(enable_timing=True);end=torch.cuda.Event(enable_timing=True)
                    start.record();graph.graph.replay();end.record();events.append((start,end))
                measurements[arm]=events
            torch.cuda.synchronize()
            values={key:[start.elapsed_time(end) for start,end in events] for key,events in measurements.items()}
            stats={key:dict(raw_ms=times,median_ms=statistics.median(times),mean_ms=statistics.mean(times),minimum_ms=min(times),maximum_ms=max(times)) for key,times in values.items()}
            improvement=1-stats['candidate']['median_ms']/stats['control']['median_ms']
            row=dict(case=name,statistics=stats,median_latency_reduction=improvement,continuation_pass=improvement>=.05)
            report['timings'].append(row);flush();print(json.dumps(dict(stage='AB100',case=name,reduction=improvement,median_ms={k:v['median_ms'] for k,v in stats.items()})),flush=True)
        report['status']='PASS';report['continuation_pass']=all(x['continuation_pass'] for x in report['timings']);report['peak_allocated_bytes']=torch.cuda.max_memory_allocated();flush()
    except Exception as error:
        report['status']='FAIL';report['failure']=dict(type=type(error).__name__,message=str(error));flush();raise


if __name__=='__main__':
    if '--cpu-check' in sys.argv:print(json.dumps(cpu_check(),indent=2))
    else:main()
