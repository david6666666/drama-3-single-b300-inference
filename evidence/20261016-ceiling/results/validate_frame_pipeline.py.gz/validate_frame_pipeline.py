"""Artifact-only exact two-frame pipeline: next backbone overlaps tower tail."""

import hashlib, json, os, statistics, subprocess, sys
from pathlib import Path
from types import SimpleNamespace

ROOT = Path("/home/zjy/code/hsliu/artifacts/drama3-ceiling-20261016")
SOURCE = ROOT / "source-moe-residual-6ff8d80"
sys.path.insert(0, str(SOURCE / "src"))
sys.path.insert(0, str(SOURCE / "scripts"))
import torch, triton
import torch.nn.functional as F
from fish_speech.models.text2semantic.fish_omni.generate import build_drama3_prompt
from validate_mixed_layers import Checks, restore, snapshot, state_tensors
from drama3.engine import BatchedPrefillGraph, DecodeGraph, state_pool_size
from drama3.model import AttentionBatch, DramaModel
from drama3.kernels import linear, sample_partitioned as sample
from drama3.runtime_state import DeviceRequests

CHECKPOINT = "/home/zjy/.cache/huggingface/hub/models--fishaudio--drama-3/snapshots/e0a9218aa48888270f06ef1ed9ea67622c0e17d2"
CORPUS = Path(
    "/home/zjy/code/hsliu/artifacts/drama3-b300-20261014/seedtts-en1088-codes/requests.jsonl"
)


def tower_prefix(model, hidden, frames, positions, slots, batch, history):
    model.sampling_step.add_(1)
    logits = linear(hidden, model.lm_head)[:, : len(model.candidates)]
    first = model.candidates[sample(logits, model.sampling_step, 0)]
    retry = model.candidates[sample(logits, model.sampling_step, 1, top_p=0.95)]
    repeated = (history == first[:, None]).any(-1) & model.tower.is_semantic(first)
    main = torch.where(repeated, retry, first)
    code = (main - model.tower.semantic_begin).clamp(0, 4095)
    semantic = model.tower.is_semantic(main)
    extra = model.tower.embedding_sum(frames, 2, 10)
    extra = torch.where(model.tower.is_semantic(frames[:, 0])[:, None], extra, 0.0)
    for index, layer in enumerate(model.tower.shared_layers):
        hidden = model.tower_layer(
            hidden,
            code,
            semantic,
            extra if index == 0 else None,
            layer,
            index,
            positions,
            slots,
            batch,
        )
    hidden = model.tower_layer(
        hidden,
        code,
        semantic,
        None,
        model.tower.residual_layers[0],
        4,
        positions,
        slots,
        batch,
    )
    code1 = sample(
        linear(hidden, model.tower.codebook_heads[0].weight), model.sampling_step, 2
    )
    return hidden, main, code, code1, semantic


def tower_tail(model, prefix, positions, slots, batch):
    hidden, main, code, code1, semantic = prefix
    codes = [code, code1]
    for index in range(1, len(model.tower.residual_layers)):
        hidden = model.tower_layer(
            hidden,
            codes[-1],
            semantic,
            None,
            model.tower.residual_layers[index],
            4 + index,
            positions,
            slots,
            batch,
        )
        codes.append(
            sample(
                linear(hidden, model.tower.codebook_heads[index].weight),
                model.sampling_step,
                index + 2,
            )
        )
    return torch.stack((main, *codes), dim=-1)


class TwoFrameGraph:
    def __init__(self, model, requests, size, pipeline):
        self.model, self.requests, self.size, self.pipeline = (
            model,
            requests,
            size,
            pipeline,
        )
        self.slots = (
            torch.arange(size, device="cuda", dtype=torch.int64) + model.slots // 2
        )
        self.positions = torch.full(
            (size,), model.max_length - 1, device="cuda", dtype=torch.int64
        )
        self.next_positions = torch.empty_like(self.positions)
        self.next_positions.copy_(self.positions)
        self.frames = torch.zeros(size, 11, device="cuda", dtype=torch.int64)
        self.frames[:, 0] = model.config.eos_token_id
        self.history = torch.full((size, 16), -1, device="cuda", dtype=torch.int64)
        self.first_batch = AttentionBatch(self.slots, self.positions, model.max_length)
        self.next_batch = AttentionBatch(
            self.slots, self.next_positions, model.max_length
        )
        self.capture_stream = torch.cuda.Stream()
        self.auxiliary = torch.cuda.Stream()
        self.graph = torch.cuda.CUDAGraph()
        self.capture_stream.wait_stream(torch.cuda.current_stream())
        with torch.cuda.stream(self.capture_stream):
            for _ in range(3):
                self.output = self.forward()
        torch.cuda.current_stream().wait_stream(self.capture_stream)
        with torch.cuda.graph(self.graph, stream=self.capture_stream):
            self.output = self.forward()

    def forward(self):
        model = self.model
        self.requests.load(
            self.slots,
            self.frames,
            self.history,
            self.positions,
            padding_start=model.slots // 2,
        )
        self.first_batch.refresh()
        hidden = model.backbone_forward(
            self.frames, self.positions, self.slots, self.first_batch
        )
        torch.add(self.positions, 1, out=self.next_positions)
        self.next_positions.clamp_(max=model.max_length - 1)
        self.next_batch.refresh()
        if self.pipeline:
            prefix = tower_prefix(
                model,
                hidden,
                self.frames,
                self.positions,
                self.slots,
                self.first_batch,
                self.history,
            )
            # Only semantic and code1 are read by embed_backbone for this checkpoint.
            blank = torch.zeros_like(prefix[1])
            partial = torch.stack(
                (prefix[1], prefix[2], prefix[3], *(blank for _ in range(8))), dim=-1
            )
            current = torch.cuda.current_stream()
            self.auxiliary.wait_stream(current)
            with torch.cuda.stream(self.auxiliary):
                hidden2 = model.backbone_forward(
                    partial, self.next_positions, self.slots, self.next_batch
                )
            frame1 = tower_tail(
                model, prefix, self.positions, self.slots, self.first_batch
            )
            self.requests.save(self.slots, frame1)
            history2 = torch.cat((self.history[:, 1:], frame1[:, :1]), dim=-1)
            current.wait_stream(self.auxiliary)
        else:
            frame1 = model.tower_forward(
                hidden,
                self.frames,
                self.positions,
                self.slots,
                self.first_batch,
                None,
                self.history,
            )
            self.requests.save(self.slots, frame1)
            history2 = torch.cat((self.history[:, 1:], frame1[:, :1]), dim=-1)
            hidden2 = model.backbone_forward(
                frame1, self.next_positions, self.slots, self.next_batch
            )
        # The tail's samples have completed before the next sampling_step increment.
        frame2 = model.tower_forward(
            hidden2,
            frame1,
            self.next_positions,
            self.slots,
            self.next_batch,
            None,
            history2,
        )
        self.requests.save(self.slots, frame2)
        return torch.stack((frame1, frame2)), hidden2


@torch.inference_mode()
def main():
    checks = Checks(
        ROOT / "frame-pipeline-validation.json",
        dict(
            source_sha=subprocess.check_output(
                ["git", "rev-parse", "HEAD"], cwd=SOURCE, text=True
            ).strip(),
            source_status=subprocess.check_output(
                ["git", "status", "--porcelain"], cwd=SOURCE, text=True
            ),
            driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            corpus_sha256=hashlib.sha256(CORPUS.read_bytes()).hexdigest(),
            gpu_uuid=str(torch.cuda.get_device_properties(0).uuid),
            environment={
                k: v for k, v in os.environ.items() if k.startswith("DRAMA3_")
            },
            experiment=json.loads(
                (ROOT / "frame-pipeline-experiment.json").read_text()
            ),
        ),
    )
    try:
        model = DramaModel(CHECKPOINT, slots=state_pool_size(64), max_length=2048)
        assert model.tower.config.vq_backbone_codebooks == 1
        assert (
            len(model.tower.shared_layers) == 4
            and len(model.tower.residual_layers) == 9
        )
        assert model.fused_moe_residual and model.moe_shared_stream is None
        device = DeviceRequests(
            model.slots, model.config.eos_token_id, model.max_length
        )
        samples = [json.loads(line) for line in CORPUS.read_bytes().splitlines()][:64]
        prompts = [
            build_drama3_prompt(
                s["text"],
                model.weights.tokenizer,
                model.config,
                [s["reference_text"]],
                [torch.tensor(s["reference_codes"])],
            )
            for s in samples
        ]
        prefill = BatchedPrefillGraph(
            model, 8, triton.next_power_of_2(max(map(len, prompts)))
        )
        first = DecodeGraph(model, 8, first_frame=True, requests=device)
        tensors = state_tensors(model, device)

        def initialize(count):
            active = [
                SimpleNamespace(slot=i, position=len(prompts[i]) - 1)
                for i in range(count)
            ]
            for i, p in enumerate(prompts[:count]):
                history = F.pad(p[-16:, 0], (max(0, 16 - len(p)), 0), value=-1).cuda()
                device.initialize(i, p[-1].cuda(), history, len(p) - 1, 500)
            for start in range(0, count, 8):
                end = min(start + 8, count)
                hidden = prefill.run(prompts[start:end], list(range(start, end)))
                first.run(active[start:end], hidden)
            return active

        def compare(label, size, count, serial, pipeline, native, max_boundary=False):
            active = initialize(count)
            slots = list(range(count)) + list(
                range(model.slots // 2 + count, model.slots // 2 + size)
            )
            for graph in (serial, pipeline, native):
                graph.slots.copy_(torch.tensor(slots, device="cuda"))
            # Exercise the append mask without excluding the row or changing sampled tokens.
            if max_boundary:
                device.metadata[0, 2].copy_(device.metadata[0, 1] + 1)
            initial = snapshot(tensors.values())
            other = torch.tensor(
                [s for s in range(model.slots) if s not in slots], device="cuda"
            )
            native.graph.replay()
            native_output = native.output.clone()
            native_state = snapshot(tensors.values())
            restore(tensors.values(), initial)
            serial.graph.replay()
            expected_output = snapshot(serial.output)
            checks.tensor(
                label + "/serial_vs_native_frames",
                serial.output[0],
                native_output,
                exact=True,
            )
            for (name, value), saved in zip(tensors.items(), native_state, strict=True):
                checks.tensor(
                    label + "/serial_vs_native_state/" + name, value, saved, exact=True
                )
            expected_state = snapshot(tensors.values())
            del native_state, native_output
            restore(tensors.values(), initial)
            pipeline.graph.replay()
            for index, (value, saved) in enumerate(
                zip(pipeline.output, expected_output, strict=True)
            ):
                checks.tensor(
                    f"{label}/pipeline_output{index}", value, saved, exact=True
                )
            for (name, value), saved, before in zip(
                tensors.items(), expected_state, initial, strict=True
            ):
                checks.tensor(
                    label + "/pipeline_state/" + name, value, saved, exact=True
                )
                if name != "sampling_step":
                    checks.tensor(
                        label + "/untouched/" + name,
                        value.index_select(0, other),
                        before.index_select(0, other),
                        exact=True,
                    )
            if max_boundary:
                if int(device.metadata[0, 3]) != 1:
                    raise AssertionError("max_frames boundary was not exercised")
            del expected_state
            restore(tensors.values(), initial)
            eager = pipeline.forward()
            for index, (value, saved) in enumerate(
                zip(eager, expected_output, strict=True)
            ):
                checks.tensor(
                    f"{label}/pipeline_eager_output{index}", value, saved, exact=True
                )
            eager_state = snapshot(tensors.values())
            restore(tensors.values(), initial)
            pipeline.graph.replay()
            for (name, value), saved in zip(tensors.items(), eager_state, strict=True):
                checks.tensor(
                    label + "/graph_vs_eager_state/" + name, value, saved, exact=True
                )
            del eager_state, expected_output
            timings = {"serial_ms": [], "pipeline_ms": []}
            for iteration in range(6):
                arms = [("serial_ms", serial), ("pipeline_ms", pipeline)]
                if iteration % 2:
                    arms.reverse()
                for name, graph in arms:
                    restore(tensors.values(), initial)
                    begin, end = (
                        torch.cuda.Event(enable_timing=True) for _ in range(2)
                    )
                    begin.record()
                    graph.graph.replay()
                    end.record()
                    end.synchronize()
                    if iteration:
                        timings[name].append(begin.elapsed_time(end))
            medians = {k: statistics.median(v) for k, v in timings.items()}
            result = dict(
                case=label,
                batch_size=size,
                actual_requests=count,
                two_frames=True,
                max_frames_boundary=max_boundary,
                timings=timings,
                median_ms=medians,
                latency_decrease_ms=medians["serial_ms"] - medians["pipeline_ms"],
                passed=True,
            )
            checks.report["cases"].append(result)
            checks.flush()
            print(json.dumps(result), flush=True)

        # All captures precede actual prompt initialization, and each case restores full state.
        serial = TwoFrameGraph(model, device, 64, False)
        pipeline = TwoFrameGraph(model, device, 64, True)
        native = DecodeGraph(model, 64, steps=2, requests=device)
        compare("b64", 64, 64, serial, pipeline, native)
        compare("partial58", 64, 58, serial, pipeline, native)
        compare(
            "b64-maxframes-boundary",
            64,
            64,
            serial,
            pipeline,
            native,
            max_boundary=True,
        )
        del serial, pipeline, native
        serial = TwoFrameGraph(model, device, 32, False)
        pipeline = TwoFrameGraph(model, device, 32, True)
        native = DecodeGraph(model, 32, steps=2, requests=device)
        compare("b32", 32, 32, serial, pipeline, native)
        checks.report["status"] = "PASS"
        checks.flush()
    except Exception as error:
        checks.report["status"] = "FAIL"
        checks.report["failure"] = dict(type=type(error).__name__, message=str(error))
        checks.flush()
        raise


if __name__ == "__main__":
    main()
