"""Build a local inverse-address-only norm clone and prove original arithmetic AST."""
import ast
import copy
import hashlib
import json
from pathlib import Path

OUT=Path(__file__).resolve().parent
ROOT=OUT.parent
SOURCE=ROOT/'source-codec-cache/src/drama3/kernels.py'
tree=ast.parse(SOURCE.read_text())
original=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='combine_experts_add_norm_kernel')
candidate=copy.deepcopy(original)
candidate.name='inverse_combine_experts_add_norm_kernel'
candidate.args.args.insert(3,ast.arg(arg='INVERSE'))
row_index=next(i for i,n in enumerate(candidate.body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='row' for t in n.targets))
candidate.body.insert(row_index+1,ast.parse('source_row = tl.load(INVERSE + row)').body[0])
class RenameRow(ast.NodeTransformer):
    def __init__(self,before,after):self.before,self.after=before,after
    def visit_Name(self,n):
        if n.id==self.before:n.id=self.after
        return n
for node in candidate.body:
    if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id in ('routed','shared','gate') for t in node.targets):
        RenameRow('row','source_row').visit(node.value)
module=ast.fix_missing_locations(ast.Module(body=[candidate],type_ignores=[]))
helper='''"""Frozen native BF16 combine/RMS arithmetic; only MoE read row is indirect.

Generated from e7cda1e kernels.py. Residual/output row and normalization axes are
unchanged. No new quantization, arithmetic reassociation or dtype boundary.
Caller owns INVERSE, per-call output storage and all input lifetimes.
"""
import triton
import triton.language as tl

'''+ast.unparse(module)+'\n\n'+'''def inverse_combine(routed, shared, gate, inverse, residual, weight, epsilon, output):
    assert routed.shape == shared.shape and routed.shape[1] == residual.shape[1] == 2048
    assert gate.shape == (len(routed), 1) and output.shape == residual.shape
    assert inverse.shape == (len(residual),) and inverse.stride(0) == 1
    inverse_combine_experts_add_norm_kernel[(len(residual),)](
        routed, shared, gate, inverse, residual, weight, output,
        gate.stride(0), epsilon, residual.shape[-1], num_warps=4,
        enable_fp_fusion=False)
    return output
'''
(OUT/'inverse_norm.py').write_text(helper)
# Remove precisely the new address indirection and recover the original kernel AST.
restored=copy.deepcopy(candidate);restored.name=original.name
restored.args.args=[a for a in restored.args.args if a.arg!='INVERSE']
restored.body=[n for n in restored.body if not (isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='source_row' for t in n.targets))]
for node in restored.body:
    if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id in ('routed','shared','gate') for t in node.targets):RenameRow('source_row','row').visit(node.value)
assert ast.dump(original,include_attributes=False)==ast.dump(restored,include_attributes=False)
prior=json.loads((ROOT/'native-row-reuse-mixed/summary.json').read_text())
budget=[]
for x in prior['timings']:
    needed=x['candidate_median_ms']-.95*x['control_median_ms']
    budget.append(dict(case=x['case'],additional_saved_ms_to_5pct=needed))
read_write_bytes=2*1600*(2048+2048+1)*2*40
result=dict(status='CPU_AST_PASS_NO_GPU_OR_AOT',native_kernel_sha256=hashlib.sha256(SOURCE.read_bytes()).hexdigest(),helper_sha256=hashlib.sha256((OUT/'inverse_norm.py').read_bytes()).hexdigest(),arithmetic_AST_identical_after_removing_only_address_indirection=True,
    arithmetic=['same BF16 sigmoid rounding','same fma.rn.bf16(shared,gate,routed)','same FP32 residual sum then BF16 round/store','same per-row WIDTH2048 sum/rsqrt and FP32 weight1+ expression','same BF16 output store, num_warps4, enable_fp_fusionFalse'],
    proposed_schedule=dict(old_index_selects=200,new_index_selects=41,removed_launches=159,unchanged_norm_kernels=40,slots_gather='Only at first layer after MixedGraph row metadata; remaining layers use same immutable row_slots'),
    removed_logical_expand_read_write_bytes=read_write_bytes,extra_inverse_read_logical_bytes=1600*8*40,
    budget_to_threshold=budget,limitations=['Logical traffic is not measured DRAM traffic and cannot directly be converted into latency.','No new latency prediction;159launches plus1.049GB adapter traffic provide a concrete candidate, not guarantee5%.','Native full mixed exact gate must pass after integration; CPU AST proof does not establish compiled equivalence.'])
(OUT/'cpu-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
