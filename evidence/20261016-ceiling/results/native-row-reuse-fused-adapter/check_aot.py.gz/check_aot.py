"""Offline SM103 compile of the original and inverse-address native arithmetic."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path

OUT = Path(__file__).resolve().parent
os.environ['CUDA_VISIBLE_DEVICES'] = ''
os.environ['TRITON_CACHE_DIR'] = str(OUT / 'triton-cache')
import torch
import triton
from triton.backends.compiler import GPUTarget
from triton.compiler import ASTSource
from inverse_norm import inverse_combine_experts_add_norm_kernel

original_path = OUT.parent / 'source-codec-cache/src/drama3/kernels.py'
spec = importlib.util.spec_from_file_location('native_row_reuse_kernels', original_path)
native = importlib.util.module_from_spec(spec)
spec.loader.exec_module(native)
results = []
for name, kernel in [('control', native.combine_experts_add_norm_kernel), ('candidate', inverse_combine_experts_add_norm_kernel)]:
    signature = {name: '*bf16' for name in ('ROUTED', 'SHARED', 'GATE', 'RESIDUAL', 'W', 'OUT')}
    if name == 'candidate':
        signature['INVERSE'] = '*i64'
    constants = {'STRIDE': 1408, 'EPS': 1e-6, 'WIDTH': 2048}
    compiled = triton.compile(ASTSource(kernel, signature=signature, constexprs=constants), target=GPUTarget('cuda', 103, 32), options={'num_warps': 4, 'enable_fp_fusion': False})
    ptx = compiled.asm['ptx']
    (OUT / f'{name}.ptx').write_text(ptx)
    (OUT / f'{name}.cubin').write_bytes(compiled.asm['cubin'])
    assert 'fma.rn.bf16' in ptx
    assert 'fma.rn.f32' not in ptx
    results.append(dict(arm=name, constants=constants, options=dict(num_warps=4, enable_fp_fusion=False), metadata=compiled.metadata._asdict(), cubin_sha256=hashlib.sha256(compiled.asm['cubin']).hexdigest(), ptx_sha256=hashlib.sha256(ptx.encode()).hexdigest()))
assert not torch.cuda.is_initialized()
result = dict(status='CPU_AOT_PASS', cuda_initialized=False, target='sm103', arms=results, limitations=['Offline resources do not establish byte equality. The full mixed three-case gate remains required.', 'No GPU or timing executed by this script.'])
(OUT / 'cpu-aot.json').write_text(json.dumps(result, indent=2, default=str) + '\n')
print(json.dumps(result, indent=2, default=str))
