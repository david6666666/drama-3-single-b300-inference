import ctypes as C
import hashlib
import json
import subprocess
from pathlib import Path
from lt_binding import Algo, Heuristic, layout_spec, check_family
p=Path(__file__).parent
abi=json.loads(subprocess.check_output([str(p/'abi_probe')],text=True))
expected=dict(algo_size=C.sizeof(Algo),heuristic_size=C.sizeof(Heuristic),workspace_offset=Heuristic.workspaceSize.offset,state_offset=Heuristic.state.offset,waves_offset=Heuristic.wavesCount.offset,compute32=68,bf16=14,reduction_mask_attr=3,compute_reduction=2,numerical_flags_attr=15)
assert abi==expected,(abi,expected)
checks=[]
for m,n,k,stride in [(64,12352,2048,2048),(64,2048,4096,4096),(64,1408,2048,2064),(1,8,8,16)]:
    spec=layout_spec(m,n,k,stride)
    for i,j,q in [(0,0,0),(m-1,n-1,k-1),(m//2,n//2,k//2)]:
        # Column-major op(A)[j,q] -> W[j,q]; op(B)[q,i] -> X[i,q].
        assert q+j*spec['a'][2] == j*k+q
        assert q+i*spec['b'][2] == i*stride+q
        assert j+i*spec['d'][2] == i*n+j
    checks.append(dict(shape=[m,n,k,stride],address_pass=True))
for shape in [(0,8,8,8),(64,8,16,8),(-1,8,8,8)]:
    try: layout_spec(*shape)
    except ValueError: pass
    else: raise AssertionError(shape)
family_checks=[]
for flags in [0x020202,0x010202,0x040202,0x020102,0x400202]:
    for split,reduction in [(1,0),(4,2),(4,1),(4,4),(1,2),(4,0)]:
        meta=dict(numerical_flags=flags,split_k=split,reduction=reduction)
        result=check_family(meta)
        expected_family=('non_split' if split==1 and reduction==0 else 'fp32_split' if split>1 and reduction==2 else None) if flags==0x020202 else None
        assert result==expected_family,(meta,result,expected_family)
        family_checks.append(dict(**meta,result=result))
r=dict(status='CPU_ABI_LAYOUT_FAMILY_PASS',gpu_initialized=False,abi=abi,layout_checks=checks,invalid_shapes_rejected=3,family_checks=family_checks,source_hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in p.glob('*.py')})
(p/'cpu-check.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(dict(status=r['status'],layout_cases=len(checks),family_cases=len(family_checks))))
