#include <cublasLt.h>
#include <cstddef>
#include <iostream>
int main() {
  std::cout << "{\"algo_size\":" << sizeof(cublasLtMatmulAlgo_t)
    << ",\"heuristic_size\":" << sizeof(cublasLtMatmulHeuristicResult_t)
    << ",\"workspace_offset\":" << offsetof(cublasLtMatmulHeuristicResult_t, workspaceSize)
    << ",\"state_offset\":" << offsetof(cublasLtMatmulHeuristicResult_t, state)
    << ",\"waves_offset\":" << offsetof(cublasLtMatmulHeuristicResult_t, wavesCount)
    << ",\"compute32\":" << CUBLAS_COMPUTE_32F
    << ",\"bf16\":" << CUDA_R_16BF
    << ",\"reduction_mask_attr\":" << CUBLASLT_MATMUL_PREF_REDUCTION_SCHEME_MASK
    << ",\"compute_reduction\":" << CUBLASLT_REDUCTION_SCHEME_COMPUTE_TYPE
    << ",\"numerical_flags_attr\":" << CUBLASLT_ALGO_CAP_NUMERICAL_IMPL_FLAGS
    << "}\n";
}
