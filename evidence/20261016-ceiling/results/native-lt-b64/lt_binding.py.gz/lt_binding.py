"""Artifact-only BF16 -> FP32 accumulate -> BF16 cuBLASLt plans.

No autotuning or fallback changes in the runtime. Only two bounded families:
non-split and FP32 workspace reduction split-K. This module imports no torch.
"""
import ctypes as C
from dataclasses import dataclass
from pathlib import Path

VENV = Path('/home/zjy/code/hsliu/venvs/codex-drama3-standalone')
LIBPATH = VENV / 'lib/python3.12/site-packages/nvidia/cu13/lib/libcublasLt.so.13'
P, I, Z = C.c_void_p, C.c_int, C.c_size_t

class Algo(C.Structure):
    _fields_ = [('data', C.c_uint64 * 8)]

class Heuristic(C.Structure):
    _fields_ = [('algo', Algo), ('workspaceSize', Z), ('state', I),
                ('wavesCount', C.c_float), ('reserved', I * 4)]


def layout_spec(m, n, k, stride_x):
    # Row-major X[M,K] and W[N,K]: D^T[N,M] = W[N,K] * X^T[K,M].
    # W's memory is column-major [K,N], so transpose A; B is [K,M].
    if min(m, n, k) <= 0 or stride_x < k:
        raise ValueError('invalid projection shape/stride')
    return dict(a=(k, n, k), b=(k, m, stride_x), d=(n, m, n), transa=1, transb=0)


def check_family(meta):
    # Fixed bitmasks from the installed CUDA13 headers: BF16 input, FP32 accumulator.
    flags = meta['numerical_flags']
    if flags & 0xFF00 != 0x0200 or flags & 0xFF0000 != 0x020000:
        return None
    if meta['split_k'] <= 1 and meta['reduction'] == 0:
        return 'non_split'
    if meta['split_k'] > 1 and meta['reduction'] == 2:
        return 'fp32_split'
    return None


class Lt:
    def __init__(self):
        self.lib = C.CDLL(str(LIBPATH))
        signatures = {
            'cublasLtCreate': [C.POINTER(P)], 'cublasLtDestroy': [P],
            'cublasLtMatmulDescCreate': [C.POINTER(P), I, I],
            'cublasLtMatmulDescDestroy': [P],
            'cublasLtMatmulDescSetAttribute': [P, I, P, Z],
            'cublasLtMatrixLayoutCreate': [C.POINTER(P), I, C.c_uint64, C.c_uint64, C.c_int64],
            'cublasLtMatrixLayoutDestroy': [P],
            'cublasLtMatmulPreferenceCreate': [C.POINTER(P)],
            'cublasLtMatmulPreferenceDestroy': [P],
            'cublasLtMatmulPreferenceSetAttribute': [P, I, P, Z],
            'cublasLtMatmulAlgoGetHeuristic': [P, P, P, P, P, P, P, I, C.POINTER(Heuristic), C.POINTER(I)],
            'cublasLtMatmulAlgoConfigGetAttribute': [C.POINTER(Algo), I, P, Z, C.POINTER(Z)],
            'cublasLtMatmulAlgoCapGetAttribute': [C.POINTER(Algo), I, P, Z, C.POINTER(Z)],
            'cublasLtMatmul': [P, P, P, P, P, P, P, P, P, P, P, P, C.POINTER(Algo), P, Z, P],
        }
        for name, signature in signatures.items():
            fn = getattr(self.lib, name); fn.argtypes = signature; fn.restype = I
        self.handle = P()
        self.call('cublasLtCreate', C.byref(self.handle))
        self.closed = False

    def call(self, name, *args):
        status = getattr(self.lib, name)(*args)
        if status != 0:
            raise RuntimeError(f'{name}: cuBLAS status {status}')

    def close(self):
        if not self.closed:
            self.call('cublasLtDestroy', self.handle); self.closed = True

    def attribute(self, algo, attribute, cap=False, dtype=I):
        result, written = dtype(), Z()
        self.call('cublasLtMatmulAlgoCapGetAttribute' if cap else 'cublasLtMatmulAlgoConfigGetAttribute',
                  C.byref(algo), attribute, C.byref(result), C.sizeof(result), C.byref(written))
        if written.value != C.sizeof(result):
            raise RuntimeError('attribute size mismatch')
        return result.value

    def metadata(self, h):
        return dict(algo_id=self.attribute(h.algo, 0), tile_id=self.attribute(h.algo, 1),
                    split_k=self.attribute(h.algo, 2), reduction=self.attribute(h.algo, 3),
                    stages_id=self.attribute(h.algo, 6),
                    numerical_flags=self.attribute(h.algo, 15, True, C.c_uint64),
                    workspace_bytes=h.workspaceSize, waves=h.wavesCount,
                    algo_bytes=bytes(h.algo).hex())


class Plan:
    def __init__(self, lt, m, n, k, stride_x, workspace_bytes=32 << 20):
        self.lt, self.shape = lt, (m, n, k, stride_x)
        self.spec = layout_spec(m, n, k, stride_x)
        self.desc, self.pref = P(), P()
        self.layouts = []
        # CUDA_R_16BF=14, CUDA_R_32F=0; CUBLAS_COMPUTE_32F=68.
        lt.call('cublasLtMatmulDescCreate', C.byref(self.desc), 68, 0)
        trans = I(1)
        lt.call('cublasLtMatmulDescSetAttribute', self.desc, 3, C.byref(trans), C.sizeof(trans))
        for key in ('a', 'b', 'd'):
            ptr = P(); lt.call('cublasLtMatrixLayoutCreate', C.byref(ptr), 14, *self.spec[key])
            self.layouts.append(ptr)
        lt.call('cublasLtMatmulPreferenceCreate', C.byref(self.pref))
        for key, value in [(1, Z(workspace_bytes)), (3, C.c_uint32(2))]:
            lt.call('cublasLtMatmulPreferenceSetAttribute', self.pref, key, C.byref(value), C.sizeof(value))
        # Torch allocations and row strides must provide >=16-byte alignment.
        for key in (5, 6, 7, 8):
            value = C.c_uint32(16)
            lt.call('cublasLtMatmulPreferenceSetAttribute', self.pref, key, C.byref(value), C.sizeof(value))
        self.alpha, self.beta = C.c_float(1), C.c_float(0)
        self.closed = False

    def heuristics(self):
        # Inspect at most16, execute only the first supported result per family.
        results, returned = (Heuristic * 16)(), I()
        a, b, d = self.layouts
        self.lt.call('cublasLtMatmulAlgoGetHeuristic', self.lt.handle, self.desc,
                     a, b, d, d, self.pref, 16, results, C.byref(returned))
        selected, examined = {}, []
        for h in results[:returned.value]:
            if h.state != 0:
                examined.append(dict(status=h.state)); continue
            meta = self.lt.metadata(h); family = check_family(meta)
            meta['family'] = family; examined.append(meta)
            if family and family not in selected:
                selected[family] = (Algo.from_buffer_copy(h.algo), meta)
        return selected, examined

    def run(self, algo, x, weight, out, workspace, stream):
        # Keep all tensors, descriptor, algorithm and workspace alive through replay.
        m, n, k, stride_x = self.shape
        if (tuple(x.shape), tuple(weight.shape), tuple(out.shape)) != ((m, k), (n, k), (m, n)):
            raise ValueError('shape mismatch')
        if x.stride() != (stride_x, 1) or weight.stride() != (k, 1) or out.stride() != (n, 1):
            raise ValueError('stride mismatch')
        if any(str(t.dtype) != 'torch.bfloat16' or not t.is_cuda for t in (x, weight, out)):
            raise ValueError('native CUDA BF16 required')
        if any(t.device != x.device for t in (weight, out, workspace)):
            raise ValueError('device mismatch')
        if any(t.data_ptr() % 16 for t in (x, weight, out, workspace)):
            raise ValueError('pointer alignment')
        if stride_x * 2 % 16 or k * 2 % 16 or n * 2 % 16:
            raise ValueError('stride alignment')
        a, b, d = self.layouts
        self.lt.call('cublasLtMatmul', self.lt.handle, self.desc, C.byref(self.alpha),
                     P(weight.data_ptr()), a, P(x.data_ptr()), b, C.byref(self.beta),
                     P(out.data_ptr()), d, P(out.data_ptr()), d, C.byref(algo),
                     P(workspace.data_ptr()), workspace.numel() * workspace.element_size(), P(stream))
        return out

    def close(self):
        if self.closed: return
        for layout in self.layouts: self.lt.call('cublasLtMatrixLayoutDestroy', layout)
        self.lt.call('cublasLtMatmulPreferenceDestroy', self.pref)
        self.lt.call('cublasLtMatmulDescDestroy', self.desc)
        self.closed = True
