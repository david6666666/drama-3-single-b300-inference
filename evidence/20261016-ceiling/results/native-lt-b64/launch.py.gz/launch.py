"""One-process bounded GPU0 feasibility with owner and source checks."""
import hashlib,json,os,signal,subprocess,time
from pathlib import Path
P=Path(__file__).parent
GPU='GPU-53ed8fd9-9f5a-9c77-430d-095ad4fc860d'
PY='/home/zjy/code/hsliu/venvs/codex-drama3-standalone/bin/python'
def apps():
    r=subprocess.run(['nvidia-smi','--query-compute-apps=gpu_uuid,pid,process_name,used_gpu_memory','--format=csv,noheader'],capture_output=True,text=True,check=True)
    return [line for line in r.stdout.splitlines() if GPU in line]
def main():
    protocol=json.loads((P/'protocol.json').read_text())
    for path,digest in protocol['frozen_files'].items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest,path
    assert not (P/'result.json').exists(),'do not overwrite an executed experiment'
    assert not apps(),'GPU0 occupied'
    env=os.environ.copy();env.update(protocol['environment'])
    env.update(CUDA_VISIBLE_DEVICES=GPU,PYTHONUNBUFFERED='1')
    command=[PY,str(P/'driver.py')]
    report=dict(status='PREPARING',command=command,gpu_uuid=GPU,process_audit='2-second samples; not continuous exclusivity proof')
    def save():(P/'launch-result.json').write_text(json.dumps(report,indent=2)+'\n')
    with (P/'stdout.log').open('x') as log,(P/'process-audit.jsonl').open('x') as audit:
        child=subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        report.update(status='RUNNING',pid=child.pid);save();start=time.monotonic()
        try:
            while child.poll() is None:
                rows=apps();elapsed=time.monotonic()-start
                audit.write(json.dumps(dict(elapsed_seconds=elapsed,rows=rows))+'\n');audit.flush()
                foreign=[line for line in rows if int(line.split(',')[1])!=child.pid]
                if foreign or elapsed>600:
                    report.update(status='STOPPED_FOREIGN_OR_TIMEOUT',foreign=foreign)
                    os.killpg(child.pid,signal.SIGKILL);child.wait();break
                time.sleep(2)
            report.update(returncode=child.returncode,elapsed_seconds=time.monotonic()-start)
            if report['status']=='RUNNING':report['status']='EXITED'
        finally:
            if child.poll() is None:os.killpg(child.pid,signal.SIGKILL);child.wait()
            report['post_gpu']=apps();save()
    assert child.returncode==0,report
if __name__=='__main__':main()
