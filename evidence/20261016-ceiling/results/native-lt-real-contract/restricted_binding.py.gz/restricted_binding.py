"""Two exact serialized descriptors for a numerical diagnostic, NOT qualification.

INPUT16F capability semantics remains unresolved. No generic filter is changed.
The descriptor's BF16/FP32 API contract and separately validated range tests
allow only this diagnostic to establish real-input behavior and budget.
"""
import ctypes as C
import json,sys
from pathlib import Path
P=Path(__file__).parent
sys.path.insert(0,str(P.parent/'native-lt-b64'))
from lt_binding import Lt,Plan as BasePlan,Algo,LIBPATH

OLD=json.loads((P.parent/'native-lt-b64/result.json').read_text())
APPROVED={tuple(s['shape']):s['heuristics'][0] for s in OLD['shapes']}

def attribute(lib,name,obj,attr):
    fn=getattr(lib,name);fn.argtypes=[C.c_void_p,C.c_int,C.c_void_p,C.c_size_t,C.POINTER(C.c_size_t)];fn.restype=C.c_int
    v,n=C.c_int(),C.c_size_t();status=fn(obj,attr,C.byref(v),C.sizeof(v),C.byref(n))
    if status!=0 or n.value!=C.sizeof(v):raise RuntimeError((name,status,n.value))
    return v.value

class Plan(BasePlan):
    def heuristics(self):
        r=json.loads((P.parent/'native-lt-dtype-contract/result.json').read_text())
        if r['status']!='BF16_DESCRIPTOR_AND_RANGE_DIAGNOSTIC_PASS' or len(r['tests'])!=8:raise RuntimeError('missing separate range diagnostic')
        h=APPROVED[self.shape]
        if h['numerical_flags']!=66050 or h['algo_id']!=66:raise RuntimeError('unreviewed algorithm')
        # Source/ABI/library hashes are frozen externally; all actual descriptor
        # data types are independently queried, not inferred from Python tensors.
        actual=[attribute(self.lt.lib,'cublasLtMatmulDescGetAttribute',self.desc,0),attribute(self.lt.lib,'cublasLtMatmulDescGetAttribute',self.desc,1)]
        actual += [attribute(self.lt.lib,'cublasLtMatrixLayoutGetAttribute',d,0) for d in self.layouts]
        if actual!=[68,0,14,14,14]:raise RuntimeError(('descriptor changed',actual))
        algo=Algo.from_buffer_copy(bytes.fromhex(h['algo_bytes']))
        if self.lt.attribute(algo,15,True,C.c_uint64)!=66050:raise RuntimeError('capability changed')
        family='non_split' if h['split_k']==1 and h['reduction']==0 else 'fp32_split' if h['split_k']>1 and h['reduction']==2 else None
        if family is None:raise RuntimeError('unreviewed reduction')
        h=dict(h,descriptor_getters=actual,capability_qualification=False,family=family)
        return {family:(algo,h)},[h]
