"""One bounded B64 feasibility: at most two shapes, one Lt result/family.

Projection-only budgets; never described as service throughput. Original exact
failures are recorded even when independently identified as reduction rounding.
"""
import hashlib
import json
import os
import time
from collections import Counter, defaultdict
from pathlib import Path
from types import SimpleNamespace

import torch
import torch.nn.functional as F
import triton
from fish_speech.models.text2semantic.fish_omni.generate import build_drama3_prompt
from drama3.engine import BatchedPrefillGraph, DecodeGraph, state_pool_size
from drama3.model import DramaModel
from drama3.runtime_state import DeviceRequests
from restricted_binding import Lt, Plan

P=Path(__file__).parent
CKPT='/home/zjy/.cache/huggingface/hub/models--fishaudio--drama-3/snapshots/e0a9218aa48888270f06ef1ed9ea67622c0e17d2'
CORPUS=Path('/home/zjy/code/hsliu/artifacts/drama3-b300-20261014/seedtts-en1088-codes/requests.jsonl')
result=dict(capability_semantics='UNRESOLVED_INPUT16F_FLAG; descriptor-bound numerical diagnostic only', native_runtime_qualification=False, status='PREPARING',gpu=0,source_sha='e7cda1eba083603b88e1f2e89688e1ff2ced7fc2',timing_scope='projection sequence only; input projections retained in model-call order',rounds=1,service_claim=False)
def save():
    (P/'result.json').write_text(json.dumps(result,indent=2)+'\n')
def timed_graph(fn, count=100):
    stream=torch.cuda.Stream()
    stream.wait_stream(torch.cuda.current_stream())
    with torch.cuda.stream(stream):
        for _ in range(3): fn()
    stream.synchronize()
    graph=torch.cuda.CUDAGraph()
    with torch.cuda.graph(graph,stream=stream): fn()
    for _ in range(3): graph.replay()
    a,b=torch.cuda.Event(enable_timing=True),torch.cuda.Event(enable_timing=True)
    a.record()
    for _ in range(count): graph.replay()
    b.record();b.synchronize()
    return a.elapsed_time(b)/count

def fingerprint(t):
    return hashlib.sha256(t.detach().contiguous().view(torch.uint8).cpu().numpy().tobytes()).hexdigest()

@torch.inference_mode()
def main():
    import drama3.model as model_module
    started=time.monotonic()
    result['baseline_backend_flags']=dict(torch_version=torch.__version__,cuda_build=torch.version.cuda,allow_bf16_reduced_precision_reduction=torch.backends.cuda.matmul.allow_bf16_reduced_precision_reduction,allow_fp16_reduced_precision_reduction=torch.backends.cuda.matmul.allow_fp16_reduced_precision_reduction,allow_tf32=torch.backends.cuda.matmul.allow_tf32,preferred_blas_library=str(torch.backends.cuda.preferred_blas_library()))
    save()
    model=DramaModel(CKPT,slots=state_pool_size(64),max_length=2048)
    samples=[json.loads(s) for s in CORPUS.read_text().splitlines()][:64]
    prompts=[build_drama3_prompt(s['text'],model.weights.tokenizer,model.config,[s['reference_text']],[torch.tensor(s['reference_codes'])]) for s in samples]
    device=DeviceRequests(model.slots,model.config.eos_token_id,model.max_length)
    requests=[SimpleNamespace(slot=i,position=len(p)-1) for i,p in enumerate(prompts)]
    captured=[];native_linear=model_module.linear
    def capture_linear(x,w):
        if torch.cuda.is_current_stream_capturing(): captured.append((x,w))
        return native_linear(x,w)
    model_module.linear=capture_linear
    try: graph=DecodeGraph(model,64,requests=device)
    finally: model_module.linear=native_linear
    assert captured and all(len(x)==64 for x,_ in captured)
    first=DecodeGraph(model,8,first_frame=True,requests=device)
    prefill=BatchedPrefillGraph(model,8,max(128,triton.next_power_of_2(max(map(len,prompts)))))
    for i,prompt in enumerate(prompts):
        history=F.pad(prompt[-16:,0],(max(0,16-len(prompt)),0),value=-1).to('cuda')
        device.initialize(i,prompt[-1].to('cuda'),history,len(prompt)-1,500)
    for i in range(0,64,8):
        hidden=prefill.run(prompts[i:i+8],list(range(i,i+8)));first.run(requests[i:i+8],hidden)
    graph.run(requests)
    for _ in range(7):graph.graph.replay()
    torch.cuda.synchronize()
    # Preserve complete call order, including any repeated weight use. x live
    # storage was retained during capture, then cloned only outside the graph.
    calls=[]
    for x,w in captured:
        retained=torch.empty_strided(x.shape,x.stride(),device=x.device,dtype=x.dtype)
        retained.copy_(x)
        assert retained.stride()==x.stride()
        calls.append((retained,w))
    result['prepare_seconds']=time.monotonic()-started
    result['corpus_sha256']=hashlib.sha256(CORPUS.read_bytes()).hexdigest()
    result['call_shapes']=[dict(x=list(x.shape),w=list(w.shape),x_stride=list(x.stride()),w_stride=list(w.stride())) for x,w in calls]
    shapes=defaultdict(list)
    for index,(x,w) in enumerate(calls):shapes[(len(x),*w.shape,x.stride(0))].append(index)
    ordered=sorted(shapes,key=lambda s:sum(calls[i][1].numel()*2 for i in shapes[s]),reverse=True)
    chosen=ordered[:2]
    result['selected_shapes_by_total_weight_bytes']=[dict(shape=list(s),calls=len(shapes[s]),weight_bytes=sum(calls[i][1].numel()*2 for i in shapes[s])) for s in chosen]
    result['all_projection_baseline_ms']=timed_graph(lambda:[F.linear(x,w) for x,w in calls])
    result['selected_baseline_ms']=timed_graph(lambda:[F.linear(*calls[i]) for s in chosen for i in shapes[s]])
    result['status']='BASELINE_BUDGET_READY';save()
    lt=Lt();workspace=torch.empty(32<<20,device='cuda',dtype=torch.uint8)
    rows=[];replacements={};plans=[];keepalive=[]
    for shape in chosen:
        m,n,k,sx=shape;plan=Plan(lt,m,n,k,sx);plans.append(plan)
        selected,examined=plan.heuristics()
        row=dict(shape=list(shape),heuristics=examined,families={})
        rows.append(row);result['shapes']=rows;save()
        indices=shapes[shape];baseline=timed_graph(lambda:[F.linear(*calls[i]) for i in indices])
        best_time=baseline;best=None
        for family,(algo,meta) in selected.items():
            guards={i:torch.full((m*n+128,),7.,device='cuda',dtype=torch.bfloat16) for i in indices}
            outputs={i:guards[i][64:-64].view(m,n) for i in indices}
            initial_rng=torch.cuda.get_rng_state().clone()
            keepalive.extend(outputs.values());checks=[]
            # Compare every invocation selected for replacement, not only one layer.
            for index in indices:
                x,w=calls[index];before_x=fingerprint(x);before_w=fingerprint(w)
                native=F.linear(x,w)
                actual=plan.run(algo,x,w,outputs[index],workspace,torch.cuda.current_stream().cuda_stream)
                torch.cuda.synchronize()
                exact=torch.equal(actual.contiguous().view(torch.uint8),native.contiguous().view(torch.uint8))
                diff=actual.float()-native.float()
                rrms=float((diff.square().mean()/native.float().square().mean().clamp_min(1e-20)).sqrt())
                # Independent FP64 dot products for a fixed spread of rows/cols.
                ridx=torch.tensor([0,m//3,2*m//3,m-1],device='cuda')
                cidx=torch.linspace(0,n-1,128,device='cuda').round().long()
                ref=x[ridx].double() @ w[cidx].double().T
                nd=native[ridx[:,None],cidx].double();ad=actual[ridx[:,None],cidx].double()
                ref_bf=ref.to(torch.bfloat16).double()
                # Predeclared sampled diagnostic allowance; not a proof for the full matrix.
                allowance=(ref_bf-ref).abs()+2e-5*(x[ridx].double().abs() @ w[cidx].double().abs().T)+1e-8
                classified=bool(((ad-ref).abs()<=allowance).all())
                finite=bool(actual.isfinite().all())
                unchanged=fingerprint(x)==before_x and fingerprint(w)==before_w and bool((guards[index][:64]==7).all()) and bool((guards[index][-64:]==7).all()) and torch.equal(initial_rng,torch.cuda.get_rng_state())
                checks.append(dict(call=index,bit_exact=exact,rrms=rrms,max_abs=float(diff.abs().max()),finite=finite,inputs_unchanged=unchanged,fp64_samples=512,fp64_candidate_max_abs=float((ad-ref).abs().max()),fp64_native_max_abs=float((nd-ref).abs().max()),fp64_bf16_rounded_max_abs=float((ref_bf-ref).abs().max()),within_declared_fp32_rounding_bound=classified,input_sha256=before_x,weight_sha256=before_w))
            valid=all(c['bit_exact'] and c['finite'] and c['inputs_unchanged'] and c['rrms']<0.003 and c['within_declared_fp32_rounding_bound'] for c in checks)
            family_row=dict(meta=meta,checks=checks,exact_gate=all(c['bit_exact'] for c in checks),numeric_diagnostic_gate=valid,baseline_sequence_ms=baseline)
            row['families'][family]=family_row;save()
            if not valid:raise AssertionError("strict byte equality or input/guard/RNG ownership gate failed")
            def run_family(plan=plan,algo=algo,outputs=outputs,indices=indices):
                stream=torch.cuda.current_stream().cuda_stream
                for i in indices:plan.run(algo,*calls[i],outputs[i],workspace,stream)
            # Exact graph-vs-eager gate; same immutable real inputs, every selected call.
            eager_copies={i:outputs[i].clone() for i in indices}
            graph=torch.cuda.CUDAGraph()
            with torch.cuda.graph(graph):run_family()
            for _ in range(3):graph.replay()
            torch.cuda.synchronize()
            graph_checks=[]
            for i,c in zip(indices,checks):
                x,w=calls[i]
                same=torch.equal(outputs[i].view(torch.uint8),eager_copies[i].view(torch.uint8))
                owned=fingerprint(x)==c['input_sha256'] and fingerprint(w)==c['weight_sha256'] and bool((guards[i][:64]==7).all()) and bool((guards[i][-64:]==7).all()) and torch.equal(initial_rng,torch.cuda.get_rng_state())
                graph_checks.append(dict(call=i,output_exact=same,input_weight_unchanged=owned))
                assert same and owned,graph_checks[-1]
            family_row['graph_checks']=graph_checks
            save()
            ms=timed_graph(run_family)
            family_row['sequence_ms']=ms;family_row['reduction_fraction']=1-ms/baseline
            if ms<best_time:best_time,best=ms,(plan,algo,outputs)
            save()
        if best:
            plan,algo,outputs=best
            for i in indices:replacements[i]=(plan,algo,outputs[i])
    def all_candidate():
        stream=torch.cuda.current_stream().cuda_stream
        for i,(x,w) in enumerate(calls):
            if i in replacements:
                plan,algo,out=replacements[i];plan.run(algo,x,w,out,workspace,stream)
            else:F.linear(x,w)
    # Single complete-sequence AB feasibility; retain the earlier budgeting timer.
    result['feasibility_baseline_ms']=timed_graph(lambda:[F.linear(x,w) for x,w in calls])
    result['feasibility_candidate_ms']=timed_graph(all_candidate)
    result['saved_ms']=result['feasibility_baseline_ms']-result['feasibility_candidate_ms']
    result['replaced_calls']=len(replacements)
    result['local_feasibility_pass']=result['saved_ms']>=0.3
    result['status']='FEASIBILITY_PASS_REQUIRES_REPEAT_AND_MODEL_GATE' if result['local_feasibility_pass'] else 'STOPPED_BELOW_0_3MS_BUDGET'
    candidate_rows=[f for row in rows for f in row['families'].values()]
    result['candidate_count']=len(candidate_rows)
    result['exact_pass_all_candidates']=all(f['exact_gate'] for f in candidate_rows) if candidate_rows else None
    # Collect executed kernel names after all feasibility timings, not during them.
    from torch.profiler import profile, ProfilerActivity
    with profile(activities=[ProfilerActivity.CPU,ProfilerActivity.CUDA]) as prof:
        with torch.profiler.record_function('native_projection_sequence'): [F.linear(x,w) for x,w in calls]
        with torch.profiler.record_function('selected_lt_projection_sequence'): all_candidate()
        torch.cuda.synchronize()
    prof.export_chrome_trace(str(P/'kernel-trace.json.gz'))
    (P/'kernel-table.txt').write_text(prof.key_averages().table(sort_by='self_device_time_total',row_limit=40)+'\n')
    result['elapsed_seconds']=time.monotonic()-started
    save();print(json.dumps({k:v for k,v in result.items() if k not in ('shapes','call_shapes')}),flush=True)
    torch.cuda.synchronize()
    for plan in plans:plan.close()
    lt.close()

if __name__=='__main__':
    try:main()
    except Exception as e:
        result['status']='FAILED';result['error']=repr(e);save();raise
