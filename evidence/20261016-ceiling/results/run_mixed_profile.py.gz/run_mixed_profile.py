import os,subprocess
from pathlib import Path
root=Path('/home/zjy/code/hsliu/artifacts/drama3-ceiling-20261016')
source=root/'source-initial'
env=dict(os.environ,CUDA_VISIBLE_DEVICES='0',OMP_NUM_THREADS='8',PYTHONPATH=str(source/'src')+':/home/zjy/code/hsliu/drama3-sources/fish-speech',DRAMA3_GDN_STATE_DTYPE='bfloat16',DRAMA3_PACKED_MOE_PROJECTION='1',DRAMA3_PREFILL_CONV='triton',DRAMA3_PREFILL_MOE_TUNED='0',DRAMA3_PREFILL_MOE='flashinfer',DRAMA3_FUSED_MOE_INPUT='1')
with (root/'mixed-profile'/'stdout.log').open('w') as out:
 subprocess.run(['/home/zjy/code/hsliu/venvs/codex-drama3-standalone/bin/python',str(root/'mixed-profile'/'driver.py')],env=env,stdout=out,stderr=subprocess.STDOUT,check=True)
