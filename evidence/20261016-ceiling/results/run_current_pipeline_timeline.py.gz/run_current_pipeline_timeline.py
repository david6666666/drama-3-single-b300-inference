"""Single current-source event timeline; diagnostic only, no A/B claim."""
import datetime,hashlib,json,os,re,socket,subprocess,threading
from pathlib import Path
root=Path('/home/zjy/code/hsliu/artifacts/drama3-ceiling-20261016')
source=root/'source-codec-cache'
venv=Path('/home/zjy/code/hsliu/venvs/codex-drama3-standalone')
base=json.loads((root/'codec-cache-service-experiment.json').read_text())
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()
assert sha==base['source_sha']=='e7cda1eba083603b88e1f2e89688e1ff2ced7fc2'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True)
flags=dict(base['flags'],DRAMA3_TIMELINE_PATH=str(root/'current-pipeline-timeline.json'))
env={k:v for k,v in os.environ.items() if not k.startswith('DRAMA3_')}
env.update(flags,PYTHONPATH=str(source/'src'),HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_MODULES_CACHE='/home/zjy/code/hsliu/artifacts/drama3-b300-20261014/quality-hf-modules')
uuid='GPU-53ed8fd9-9f5a-9c77-430d-095ad4fc860d'
processes=subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid,pid,process_name,used_gpu_memory','--format=csv,noheader'],text=True)
assert uuid not in processes
with socket.socket() as probe:assert probe.connect_ex(('127.0.0.1',18145))!=0
plan=dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha=sha,source=str(source),flags=flags,gpu_uuid=uuid,requests=1088,concurrency=64,repeats=1,profile_enabled=True,
 hypothesis='The current native pipeline/deferred configuration still pays substantial continuous-intake model and mixed-prompt cost; record actual step-weighted batches and nonblocking model/codec interval unions instead of reusing an older-source timeline.',
 isolated_variable='Observation only: enable existing nonblocking CUDA event TimelineProfiler on the cache-off service control. One diagnostic run; no A/B performance claim.',
 controls='Same full corpus/checkpoint/native precision/top8 and startup policy as codec-cache control; GPU0 explicitly differs from previous GPU6 and this is not an improvement comparison. No sharedcacheflush/clock changes.',
 gate='All1088 requests complete without error, clean audio drain, valid timestamp accounting, exclusive own process onGPU0. Counters include64warmup; client interval isolates measured requests.',
 stop='Server failure, incomplete outputs, externalGPU0 interference or inconsistent timelines. Preserve failures. No formal throughput or task-quality acceptance from this profiled run.',
 limitation='CUDA event spans can contain host-submission gaps and count cross-stream pipeline fork/join completion; not SM utilization or summed kernel activity. steps=2 metadata weights paired decode correctly. Stochastic output lengths differ from prior runs.',
 corpus=base['corpus'],corpus_sha256=base['corpus_sha256'],checkpoint=base['checkpoint'],cpu_affinity=sorted(os.sched_getaffinity(0)),driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),before_processes=processes)
plan['storage']={p:subprocess.check_output(['findmnt','-T',p,'-o','TARGET,SOURCE,FSTYPE','--noheadings'],text=True).strip() for p in (str(venv),base['checkpoint'],env['HF_MODULES_CACHE'])}
(root/'current-pipeline-timeline-experiment.json').write_text(json.dumps(plan,indent=2)+'\n')
stop=threading.Event()
def audit():
 with(root/'current-pipeline-timeline-process-audit.jsonl').open('w') as f:
  while not stop.is_set():
   out=subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid,pid,process_name,used_gpu_memory','--format=csv,noheader'],text=True)
   f.write(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),processes=out.splitlines()))+'\n');f.flush();stop.wait(1)
t=threading.Thread(target=audit);t.start()
name='current-pipeline-timeline-gpu0'
cmd=[str(venv/'bin/python'),str(source/'scripts/run_baseline.py'),'--backend','standalone','--source',str(source),'--venv',str(venv),'--bench-python',str(venv/'bin/python'),'--checkpoint',base['checkpoint'],'--fish-source','/home/zjy/code/hsliu/drama3-sources/fish-speech','--corpus',base['corpus'],'--output',str(root/name),'--gpu','0','--port','18145','--capacity','64','--requests','1088','--repeats','1','--concurrency','64','--skip-reference-warmup']
(root/'current-pipeline-timeline-command.json').write_text(json.dumps(cmd,indent=2)+'\n')
try:
 subprocess.run(cmd,env=env,check=True)
 metrics=json.loads((root/name/'benchmark/summary.json').read_text())[0]
 assert metrics['completed']==1088 and metrics['failed']==0,metrics
 log=(root/name/'server.log').read_text();assert 'Application shutdown complete' in log
 pid=int(re.search(r'Started server process \[(\d+)\]',log).group(1))
 rows=[json.loads(x)for x in(root/'current-pipeline-timeline-process-audit.jsonl').read_text().splitlines()]
 observed={int(x.split(',')[1].strip())for a in rows for x in a['processes']if uuid in x}
 assert observed=={pid},observed
 print(json.dumps(dict(diagnostic_completed=True,metrics=metrics,server_pid=pid)),flush=True)
finally:stop.set();t.join()
