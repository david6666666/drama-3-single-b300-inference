"""CPU-only accounting; upper screening budgets are not hardware lower bounds."""
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent
INPUTS = [
    ROOT / 'current-pipeline-service-ledger.json',
    ROOT / 'cpu-service-ceiling/current-delivery-ledgers.json',
    ROOT / 'cpu-service-ceiling/current-timeline-independent-audit.json',
    ROOT / 'padding-router-probe.json',
    ROOT / 'mixed-profile/trace.json.gz',
    ROOT / 'native-row-reuse-audit/counts.json',
    ROOT / 'native-row-reuse-audit/alias-result.json',
    ROOT / 'codec-kernel-profile/summary.json',
    ROOT.parent / 'drama3-mixed-20261016/vllm-continuous-schedule.json',
]
ledger = json.loads(INPUTS[0].read_text())
target = ledger['reference_budget']['target_frames_s']
frames = ledger['output']['total_acoustic_frames']
wall = ledger['summary']['makespan_s']
t = ledger['timeline']
stages = {k: x['gpu_event_union_ms'] / 1000 for k, x in t['stage'].items()}
u = {k: v / 1000 for k, v in t['union'].items()}
active = t['by_client_submission_phase']['continuous_intake_after_fill']['decode']['event_time_weighted_active']
intake_decode = t['by_client_submission_phase']['continuous_intake_after_fill']['decode']['gpu_event_union_ms'] / 1000
mixed = stages['mixed_backbone']
rows = t['conditional_decode_row_accounting']
# Actual historical graph suffix: forty native finalize kernels followed by
# shared expert finish, combine, final backbone norm, then teacher semantic prep.
trace = json.loads(gzip.decompress(INPUTS[4].read_bytes()))
events = sorted((x for x in trace['traceEvents'] if x.get('cat') == 'kernel'), key=lambda x: x['ts'])
assert len(events) == 8319
per_replay = len(events) // 3
teacher = []
for repeat in range(3):
    part = events[repeat * per_replay:(repeat + 1) * per_replay]
    finalizers = [i for i, x in enumerate(part) if 'finalizeKernel' in x['name']]
    assert len(finalizers) == 40
    boundary = finalizers[-1] + 5
    after = [x['name'] for x in part[finalizers[-1] + 1:boundary]]
    assert after[0] == 'silu_mul_kernel' and after[2:] == ['combine_experts_kernel', 'add_norm_kernel']
    suffix = part[boundary:]
    assert len(suffix) == 657
    teacher.append({'repeat': repeat, 'boundary_kernel_index': boundary,
                    'suffix_kernel_count': len(suffix),
                    'suffix_span_ms': (max(x['ts'] + x['dur'] for x in suffix) - suffix[0]['ts']) / 1000,
                    'suffix_summed_ms': sum(x['dur'] for x in suffix) / 1000})
route_cases = []
for case in json.loads(INPUTS[3].read_text())['cases']:
    all_bytes = sum(x['all_weight_bytes'] for x in case['layers'])
    dummy_bytes = sum(x['padding_only_weight_bytes'] for x in case['layers'])
    route_cases.append({'real_rows': case['real_rows'], 'layers': len(case['layers']),
                        'real_unique_expert_layer_pairs': sum(x['real_experts'] for x in case['layers']),
                        'one_read_real_expert_weight_bytes': all_bytes - dummy_bytes,
                        'scope': 'One archived fixed step, not service aggregate; FP8 weights only.'})
upstream = json.loads(INPUTS[-1].read_text())['by_client_phase']['continuous_admission']
delivery = json.loads(INPUTS[1].read_text())['runs']
result = {
    'status': 'CPU_SOURCE_AUDIT_ONLY', 'target_frames_s': target,
    'diagnostic': {'source_sha': ledger['launch']['source_sha'], 'frames': frames,
                   'wall_s': wall, 'target_fixed_work_s': frames / target,
                   'required_saving_s': wall - frames / target,
                   'required_time_fraction': 1 - frames / target / wall,
                   'pure_decode_s': stages['decode'], 'mixed_s': mixed,
                   'model_union_s': u['model_event_union_ms'],
                   'codec_only_s': u['codec_only_ms'],
                   'neither_s': u['neither_model_nor_codec_in_envelope_ms'],
                   'codec_union_s': u['codec_event_union_ms'],
                   'overlap_s': u['model_codec_overlap_ms']},
    'conditional_screening_not_predictions': {
        'delete_codec_only_plus_neither_s': u['codec_only_ms'] + u['neither_model_nor_codec_in_envelope_ms'],
        'delete_all_mixed_fps': frames / (wall - mixed),
        'intake_decode_time_weighted_active': active,
        'fill_to64_fixed_step_throughput_fraction': 64 / active - 1,
        'fill_to64_fixed_cost_decode_time_s': intake_decode * (1 - active / 64),
        'delete_entire_drain_s': ledger['client_phases']['final_drain']['duration_s'],
        'executed_excess_row_fraction': rows['observed_executed_minus_conditional_productive_rows'] / rows['total_decode_backbone_request_rows'],
        'mixed_prompt_padding_fraction': t['mixed_recorded_metadata']['prompt_token_padding_fraction'],
        'mixed_actual_prompt_rows': t['mixed_recorded_metadata']['prompt_tokens'],
        'mixed_current_capacity_rows': t['mixed_recorded_metadata']['prefill_capacity'],
        'teacher_historical_proxy_gross_s': sum(x['suffix_span_ms'] for x in teacher) / len(teacher) * t['mixed_recorded_metadata']['events'] / 1000,
        'old_tower_only_delete_s': stages['mixed_decode_tower'],
        'codec_fraction_25pct_event_s': u['codec_event_union_ms'] * .25,
        'codec_fraction_25pct_exclusive_proportional_s': u['codec_only_ms'] * .25,
        'no_additivity': 'Row utilization, prefix reuse, teacher overlap and codec effects can overlap or change the trajectory. Never sum as achieved savings.'},
    'historical_teacher_suffix': teacher,
    'archived_unique_weight_examples': route_cases,
    'upstream_continuous_trace': {'requests': 256, 'scheduled_mean': upstream['scheduled_requests']['mean'],
                                 'pure_decode_mean': upstream['pure_decode_requests']['mean'],
                                 'mixed_requests_median': upstream['mixed_prompt_requests']['p50'],
                                 'mixed_tokens_median': upstream['mixed_prompt_tokens']['p50'],
                                 'scope': 'Different profiled workload, counts only, not matched timing.'},
    'unprofiled_single_runs': {k: {'fps': v['summary']['throughput_frames_s'], 'frames': v['frames'],
                                  'wall_s': v['summary']['makespan_s'], 'required_saving_s': v['required_time_reduction_s']}
                              for k, v in delivery.items()},
    'inputs_sha256': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in INPUTS},
    'hardware_lower_bound': 'Not established: current fullservice per-layer route sets, actual DRAM bytes/cache reuse, non-expert bytes, mixed/codec resource concurrency and sustainable combined bandwidth not measured.',
    'isolated_decode_used_as_upper_bound': False, 'gpu_initialized': False,
}
(OUT / 'budget.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'status': result['status'], 'required_saving_s': result['diagnostic']['required_saving_s'],
                  'teacher_proxy_gross_s': result['conditional_screening_not_predictions']['teacher_historical_proxy_gross_s'],
                  'intake_fill_proxy_s': result['conditional_screening_not_predictions']['fill_to64_fixed_cost_decode_time_s']}))
