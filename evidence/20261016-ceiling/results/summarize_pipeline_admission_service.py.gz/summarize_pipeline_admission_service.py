import collections,json,re,subprocess
from pathlib import Path
root=Path(__file__).resolve().parent
uuid='GPU-619f7fdc-5f98-8c37-fe89-0465d6130baf'
limits=dict(wer_corpus_max=.02950933601272712,sim_min=61.88158934120563)
summary=dict(source_sha='95fcb0ef2662f2caf9bfb7fe6863dc3ad7805b1b',concurrency=64,requests_per_arm=1088,repeats_per_arm=1,profile_enabled=False,limits=limits,arms={},qualification='One feasibility pair, no replicated or fixed-output speedup claim. Production pipeline3689 exact checks passed before service, including separately synthetic first-EOS. Only DEFERRED_WAITING changes; both FRAME_PIPELINE1 with identical captures, router1/five native flags. New production selection CPU suite73 PASS. DP partitions are not held fixed. Both arms require complete unfiltered1088 WER/SIM.',artifacts=dict(service_protocol='pipeline-admission-service-experiment.json',quality_protocol='pipeline-admission-quality-experiment.json',native_gate='frame-pipeline-production-v2-validation.json',native_micro='frame-pipeline-production-results.md'))
raw={}
for arm in ('control','candidate'):
 path=root/f'pipeline-admission-{arm}-gpu6';bench=path/'benchmark'
 metrics=json.loads((bench/'summary.json').read_text())[0]
 rows=[json.loads(x) for x in (bench/'c64-r0.jsonl').read_text().splitlines()]
 raw[arm]={r['request_id']:r for r in rows}
 assert len(rows)==1088 and len(raw[arm])==1088 and metrics['completed']==1088 and metrics['failed']==0
 quality=json.loads((root/f'pipeline-admission-{arm}-quality.json').read_text())['groups']['c64-r0']
 assert quality['complete'] and quality['wer']['evaluated']==1088 and quality['similarity']['evaluated']==1088 and len(quality['records'])==1088
 assert {r['request_id'] for r in quality['records']}==set(raw[arm])
 warmup=json.loads((bench/'c64-warmup.json').read_text());assert warmup and all(r['success'] for r in warmup)
 launch=json.loads((path/'launch.json').read_text());assert launch['source_sha']==summary['source_sha'] and not launch['source_status']
 pid=int(re.search(r'Started server process \[(\d+)\]',(path/'server.log').read_text()).group(1))
 summary['arms'][arm]=dict(metrics=metrics,output=dict(acoustic_frames=sum(r['acoustic_frames'] for r in rows),audio_samples=sum(r['audio_samples'] for r in rows),audio_duration_s=sum(r['audio_duration_s'] for r in rows),at_or_above_500_frames=sum(r['acoustic_frames']>=500 for r in rows),rms_below_1e_3=sum(r['rms']<1e-3 for r in rows),finish_reasons=dict(collections.Counter(r['finish_reason'] for r in rows))),quality={k:v for k,v in quality.items() if k!='records'},quality_gate_pass=quality['wer']['wer_corpus']<=limits['wer_corpus_max'] and quality['similarity']['mean']>=limits['sim_min'],server_pid=pid,startup_to_readiness_s=launch['startup_to_readiness_s'],warmup_requests=len(warmup),warmup_success=True)
for arm in ('control','candidate'):
 log=(root/f'pipeline-admission-{arm}-gpu6/server.log').read_text()
 summary['arms'][arm]['clean_shutdown']='Application shutdown complete.' in log
 records=[json.loads(line) for line in log.splitlines() if line.startswith('{"frame_pipeline_counts":')]
 matches=[row['frame_pipeline_counts'] for row in records]
 summary['arms'][arm]['waiting_context']=records[-1]['frame_pipeline_waiting_counts'] if records else None
 summary['arms'][arm]['pipeline_decisions']=matches[-1] if matches else None
 if matches:
  counts=matches[-1]
  summary['arms'][arm]['pipeline_fraction_of_ordinary_decode_launches']=counts['eligible']/sum(counts.values())
  summary['arms'][arm]['pipeline_counter_scope']='Entire server lifetime:64 warmup +1088 measured requests; excludes mixed/prefill branches. Not benchmark-only pair coverage.'
 assert summary['arms'][arm]['clean_shutdown']
summary['sampler_limitation']='Both arms capture identical FRAME_PIPELINE1 graphs. Global sampling_step is not reset or independently measured after capture; later admission and pairing alter step/row schedules. Outputs are scored unfiltered; no fixed-seed or fixed-output speedup claim.'
a,b=summary['arms']['control'],summary['arms']['candidate']
summary['comparison']=dict(eligible_decisions_delta=b['pipeline_decisions']['eligible']-a['pipeline_decisions']['eligible'],eligible_fraction_delta=b['pipeline_fraction_of_ordinary_decode_launches']-a['pipeline_fraction_of_ordinary_decode_launches'],throughput_relative_change=b['metrics']['throughput_frames_s']/a['metrics']['throughput_frames_s']-1,makespan_relative_change=b['metrics']['makespan_s']/a['metrics']['makespan_s']-1,output_frames_relative_change=b['output']['acoustic_frames']/a['output']['acoustic_frames']-1,ttfa_p50_delta_ms=b['metrics']['ttfa_p50_ms']-a['metrics']['ttfa_p50_ms'],ttfa_p95_delta_ms=b['metrics']['ttfa_p95_ms']-a['metrics']['ttfa_p95_ms'],wer_delta_percentage_points=100*(b['quality']['wer']['wer_corpus']-a['quality']['wer']['wer_corpus']),sim_delta=b['quality']['similarity']['mean']-a['quality']['similarity']['mean'],same_audio_sha256=sum(raw['control'][k]['audio_sha256']==raw['candidate'][k]['audio_sha256'] for k in raw['control']),same_output_frame_count=sum(raw['control'][k]['acoustic_frames']==raw['candidate'][k]['acoustic_frames'] for k in raw['control']))
expected={a['server_pid'],b['server_pid']}
for kind,filename in [('service','pipeline-admission-service-process-audit.jsonl'),('quality','pipeline-admission-quality-process-audit.jsonl')]:
 samples=[json.loads(x) for x in (root/filename).read_text().splitlines()]
 per=[[int(p.split(',')[1].strip()) for p in s['processes'] if uuid in p] for s in samples]
 observed=set(p for s in per for p in s)
 report=dict(path=filename,samples=len(samples),sampling_interval_s=1,observed_gpu6_pids=sorted(observed),maximum_simultaneous_gpu6_processes=max(map(len,per)),sampling_limitation='One-second polling cannot exclude shorter unobserved interference.')
 if kind=='service':report.update(expected_server_pids=sorted(expected),foreign_process_observed=bool(observed-expected))
 summary[f'{kind}_process_audit']=report
baseline=4510.271508809941
summary['target']=dict(vllm_c64_baseline_frames_s=baseline,required_ratio=1.5,target_frames_s=6765.407263214912,observed_candidate_vs_vllm=b['metrics']['throughput_frames_s']/baseline,achieved=b['metrics']['throughput_frames_s']>=baseline*1.5 and b['quality_gate_pass'])
processes=subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid,pid,process_name,used_gpu_memory','--format=csv,noheader'],text=True)
summary['post_run_gpu6_empty']=uuid not in processes
summary['interpretation']="Same-source bounded native two-frame feasibility with only DEFERRED_WAITING0->1 and FRAME_PIPELINE1 in both arms. Identical graph captures; later scheduling and output lengths can differ. One pair is not a repeated or fixed-work speedup claim. Actual shutdown eligibility is recorded including warmup; source remains default off. Full unfiltered quality and all failures retained; no1.5x goal claim."
(root/'pipeline-admission-service-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ('arms',)},indent=2))
for arm,x in summary['arms'].items():print(arm,x['metrics'],x['quality']['wer']['wer_corpus'],x['quality']['similarity']['mean'],x['quality_gate_pass'])
