import os,traceback,subprocess
from pathlib import Path
os.environ['CUTE_DSL_ARCH']='sm_103a'
os.environ['CUTE_DSL_KEEP']='ptx,cubin'
os.environ['CUTE_DSL_DUMP_DIR']=str(Path(__file__).resolve().parent/'gpu-compile-artifacts')
os.environ['CUTE_DSL_CACHE_DIR']=str(Path(__file__).resolve().parent/'gpu-compile-cache')
os.environ['FLASHINFER_PRIMS_TS_COMPILE_OPTIONS']='--opt-level 2 --gpu-arch sm_103a'
from common import *
from flashinfer.prims_ts.batched_gemm.batched_gemm_run import _compile_for_launch,_launch_arg_tuple
import cuda.bindings.driver as cuda_drv
(OUT/'gpu-compile-artifacts').mkdir(exist_ok=True)
report={'status':'PREPARING','timings_allowed':False,'passed':False,'checks':[],'pid':os.getpid()}
def flush():(OUT/'result.json').write_text(json.dumps(report,indent=2)+'\n')
def exact(name,a,b):
 ac=a.detach().cpu().contiguous();bc=b.detach().cpu().contiguous()
 ok=ac.shape==bc.shape and ac.dtype==bc.dtype and torch.equal(ac.view(torch.uint8),bc.view(torch.uint8))
 row={'name':name,'exact':ok,'shape':list(ac.shape),'dtype':str(ac.dtype)}
 if not ok:
  row['changed_values']=int((ac!=bc).sum());row['changed_bytes']=int((ac.view(torch.uint8)!=bc.view(torch.uint8)).sum())
  delta=ac.float()-bc.float();row['maxabs']=float(delta.abs().max());row['rrms']=float(delta.square().mean().sqrt()/(bc.float().square().mean().sqrt()+1e-30))
 report['checks'].append(row);flush();return ok
@torch.inference_mode()
def main():
 prep=json.loads((OUT/'prepare-result.json').read_text());assert prep['status']=='CPU_AOT_PASS' and prep['cuda_initialized'] is False
 manifest=json.loads((OUT/'frozen-inputs.json').read_text());assert all(sha(p)==h for p,h in manifest.items())
 assert os.environ['CUDA_VISIBLE_DEVICES']=='GPU-40e00845-d89c-1393-2c32-a2dca3ee9442'
 report.update(source_sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip(),source_status=subprocess.check_output(['git','status','--porcelain'],cwd=SOURCE,text=True),prepare=prep,cpu_affinity=sorted(os.sched_getaffinity(0)));flush()
 assert report['source_sha']==prep['source_sha'] and report['source_status']==''
 cfg,info=config();assert info['candidate']==prep['config']['candidate']
 data=torch.load(OUT/'inputs.pt',map_location='cpu',weights_only=False)
 io,x=io_for(cfg,data,'cuda');stream=cuda_drv.CUstream(torch.cuda.current_stream().cuda_stream)
 report.update(gpu_uuid=str(torch.cuda.get_device_properties(0).uuid),device_name=torch.cuda.get_device_name(0),torch_version=torch.__version__,shared_bytes=prep['resource_audit'])
 fn=_compile_for_launch(io,stream)
 cpu_bins=list((OUT/'compile-artifacts').glob('*.cubin'));gpu_bins=list((OUT/'gpu-compile-artifacts').glob('*.cubin'))
 assert len(cpu_bins)==len(gpu_bins)==1
 report['cpu_cubin_sha256']=sha(cpu_bins[0]);report['gpu_cubin_sha256']=sha(gpu_bins[0]);assert report['cpu_cubin_sha256']==report['gpu_cubin_sha256']
 assert report['shared_bytes']['total']<=80*1024
 before={k:v.clone() for k,v in x.items() if k!='fc2'};rng=torch.cuda.get_rng_state().clone()
 fn(*_launch_arg_tuple(io,stream));torch.cuda.synchronize()
 torch.save({'output_bf16':x['fc2'].cpu(),'expected_bf16':x['expected'].cpu(),'tokens':x['tokens'].cpu(),'expanded':x['expanded'].cpu()},OUT/'actual-reference.pt')
 good=exact('fc2_bf16',x['fc2'],x['expected'])
 for k,v in before.items():good=exact('untouched/'+k,x[k],v) and good
 good=exact('rng_unchanged',torch.cuda.get_rng_state(),rng) and good
 if not good:
  report['status']='NATIVE_MATH_FAIL';flush();return
 graph=torch.cuda.CUDAGraph()
 with torch.cuda.graph(graph):fn(*_launch_arg_tuple(io,cuda_drv.CUstream(torch.cuda.current_stream().cuda_stream)))
 x['fc2'].fill_(-17.0);graph.replay();torch.cuda.synchronize()
 good=exact('graph_fc2_bf16',x['fc2'],x['expected'])
 for k,v in before.items():good=exact('graph_untouched/'+k,x[k],v) and good
 good=exact('graph_rng_unchanged',torch.cuda.get_rng_state(),rng) and good
 report['passed']=good;report['status']='ONE_EXPERT_FC2_EXACT_PASS' if good else 'GRAPH_EXACT_FAIL';flush()
try:main()
except BaseException as e:
 report.update(status='EXECUTION_FAIL',error=repr(e),traceback=traceback.format_exc());flush();raise
finally:flush()
print(json.dumps(report,indent=2))
