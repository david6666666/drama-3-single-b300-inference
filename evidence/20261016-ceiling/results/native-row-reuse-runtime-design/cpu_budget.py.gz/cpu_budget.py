"""CPU-only exact full-prefix trie and finite graph-budget feasibility."""
import ast
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import statistics
import time
from types import SimpleNamespace
from typing import Sequence
import torch
from tokenizers import Tokenizer

OUT=Path(__file__).resolve().parent
ROOT=OUT.parent
FISH=Path('/home/zjy/code/hsliu/drama3-sources/fish-speech/fish_speech/models/text2semantic/fish_omni/generate.py')
CKPT=Path('/home/zjy/.cache/huggingface/hub/models--fishaudio--drama-3/snapshots/e0a9218aa48888270f06ef1ed9ea67622c0e17d2')
CORPUS=Path('/home/zjy/code/hsliu/artifacts/drama3-b300-20261014/seedtts-en1088-codes/requests.jsonl')

def mapping(prompts,decode_rows,prefill_capacity):
    # Equality on (parent-node-id, full88-byte row), never digest-only equality.
    nodes={};next_id=1;owners=list(range(decode_rows+prefill_capacity));offset=decode_rows
    for prompt in prompts:
        assert prompt.device.type=='cpu' and prompt.dtype==torch.int64 and prompt.ndim==2 and prompt.shape[1]==11
        parent=0;data=prompt.contiguous().numpy().tobytes()
        for position in range(len(prompt)):
            key=(parent,data[position*88:(position+1)*88])
            found=nodes.get(key)
            if found is None:
                found=(next_id,offset+position);nodes[key]=found;next_id+=1
            parent,owners[offset+position]=found
        offset+=len(prompt)
    assert offset<=len(owners)
    keep=[row for row,owner in enumerate(owners) if row==owner]
    index={row:i for i,row in enumerate(keep)}
    inverse=[index[owner] for owner in owners]
    capacity=(len(keep)+63)//64*64
    keep.extend([0]*(capacity-len(keep)))
    # Include actual CPU tensor materialization in the measured host work.
    packed=torch.tensor(keep+inverse,dtype=torch.int64)
    return dict(keep=keep,inverse=inverse,unique=len(index),compact=capacity,packed=packed)

def build_prompts():
    constants={'DRAMA3_TTS_INSTRUCTION','DRAMA3_REFERENCE_INSTRUCTION','DRAMA3_MESSAGE_END','DRAMA3_GENERATION_START','DRAMA3_STRUCTURAL_TOKENS','SPEAKER_TAG_PATTERN','MAX_SPEAKER_ID','UNICODE_WHITE_SPACE','DRAMA3_MAX_PROMPT_ROWS'}
    functions={'validate_drama3_text','with_speaker_tag','build_drama3_prompt'}
    nodes=[n for n in ast.parse(FISH.read_text()).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in constants for t in n.targets) or isinstance(n,ast.FunctionDef) and n.name in functions]
    ns=dict(torch=torch,re=re,Sequence=Sequence,Tokenizer=Tokenizer,FishOmniConfig=object,InvalidInputError=ValueError,Drama3PromptTooLongError=ValueError)
    exec(compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),str(FISH),'exec'),ns)
    cfg=json.loads((CKPT/'config.json').read_text());config=SimpleNamespace(audio_decoder=SimpleNamespace(num_codebooks=cfg['audio_decoder_config']['num_codebooks'],vocab_size=cfg['audio_decoder_config']['vocab_size']),**{k:cfg[k] for k in ('semantic_start_token_id','semantic_end_token_id','eos_token_id')})
    tokenizer=Tokenizer.from_file(str(CKPT/'tokenizer.json'));samples=[json.loads(x) for x in CORPUS.read_bytes().splitlines()]
    return [ns['build_drama3_prompt'](s['text'],tokenizer,config,[s['reference_text']],[torch.tensor(s['reference_codes'],dtype=torch.int64)]) for s in samples]

prompts=build_prompts();groups=json.loads((ROOT/'native-row-reuse-audit/counts.json').read_text())['groups'];groups=[g for g in groups if g['stage']=='mixed_backbone']
keys=[(64,p,256,c) for p in (768,1024,1280,1536) for c in range(512,(int(.75*(64+p))//64)*64+1,64)]
records=[]
for g in groups:
    selected=prompts[g['corpus_start']:g['corpus_start']+g['count']];assert sum(map(len,selected))==g['prompt_tokens']
    durations=[]
    for _ in range(5):
        start=time.perf_counter_ns();m=mapping(selected,g['decode_capacity'],g['prefill_capacity']);durations.append((time.perf_counter_ns()-start)/1e6)
    d=g['decode_capacity'];full=d+g['prefill_capacity'];padding=d+sum(map(len,selected))
    assert m['keep'][:d]==list(range(d)) and all(row in m['keep'] for row in range(padding,full))
    for i,owner in enumerate(m['inverse']):assert 0<=owner<len(m['keep']) and m['keep'][owner]<=i
    span=256 if max([*map(len,selected),g['prefill_capacity']-g['prompt_tokens']])<=256 else 512
    key=(d,g['prefill_capacity'],span,m['compact']);supported=key in keys
    records.append(dict(group=g['group'],key=list(key),count=g['count'],unique=m['unique'],alias_rows=full-m['unique'],rounded_removed_rows=full-m['compact'],supported=supported,cpu_raw_ms=durations,cpu_median_ms=statistics.median(durations),gpu_mixed_ms=g['gpu_ms']))
# Branching proof: later equality cannot merge after a different earlier row.
a=torch.zeros((5,11),dtype=torch.int64);b=a.clone();b[1,10]=1
m=mapping([a,b],64,16);assert m['inverse'][64]==m['inverse'][69]
assert all(m['inverse'][64+i]!=m['inverse'][69+i] for i in range(1,5))
# Different lengths share only valid causal prefix; zero-lengths do not alias padding.
m=mapping([a,a[:3],a[:0]],16,16);assert all(m['inverse'][16+i]==m['inverse'][21+i] for i in range(3));assert all(row in m['keep'] for row in range(24,32))
assert not torch.cuda.is_initialized()
eligible=[x for x in records if x['supported']];times=[x['cpu_median_ms'] for x in records]
result=dict(status='CPU_DESIGN_PASS_NO_GPU',driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_builder_sha256=hashlib.sha256(FISH.read_bytes()).hexdigest(),corpus_sha256=hashlib.sha256(CORPUS.read_bytes()).hexdigest(),cuda_initialized=False,policy='D64, P768/1024/1280/1536,span256; exactceil64compact in prebuilt512..floor64(.75full),otherwise originalgraph',keys=[list(k) for k in keys],additional_graphs=len(keys),attention_workspace_bytes=len(keys)*128*1024*1024,covered_groups=len(eligible),all_groups=len(records),covered_mixed_gpu_ms=sum(x['gpu_mixed_ms'] for x in eligible),all_mixed_gpu_ms=sum(x['gpu_mixed_ms'] for x in records),total_cpu_plan_median_sum_ms=sum(times),cpu_group_median_ms=statistics.median(times),cpu_group_p95_ms=sorted(times)[int(.95*len(times))],cpu_group_max_ms=max(times),actual_key_histogram={str(k):v for k,v in Counter(tuple(x['key']) for x in records).items()},records=records,limitations=['FIFO membership proxy only, not live admission request IDs.','CPU mapping construction measured including tensorcreation, no H2D or service critical-path measurement.','26graphs×128MiB AttentionBatch workspace is persistent lower accounting, not measured total graphpool peak.','At least25% row reduction is a conservative eligibility policy, not proof of5%localgain orservicegain.','All decode/padding remain untouched; no cross-admission cached prefix/model state.'])
(OUT/'cpu-budget.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ('records','keys','actual_key_histogram')},indent=2))
