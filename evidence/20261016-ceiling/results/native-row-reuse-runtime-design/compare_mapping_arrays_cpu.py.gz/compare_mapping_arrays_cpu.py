"""Vectorized equality for <=8 prompts, compared against exact causal trie."""
import importlib.util
import json
from pathlib import Path
import statistics
import time
import numpy as np
import torch

OUT=Path(__file__).resolve().parent
# Load only definitions and imports from the earlier CPU-only budget source.
import ast
p=OUT/'cpu_budget.py';tree=ast.parse(p.read_text());nodes=[]
for node in tree.body:
    if isinstance(node,(ast.Import,ast.ImportFrom,ast.FunctionDef)):nodes.append(node)
    elif isinstance(node,ast.Assign) and all(isinstance(x,ast.Name) and x.id in {'OUT','ROOT','FISH','CKPT','CORPUS'} for x in node.targets):nodes.append(node)
ns={'__file__':str(p)};exec(compile(ast.Module(body=nodes,type_ignores=[]),str(p),'exec'),ns)

def mapping(prompts,d,capacity):
    arrays=[p.numpy() for p in prompts];all_rows=np.arange(d+capacity,dtype=np.int64);owners=all_rows.copy();offsets=[];offset=d
    for index,a in enumerate(arrays):
        best_length=0;best_owner=None
        for previous,b in enumerate(arrays[:index]):
            limit=min(len(a),len(b))
            differences=np.flatnonzero(~np.all(a[:limit]==b[:limit],axis=1))
            length=int(differences[0]) if len(differences) else limit
            if length>best_length:best_length,best_owner=length,previous
        if best_length:
            start=offsets[best_owner];owners[offset:offset+best_length]=owners[start:start+best_length]
        offsets.append(offset);offset+=len(a)
    assert offset<=len(owners)
    keep=np.flatnonzero(owners==all_rows);unique=len(keep);compact=(unique+63)//64*64
    index=np.empty_like(owners);index[keep]=np.arange(unique,dtype=np.int64)
    inverse=index[owners];packed=np.zeros(compact+len(owners),dtype=np.int64)
    packed[:unique]=keep;packed[compact:]=inverse
    return dict(keep=packed[:compact],inverse=inverse,unique=unique,compact=compact,packed=torch.from_numpy(packed))

prompts=ns['build_prompts']();groups=json.loads((OUT.parent/'native-row-reuse-audit/counts.json').read_text())['groups'];records=[]
for g in groups:
    if g['stage']!='mixed_backbone':continue
    selected=prompts[g['corpus_start']:g['corpus_start']+g['count']];expected=ns['mapping'](selected,g['decode_capacity'],g['prefill_capacity']);timings=[]
    for _ in range(5):
        start=time.perf_counter_ns();m=mapping(selected,g['decode_capacity'],g['prefill_capacity']);timings.append((time.perf_counter_ns()-start)/1e6)
    assert np.array_equal(m['keep'],expected['keep']) and np.array_equal(m['inverse'],expected['inverse']) and torch.equal(m['packed'],expected['packed'])
    records.append(dict(group=g['group'],count=g['count'],cpu_raw_ms=timings,median_ms=statistics.median(timings)))
assert not torch.cuda.is_initialized();times=[r['median_ms'] for r in records]
result=dict(status='CPU_MAPPING_EXACT_PASS',groups=len(records),median_ms=statistics.median(times),p95_ms=sorted(times)[int(.95*len(times))],max_ms=max(times),total_ms=sum(times),records=records,limits=['CPU only. Does not include H2D copy or GPU/service timing.','Exact full11-column equality; no hash or digest. All prefix chains resolve to earlier canonical owner.'])
(OUT/'cpu-array-budget.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='records'},indent=2))
