"""CPU-only resource and arithmetic-oracle census; does not allocate CUDA tensors."""
import csv
import hashlib
import json
from pathlib import Path
import torch

ROOT = Path('/home/zjy/code/hsliu/artifacts/drama3-ceiling-20261016')
OUT = ROOT / 'expert-resident-cpu'
FI = Path('/home/zjy/code/hsliu/venvs/codex-drama3-standalone/lib/python3.12/site-packages/flashinfer')
NCU = Path('/home/zjy/code/hsliu/artifacts/drama3-mixed-20261016/ncu/real-moe-metrics-base.csv')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

rows = list(csv.DictReader(NCU.open()))
rows = [r for r in rows if r['Kernel Name'].startswith('bmm_')]
assert len(rows) == 6
out = {'cpu_only': True, 'framework_source_sha': '95fcb0ef2662f2caf9bfb7fe6863dc3ad7805b1b',
       'oracle_provenance': 'Successful 1373-check metadata-rebase experiment; archived actual FI IDs, B64=63 real + 1 reserved padding',
       'layers': [], 'ncu_conditional_budgets': [], 'source_hashes': {str(NCU): sha(NCU)}}
for layer in (0, 19, 39):
    p = ROOT / 'expert-metadata-rebase' / f'oracle-layer{layer}-real.pt'
    d = torch.load(p, map_location='cpu', weights_only=False)
    ids = d['ids'].long().flatten()
    counts = torch.bincount(ids, minlength=256)
    groups = int(((counts + 7) // 8).sum())
    active = int((counts > 0).sum())
    expert = int(torch.where(counts == 8)[0][0])
    expanded = torch.where(ids == expert)[0]
    assert all(v.device.type == 'cpu' for v in d['intermediates'].values())
    assert d['intermediates']['fc1_bytes'].shape == (512, 1024)
    assert d['intermediates']['fc1_scale'].shape == (512, 8)
    assert d['intermediates']['activation_bytes'].shape == (512, 512)
    assert d['intermediates']['activation_scale'].shape == (512, 4)
    assert d['intermediates']['fc2_bf16'].shape == (512, 2048)
    per_route = 1024 + 8*4 + 512 + 4*4
    out['layers'].append({'layer': layer, 'active_experts': active, 'token8_groups': groups,
        'max_expert_tokens': int(counts.max()), 'four_cta_per_token8_ctas': 4*groups,
        'cta_waves_if_one_cta_per_SM': 4*groups/148,
        'cta_waves_if_two_ctas_per_SM': 4*groups/296,
        'selected_eight_route_expert': expert,
        'selected_expanded_indices': expanded.tolist(),
        'selected_token_indices': (expanded // 8).tolist(),
        'selected_original_k': (expanded % 8).tolist(),
        'active_weight_bytes': active * 3*1024**2,
        'token8_group_weight_bytes_requested_if_no_cache': groups * 3*1024**2,
        'extra_weight_request_fraction_vs_one_per_expert': groups/active-1,
        'logical_padded_intermediate_write_read_bytes': groups*8*per_route*2,
        'logical_padded_intermediate_fraction_of_active_weights': groups*8*per_route*2/(active*3*1024**2),
        'cross_CTA_activation_replica_bytes_total': groups*4*3*(8*128+8*4),
        'warning': 'Logical request counts are not measured DRAM. Cache behavior may retain repeated expert weights.'})
    out['source_hashes'][str(p)] = sha(p)

for i, layer in enumerate((0, 19, 39)):
    rr = rows[2*i:2*i+2]
    durations = [float(r['gpu__time_duration.sum']) / 1000 for r in rr]
    peak = [float(r['dram__throughput.avg.pct_of_peak_sustained_elapsed']) / 100 for r in rr]
    native_sum = sum(durations)
    full_bw_time = sum(t*b for t,b in zip(durations, peak))
    out['ncu_conditional_budgets'].append({'layer': layer, 'native_serial_sum_us': native_sum,
        'kernel_names': [r['Kernel Name'] for r in rr],
        'same_measured_bytes_at100pct_peak_us': full_bw_time,
        'conditional_saved_at100pct_peak_us': native_sum-full_bw_time,
        'same_measured_bytes_at90pct_peak_us': full_bw_time/.9,
        'conditional_saved_at90pct_peak_us': native_sum-full_bw_time/.9,
        'conditional_time_reduction_fraction_at90pct': 1-full_bw_time/.9/native_sum,
        'warning': 'Diagnostic arithmetic only. NCU can serialize PDL. Different inputs/source from successful oracles; not a bound for unprofiled service and not an achievable forecast.'})

out['resource_design'] = {'not_compiled_not_measured': True,
 'ctas_per_cluster':4, 'threads_per_cta_proposed':256, 'token_tile':8,
 'mma_preserved':'m64n8k32, four K32 instructions per original K128 block',
 'fc1_owned_channels_per_cta':'up128 + gate128; four M64 subtiles',
 'fc2_owned_channels_per_cta':512, 'fc2_streamed_output_channels':128,
 'weight_bytes_per_expert_token8':3*1024**2,
 'weight_bytes_per_cta':3*1024**2//4,
 'fc1_weight_TMA_tiles_16KiB_per_cta':32,
 'fc2_weight_TMA_tiles_16KiB_per_cta':16,
 'weight_TMA_tiles_per_cluster':192,
 'native_weight_TMA_tiles_per_expert_token8':192,
 'fc1_weight_stages_bytes':2*2*128*128,
 'fc1_input_stages_bytes':2*8*128,
 'fc1_byte_and_scale_scratch_bytes':8*256+8*2*4,
 'complete_activation_local_replica_bytes':8*512+8*4*4,
 'minimal_logical_shared_bytes_before_scale_staging_and_barriers':73920,
 'additional_scale_staging_estimate_bytes':288,
 'shared_budget_for_first_compile_bytes':80*1024,
 'two_CTA_per_SM_shared_limit_before_system_overhead_bytes':233472//2,
 'two_CTA_per_SM_register_limit_for256threads':65536//(2*256),
 'FC1_logical_FP32_persistent_accumulator_bytes':8*256*4,
 'FC1_accumulator_FP32_registers_per128consumer_threads':8*256//128,
 'FC2_FP32_persistent_accumulator_bytes_streamed_tile':8*128*4,
 'minimum_nonexclusive_TMEM_allocation_bytes':128*32*4,
 'remote_DSM_bytes_per_cluster_with_replication':4*3*(8*128+8*4),
 'correctness_dependencies':'cluster publication, DSM completion before source reuse, local shared-to-MMA fence; original FC2 K128 order 0..3'}
for rel in ('prims_ts/batched_gemm/tmem_c_resources.py', 'prims_ts/batched_gemm/smem_deepseek_sf_resources.py',
            'prims_ts/batched_gemm/gmem_c_resources.py', 'data/csrc/fused_moe/trtllm_backend/trtllm_fused_moe_dev_kernel.cu'):
 p=FI/rel; out['source_hashes'][str(p)]=sha(p)
out['source_hashes'][str(Path(__file__))] = sha(Path(__file__))
out['cuda_initialized'] = torch.cuda.is_initialized()
assert not out['cuda_initialized']
(OUT/'audit.json').write_text(json.dumps(out, indent=2)+'\n')
print(json.dumps({'layers':out['layers'],'budgets':out['ncu_conditional_budgets'],'cuda_initialized':out['cuda_initialized']}, indent=2))
