"""CPU-only algebra on already recorded prefix and admission evidence."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent

def read(name):
    return json.loads((ROOT / name).read_text())

rows = read('reference-prefix/per-request.json')
proxy = read('reference-prefix/admission-proxy.json')
ledger = read('current-pipeline-service-ledger.json')
recorded_common = read('prefix-reuse-probe.json')['common_prefix_rows']
assert recorded_common == 25
start, end = ledger['time']['first_dispatch_s'], ledger['time']['last_completion_s']
events = [e for e in read('current-pipeline-timeline.json')['records']
          if e['stage'] == 'mixed_backbone' and start <= e['cpu_start_s'] <= end]
assert len(events) == 196
result = []
event_index = 0
for group, check in enumerate(proxy['checks']):
    batch = rows[check['corpus_start']:check['corpus_start'] + check['count']]
    seen = set()
    reference_saved = 0
    for prompt in batch:
        if prompt['prefix_sha256'] in seen:
            reference_saved += prompt['prefix_rows']
        seen.add(prompt['prefix_sha256'])
    common_saved = recorded_common * max(0, len(seen) - 1)
    saved = reference_saved + common_saved
    entry = dict(group=group, stage=check['stage'], corpus_start=check['corpus_start'],
                 count=len(batch), reference_saved=reference_saved,
                 common_saved=common_saved, saved=saved,
                 prompt_tokens=sum(x['prompt_rows'] for x in batch),
                 capacity256_saved=(saved // 256) * 256,
                 capacity64_saved=(saved // 64) * 64)
    if check['stage'] == 'mixed_backbone':
        event = events[event_index]
        event_index += 1
        assert entry['prompt_tokens'] == event['prompt_tokens']
        assert entry['count'] == event['prompt_count']
        entry.update(prefill_capacity=event['prefill_capacity'],
                     decode_capacity=event['decode_padded_batch'],
                     input_rows=event['prefill_capacity'] + event['decode_padded_batch'],
                     gpu_ms=event['gpu_ms'])
    result.append(entry)
mixed = [e for e in result if e['stage'] == 'mixed_backbone']
keys = ('count', 'prompt_tokens', 'prefill_capacity', 'decode_capacity', 'input_rows',
        'reference_saved', 'common_saved', 'saved', 'capacity256_saved', 'capacity64_saved')
sums = {key: sum(e[key] for e in mixed) for key in keys}
assert sums['prompt_tokens'] == 183228 and sums['prefill_capacity'] == 209664
policy = {}
for name, field in [('ideal_rows', 'saved'), ('preserve_padding_round256', 'capacity256_saved'),
                    ('preserve_padding_round64', 'capacity64_saved')]:
    removed = sums[field]
    policy[name] = dict(saved_rows=removed, fraction_of_all_moe_rows=removed/sums['input_rows'],
        eligible_groups=sum(e[field] > 0 for e in mixed),
        optimistic_all_mixed_row_linear_s=sum(e['gpu_ms'] * e[field] / e['input_rows'] / 1000 for e in mixed),
        historical_activation_finalize_row_linear_s=(1.4746666666666666 + .504) * removed / 1344 / 1000)
inputs = ['reference-prefix/per-request.json', 'reference-prefix/admission-proxy.json',
          'prefix-reuse-probe.json', 'current-pipeline-service-ledger.json', 'current-pipeline-timeline.json']
report = dict(status='CPU_PROXY_ONLY_NOT_HIDDEN_PARITY_OR_MEASURED_SPEEDUP',
    source_sha=ledger['launch']['source_sha'], common_prefix_rows=recorded_common,
    input_hashes={name: hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in inputs},
    mixed_totals=sums, policies=policy,
    fixed_work_target=dict(current_diag_s=ledger['summary']['makespan_s'],
        target_s=ledger['output']['total_acoustic_frames']/ledger['reference_budget']['target_frames_s'],
        required_saved_s=ledger['reference_budget']['actual_time_reduction_to_target_s'],
        delete_all_mixed_fixed_rest_fps=ledger['output']['total_acoustic_frames'] /
            (ledger['summary']['makespan_s']-sum(e['gpu_ms'] for e in mixed)/1000)),
    limitations=['FIFO grouping is a proxy: matching 196 prompt sums is not request-ID proof.',
        'Equal raw prefix frames do not establish bit-exact hidden rows across batched numerical paths.',
        'All-mixed row-linear allocation overstates the candidate by scaling unchanged state, teacher, decode and fixed weight work.',
        'Historical activation/finalizer per-row proxy is from an older isolated graph and is not current service kernel attribution.',
        'Original participating padding rows remain computed; bucket surplus may repeat a retained row.',
        'No cache hits from future requests or generation-code speculation are included.'],
    groups=result)
(OUT/'counts.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'mixed_totals':sums,'policies':policy,'fixed_work_target':report['fixed_work_target']},indent=2))
