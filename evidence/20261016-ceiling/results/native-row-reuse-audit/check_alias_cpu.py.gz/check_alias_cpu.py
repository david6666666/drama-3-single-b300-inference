"""CPU-only exact aliases using the previously audited real prompt builder AST."""
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import torch

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
spec = importlib.util.spec_from_file_location('alias_observer', OUT/'observe_alias.py')
observer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(observer)
# Reuse the frozen audit's builder extraction/config/tokenizer setup only.
source = ROOT/'reference-prefix/audit_prefix_cpu.py'
tree = ast.parse(source.read_text())
stop = next(i for i,n in enumerate(tree.body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='samples' for t in n.targets))
ns = {'__file__':str(source)}
exec(compile(ast.Module(body=tree.body[:stop],type_ignores=[]),str(source),'exec'),ns)
samples=[json.loads(line) for line in observer.CORPUS.read_bytes().splitlines()]
rows=json.loads((ROOT/'reference-prefix/per-request.json').read_text())
results=[]
for name,indices,slots in observer.CASES:
    prompts=[ns['ns']['build_drama3_prompt'](samples[i]['text'],ns['tokenizer'],ns['config'],[samples[i]['reference_text']],[torch.tensor(samples[i]['reference_codes'],dtype=torch.int64)]) for i in indices]
    aliases,negatives,descriptions=observer.alias_plan(prompts,indices,rows)
    total=sum(map(len,prompts));padding=observer.P-total
    assert 0<=padding<=observer.SPAN and max(map(len,prompts))<=observer.SPAN
    expected=661 if indices[0] in (1040,1047) else 531
    assert len(aliases)==expected
    # Exact prefix identity, absolute position and slot independence are explicit.
    starts=[];offset=observer.D
    lookup={}
    for p in prompts:
        starts.append(offset)
        for j in range(len(p)): lookup[offset+j]=(p,j)
        offset+=len(p)
    for a,b,pos in aliases:
        pa,ia=lookup[a];pb,ib=lookup[b]
        assert ia==ib==pos and torch.equal(pa[:ia+1],pb[:ib+1])
    for a,b,pos in negatives:
        pa,ia=lookup[a];pb,ib=lookup[b]
        assert ia==ib==pos and not torch.equal(pa[:ia+1],pb[:ib+1])
    results.append(dict(case=name,aliases=len(aliases),negative_pairs=len(negatives),prompt_rows=total,padding_rows=padding,max_prompt_rows=max(map(len,prompts))))
assert not torch.cuda.is_initialized()
result=dict(status='CPU_PASS',cuda_initialized=False,import_check=observer.cpu_check(),cases=results,
    hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (Path(__file__),OUT/'observe_alias.py',source,ROOT/'reference-prefix/per-request.json')})
(OUT/'alias-cpu-check.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
