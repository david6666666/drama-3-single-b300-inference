"""Original native MoE, identical inputs/math; only VMM compression differs."""

import argparse
import gc
import hashlib
import json
import os
import subprocess
import sys
import traceback
from contextlib import ExitStack
from pathlib import Path
from types import SimpleNamespace

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
SOURCE = ROOT / "source-metadata-rebase-95fcb0e"
SOURCE_SHA = "95fcb0ef2662f2caf9bfb7fe6863dc3ad7805b1b"
CKPT = Path(
    "/home/zjy/.cache/huggingface/hub/models--fishaudio--drama-3/snapshots/e0a9218aa48888270f06ef1ed9ea67622c0e17d2"
)
ORACLES = sorted((ROOT / "expert-metadata-rebase").glob("oracle-layer*.pt"))
CAP, CTA, GUARD = 2304, 288, 256
FIELDS = (
    "cta_idx_xy_to_batch_idx",
    "cta_idx_xy_to_mn_limit",
    "permuted_idx_to_token_idx",
    "num_non_exiting_ctas",
    "total_num_padded_tokens",
    "expanded_idx_to_permuted_idx",
)
REPORT = {
    "driver_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "status": "PREPARING",
    "checks": [],
    "allocations": [],
    "graphs": [],
    "timing": [],
    "timing_scope": "Live native metadata + native FC1/activation/FC2/finalizer; common input quantization/logits routing excluded",
    "candidate_kernel_change": False,
    "gpu_performance_claim": False,
}
OUT = HERE


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(16 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def flush():
    (OUT / "result.json").write_text(json.dumps(REPORT, indent=2) + "\n")


def req(name, value, detail=None):
    REPORT["checks"].append({"name": name, "pass": bool(value), "detail": detail})
    flush()
    if not value:
        raise AssertionError(name)


def exact(name, a, b):
    import torch

    equal = (
        a.shape == b.shape
        and a.dtype == b.dtype
        and torch.equal(
            a.detach().contiguous().view(torch.uint8),
            b.detach().contiguous().view(torch.uint8),
        )
    )
    if not equal:
        torch.save(
            {"actual": a.detach().cpu(), "expected": b.detach().cpu()},
            OUT / (name.replace("/", "_") + "-mismatch.pt"),
        )
    req(name, equal, {"shape": list(a.shape), "dtype": str(a.dtype)})


def tensor_hash(t):
    import torch

    return hashlib.sha256(
        t.detach().contiguous().view(torch.uint8).cpu().numpy().tobytes()
    ).hexdigest()


def metadata_check(name, slot, ids, expected_padded):
    import torch

    mp = slot.expanded_idx_to_permuted_idx.long()
    n, p = int(slot.num_non_exiting_ctas), int(slot.total_num_padded_tokens)
    req(
        name + "/bijection",
        mp.numel() == 512
        and mp.unique().numel() == 512
        and 0 < n <= CTA
        and p == 8 * n
        and p <= CAP
        and bool(((mp >= 0) & (mp < p)).all()),
    )
    exact(
        name + "/expert",
        slot.cta_idx_xy_to_batch_idx[mp // 8].long(),
        ids.flatten().long(),
    )
    exact(
        name + "/token",
        slot.permuted_idx_to_token_idx[mp].long(),
        torch.arange(512, device=mp.device) // 8,
    )
    req(name + "/padded", p == int(expected_padded))
    counts = torch.bincount(mp // 8, minlength=n)
    req(name + "/prefix", bool((mp % 8 < counts[mp // 8]).all()))
    exact(
        name + "/mn",
        slot.cta_idx_xy_to_mn_limit[:n].long() - torch.arange(n, device=mp.device) * 8,
        counts,
    )
    return mp, p


def weights(layer, device):
    import torch
    from safetensors import safe_open

    index = json.loads((CKPT / "model.safetensors.index.json").read_text())[
        "weight_map"
    ]

    def key(e, p, s):
        return f"model.language_model.layers.{layer}.mlp.experts.{e}.{p}.{s}"

    keys = [
        key(e, p, s)
        for e in range(256)
        for p in ("up_proj", "gate_proj", "down_proj")
        for s in ("weight", "weight_scale_inv")
    ]
    with ExitStack() as stack:
        handles = {
            f: stack.enter_context(
                safe_open(str(CKPT / f), framework="pt", device="cpu")
            )
            for f in sorted({index[k] for k in keys})
        }

        def get(e, p, s):
            k = key(e, p, s)
            return handles[index[k]].get_tensor(k)

        w1 = torch.stack(
            [
                torch.cat(
                    (get(e, "up_proj", "weight"), get(e, "gate_proj", "weight")), 0
                )
                for e in range(256)
            ]
        )
        s1 = torch.stack(
            [
                torch.cat(
                    (
                        get(e, "up_proj", "weight_scale_inv"),
                        get(e, "gate_proj", "weight_scale_inv"),
                    ),
                    0,
                )
                for e in range(256)
            ]
        )
        w2 = torch.stack([get(e, "down_proj", "weight") for e in range(256)])
        s2 = torch.stack([get(e, "down_proj", "weight_scale_inv") for e in range(256)])
    return [t.to(device) for t in (w1, s1, w2, s2)]


def guarded(shape, dtype, device):
    import math

    import torch

    raw = torch.full((math.prod(shape) + 2 * GUARD,), 37, dtype=dtype, device=device)
    return raw[GUARD:-GUARD].reshape(shape), raw


def make_native(runtime, dataset, w):
    import torch
    from flashinfer.fused_moe import core as fi
    from flashinfer.fused_moe.shared.inputs import MoeRunnerInputs
    from flashinfer.tllm_enums import (
        DtypeTrtllmGen,
        Fp8QuantizationType,
        RoutingInputMode,
    )

    x = {
        dst: dataset[src].cuda()
        for dst, src in [
            ("q", "q"),
            ("s", "input_scale"),
            ("ids", "ids"),
            ("weights", "weights"),
        ]
    }
    runner = runtime.MoERunner(
        runtime.moe_op,
        top_k=8,
        num_local_experts=256,
        dtype_act=DtypeTrtllmGen.E4m3,
        dtype_weights=DtypeTrtllmGen.E4m3,
        fp8_quantization_type=Fp8QuantizationType.DeepSeekFp8,
        hidden_size=2048,
        intermediate_size=512,
        num_experts=256,
    )
    output, out_guard = guarded((64, 2048), torch.bfloat16, "cuda")
    inputs = MoeRunnerInputs(
        output, None, x["ids"], x["weights"], x["q"], x["s"], None, None
    ).to_list()
    kw = {
        "routing_bias": None,
        "num_experts": 256,
        "n_group": None,
        "topk_group": None,
        "routed_scaling_factor": 1.0,
        "routing_method_type": 4,
        "use_shuffled_weight": False,
        "weight_layout": 0,
        "enable_pdl": True,
        "local_expert_offset": 0,
        "do_finalize": True,
        "routing_input_mode": RoutingInputMode.UnpackedPrecomputed,
        "gemm1_weights": w[0],
        "gemm1_weights_scale": w[1],
        "gemm2_weights": w[2],
        "gemm2_weights_scale": w[3],
    }
    meta = fi.trtllm_moe_allocate_routing_metadata_multi_tile(
        x["ids"],
        num_experts=256,
        top_k=8,
        local_expert_offset=0,
        num_local_experts=256,
        tile_ns=[8],
        routing_input_mode=RoutingInputMode.UnpackedPrecomputed,
        topk_weights=x["weights"],
    )
    fi.populate_trtllm_moe_routing_metadata_(meta, x["ids"], x["weights"])
    slot = meta.slots[0]
    body = SimpleNamespace(tile_n=8, tactic=5)
    body_runner = runtime.DABodyRunner(runner)
    originals = tuple(
        t if isinstance(t, torch.Tensor) else torch.from_dlpack(t)
        for t in body_runner.prepare_body(inputs, body, slot, **kw)
    )
    if len(originals) != 7:
        raise RuntimeError("Unexpected native DeepSeek workspace ABI")
    # Native scratch keeps the original prepare allocation and initialization.
    pairs = [guarded(tuple(t.shape), t.dtype, t.device) for t in originals[:5]]
    ws = tuple(pair[0] for pair in pairs) + originals[5:]
    guards = [out_guard] + [pair[1] for pair in pairs]
    if any(t.data_ptr() % 256 for t in (output, *ws[:5])):
        raise RuntimeError("Guarded native tensors lost 256-byte alignment")

    def call():
        fi.populate_trtllm_moe_routing_metadata_(meta, x["ids"], x["weights"])
        body_runner.forward_from_metadata(inputs, body, slot, ws, **kw)

    return {
        "x": x,
        "w": w,
        "output": output,
        "slot": slot,
        "ws": ws,
        "guards": guards,
        "inputs": inputs,
        "runner": body_runner,
        "meta": meta,
        "body": body,
        "kw": kw,
        "call": call,
    }


def update(owner, dataset):
    for dst, src in [
        ("q", "q"),
        ("s", "input_scale"),
        ("ids", "ids"),
        ("weights", "weights"),
    ]:
        owner["x"][dst].copy_(dataset[src])
    owner["output"].fill_(11)
    for t in owner["ws"][:5]:
        t.fill_(23)


def check_owner(name, owner, dataset, before, rng):
    import torch

    mp, p = metadata_check(
        name + "/map",
        owner["slot"],
        owner["x"]["ids"],
        dataset["global_meta"]["padded"],
    )
    for key, idx, channels in [
        ("fc1_bytes", 0, 1024),
        ("activation_bytes", 2, 512),
        ("fc2_bf16", 4, 2048),
    ]:
        exact(
            name + "/" + key,
            owner["ws"][idx].reshape(-1, channels)[mp],
            dataset["intermediates"][key].cuda(),
        )
    for key, idx, blocks in [("fc1_scale", 1, 8), ("activation_scale", 3, 4)]:
        exact(
            name + "/" + key,
            owner["ws"][idx].flatten()[: p * blocks].reshape(blocks, p).T[mp],
            dataset["intermediates"][key].cuda(),
        )
    exact(name + "/routed", owner["output"], dataset["routed"].cuda())
    for key, value in before.items():
        exact(name + "/input_" + key, owner["x"][key], value)
    for idx, raw in enumerate(owner["guards"]):
        exact(
            name + f"/guard{idx}",
            torch.cat((raw[:GUARD], raw[-GUARD:])),
            torch.full_like(raw[: 2 * GUARD], 37),
        )
    exact(name + "/rng", torch.cuda.get_rng_state(), rng)
    return {"mapping": mp.cpu().tolist(), "padded": p}


def graph_capture(owner):
    import cuda.bindings.driver as drv
    import torch

    sys.path.insert(0, str(ROOT / "expert-m128-pdl-metadata-ready"))
    from metadata_ready_graph import _CudaBackend

    graph = torch.cuda.CUDAGraph(keep_graph=True)
    with torch.cuda.graph(graph):
        info = drv.cuStreamGetCaptureInfo(
            drv.CUstream(torch.cuda.current_stream().cuda_stream)
        )
        if int(info[0]) != 0:
            raise RuntimeError(info)
        owner["call"]()
    backend = _CudaBackend()
    backend._graph, backend._driver, backend._torch = graph, drv, torch
    backend._generation = int(info[2])
    backend._handle = drv.CUgraph(graph.raw_cuda_graph())
    snap = backend.snapshot()
    graph.instantiate()
    return graph, backend, snap


def snapshot_dict(snap):
    return {
        "identity": snap.identity,
        "nodes": [vars(n) for n in snap.nodes],
        "edges": [vars(e) for e in snap.edges],
    }


def binding(owner):
    tensors = {
        **owner["x"],
        **{f"w{i}": t for i, t in enumerate(owner["w"])},
        "output": owner["output"],
        **{f"ws{i}": t for i, t in enumerate(owner["ws"])},
        **{f"meta_{f}": getattr(owner["slot"], f) for f in FIELDS},
    }
    return {
        k: {
            "ptr": v.data_ptr(),
            "shape": list(v.shape),
            "stride": list(v.stride()),
            "dtype": str(v.dtype),
            "bytes": v.numel() * v.element_size(),
        }
        for k, v in tensors.items()
    }


def verify_protocol():
    protocol = json.loads((HERE / "protocol.json").read_text())
    for path, digest in json.loads((HERE / "frozen-inputs.json").read_text()).items():
        if sha(path) != digest:
            raise RuntimeError("Frozen input changed: " + path)
    if (
        subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=SOURCE, text=True
        ).strip()
        != SOURCE_SHA
    ):
        raise RuntimeError("Runtime source SHA mismatch")
    if subprocess.check_output(
        ["git", "status", "--porcelain"], cwd=SOURCE, text=True
    ).strip():
        raise RuntimeError("Frozen source is dirty")
    return protocol


def measure(graph, replays):
    import torch

    start, end = (
        torch.cuda.Event(enable_timing=True),
        torch.cuda.Event(enable_timing=True),
    )
    start.record()
    for _ in range(replays):
        graph.replay()
    end.record()
    end.synchronize()
    return start.elapsed_time(end) / replays


def run_gpu():
    import torch

    protocol = verify_protocol()
    req("visible_gpu", os.environ.get("CUDA_VISIBLE_DEVICES") == protocol["gpu_uuid"])
    sys.path.insert(0, str(ROOT / "native-compressed-vmm"))
    import vmm_weights
    from flashinfer.fused_moe import core as fi

    props = torch.cuda.get_device_properties(0)
    req(
        "device_uuid",
        str(props.uuid).removeprefix("GPU-").lower()
        == protocol["gpu_uuid"].removeprefix("GPU-").lower(),
    )
    req(
        "clean_custom_allocator",
        vmm_weights.stats() == {"live": 0, "destroyed": 0, "cleanup_errors": 0},
    )
    runtime = fi.get_trtllm_moe_sm100_module()
    native_binary = protocol["native_binary"]
    req("native_binary_loaded", native_binary in Path("/proc/self/maps").read_text())
    REPORT["native_binary"] = {"path": native_binary, "sha256": sha(native_binary)}
    records = []
    initial_rng = torch.cuda.get_rng_state().clone()
    for layer in (0, 19, 39):
        datasets = [
            torch.load(p, map_location="cpu", weights_only=False)
            for p in ORACLES
            if f"layer{layer}-" in p.name
        ]
        req(f"L{layer}/five_fixtures", len(datasets) == 5)
        real = next(d for d in datasets if d["scenario"] == "real")
        original = weights(layer, "cuda")
        hashes = [tensor_hash(t) for t in original]
        record = {
            "layer": layer,
            "datasets": datasets,
            "real": real,
            "original": original,
            "hashes": hashes,
            "arms": {},
        }
        for arm, compressed in [("control", False), ("compressed", True)]:
            w = list(original)
            for index in (0, 2):
                w[index], meta = vmm_weights.clone_weight(
                    original[index], compression=compressed
                )
                REPORT["allocations"].append(
                    {"layer": layer, "arm": arm, "weight_index": index, **meta}
                )
                req(
                    f"L{layer}/{arm}/flag{index}",
                    meta["compression_actual"] == int(compressed)
                    and meta["compression_requested"] == int(compressed)
                    and meta["pointer"] == w[index].data_ptr(),
                )
                req(
                    f"L{layer}/{arm}/full_bytes{index}",
                    tensor_hash(w[index]) == hashes[index],
                )
                req(
                    f"L{layer}/{arm}/layout{index}",
                    w[index].dtype == original[index].dtype
                    and w[index].shape == original[index].shape
                    and w[index].stride() == original[index].stride(),
                )
            req(
                f"L{layer}/{arm}/shared_original_scales",
                w[1] is original[1] and w[3] is original[3],
            )
            owner = make_native(runtime, real, w)
            owner["call"]()
            torch.cuda.synchronize()
            before = {k: t.clone() for k, t in owner["x"].items()}
            check_owner(f"L{layer}/{arm}/initial", owner, real, before, initial_rng)
            graph, backend, snap = graph_capture(owner)
            arm_record = {
                "owner": owner,
                "graph": graph,
                "backend": backend,
                "snap": snap,
            }
            record["arms"][arm] = arm_record
            REPORT["graphs"].append(
                {
                    "layer": layer,
                    "arm": arm,
                    "snapshot": snapshot_dict(snap),
                    "bindings": binding(owner),
                }
            )
            # One graph per arm/layer is reused across all five live distributions.
            for d in datasets:
                label = f"L{layer}/{arm}/{d['scenario']}"
                update(owner, d)
                before = {k: t.clone() for k, t in owner["x"].items()}
                owner["call"]()
                torch.cuda.synchronize()
                check_owner(label + "/eager", owner, d, before, initial_rng)
                for replay in range(3):
                    graph.replay()
                    torch.cuda.synchronize()
                    check_owner(
                        label + f"/graph{replay}", owner, d, before, initial_rng
                    )
                req(label + "/graph_unchanged", backend.snapshot() == snap)
            update(owner, real)
            for _ in range(5):
                graph.replay()
            torch.cuda.synchronize()
            check_owner(
                f"L{layer}/{arm}/restored_real",
                owner,
                real,
                {k: t.clone() for k, t in owner["x"].items()},
                initial_rng,
            )
            req(
                f"L{layer}/{arm}/weights_after_gate",
                all(tensor_hash(t) == h for t, h in zip(w, hashes)),
            )
        ptrs = [
            {
                v["ptr"]
                for k, v in binding(record["arms"][a]["owner"]).items()
                if k not in ("w1", "w3") and v["bytes"] > 0
            }
            for a in ("control", "compressed")
        ]
        req(f"L{layer}/arms_disjoint_except_shared_scales", not (ptrs[0] & ptrs[1]))
        records.append(record)
    req("all_15_exact_before_timing", len(records) == 3)
    req(
        "all_12_vmm_allocations_live",
        vmm_weights.stats()["live"] == 12
        and vmm_weights.stats()["cleanup_errors"] == 0,
    )
    REPORT["status"] = "EXACT_PASS_TIMING_STARTED"
    flush()
    sequence = {}
    for arm in ("control", "compressed"):
        owners = [r["arms"][arm]["owner"] for r in records]

        def call(owners=owners):
            for owner in owners:
                owner["call"]()

        graph, backend, snap = graph_capture({"call": call})
        sequence[arm] = {
            "graph": graph,
            "backend": backend,
            "snap": snap,
            "owners": owners,
            "call": call,
        }
        REPORT["graphs"].append(
            {
                "scope": "three_layer_sequence",
                "arm": arm,
                "snapshot": snapshot_dict(snap),
            }
        )
        for _ in range(5):
            graph.replay()
    torch.cuda.synchronize()
    for r in records:
        for arm, ar in r["arms"].items():
            check_owner(
                f"L{r['layer']}/{arm}/sequence_pre_timing",
                ar["owner"],
                r["real"],
                {
                    k: r["real"][src].cuda()
                    for k, src in [
                        ("q", "q"),
                        ("s", "input_scale"),
                        ("ids", "ids"),
                        ("weights", "weights"),
                    ]
                },
                initial_rng,
            )
    # A single predeclared AB observation; no opportunistic retiming or sweep.
    for r in records:
        a = measure(r["arms"]["control"]["graph"], protocol["replays"])
        b = measure(r["arms"]["compressed"]["graph"], protocol["replays"])
        REPORT["timing"].append(
            {
                "scope": "single_layer",
                "layer": r["layer"],
                "control_ms": a,
                "compressed_ms": b,
                "latency_reduction": 1 - b / a,
            }
        )
        flush()
    a = measure(sequence["control"]["graph"], protocol["replays"])
    b = measure(sequence["compressed"]["graph"], protocol["replays"])
    REPORT["timing"].append(
        {
            "scope": "three_layer_sequence",
            "control_ms": a,
            "compressed_ms": b,
            "latency_reduction": 1 - b / a,
        }
    )
    for r in records:
        for arm, ar in r["arms"].items():
            torch.cuda.synchronize()
            check_owner(
                f"L{r['layer']}/{arm}/post_timing",
                ar["owner"],
                r["real"],
                {
                    k: r["real"][src].cuda()
                    for k, src in [
                        ("q", "q"),
                        ("s", "input_scale"),
                        ("ids", "ids"),
                        ("weights", "weights"),
                    ]
                },
                initial_rng,
            )
            req(
                f"L{r['layer']}/{arm}/immutable_weights",
                all(tensor_hash(t) == h for t, h in zip(ar["owner"]["w"], r["hashes"])),
            )
            req(
                f"L{r['layer']}/{arm}/post_graph",
                ar["backend"].snapshot() == ar["snap"],
            )
    for arm, seq in sequence.items():
        req(arm + "/sequence_graph_unchanged", seq["backend"].snapshot() == seq["snap"])
    full_gain = REPORT["timing"][-1]["latency_reduction"]
    no_regression = all(t["latency_reduction"] >= -0.01 for t in REPORT["timing"][:-1])
    REPORT["continuation_gate"] = {
        "sequence_at_least_5pct": full_gain >= 0.05,
        "each_layer_no_more1pct_regression": no_regression,
        "passed": full_gain >= 0.05 and no_regression,
        "three_paired_rounds": "NOT_RUN",
        "stress_performance": "NOT_RUN",
    }
    # Graphs and closures are explicitly released before their VMM storage owners.
    for seq in sequence.values():
        seq["graph"].reset()
        seq["backend"]._graph = None
    sequence.clear()
    for r in records:
        for ar in r["arms"].values():
            ar["graph"].reset()
            ar["backend"]._graph = None
    # Remove loop locals that retain closures/owners; records are the last owners.
    del seq, ar, r, owner, owners, w, original, record, arm_record, graph, backend, call
    records.clear()
    gc.collect()
    torch.cuda.synchronize()
    gc.collect()
    REPORT["allocator_post"] = vmm_weights.stats()
    req(
        "allocator_cleaned",
        REPORT["allocator_post"] == {"live": 0, "destroyed": 12, "cleanup_errors": 0},
    )
    REPORT["status"] = (
        "FEASIBILITY_PASS"
        if REPORT["continuation_gate"]["passed"]
        else "FEASIBILITY_FAIL"
    )
    REPORT["native_exact"] = True
    REPORT["runtime_promoted"] = False
    flush()


def cpu_check():
    import torch

    req("cpu_no_cuda_initialization", not torch.cuda.is_initialized())
    req("fifteen_fixtures", len(ORACLES) == 15)
    for path in ORACLES:
        d = torch.load(path, map_location="cpu", weights_only=False)
        md = d["global_meta"]
        n = int(md["ncta"])
        p = int(md["padded"])
        mp = md["expanded"].long()
        route = torch.zeros(CAP + 1, dtype=torch.int32)
        route[mp] = torch.arange(512, dtype=torch.int32) // 8
        slot = SimpleNamespace(
            expanded_idx_to_permuted_idx=mp,
            num_non_exiting_ctas=torch.tensor(n),
            total_num_padded_tokens=torch.tensor(p),
            cta_idx_xy_to_batch_idx=d["cta"],
            cta_idx_xy_to_mn_limit=d["mn"],
            permuted_idx_to_token_idx=route,
        )
        metadata_check(path.stem, slot, d["ids"], p)
        req(
            path.stem + "/five_native_boundaries",
            {
                "fc1_bytes",
                "fc1_scale",
                "activation_bytes",
                "activation_scale",
                "fc2_bf16",
            }.issubset(d["intermediates"]),
        )
    req("cpu_cuda_remains_uninitialized", not torch.cuda.is_initialized())
    REPORT["status"] = "CPU_CONTRACT_PASS"
    flush()


def main():
    global OUT
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=["cpu", "gate-screen"], required=True)
    args = parser.parse_args()
    OUT = HERE / ("cpu" if args.mode == "cpu" else "gpu")
    OUT.mkdir(exist_ok=False)
    REPORT["mode"] = args.mode
    try:
        if args.mode == "cpu":
            cpu_check()
        else:
            import torch

            with torch.inference_mode():
                run_gpu()
    except Exception as error:
        REPORT.update(
            status="FAIL", error=repr(error), traceback=traceback.format_exc()
        )
        flush()
        raise


if __name__ == "__main__":
    main()
