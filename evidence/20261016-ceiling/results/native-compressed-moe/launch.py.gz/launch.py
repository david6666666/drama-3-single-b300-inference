"""One isolated gate and AB screen. No repeated timing or automatic promotion."""

import hashlib
import json
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
PY = "/home/zjy/code/hsliu/venvs/codex-drama3-standalone/bin/python"


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(16 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def query(gpu):
    out = subprocess.check_output(
        [
            "nvidia-smi",
            "--query-compute-apps=gpu_uuid,pid,used_gpu_memory",
            "--format=csv,noheader,nounits",
        ],
        text=True,
    )
    rows = []
    for line in out.splitlines():
        parts = [part.strip() for part in line.split(",")]
        if parts[0] == gpu:
            rows.append(
                {"uuid": parts[0], "pid": int(parts[1]), "memory_mib": parts[2]}
            )
    memory = int(
        subprocess.check_output(
            [
                "nvidia-smi",
                "-i",
                gpu,
                "--query-gpu=memory.used",
                "--format=csv,noheader,nounits",
            ],
            text=True,
        ).strip()
    )
    return {"time": time.time(), "processes": rows, "memory_mib": memory}


def owned_pid(pid, pgid):
    try:
        return os.getpgid(pid) == pgid
    except ProcessLookupError:
        return False


def terminate_owned_group(pgid):
    try:
        os.killpg(pgid, signal.SIGTERM)
        time.sleep(0.5)
        os.killpg(pgid, signal.SIGKILL)
    except ProcessLookupError:
        pass


def main():
    protocol = json.loads((HERE / "protocol.json").read_text())
    manifest = json.loads((HERE / "frozen-inputs.json").read_text())
    for path, digest in manifest.items():
        if sha(path) != digest:
            raise RuntimeError("Frozen input changed: " + path)
    result = HERE / "launch-result.json"
    if result.exists() or (HERE / "gpu").exists():
        raise RuntimeError("Refusing to overwrite prior execution")
    report = {
        "status": "PREPARING",
        "protocol_sha256": hashlib.sha256(
            (HERE / "protocol.json").read_bytes()
        ).hexdigest(),
        "audits": [],
        "ownership_scope": "Sampled every 1 second; not a proof of continuous exclusivity",
    }

    def save():
        result.write_text(json.dumps(report, indent=2) + "\n")

    gpu = protocol["gpu_uuid"]
    pre = query(gpu)
    report["audits"].append(pre)
    if pre["processes"] or pre["memory_mib"] > 256:
        report["status"] = "PREFLIGHT_OCCUPIED"
        save()
        return 2
    environment = os.environ.copy()
    environment.update(protocol["environment"])
    environment.update(
        CUDA_VISIBLE_DEVICES=gpu, PYTHONUNBUFFERED="1", PYTHONDONTWRITEBYTECODE="1"
    )
    proc = None
    pgid = None
    start = time.monotonic()
    try:
        with (
            (HERE / "stdout.log").open("x") as stdout,
            (HERE / "stderr.log").open("x") as stderr,
        ):
            proc = subprocess.Popen(
                [PY, str(HERE / "driver.py"), "--mode", "gate-screen"],
                env=environment,
                cwd=HERE,
                stdout=stdout,
                stderr=stderr,
                start_new_session=True,
            )
            pgid = proc.pid
            report["pid"] = proc.pid
            save()
            while proc.poll() is None:
                audit = query(gpu)
                report["audits"].append(audit)
                save()
                if any(not owned_pid(row["pid"], pgid) for row in audit["processes"]):
                    raise RuntimeError("FOREIGN_PROCESS_DETECTED")
                if time.monotonic() - start > protocol["watchdog_seconds"]:
                    raise TimeoutError("Gate-screen watchdog")
                time.sleep(1)
            report["exit_code"] = proc.returncode
            if proc.returncode:
                raise RuntimeError("Driver nonzero exit")
        report["status"] = "CHILD_COMPLETE"
    except Exception as error:  # noqa: BLE001 -- archive and clean only the owned process group
        report.update(status="FAIL", error=repr(error))
        if pgid is not None:
            terminate_owned_group(pgid)
        if proc is not None:
            proc.wait(timeout=10)
    finally:
        report["elapsed_seconds"] = time.monotonic() - start
        try:
            # Wait only for this process group's already-exited GPU bookkeeping.
            deadline = time.monotonic() + 5
            while True:
                post = query(gpu)
                report["audits"].append(post)
                if not post["processes"] or time.monotonic() >= deadline:
                    break
                if pgid is None or any(
                    not owned_pid(row["pid"], pgid) for row in post["processes"]
                ):
                    break
                time.sleep(0.5)
            report["post"] = post
            if post["processes"]:
                report["status"] = "POST_PROCESS_AUDIT_FAIL"
        except Exception as error:  # noqa: BLE001 -- archive and clean only the owned process group
            report.update(status="POST_PROCESS_AUDIT_FAIL", post_error=repr(error))
        save()
    return 0 if report["status"] == "CHILD_COMPLETE" else 1


if __name__ == "__main__":
    sys.exit(main())
