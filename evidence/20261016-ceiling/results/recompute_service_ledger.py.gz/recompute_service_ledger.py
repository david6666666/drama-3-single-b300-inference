"""CPU-only request accounting and optional nonblocking-event diagnostics.

This is not an acceptance validator. It preserves all requests and distinguishes
client/PCM delivery observations, CUDA event spans, and the isolated B64 reference.
"""
import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import statistics


def quantile(values, q):
    values = sorted(values)
    if not values:
        return None
    pos = (len(values) - 1) * q
    i = int(pos)
    return values[i] + (values[min(i + 1, len(values) - 1)] - values[i]) * (pos - i)


def describe(values):
    return dict(n=len(values), sum=sum(values), mean=statistics.mean(values) if values else None,
                min=min(values) if values else None, p50=quantile(values, .5),
                p95=quantile(values, .95), p99=quantile(values, .99), max=max(values) if values else None)


def merge(intervals):
    result = []
    for lo, hi in sorted(intervals):
        if result and lo <= result[-1][1]:
            result[-1][1] = max(hi, result[-1][1])
        else:
            result.append([lo, hi])
    return result


def length(intervals):
    return sum(hi - lo for lo, hi in merge(intervals))


def overlap(a, b):
    a, b = merge(a), merge(b)
    i = j = 0
    total = 0.
    while i < len(a) and j < len(b):
        total += max(0., min(a[i][1], b[j][1]) - max(a[i][0], b[j][0]))
        if a[i][1] < b[j][1]:
            i += 1
        else:
            j += 1
    return total


def file_info(path):
    return dict(path=str(path), sha256=hashlib.sha256(path.read_bytes()).hexdigest(), bytes=path.stat().st_size)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', type=Path, required=True)
    parser.add_argument('--timeline', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    reqpath = args.run / 'benchmark/c64-r0.jsonl'
    sumpath = args.run / 'benchmark/summary.json'
    manpath = args.run / 'benchmark/manifest.json'
    rows = [json.loads(line) for line in reqpath.read_text().splitlines() if line.strip()]
    summary = json.loads(sumpath.read_text())[0]
    manifest = json.loads(manpath.read_text())
    rows.sort(key=lambda row: row['dispatch_s'])
    c = summary['concurrency']
    start = rows[0]['dispatch_s']
    fill_end = rows[min(c, len(rows)) - 1]['dispatch_s']
    last_dispatch = rows[-1]['dispatch_s']
    end = max(r['dispatch_s'] + r['completion_s'] for r in rows)
    good = [r for r in rows if r['success']]
    frames = sum(r['audio_samples'] / 2048 for r in good)
    dispatches = [r['dispatch_s'] for r in rows]
    completions = sorted(r['dispatch_s'] + r['completion_s'] for r in rows)
    arrivals = [(r['dispatch_s'] + t, n / 4096) for r in good
                for t, n in zip(r['chunk_arrivals_s'], r['chunk_bytes'], strict=True)]
    assert abs(sum(n for _, n in arrivals) - frames) < 1e-6
    ideal = 64 / .008275
    exact_ideal = 64 / .008275183868408202
    target = 6765.407263214912
    intervals = [(r['dispatch_s'], r['dispatch_s'] + r['completion_s']) for r in rows]
    phases = {}
    for name, lo, hi, include_lo in [('initial_client_fill', start, fill_end, True),
                                    ('continuous_intake_after_fill', fill_end, last_dispatch, False),
                                    ('final_drain', last_dispatch, end, False)]:
        occupied = sum(max(0., min(hi, e) - max(lo, d)) for d, e in intervals)
        delivered = sum(n for t, n in arrivals if (t >= lo if include_lo else t > lo) and t <= hi)
        duration = hi - lo
        phases[name] = dict(start_offset_s=lo - start, end_offset_s=hi - start,
                            duration_s=duration, delivered_frames=delivered,
                            delivered_frames_per_s=delivered / duration if duration else None,
                            client_inflight_request_seconds=occupied,
                            time_weighted_client_inflight=occupied / duration if duration else None,
                            missing_client_request_seconds=c * duration - occupied,
                            full_concurrency_equivalent_client_deficit_s=duration - occupied / c,
                            frame_delivery_algebraic_gap_to_reference_s=duration - delivered / ideal)
    refill = [d - e for d, e in zip(dispatches[c:], completions[:len(rows) - c], strict=True)]
    pairing_valid = all(v >= 0 for v in refill)
    tail_rows = [r for r in rows if r['dispatch_s'] + r['completion_s'] > last_dispatch]
    top_tail = sorted(tail_rows, key=lambda r:r['dispatch_s'] + r['completion_s'], reverse=True)[:20]
    at_limit = sum(r['acoustic_frames'] == manifest['max_frames'] for r in good)
    result = dict(
        diagnostic_only=True, generated_at_utc=datetime.now(timezone.utc).isoformat(),
        inputs={n:file_info(p) for n,p in [('requests',reqpath),('summary',sumpath),('manifest',manpath)]},
        launch=json.loads((args.run / 'launch.json').read_text()) if (args.run / 'launch.json').exists() else None,
        summary=summary,
        completeness=dict(requests=len(rows), successful=len(good), unique_request_ids=len({r['request_id'] for r in rows}),
                          unique_sample_ids=len({r['sample_id'] for r in rows}), corpus_sha256=manifest['corpus_sha256']),
        output=dict(total_acoustic_frames=frames, frames=describe([r['acoustic_frames'] for r in good]),
                    total_audio_seconds=sum(r['audio_duration_s'] for r in good), max_frame_outputs=at_limit,
                    rms_below_001=sum(r['rms'] < .001 for r in good),
                    conditional_eos_terminations=len(good)-at_limit,
                    conditional_decode_backbone_request_rows=frames-at_limit,
                    conditional_row_count_assumption='All successes use native Engine EOS/max_frames termination with no cancellation. First frame uses prefill hidden; each non-limit request needs one terminal EOS decode. Raw PCM does not expose finish reason.'),
        time=dict(first_dispatch_s=start, client_fill_end_s=fill_end, last_dispatch_s=last_dispatch,
                  last_completion_s=end, raw_request_window_s=end-start,
                  benchmark_wrapper_overhead_s=summary['makespan_s']-(end-start),
                  completion_latency_s=describe([r['completion_s'] for r in rows]),
                  completion_minus_last_audio_s=describe([r['completion_s']-r['last_audio_s'] for r in good])),
        dispatch=dict(interarrival_s=describe([b-a for a,b in zip(dispatches,dispatches[1:])]),
                      post_initial_wave_interarrival_s=describe([dispatches[i]-dispatches[i-1] for i in range(c,len(rows))]),
                      completion_to_next_dispatch_s=describe(refill), completion_dispatch_pairing_nonnegative=pairing_valid,
                      pairing_basis='Closed-loop worker has no await between end timestamp / PCM accounting / next request dispatch; sorted first N-C completions pair with the N-C refill dispatches. This is client processing/loop gap, not server admission delay.'),
        client_phases=phases,
        tail=dict(requests_remaining_after_last_dispatch=len(tail_rows),
                  remaining_request_total_frames=sum(r.get('acoustic_frames',0) for r in tail_rows),
                  latest_finishes=[dict(request_id=r['request_id'], sample_id=r['sample_id'],
                                      frames=r.get('acoustic_frames'), rms=r.get('rms'),
                                      dispatch_offset_s=r['dispatch_s']-start,
                                      completion_offset_s=r['dispatch_s']+r['completion_s']-start,
                                      completion_after_last_dispatch_s=r['dispatch_s']+r['completion_s']-last_dispatch,
                                      delivered_frames_after_last_dispatch=sum(n/4096 for t,n in zip(r.get('chunk_arrivals_s',[]),r.get('chunk_bytes',[]),strict=True) if r['dispatch_s']+t > last_dispatch)) for r in top_tail]),
        reference_budget=dict(rounded_decode_ms=8.275, exact_decode_ms=8.275183868408202,
                              rounded_full_B64_frames_s=ideal, exact_full_B64_frames_s=exact_ideal,
                              target_frames_s=target, target_fraction_of_reference=target/ideal,
                              observed_fraction_of_reference=summary['throughput_frames_s']/ideal,
                              required_relative_throughput_gain=target/summary['throughput_frames_s']-1,
                              output_equivalent_reference_time_s=frames/ideal,
                              actual_minus_reference_time_s=summary['makespan_s']-frames/ideal,
                              output_equivalent_target_time_s=frames/target,
                              actual_time_reduction_to_target_s=summary['makespan_s']-frames/target,
                              target_time_above_reference_s=frames/target-frames/ideal,
                              limitations='Reference assumes continuous full B64 at one isolated measured step duration; does not include prompt/first-frame work, incomplete batches, state/context variation, resource contention or transport. It is neither a proven hardware upper bound nor a guaranteed serving lower bound.'))
    if args.timeline:
        result['inputs']['timeline'] = file_info(args.timeline)
        raw = json.loads(args.timeline.read_text())['records']
        events = [r for r in raw if start <= r['cpu_start_s'] <= end]
        def scope(e):
            return [(e['gpu_start_ms'],e['gpu_end_ms'])]
        def phase(e):
            return 'initial_client_fill' if e['cpu_start_s'] <= fill_end else 'continuous_intake_after_fill' if e['cpu_start_s'] <= last_dispatch else 'final_drain'
        def stats(es):
            return dict(calls=len(es), batch_histogram=dict(sorted(Counter(e['batch'] for e in es).items())),
                        call_weighted_active=statistics.mean(e['batch'] for e in es) if es else None,
                        event_time_weighted_active=sum(e['batch']*e['gpu_ms'] for e in es)/sum(e['gpu_ms'] for e in es) if es else None,
                        gpu_event_ms=describe([e['gpu_ms'] for e in es]),
                        gpu_event_union_ms=length([scope(e)[0] for e in es]),
                        cpu_submit_or_wait_ms=describe([e['cpu_submit_ms'] for e in es]))
        bystage = defaultdict(list)
        byphase = defaultdict(lambda:defaultdict(list))
        for e in events:
            bystage[e['stage']].append(e)
            byphase[phase(e)][e['stage']].append(e)
        model_stages={'decode','mixed_backbone','first_frame','mixed_decode_tower','prefill'}
        model_events=[e for e in events if e['stage'] in model_stages]
        codec_events=[e for e in events if e['stage'] in {'codec','codec_gpu_and_copy'}]
        model_iv=[scope(e)[0] for e in model_events]
        codec_iv=[scope(e)[0] for e in codec_events]
        all_iv=[scope(e)[0] for e in events]
        shared=overlap(model_iv,codec_iv)
        env=max(e['gpu_end_ms'] for e in events)-min(e['gpu_start_ms'] for e in events)
        buckets=(1,2,4,8,12,16,24,32,40,48,56,64)
        decodegroups=defaultdict(lambda:defaultdict(list))
        for e in bystage['decode']:
            ov=overlap(scope(e),codec_iv)
            ee={**e,'codec_overlap_ms':ov}
            label='with_codec_overlap' if ov > .001 else 'no_codec_overlap'
            decodegroups[str(e['batch'])][label].append(ee)
        stratified={}
        for batch,groups in sorted(decodegroups.items(),key=lambda p:int(p[0])):
            stratified[batch]={label:{**stats(es),'codec_overlap_ms':describe([e['codec_overlap_ms'] for e in es]),
                                     'client_phase_histogram':dict(Counter(phase(e) for e in es))} for label,es in groups.items()}
        decode=bystage['decode']
        active_rows=sum(e['batch'] for e in decode)
        padded_rows=sum(e.get('padded_batch', next(b for b in buckets if b>=e['batch'])) for e in decode)
        timeline=dict(selected_events=len(events),excluded_events=len(raw)-len(events),
                      cuda_streams=sorted(set(e['cuda_stream'] for e in events)),
                      stage={name:stats(es) for name,es in bystage.items()},
                      by_client_submission_phase={p:{name:stats(es) for name,es in stages.items()} for p,stages in byphase.items()},
                      union=dict(gpu_event_envelope_ms=env, all_recorded_union_ms=length(all_iv),
                                 model_event_union_ms=length(model_iv), codec_event_union_ms=length(codec_iv),
                                 model_codec_overlap_ms=shared, model_only_ms=length(model_iv)-shared,
                                 codec_only_ms=length(codec_iv)-shared,
                                 neither_model_nor_codec_in_envelope_ms=env-length(model_iv+codec_iv),
                                 outside_all_recorded_events_in_envelope_ms=env-length(all_iv)),
                      pure_decode_call_row_padding=dict(active_call_rows=active_rows,padded_call_rows=padded_rows,
                                                        padded_over_active_fraction=padded_rows/active_rows-1,
                                                        limitation='Call-row weighting, not GPU time or generated rows. Single-request multi-step decode can execute 2/4 steps per event; event metadata does not expose steps.'),
                      pure_decode_same_active_overlap_groups=stratified,
                      limitations=['All events selected by CPU submission time inside the measured request window; phase is a client submission proxy, not a GPU execution boundary.',
                                   'Event spans include possible host launch gaps; union is not kernel busy time or SM utilization.',
                                   'codec_submit is nested host submission scope; excluded from model and codec compute-stage unions, retained in all-recorded union.',
                                   'Overlap groups with equal active count still differ in context lengths, execution time, and cache/resource history; observed differences do not prove a causal codec slowdown.',
                                   'mixed_backbone contains prefill teacher tower; first_frame CPU time may wait for prior mixed GPU work.',
                                   'Prompt token sum/capacity/span and active/pending server queues are not present in the existing event schema; do not invent them.',
                                   'No synchronous historical profile proportion was transferred to this asynchronous profile.'])
        mixed_old_rows = sum(e['batch'] for e in bystage['mixed_backbone'])
        conditional_rows = result['output']['conditional_decode_backbone_request_rows']
        pure_rows = conditional_rows - mixed_old_rows
        extra_single_steps = pure_rows - active_rows
        has_steps = all('steps' in e and 'padded_batch' in e for e in decode)
        conditional_rows_expected = conditional_rows
        if has_steps:
            pure_rows = sum(e['batch'] * e['steps'] for e in decode)
            conditional_rows = pure_rows + mixed_old_rows
            extra_single_steps = sum(e['steps'] - 1 for e in decode)
        row_time_ms = 8.275 / 64
        model_union_by_stage = {stage:length([scope(e)[0] for e in bystage[stage]]) for stage in model_stages}
        mixed_stages = ('mixed_backbone','first_frame','mixed_decode_tower')
        components = dict(
            pure_decode_above_reference_row_allowance_s=(model_union_by_stage['decode']-pure_rows*row_time_ms)/1000,
            mixed_refill_plus_towers_above_old_decode_row_allowance_s=(sum(model_union_by_stage[n] for n in mixed_stages)-mixed_old_rows*row_time_ms)/1000,
            initial_prefill_s=model_union_by_stage['prefill']/1000,
            codec_only_s=(length(codec_iv)-shared)/1000,
            neither_model_nor_codec_s=(env-length(model_iv+codec_iv))/1000,
            benchmark_wall_minus_gpu_event_envelope_s=summary['makespan_s']-env/1000,
            first_frame_EOS_row_count_correction_s=-(frames-conditional_rows)*row_time_ms/1000)
        mixed_pad=sum(e.get('decode_padded_batch', next(b for b in (16,32,48,64) if b>=e['batch'])) for e in bystage['mixed_backbone'])
        timeline['conditional_decode_row_accounting']=dict(
            total_decode_backbone_request_rows=conditional_rows, mixed_old_request_rows=mixed_old_rows,
            pure_decode_request_rows=pure_rows, additional_single_request_multistep_rows=extra_single_steps,
            conditional_pure_decode_actual_steps=len(decode)+extra_single_steps,
            conditional_step_weighted_pure_decode_active=pure_rows/(len(decode)+extra_single_steps),
            pure_padding_fraction_including_extra_single_steps=(sum(e['padded_batch']*e['steps'] for e in decode) if has_steps else padded_rows+extra_single_steps)/pure_rows-1,
            row_count_source='Recorded steps and padded_batch' if has_steps else 'Conditional EOS/frame inference',
            conditional_expected_productive_decode_rows=conditional_rows_expected,
            observed_executed_minus_conditional_productive_rows=conditional_rows-conditional_rows_expected if has_steps else None,
            steps_histogram=dict(sorted(Counter(e.get('steps', 1) for e in decode).items())) if has_steps else None,
            mixed_decode_padding_call_rows=mixed_pad,
            mixed_decode_padding_over_active_fraction=mixed_pad/mixed_old_rows-1,
            assumptions=('Steps and padded_batch are recorded directly; all model executions count, including a graph step after native EOS within a multistep event. Conditional productive rows are retained separately.' if has_steps else 'Native EOS/max_frames successful termination; batched multistep disabled, so unrecorded extra steps belong to B1. These are inferred counts, not steps recorded by the profiler.'))
        timeline['reference_gap_decomposition']=dict(components_s=components, sum_s=sum(components.values()),
            direct_gap_s=summary['makespan_s']-frames/ideal,
            closure_error_s=sum(components.values())-(summary['makespan_s']-frames/ideal),
            limitations='Algebraic account of the isolated-B64 reference gap, not additive recoverable speedups. Mixed residual includes required prompt and teacher/first-frame work; decode residual includes underfill, context, codec contention and launch effects.')
        timeline['model_stage_codec_overlap_ms']={stage:overlap([scope(e)[0] for e in bystage[stage]],codec_iv) for stage in model_stages}
        groups={}
        for b in range(57,65):
            ss=[e for e in decode if e['batch']==b and e['cpu_start_s']<=last_dispatch]
            yes=[e for e in ss if overlap(scope(e),codec_iv)>.001]
            no=[e for e in ss if overlap(scope(e),codec_iv)<=.001]
            groups[b]={'with_codec':describe([e['gpu_ms'] for e in yes]),'without_codec':describe([e['gpu_ms'] for e in no])}
        timeline['continuous_same_active_overlap_ms']=groups
        timeline['matched_overlap_association']=dict(
            summed_difference_ms=sum(g['with_codec']['n']*(g['with_codec']['mean']-g['without_codec']['mean']) for g in groups.values() if g['with_codec']['n'] and g['without_codec']['n']),
            interpretation='Observed same-active (57..64), same-client-intake phase association relative to no-overlap group mean, not causal or guaranteed recoverable; context/cache history still uncontrolled.')
        if has_steps:
            timeline['pure_decode_call_row_padding']['limitation'] = 'Call-row weighting; use conditional_decode_row_accounting for observed execution-step weighting.'
            timeline['limitations'][5] = 'New rich records expose prompt token/capacity/span, decode steps and codec job partitions; active/pending queue depths and model context lengths remain unavailable.'
        rich_mixed = [e for e in bystage['mixed_backbone'] if 'prompt_tokens' in e]
        if rich_mixed:
            byshape = defaultdict(list)
            for e in rich_mixed:
                byshape[f"D{e['decode_padded_batch']}/P{e['prefill_capacity']}/S{e['prompt_span']}"] .append(e)
            timeline['mixed_recorded_metadata'] = dict(
                events=len(rich_mixed), prompt_count=sum(e['prompt_count'] for e in rich_mixed),
                prompt_tokens=sum(e['prompt_tokens'] for e in rich_mixed),
                prefill_capacity=sum(e['prefill_capacity'] for e in rich_mixed),
                prompt_token_padding_fraction=sum(e['prefill_capacity'] for e in rich_mixed)/sum(e['prompt_tokens'] for e in rich_mixed)-1,
                prompt_count_distribution=describe([e['prompt_count'] for e in rich_mixed]),
                prompt_tokens_distribution=describe([e['prompt_tokens'] for e in rich_mixed]),
                shape_stats={k:stats(v) for k,v in sorted(byshape.items())},
                span_histogram=dict(Counter(e['prompt_span'] for e in rich_mixed)))
        rich_codec = [e for e in codec_events if 'emit_id' in e]
        if rich_codec:
            framegroups = defaultdict(list)
            emits = defaultdict(list)
            for e in rich_codec:
                framegroups[(e['emit_id'], e['frame_group_id'])].append(e)
                emits[e['emit_id']].append(e)
            partitions=[]
            for key, es in framegroups.items():
                first=es[0]
                n=first['requested_jobs']; limit=min(16,512//first['frame_bucket'])
                min_calls=(n+limit-1)//limit
                partitions.append(dict(emit_id=key[0], frame_group_id=key[1], frame_bucket=first['frame_bucket'], requested_jobs=n,
                    selected_batches=first['selected_batches'], actual_calls=len(es), minimum_calls=min_calls,
                    avoidable_partition_calls=len(es)-min_calls, gpu_event_ms=sum(e['gpu_ms'] for e in es)))
                assert len(es)==len(first['selected_batches'])
                assert sum(e['actual_batch'] for e in es)==n
            actual_rows=sum(e['actual_batch'] for e in rich_codec)
            valid_frames=sum(sum(e['valid_frames']) for e in rich_codec)
            actual_bucket_frames=sum(e['actual_batch']*e['frame_bucket'] for e in rich_codec)
            padded_bucket_frames=sum(e['padded_batch']*e['frame_bucket'] for e in rich_codec)
            timeline['codec_recorded_partition_accounting']=dict(
                codec_calls=len(rich_codec), nonempty_emits=len(emits), frame_groups=len(framegroups),
                minimum_calls_same_frame_groups=sum(g['minimum_calls'] for g in partitions),
                avoidable_partition_calls=sum(g['avoidable_partition_calls'] for g in partitions),
                frame_diversity_extra_groups=len(framegroups)-len(emits),
                actual_request_rows=actual_rows, valid_frames=valid_frames,
                actual_bucket_frames=actual_bucket_frames, padded_bucket_frames=padded_bucket_frames,
                frame_padding_fraction=actual_bucket_frames/valid_frames-1,
                combined_frame_batch_padding_fraction=padded_bucket_frames/valid_frames-1,
                batch_padding_fraction=sum(e['padded_batch'] for e in rich_codec)/actual_rows-1,
                frame_bucket_stats={str(f):stats([e for e in rich_codec if e['frame_bucket']==f]) for f in sorted({e['frame_bucket'] for e in rich_codec})},
                groups_per_nonempty_emit=dict(sorted(Counter(len({e['frame_group_id'] for e in es}) for es in emits.values()).items())),
                changed_partitions=[g for g in partitions if g['avoidable_partition_calls']],
                caveat='Minimum legal launches holds currently ready frame buckets fixed, uses captured max_batch16 and max_padded_frames512; does not claim lower latency, identical BF16 rounding, or safe cross-bucket coalescing.')
        result['timeline']=timeline
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(dict(output=str(args.output),frames=frames,summary=summary,
                         phases=phases,reference_budget=result['reference_budget']),indent=2))


if __name__=='__main__':
    main()
