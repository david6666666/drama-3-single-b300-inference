import datetime,hashlib,json,os,subprocess,threading
from pathlib import Path
root=Path(__file__).resolve().parent;source=root.parent/'source-router-463d837'
python='/home/zjy/code/hsliu/venvs/codex-drama3-standalone/bin/python'
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()
assert sha=='463d837cd51fb62196378835a33731cb659a66c8'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True).strip()
assert json.loads((root/'warp-tiles-expanded-result.json').read_text())['status']=='ALL_LAYER_AND_GRAPH_EXACT_PASS'
uuid='GPU-40e00845-d89c-1393-2c32-a2dca3ee9442'
query=['nvidia-smi','--query-compute-apps=gpu_uuid,pid,process_name,used_gpu_memory','--format=csv,noheader']
before=subprocess.check_output(query,text=True);assert uuid not in before
flags=json.loads((root/'expanded-experiment.json').read_text())['flags']
env={k:v for k,v in os.environ.items() if not k.startswith('DRAMA3_')}
env.update(flags,CUDA_VISIBLE_DEVICES=uuid,OMP_NUM_THREADS='8',FLA_USE_FAST_OPS='0',PYTHONPATH=f'{source}/src:{source}/scripts:/home/zjy/code/hsliu/drama3-sources/fish-speech')
files=['fused_norm_warp_tiles.py','benchmark_warp_tiles.py','run_warp_tiles_timing.py','warp-tiles-compiler-audit.md','C3-warp-tiles.ptx','warp-tiles-expanded-result.json']
files += [str(p.relative_to(root)) for p in sorted((root/'warp-tiles-native-layer-inputs').glob('*.pt'))]
plan=dict(source_sha=sha,artifacts_sha256={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in files},hypothesis='Four independent nativeV32 warp subtiles preserve original Q/K and K-dot reduction/FMA trees; a separate exact native norm layout fuses postprocessing without numerical change.',scope='After all180layercases and6fullgraphs pass exact, measure30native real B64layer recurrence+zcopy+norm graphs, A versus C3 no-dump. 6alternatingAB/BA samples perarm,100replays each,resetinitialstate outsideevents; exactfinalstates/outputs eachrepeat. No runtime edits or fullservice claim.',gate='Expanded exact PASS prerequisite; compact benchmark input remapping must first give bitwise equal state/output. Every timing repeat must end with bitwise equal state/output; median combined all30layer latency reduction>=5%. Stop on mismatch/error. No runtime integration or fullservicepromotion from localgate.',gpu_uuid=uuid,before_processes=before,flags=flags,command=[python,str(root/'benchmark_warp_tiles.py')])
(root/'warp-tiles-timing-experiment.json').write_text(json.dumps(plan,indent=2)+'\n')
stop=threading.Event()
def audit():
 with (root/'warp-tiles-timing-process-audit.jsonl').open('w') as f:
  while not stop.is_set():
   p=subprocess.run(query,text=True,capture_output=True);f.write(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),processes=p.stdout.splitlines()))+'\n');f.flush();stop.wait(1)
t=threading.Thread(target=audit);t.start()
try:
 with (root/'warp-tiles-timing.log').open('w') as f:p=subprocess.run(plan['command'],env=env,stdout=f,stderr=subprocess.STDOUT)
 (root/'warp-tiles-timing-exit.json').write_text(json.dumps(dict(exit_code=p.returncode))+'\n')
finally:stop.set();t.join()
