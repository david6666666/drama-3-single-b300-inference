"""Expanded native GDN C2 numerical gates; original exact failure is retained."""
import json,os,sys,subprocess
from pathlib import Path
from types import SimpleNamespace,MethodType
ROOT=Path(__file__).resolve().parent;SOURCE=ROOT.parent/'source-router-463d837'
sys.path[:0]=[str(SOURCE/'src'),str(SOURCE/'scripts'),'/home/zjy/code/hsliu/drama3-sources/fish-speech']
import torch
import torch.nn.functional as F
import triton
from fish_speech.models.text2semantic.fish_omni.generate import build_drama3_prompt
import drama3.model as module
from drama3.engine import BatchedPrefillGraph,DecodeGraph,state_pool_size
from drama3.model import DramaModel
from drama3.runtime_state import DeviceRequests
from validate_mixed_layers import snapshot,restore,state_tensors
from fused_norm_v2 import launch
from reference_helpers import reference,head_rrms
from validate_first_layer import fullhead,CHECKPOINT,CORPUS
report=dict(status='RUNNING',source_sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip(),old_exact_gate='EXACT_FAIL preserved',protocol=json.loads((ROOT/'expanded-experiment.json').read_text()),layers=[],graphs=[],timing_run=False)
OUT=ROOT/'expanded-result.json'
def save():OUT.write_text(json.dumps(report,indent=2)+'\n')
def fail(row):
    report['status']='NUMERIC_FAIL';report['first_failure']=row;save();raise AssertionError(row)

@torch.inference_mode()
def main():
    torch.set_num_threads(8);save()
    model=DramaModel(CHECKPOINT,slots=state_pool_size(64),max_length=2048)
    device=DeviceRequests(model.slots,model.config.eos_token_id,model.max_length)
    samples=[json.loads(x) for x in CORPUS.read_bytes().splitlines()][:64]
    prompts=[build_drama3_prompt(s['text'],model.weights.tokenizer,model.config,[s['reference_text']],[torch.tensor(s['reference_codes'])]) for s in samples]
    prefill=BatchedPrefillGraph(model,8,triton.next_power_of_2(max(map(len,prompts))))
    first=DecodeGraph(model,8,first_frame=True,requests=device)
    graphs={n:DecodeGraph(model,n,requests=device) for n in (1,8,32,64)}
    active=[SimpleNamespace(slot=i,position=len(p)-1) for i,p in enumerate(prompts)]
    for i,p in enumerate(prompts):
        history=F.pad(p[-16:,0],(max(0,16-len(p)),0),value=-1).cuda();device.initialize(i,p[-1].cuda(),history,len(p)-1,500)
    for start in range(0,64,8):
        hidden=prefill.run(prompts[start:start+8],list(range(start,start+8)));first.run(active[start:start+8],hidden)
    for _ in range(8):graphs[64].run(active)
    tensors=state_tensors(model,device);base=snapshot(tensors.values());rng=torch.cuda.get_rng_state()
    native_decode,native_norm=module.gdn_decode,module.gated_norm
    # The original call order identifies the30 GDN layers.
    pending={};case={};visited=[]
    def observe_decode(mixed,a,b,log,bias,state,out,slots):
        assert not pending
        pending.update(mixed=mixed,a=a,b=b,log=log,bias=bias,initial_state=state.clone(),slots=slots.clone(),z=torch.as_strided(a,(len(slots),4096),(a.stride(0),1),storage_offset=a.storage_offset()-4128))
        native_decode(mixed,a,b,log,bias,state,out,slots)
        pending.update(expected_state=state.clone(),expected_raw=out.clone())
    def observe_norm(x,z,weight,eps):
        p=pending;expected=native_norm(x,z,weight,eps)
        assert torch.equal(p['z'],z.reshape(len(z),4096))
        p.update(weight=weight,eps=eps,expected_norm=expected)
        layer=len(visited);label=f"{case['label']}-layer{layer}"
        state_b=p['initial_state'].clone();raw_b=torch.empty_like(p['expected_raw']);fullhead(p,state_b,raw_b)
        state_c=p['initial_state'].clone();raw_c=torch.empty_like(raw_b);out_c=torch.empty_like(expected)
        launch(p['mixed'],p['a'],p['b'],p['log'],p['bias'],state_c,p['slots'],p['z'],weight,eps,raw_c,out_c)
        unused=torch.tensor([s for s in range(model.slots) if s not in p['slots'].tolist()],device='cuda')
        row=dict(label=label,recurrence_exact_B=torch.equal(state_b,state_c) and torch.equal(raw_b,raw_c),unused_exact=torch.equal(state_c.index_select(0,unused),p['initial_state'].index_select(0,unused)),metrics=[])
        cpu={k:(v.cpu() if isinstance(v,torch.Tensor) else v) for k,v in p.items()}
        actual=dict(state=state_c.cpu(),raw=raw_c.cpu(),norm=out_c.cpu())
        if case['label']=='b64-n64':
            folder=ROOT/'native-layer-inputs';folder.mkdir(exist_ok=True)
            compact=dict(cpu,original_slots=cpu['slots'],original_state_slots=model.slots,compact_state_snapshot=True)
            for name in ('initial_state','expected_state'):compact[name]=cpu[name].index_select(0,cpu['slots'])
            compact['slots']=torch.arange(len(cpu['slots']))
            torch.save(compact,folder/f'{label}.pt')
        ref=reference(cpu)
        for name in ('state','raw','norm'):
            a=actual[name];b=cpu['expected_'+name]
            if name=='state':a=a.index_select(0,cpu['slots']);b=b.index_select(0,cpu['slots'])
            drift=head_rrms(a[:case['live']],b[:case['live']]);ae=head_rrms(b[:case['live']],ref[name][:case['live']]);ce=head_rrms(a[:case['live']],ref[name][:case['live']])
            row['metrics'].append(dict(name=name,finite=bool(torch.isfinite(a).all() and torch.isfinite(ce).all()),max_live_head_rrms_vs_A=float(drift.max()),max_reference_rrms_A=float(ae.max()),max_reference_rrms_C2=float(ce.max()),drift_pass=bool((drift<=1e-4).all()),reference_pass=bool((ce<=ae*1.01+1e-6).all())))
        row['passed']=row['recurrence_exact_B'] and row['unused_exact'] and all(v['finite'] and v['drift_pass'] and v['reference_pass'] for v in row['metrics'])
        report['layers'].append(row);save();print(json.dumps(row),flush=True)
        if not row['passed']:
            torch.save(dict(inputs=cpu,actual=actual,reference=ref),ROOT/'expanded-first-failure.pt');fail(row)
        visited.append(layer);pending.clear();return expected
    cases=[(64,64),(64,58),(32,32),(8,8),(1,1)]
    for size,live in cases:
        graph=graphs[size];graph.run(active[:live]);restore(tensors.values(),base);torch.cuda.set_rng_state(rng)
        case.update(label=f'b{size}-n{live}',live=live);visited.clear()
        module.gdn_decode,module.gated_norm=observe_decode,observe_norm
        try:graph.forward()
        finally:module.gdn_decode,module.gated_norm=native_decode,native_norm
        assert len(visited)==30,visited
    report['status']='ALL_LAYER_NUMERIC_PASS';save()
    original=model.linear_attention
    def fused_attention(self,x,layer,index,slots,decode,valid_length=None):
        if not decode:return original(x,layer,index,slots,decode,valid_length)
        projected=module.linear(x,layer.packed_input);mixed,z,b,a=projected.split((8192,4096,32,32),dim=-1)
        conv,state=self.states[index];mixed=module.conv_update(mixed,conv,layer.conv1d.weight,slots)
        out=torch.empty((len(slots),1,32,128),device=x.device,dtype=x.dtype)
        launch(mixed,a,b,layer.A_log_fp32,layer.dt_bias_fp32,state,slots,z,layer.norm.weight,layer.norm.eps,out,out,dump=False)
        return module.linear(out.reshape(-1,4096),layer.out_proj.weight)
    model.linear_attention=MethodType(fused_attention,model)
    try:candidates={n:DecodeGraph(model,n,requests=device) for n in (1,8,32,64)}
    finally:model.linear_attention=original
    for size,live in cases:
        control,candidate=graphs[size],candidates[size]
        outputs=[];states=[]
        for graph in (control,candidate):
            restore(tensors.values(),base);torch.cuda.set_rng_state(rng)
            sequence=[graph.run(active[:live]).clone() for _ in range(8)]
            outputs.append(sequence);states.append(snapshot(tensors.values()))
        slots=list(range(live))+list(range(model.slots//2+live,model.slots//2+size));outside=torch.tensor([s for s in range(model.slots) if s not in slots],device='cuda');liveids=torch.arange(live,device='cuda')
        row=dict(label=f'graph-b{size}-n{live}',steps=8,codes_exact=all(torch.equal(a,b) for a,b in zip(*outputs)),state_checks=[])
        for (name,_),a,b in zip(tensors.items(),states[1],states[0]):
            if not a.is_floating_point():passed=torch.equal(a,b);entry=dict(name=name,exact=True,passed=passed)
            else:
                exact_unused=torch.equal(a.index_select(0,outside),b.index_select(0,outside))
                aa=a.index_select(0,liveids).float();bb=b.index_select(0,liveids).float()
                if name.startswith('gdn/'):
                    aa=aa.reshape(live,32,-1);bb=bb.reshape(live,32,-1)
                else:aa=aa.reshape(live,-1);bb=bb.reshape(live,-1)
                r=(aa-bb).square().mean(-1).sqrt()/bb.square().mean(-1).sqrt().clamp_min(1e-30)
                passed=exact_unused and bool(torch.isfinite(aa).all() and (r<=1e-4).all())
                entry=dict(name=name,unused_exact=exact_unused,max_rrms=float(r.max()),passed=passed)
            row['state_checks'].append(entry)
        row['passed']=row['codes_exact'] and all(x['passed'] for x in row['state_checks']);report['graphs'].append(row);save();print(json.dumps(row),flush=True)
        if not row['passed']:
            torch.save(dict(control_outputs=outputs[0],candidate_outputs=outputs[1],state_names=list(tensors),control_state=states[0],candidate_state=states[1]),ROOT/'graph-first-failure.pt');fail(row)
    report['status']='ALL_LAYER_AND_GRAPH_NUMERIC_PASS';save()
if __name__=='__main__':
 try:main()
 except Exception as error:
    if report['status']!='NUMERIC_FAIL':report['status']='ERROR';report['error']=dict(type=type(error).__name__,message=str(error));save()
    raise
