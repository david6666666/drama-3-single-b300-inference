import datetime,hashlib,json,os,subprocess,threading
from pathlib import Path
root=Path(__file__).resolve().parent
source=root.parent/'source-router-463d837'
python='/home/zjy/code/hsliu/venvs/codex-drama3-standalone/bin/python'
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()
assert sha=='463d837cd51fb62196378835a33731cb659a66c8'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True).strip()
flags=dict(DRAMA3_GDN_STATE_DTYPE='bfloat16',DRAMA3_PREFILL_GDN='fla',DRAMA3_PACKED_MOE_PROJECTION='1',DRAMA3_PREFILL_CONV='triton',DRAMA3_PREFILL_MOE_TUNED='0',DRAMA3_PREFILL_MOE='flashinfer',DRAMA3_FUSED_MOE_INPUT='1',DRAMA3_COMPACT_GDN='1',DRAMA3_FUSED_MIXED_LAYOUT='1',DRAMA3_PACKED_CONV_GUARD='1',DRAMA3_SHORT_PADDING_CONTEXT='1',DRAMA3_FUSED_MOE_RESIDUAL='1',DRAMA3_RESERVED_PADDING_ROUTER='0',DRAMA3_CODEC_SMS='0',DRAMA3_FRAME_PIPELINE='0')
env={k:v for k,v in os.environ.items() if not k.startswith('DRAMA3_')}
env.update(flags,CUDA_VISIBLE_DEVICES='7',OMP_NUM_THREADS='4',PYTHONPATH=f'{source}/src:{source}/scripts:/home/zjy/code/hsliu/drama3-sources/fish-speech')
query=['nvidia-smi','--query-compute-apps=gpu_uuid,pid,process_name,used_gpu_memory','--format=csv,noheader'];before=subprocess.check_output(query,text=True)
assert 'GPU-40e00845-d89c-1393-2c32-a2dca3ee9442' not in before
cmd=[python,str(root/'validate_numeric_v2.py')]
plan=dict(source_sha=sha,runtime_source=str(source),artifacts_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [root/'validate_numeric_v2.py',root/'fused_norm_v2.py']},hypothesis='Restore all native recurrence FMA contractions and fence normalization rounding explicitly; fullheadQK reduction differs from nativeBV32 but should stay bounded by independent CPUFP64 reference without changing native model equations.',isolated_variable='C2 fullheadBV128/4warp with recurrencefusionTrue and normmul.rn/add.rn barriers, compared to immutable originalA/B/FP64; no GPU timing.',controls='Frozen native463d837, first64 corpus prompts, nativeprefill/firstframe/eight decode steps, identical real mixed/a/b/z/weight/slots and initial state. Same GPU7, dtype and full model computation. No source changes.',gate='C2 state/raw bitwiseexact nativeBV128B;unusedstateexact;allfinite;each live token/head state/raw/norm RRMSvsA<=1e-4 and RRMSvsindependentCPUFP64<=A_error*1.01+1e-6. OriginalexactFAILpreserved. No timing until laterall30layers/shapes/fullgraphcodesEOSgate.',stop='Any recurrenceBexact,ownership,finite or numeric boundfailure stops expansion;retain allfailures. This does not retroactivelypass exactness or accept fullservicequality. Eventualspeedpromotionstill>=5%.',gpu=7,gpu_uuid='GPU-40e00845-d89c-1393-2c32-a2dca3ee9442',before_gpu=before,flags=flags,command=cmd,cpu_affinity=sorted(os.sched_getaffinity(0)),storage={p:subprocess.check_output(['findmnt','-T',p,'-o','TARGET,SOURCE,FSTYPE','--noheadings'],text=True).strip() for p in (python,'/home/zjy/.cache/huggingface/hub','/home/zjy/code/hsliu/cache')})
(root/'numeric-v2-experiment.json').write_text(json.dumps(plan,indent=2)+'\n')
stop=threading.Event()
def audit():
 with (root/'numeric-v2-process-audit.jsonl').open('w') as f:
  while not stop.is_set():
   p=subprocess.run(query,text=True,capture_output=True);f.write(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),processes=p.stdout.splitlines()))+'\n');f.flush();stop.wait(1)
t=threading.Thread(target=audit);t.start()
try:
 with (root/'numeric-v2.log').open('w') as f:subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
finally:stop.set();t.join()
