"""Frozen native-input first-layer gate for recurrent GDN plus gated norm fusion."""
import hashlib,json,os,statistics,subprocess,sys
from pathlib import Path
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parent
SOURCE=ROOT.parent/'source-router-463d837'
sys.path[:0]=[str(SOURCE/'src'),str(SOURCE/'scripts'),'/home/zjy/code/hsliu/drama3-sources/fish-speech']
import torch
import torch.nn.functional as F
import triton
from fish_speech.models.text2semantic.fish_omni.generate import build_drama3_prompt
from sglang.kernels.ops.attention.fla.fused_recurrent import fused_recurrent_gated_delta_rule_packed_decode_kernel as native_kernel
import drama3.model as module
from drama3.engine import BatchedPrefillGraph,DecodeGraph,state_pool_size
from drama3.model import DramaModel
from drama3.runtime_state import DeviceRequests
from fused_norm import launch
CHECKPOINT='/home/zjy/.cache/huggingface/hub/models--fishaudio--drama-3/snapshots/e0a9218aa48888270f06ef1ed9ea67622c0e17d2'
CORPUS=Path('/home/zjy/code/hsliu/artifacts/drama3-b300-20261014/seedtts-en1088-codes/requests.jsonl')
REPORT=ROOT/'first-layer-result.json'
report=dict(status='PREPARING',source_sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip(),source_status=subprocess.check_output(['git','status','--porcelain'],cwd=SOURCE,text=True),checks=[],timing_promoted=False,artifact_only=True)
assert report['source_sha']=='463d837cd51fb62196378835a33731cb659a66c8' and not report['source_status']

def save():REPORT.write_text(json.dumps(report,indent=2)+'\n')

def tensor_check(name,actual,expected):
    af,bf=actual.float(),expected.float();delta=af-bf
    row=dict(name=name,shape=list(actual.shape),exact=torch.equal(actual,expected),finite=bool(torch.isfinite(af).all() and torch.isfinite(bf).all()),different=int(torch.count_nonzero(actual!=expected)),max_abs=float(delta.abs().max()),rrms=float(delta.square().mean().sqrt()/bf.square().mean().sqrt().clamp_min(1e-30)))
    report['checks'].append(row);save();return row['exact'] and row['finite']

def fullhead(p,state,out):
    return native_kernel[(1,len(p['slots'])*32)](mixed_qkv=p['mixed'],a=p['a'],b=p['b'],A_log=p['log'],dt_bias=p['bias'],o=out,h0=state,ht=state,ssm_state_indices=p['slots'],scale=128**-0.5,stride_mixed_qkv_tok=p['mixed'].stride(0),stride_a_tok=p['a'].stride(0),stride_b_tok=p['b'].stride(0),stride_init_state_token=state.stride(0),stride_final_state_token=state.stride(0),stride_indices_seq=p['slots'].stride(0),H=16,HV=32,K=128,V=128,BK=128,BV=128,SOFTPLUS_THRESHOLD=20.,USE_QK_L2NORM_IN_KERNEL=True,num_warps=4,num_stages=3)

def compiler(name,kernel):
    for kind in ('ptx','ttgir'):
        (ROOT/f'{name}.{kind}').write_text(kernel.asm[kind])
    return dict(n_regs=getattr(kernel,'n_regs',None),n_spills=getattr(kernel,'n_spills',None),metadata=str(kernel.metadata))

class DiagnosticDone(Exception):pass

@torch.inference_mode()
def main():
    report['protocol']=json.loads((ROOT/'experiment.json').read_text())
    report['gpu_uuid']=str(torch.cuda.get_device_properties(0).uuid)
    report['environment']={k:v for k,v in os.environ.items() if k.startswith('DRAMA3_')}
    report['status']='RUNNING';save()
    model=DramaModel(CHECKPOINT,slots=state_pool_size(64),max_length=2048)
    assert model.state_precision=='bfloat16' and model.prefill_moe=='flashinfer' and model.moe_shared_stream is None
    device=DeviceRequests(model.slots,model.config.eos_token_id,model.max_length)
    samples=[json.loads(x) for x in CORPUS.read_bytes().splitlines()][:64]
    prompts=[build_drama3_prompt(s['text'],model.weights.tokenizer,model.config,[s['reference_text']],[torch.tensor(s['reference_codes'])]) for s in samples]
    prefill=BatchedPrefillGraph(model,8,triton.next_power_of_2(max(map(len,prompts))))
    first=DecodeGraph(model,8,first_frame=True,requests=device)
    decode=DecodeGraph(model,64,requests=device)
    active=[SimpleNamespace(slot=i,position=len(p)-1) for i,p in enumerate(prompts)]
    for i,p in enumerate(prompts):
        history=F.pad(p[-16:,0],(max(0,16-len(p)),0),value=-1).cuda()
        device.initialize(i,p[-1].cuda(),history,len(p)-1,500)
    for start in range(0,64,8):
        hidden=prefill.run(prompts[start:start+8],list(range(start,start+8)))
        first.run(active[start:start+8],hidden)
    for _ in range(8):decode.run(active)
    report['capture']=dict(batch=64,active=64,decode_steps_after_first=8,completed_slots=device.metadata[:64,3].nonzero().flatten().tolist(),slot_order=decode.slots.tolist())
    native_decode,native_norm=module.gdn_decode,module.gated_norm
    pending={}
    def observe_decode(mixed,a,b,log,bias,state,out,slots):
        assert not pending
        z=torch.as_strided(a,(len(slots),4096),(a.stride(0),1),storage_offset=a.storage_offset()-4128)
        pending.update(mixed=mixed,a=a,b=b,log=log,bias=bias,initial_state=state.clone(),slots=slots.clone(),z=z)
        native_decode(mixed,a,b,log,bias,state,out,slots)
        pending.update(expected_state=state.clone(),expected_raw=out.clone())
    def observe_norm(x,z,weight,eps):
        assert pending
        p=pending
        expected=native_norm(x,z,weight,eps)
        assert torch.equal(p['z'],z.reshape(len(p['slots']),4096))
        p.update(weight=weight,eps=eps,expected_norm=expected)
        report['capture'].update(mixed_stride=list(p['mixed'].stride()),a_stride=list(p['a'].stride()),z_stride=list(p['z'].stride()),state_shape=list(p['initial_state'].shape),eps=eps)
        torch.save({k:(v.detach().cpu() if isinstance(v,torch.Tensor) else v) for k,v in p.items()},ROOT/'first-native-inputs.pt')
        state_b=p['initial_state'].clone();raw_b=torch.empty_like(p['expected_raw'])
        kb=fullhead(p,state_b,raw_b);norm_b=native_norm(raw_b,p['z'].contiguous(),weight,eps)
        state_c=p['initial_state'].clone();raw_c=torch.empty_like(raw_b);out_c=torch.empty_like(expected)
        kc=launch(p['mixed'],p['a'],p['b'],p['log'],p['bias'],state_c,p['slots'],p['z'],weight,eps,raw_c,out_c)
        report['compiler']=dict(B=compiler('B-fullhead',kb),C=compiler('C-fused-debug',kc));save()
        gates=[]
        for name,value,want in [('B/state',state_b,p['expected_state']),('B/raw',raw_b,p['expected_raw']),('B/norm',norm_b,expected),('C/state',state_c,p['expected_state']),('C/raw',raw_c,p['expected_raw']),('C/norm',out_c,expected)]:gates.append(tensor_check(name,value,want))
        torch.save(dict(state_b=state_b.cpu(),raw_b=raw_b.cpu(),norm_b=norm_b.cpu(),state_c=state_c.cpu(),raw_c=raw_c.cpu(),norm_c=out_c.cpu()),ROOT/'first-native-actuals.pt')
        if not all(gates):
            report['status']='EXACT_FAIL';report['first_difference']=next(c for c in report['checks'] if not c['exact'] or not c['finite']);save();raise DiagnosticDone
        state_c.copy_(p['initial_state'])
        kn=launch(p['mixed'],p['a'],p['b'],p['log'],p['bias'],state_c,p['slots'],p['z'],weight,eps,raw_c,out_c,dump=False)
        report['compiler']['C_no_dump']=compiler('C-fused',kn)
        if not (tensor_check('C-no-dump/state',state_c,p['expected_state']) and tensor_check('C-no-dump/norm',out_c,expected)):
            report['status']='EXACT_FAIL';save();raise DiagnosticDone
        state_a=p['initial_state'].clone();raw_a=torch.empty_like(raw_b);kept=[]
        def a_fn():
            native_decode(p['mixed'],p['a'],p['b'],p['log'],p['bias'],state_a,raw_a,p['slots'])
            return native_norm(raw_a,p['z'].contiguous(),weight,eps)
        def c_fn():
            launch(p['mixed'],p['a'],p['b'],p['log'],p['bias'],state_c,p['slots'],p['z'],weight,eps,raw_c,out_c,dump=False)
            return out_c
        graphs={}
        for name,fn in [('A',a_fn),('C',c_fn)]:
            stream=torch.cuda.Stream();stream.wait_stream(torch.cuda.current_stream())
            with torch.cuda.stream(stream):
                for _ in range(3):kept.append(fn())
            torch.cuda.current_stream().wait_stream(stream)
            graph=torch.cuda.CUDAGraph()
            with torch.cuda.graph(graph):kept.append(fn())
            graphs[name]=graph
        times={'A':[],'C':[]}
        for repetition in range(6):
            for name in (('A','C') if repetition%2==0 else ('C','A')):
                events=[];state=state_a if name=='A' else state_c
                for _ in range(20):
                    state.copy_(p['initial_state'])
                    begin,end=torch.cuda.Event(enable_timing=True),torch.cuda.Event(enable_timing=True)
                    begin.record();graphs[name].replay();end.record();events.append((begin,end))
                torch.cuda.synchronize();times[name].append(statistics.median(a.elapsed_time(b) for a,b in events))
        report['timing_ms']=times
        report['combined_local_reduction']=1-statistics.median(times['C'])/statistics.median(times['A'])
        report['timing_promoted']=report['combined_local_reduction']>=.05
        report['status']='FIRST_LAYER_PASS' if report['timing_promoted'] else 'SPEED_GATE_FAIL'
        report['timing_scope']='Single real layer. State restored outside every CUDA event;20 same-input replays per arm per six alternating trials. No service claim.'
        save();raise DiagnosticDone
    module.gdn_decode, module.gated_norm=observe_decode,observe_norm
    try:decode.forward()
    except DiagnosticDone:pass
    finally:module.gdn_decode,module.gated_norm=native_decode,native_norm
    print(json.dumps({k:v for k,v in report.items() if k not in ('protocol','compiler','environment')},indent=2),flush=True)

if __name__=='__main__':
    try:main()
    except Exception as error:
        report['status']='ERROR';report['failure']=dict(type=type(error).__name__,message=str(error));save();raise
