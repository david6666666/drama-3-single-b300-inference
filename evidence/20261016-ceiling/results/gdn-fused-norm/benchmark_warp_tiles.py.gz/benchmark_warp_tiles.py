"""Frozen real-layer combined recurrence+zcopy+norm timing after all exact gates."""
import json,statistics,sys
from pathlib import Path
import torch
ROOT=Path(__file__).resolve().parent;SOURCE=ROOT.parent/'source-router-463d837'
sys.path[:0]=[str(SOURCE/'src'),'/home/zjy/code/hsliu/drama3-sources/fish-speech']
from drama3.gdn import decode
from drama3.kernels import gated_norm
from fused_norm_warp_tiles import launch
OUT=ROOT/'warp-tiles-timing-result.json'
report=dict(status='RUNNING',component='all30layers B64 recurrence+zcontiguous+gatednorm, real frozen inputs',timing_run=False)
def save():OUT.write_text(json.dumps(report,indent=2)+'\n')
def exact(a,b):return torch.equal(a.contiguous().reshape(-1).view(torch.uint8),b.contiguous().reshape(-1).view(torch.uint8))
@torch.inference_mode()
def main():
 assert json.loads((ROOT/'warp-tiles-expanded-result.json').read_text())['status']=='ALL_LAYER_AND_GRAPH_EXACT_PASS'
 torch.set_num_threads(8);save();params=[]
 for index in range(30):
  p=torch.load(ROOT/'warp-tiles-native-layer-inputs'/f'b64-n64-layer{index}.pt',map_location='cpu',weights_only=True)
  packed=torch.empty((64,12352),device='cuda',dtype=torch.bfloat16)
  z,b,a=packed[:,8192:12288],packed[:,12288:12320],packed[:,12320:12352]
  for dst,key in ((z,'z'),(b,'b'),(a,'a')):dst.copy_(p[key])
  v={k:p[k].cuda() for k in ('mixed','log','bias','slots','weight','initial_state')}
  v.update(z=z,b=b,a=a,eps=p['eps'],state_a=v['initial_state'].clone(),state_c=v['initial_state'].clone(),raw=torch.empty_like(p['expected_raw'],device='cuda'),out=torch.empty_like(p['expected_norm'],device='cuda'))
  params.append(v)
 def control():
  outputs=[]
  for p in params:
   decode(p['mixed'],p['a'],p['b'],p['log'],p['bias'],p['state_a'],p['raw'],p['slots'])
   outputs.append(gated_norm(p['raw'],p['z'].contiguous(),p['weight'],p['eps']))
  return outputs
 def candidate():
  outputs=[]
  for p in params:
   launch(p['mixed'],p['a'],p['b'],p['log'],p['bias'],p['state_c'],p['slots'],p['z'],p['weight'],p['eps'],p['out'],p['out'],dump=False)
   outputs.append(p['out'])
  return outputs
 def reset(which):
  for p in params:p['state_'+which].copy_(p['initial_state'])
 oa,oc=control(),candidate()
 report['initial_exact']=all(exact(a,c) and exact(p['state_a'],p['state_c']) for a,c,p in zip(oa,oc,params))
 assert report['initial_exact'];save()
 graphs={};outputs={};stream=torch.cuda.Stream();stream.wait_stream(torch.cuda.current_stream())
 with torch.cuda.stream(stream):
  for key,fn in (('a',control),('c',candidate)):
   for _ in range(3):fn()
   reset(key);graph=torch.cuda.CUDAGraph()
   with torch.cuda.graph(graph,stream=stream):outputs[key]=fn()
   graphs[key]=graph
 torch.cuda.current_stream().wait_stream(stream);torch.cuda.synchronize()
 measurements={'a':[],'c':[]};orders=[]
 for repeat in range(6):
  order=['a','c'] if repeat%2==0 else ['c','a'];orders.append(order)
  for key in order:
   reset(key)
   for _ in range(10):graphs[key].replay()
   reset(key);torch.cuda.synchronize()
   start,end=torch.cuda.Event(enable_timing=True),torch.cuda.Event(enable_timing=True)
   start.record()
   for _ in range(100):graphs[key].replay()
   end.record();end.synchronize();measurements[key].append(start.elapsed_time(end)/100)
  assert all(exact(p['state_a'],p['state_c']) and exact(a,c) for p,a,c in zip(params,outputs['a'],outputs['c']))
 report.update(timing_run=True,orders=orders,replays_per_sample=100,warmup_replays_per_sample=10,measurements_ms=measurements,state_and_outputs_exact_after_every_repeat=True)
 a,c=statistics.median(measurements['a']),statistics.median(measurements['c'])
 report.update(control_median_ms=a,candidate_median_ms=c,reduction_fraction=1-c/a,local_gate_pass=1-c/a>=.05,status='LOCAL_GAIN_PASS' if 1-c/a>=.05 else 'LOCAL_GAIN_FAIL')
 save();print(json.dumps(report,indent=2),flush=True)
if __name__=='__main__':
 try:main()
 except Exception as e:
  report['status']='ERROR';report['error']=dict(type=type(e).__name__,message=str(e));save();raise
