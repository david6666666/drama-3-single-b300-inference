"""CPU AOT compilation only; target sm103 is explicit and no driver is queried."""
import hashlib,json
from pathlib import Path
import torch,triton
from triton.backends.compiler import GPUTarget
from triton.experimental.gluon._runtime import GluonASTSource
from fused_norm_warp_tiles_late import fused_kernel
root=Path(__file__).resolve().parent
signature={name:('*i64' if name=='SLOTS' else '*fp32' if name in ('LOG','BIAS') else '*bf16') for name in fused_kernel.arg_names[:11]}
constants=dict(MS=8192,AS=12352,BS=12352,SS=524288,ZS=12352,EPS=1e-6,DUMP_RAW=False)
attrs={(i,):[['tt.divisibility',16]] for i in range(11)}
source=GluonASTSource(fused_kernel,signature,constants,attrs)
kernel=triton.compile(source,target=GPUTarget('cuda',103,32),options=dict(num_warps=4,num_stages=3,enable_fp_fusion=True))
for ext in ('ptx','ttgir','llir'):(root/f'C3-late.{ext}').write_text(kernel.asm[ext])
(root/'C3-late.cubin').write_bytes(kernel.asm['cubin'])
report=dict(status='COMPILED_UNAUDITED',kernel_hash=kernel.hash,metadata=str(kernel.metadata),driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),kernel_source_sha256=hashlib.sha256((root/'fused_norm_warp_tiles_late.py').read_bytes()).hexdigest(),cuda_initialized=torch.cuda.is_initialized(),gpu_run=False)
(root/'warp-tiles-late-cpu-compile.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
