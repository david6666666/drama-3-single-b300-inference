"""Separate C2 numerical diagnostic; never rewrites the original exact failure."""
import hashlib,json
from pathlib import Path
import torch
from fused_norm_v2 import launch
ROOT=Path(__file__).resolve().parent
report=dict(status='RUNNING',old_exact_gate='EXACT_FAIL preserved',checks=[],timing_run=False,protocol=json.loads((ROOT/'numeric-v2-experiment.json').read_text()))
output=ROOT/'numeric-v2-result.json'
def save():output.write_text(json.dumps(report,indent=2)+'\n')
def rrms(a,b):
 a=a.double().reshape(64,32,-1);b=b.double().reshape(64,32,-1)
 return (a-b).square().mean(-1).sqrt()/b.square().mean(-1).sqrt().clamp_min(1e-30)
@torch.inference_mode()
def main():
 torch.set_num_threads(8)
 p=torch.load(ROOT/'first-native-inputs.pt',map_location='cpu',weights_only=True)
 previous=torch.load(ROOT/'first-native-actuals.pt',map_location='cpu',weights_only=True)
 reference=torch.load(ROOT/'first-reference-fp64.pt',map_location='cpu',weights_only=True)
 save()
 packed=torch.empty((64,12352),device='cuda',dtype=torch.bfloat16)
 z,b,a=packed[:,8192:12288],packed[:,12288:12320],packed[:,12320:12352]
 z.copy_(p['z']);b.copy_(p['b']);a.copy_(p['a'])
 mixed,log,bias,slots,weight=[p[k].cuda() for k in ('mixed','log','bias','slots','weight')]
 state=p['initial_state'].cuda();raw=torch.empty_like(p['expected_raw'],device='cuda');out=torch.empty_like(raw)
 kernel=launch(mixed,a,b,log,bias,state,slots,z,weight,p['eps'],raw,out)
 actual=dict(state=state.cpu(),raw=raw.cpu(),norm=out.cpu())
 torch.save(actual,ROOT/'numeric-v2-actuals.pt')
 for ext in ('ptx','ttgir'):(ROOT/f'C2-fused.{ext}').write_text(kernel.asm[ext])
 report['compiler']=dict(n_regs=kernel.n_regs,n_spills=kernel.n_spills,metadata=str(kernel.metadata))
 report['state_raw_exact_native_B']=all(torch.equal(actual[name],previous[name+'_b']) for name in ('state','raw'))
 report['untouched_exact']=torch.equal(actual['state'][64:],p['initial_state'][64:])
 report['checks']=[]
 for name in ('state','raw','norm'):
  aa=actual[name];base=p['expected_'+name]
  if name=='state':aa=aa.index_select(0,p['slots']);base=base.index_select(0,p['slots'])
  drift=rrms(aa,base);aerr=rrms(base,reference[name]);cerr=rrms(aa,reference[name])
  finite=bool(torch.isfinite(aa).all() and torch.isfinite(cerr).all())
  row=dict(name=name,finite=finite,exact_A=torch.equal(aa,base),max_head_rrms_vs_A=float(drift.max()),head_rrms_vs_A=drift.tolist(),max_head_reference_rrms_A=float(aerr.max()),max_head_reference_rrms_C2=float(cerr.max()),reference_degradation_worst=float((cerr-(aerr*1.01+1e-6)).max()),reference_gate_pass=bool((cerr<=aerr*1.01+1e-6).all()),drift_gate_pass=bool((drift<=1e-4).all()))
  report['checks'].append(row);save()
 report['numeric_gate_pass']=report['state_raw_exact_native_B'] and report['untouched_exact'] and all(x['finite'] and x['reference_gate_pass'] and x['drift_gate_pass'] for x in report['checks'])
 report['status']='FIRST_LAYER_NUMERIC_PASS' if report['numeric_gate_pass'] else 'NUMERIC_FAIL'
 save();print(json.dumps({k:([{i:j for i,j in x.items() if i!='head_rrms_vs_A'} for x in v] if k=='checks' else v) for k,v in report.items() if k not in ('protocol','compiler')},indent=2),flush=True)
if __name__=='__main__':
 try:main()
 except Exception as error:
  report['status']='ERROR';report['error']=dict(type=type(error).__name__,message=str(error));save();raise
