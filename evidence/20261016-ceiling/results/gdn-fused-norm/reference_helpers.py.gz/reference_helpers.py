"""Independent CPU FP64 reference; retains beta/raw/norm/weight BF16 boundaries."""
import torch


def reference(p):
    states,raws,norms=[],[],[]
    slots=p['slots'];batch=len(slots)
    for start in range(0,batch,4):
        end=min(start+4,batch);m=p['mixed'][start:end].double()
        q=m[:,:2048].reshape(-1,16,128);k=m[:,2048:4096].reshape(-1,16,128);v=m[:,4096:].reshape(-1,32,128)
        q=(q/(q.square().sum(-1,keepdim=True)+1e-6).sqrt()*(128**-.5)).repeat_interleave(2,dim=1)
        k=(k/(k.square().sum(-1,keepdim=True)+1e-6).sqrt()).repeat_interleave(2,dim=1)
        x=p['a'][start:end].double()+p['bias'].double()
        decay=torch.exp(-p['log'].double().exp()*torch.where(x<=20.,torch.log1p(x.exp()),x))
        beta=p['b'][start:end].double().sigmoid().bfloat16().double()
        h=p['initial_state'].index_select(0,slots[start:end]).double()*decay[...,None,None]
        value=(v-(h*k[...,None,:]).sum(-1))*beta[...,None]
        h=h+value[...,None]*k[...,None,:]
        raw=(h*q[...,None,:]).sum(-1);bf=raw.bfloat16().double()
        norm=bf*torch.rsqrt(bf.square().mean(-1,keepdim=True)+p['eps'])
        weighted=(norm.bfloat16().double()*p['weight'].double()).bfloat16().double()
        z=p['z'][start:end].reshape(-1,32,128).double()
        states.append(h);raws.append(raw);norms.append(weighted*(z*z.sigmoid()))
    return dict(state=torch.cat(states),raw=torch.cat(raws),norm=torch.cat(norms))


def head_rrms(a,b):
    a=a.double().reshape(len(a),32,-1);b=b.double().reshape(len(b),32,-1)
    return (a-b).square().mean(-1).sqrt()/b.square().mean(-1).sqrt().clamp_min(1e-30)
