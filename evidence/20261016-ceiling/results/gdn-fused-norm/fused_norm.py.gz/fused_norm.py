"""Artifact-only packed recurrent GDN + native gated RMS norm, full V head.

Recurrence adapted from installed SGLang/FLA fused_recurrent.py, itself adapted
from vLLM and fla-org/flash-linear-attention. Copyright (c) 2023-2025,
Songlin Yang, Yu Zhang. Normalization mirrors drama3.kernels.gated_norm_kernel.
"""
import triton
import triton.language as tl
from sglang.kernels.ops.attention.fla.op import exp


@triton.jit
def fused_kernel(MIXED, A, B, LOG, BIAS, STATE, SLOTS, Z, WEIGHT, RAW, OUT,
                 MS:tl.constexpr, AS:tl.constexpr, BS:tl.constexpr, SS:tl.constexpr,
                 ZS:tl.constexpr, EPS:tl.constexpr, DUMP_RAW:tl.constexpr):
    nh=tl.program_id(0)
    row,head=nh//32,nh%32
    qhead=head//2
    k=tl.arange(0,128)
    v=tl.arange(0,128)
    slot=tl.load(SLOTS+row).to(tl.int64)
    op=OUT+(row*32+head)*128+v
    if slot<0:
        tl.store(op,tl.full((128,),0,tl.float32))
        if DUMP_RAW:tl.store(RAW+(row*32+head)*128+v,tl.full((128,),0,tl.float32))
        return
    sp=STATE+slot*SS+head*16384+v[:,None]*128+k[None,:]
    h=tl.load(sp).to(tl.float32)
    q=tl.load(MIXED+row*MS+qhead*128+k).to(tl.float32)
    key=tl.load(MIXED+row*MS+2048+qhead*128+k).to(tl.float32)
    value=tl.load(MIXED+row*MS+4096+head*128+v).to(tl.float32)
    q=q/tl.sqrt(tl.sum(q*q)+1e-6)
    key=key/tl.sqrt(tl.sum(key*key)+1e-6)
    q=q*(128**-0.5)
    av=tl.load(A+row*AS+head).to(tl.float32)
    bv=tl.load(B+row*BS+head).to(tl.float32)
    log=tl.load(LOG+head).to(tl.float32)
    bias=tl.load(BIAS+head).to(tl.float32)
    x=av+bias
    softplus=tl.where(x<=20.,tl.log(1.+tl.exp(x)),x)
    decay=-tl.exp(log)*softplus
    beta=tl.sigmoid(bv).to(B.dtype.element_ty).to(tl.float32)
    h=h*exp(decay)
    value=value-tl.sum(h*key[None,:],1)
    value=value*beta
    # Native recurrence fuses the rank-one update; normalization does not fuse.
    h=tl.fma(value[:,None],key[None,:],h)
    raw=tl.sum(h*q[None,:],1).to(OUT.dtype.element_ty)
    tl.store(sp,h.to(STATE.dtype.element_ty))
    if DUMP_RAW:tl.store(RAW+(row*32+head)*128+v,raw)
    raw=raw.to(tl.float32)
    norm=raw*tl.rsqrt(tl.sum(raw*raw,0)/128+EPS)
    norm=norm.to(OUT.dtype.element_ty).to(tl.float32)
    scaled=(norm*tl.load(WEIGHT+v).to(tl.float32)).to(OUT.dtype.element_ty).to(tl.float32)
    z=tl.load(Z+row*ZS+head*128+v).to(tl.float32)
    tl.store(op,scaled*(z*tl.sigmoid(z)))


def launch(mixed,a,b,log,bias,state,slots,z,weight,eps,raw,out,dump=True):
    assert mixed.shape==(len(slots),8192) and z.shape==(len(slots),4096)
    assert slots.stride(0)==1 and state.shape[1:]==(32,128,128)
    return fused_kernel[(len(slots)*32,)](mixed,a,b,log,bias,state,slots,z,weight,raw,out,
        mixed.stride(0),a.stride(0),b.stride(0),state.stride(0),z.stride(0),eps,dump,
        num_warps=4,num_stages=3,enable_fp_fusion=False)
