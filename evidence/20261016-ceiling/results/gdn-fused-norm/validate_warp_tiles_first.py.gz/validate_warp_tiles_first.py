"""First real-input exact gate for C3; no numeric relaxation and no timing."""
import json,sys
from pathlib import Path
import torch
ROOT=Path(__file__).resolve().parent
SOURCE=ROOT.parent/'source-router-463d837'
sys.path[:0]=[str(SOURCE/'src'),'/home/zjy/code/hsliu/drama3-sources/fish-speech']
from drama3.gdn import decode
from drama3.kernels import gated_norm
from fused_norm_warp_tiles import launch
report=dict(status='RUNNING',old_exact_and_numeric_failures_preserved=True,timing_run=False,checks=[])
output=ROOT/'warp-tiles-first-result.json'
def save():output.write_text(json.dumps(report,indent=2)+'\n')
def bits(a,b):return a.shape==b.shape and a.dtype==b.dtype and torch.equal(a.contiguous().view(torch.uint8),b.contiguous().view(torch.uint8))
def check(name,a,b):
 aa=a.cpu();bb=b.cpu();equal=bits(aa,bb)
 row=dict(name=name,exact=equal,finite=bool(torch.isfinite(aa).all()))
 if not equal:
  diff=(aa!=bb).nonzero();row.update(differing_elements=len(diff),max_abs=float((aa.float()-bb.float()).abs().max()),first_index=diff[0].tolist() if len(diff) else None)
 report['checks'].append(row);save();return equal and row['finite']
@torch.inference_mode()
def main():
 torch.set_num_threads(8);save()
 p=torch.load(ROOT/'expanded-first-failure.pt',map_location='cpu',weights_only=True)['inputs']
 n=len(p['slots']);assert n==64
 packed=torch.empty((n,12352),device='cuda',dtype=torch.bfloat16)
 z,b,a=packed[:,8192:12288],packed[:,12288:12320],packed[:,12320:12352]
 for dst,key in ((z,'z'),(b,'b'),(a,'a')):dst.copy_(p[key])
 mixed,log,bias,slots,weight=[p[k].cuda() for k in ('mixed','log','bias','slots','weight')]
 sa=p['initial_state'].cuda();sc=sa.clone();ra=torch.empty_like(p['expected_raw'],device='cuda');rc=torch.empty_like(ra);oc=torch.empty_like(ra)
 decode(mixed,a,b,log,bias,sa,ra,slots)
 oa=gated_norm(ra,z.contiguous(),weight,p['eps'])
 control=all([check('control_state_matches_fixture',sa,p['expected_state']),check('control_raw_matches_fixture',ra,p['expected_raw']),check('control_norm_matches_fixture',oa,p['expected_norm'])])
 if not control:report['status']='CONTROL_FIXTURE_FAIL';save();return
 k=launch(mixed,a,b,log,bias,sc,slots,z,weight,p['eps'],rc,oc)
 for ext in ('ptx','ttgir'):(ROOT/f'C3-first-runtime.{ext}').write_text(k.asm[ext])
 report['compiler']=dict(n_regs=k.n_regs,n_spills=k.n_spills,metadata=str(k.metadata))
 live=set(p['slots'].tolist());unused=torch.tensor([i for i in range(len(sc)) if i not in live],device='cuda')
 checks=[check('state_exact_A',sc,sa),check('raw_exact_A',rc,ra),check('norm_exact_A',oc,oa),check('unused_state_exact',sc.index_select(0,unused),p['initial_state'].index_select(0,unused.cpu()))]
 report['passed']=all(checks);report['status']='FIRST_EXACT_PASS' if report['passed'] else 'EXACT_FAIL'
 torch.save(dict(state=sc.cpu(),raw=rc.cpu(),norm=oc.cpu()),ROOT/'warp-tiles-first-actuals.pt')
 save();print(json.dumps(report,indent=2),flush=True)
if __name__=='__main__':
 try:main()
 except Exception as e:
  report['status']='ERROR';report['error']=dict(type=type(e).__name__,message=str(e));save();raise
