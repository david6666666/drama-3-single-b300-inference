"""Expanded native GDN C2 numerical gates; original exact failure is retained."""
import json,os,sys,subprocess
from pathlib import Path
from types import SimpleNamespace,MethodType
ROOT=Path(__file__).resolve().parent;SOURCE=ROOT.parent/'source-router-463d837'
sys.path[:0]=[str(SOURCE/'src'),str(SOURCE/'scripts'),'/home/zjy/code/hsliu/drama3-sources/fish-speech']
import torch
import torch.nn.functional as F
import triton
from fish_speech.models.text2semantic.fish_omni.generate import build_drama3_prompt
import drama3.model as module
from drama3.engine import BatchedPrefillGraph,DecodeGraph,state_pool_size
from drama3.model import DramaModel
from drama3.runtime_state import DeviceRequests
from validate_mixed_layers import snapshot,restore,state_tensors
from fused_norm_warp_tiles import launch
from validate_first_layer import fullhead,CHECKPOINT,CORPUS
report=dict(status='RUNNING',source_sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip(),old_failures_preserved=True,layers=[],graphs=[],timing_run=False)
OUT=ROOT/'warp-tiles-expanded-result.json'
def save():OUT.write_text(json.dumps(report,indent=2)+'\n')
def bit_equal(a,b):return a.shape==b.shape and a.dtype==b.dtype and torch.equal(a.contiguous().reshape(-1).view(torch.uint8),b.contiguous().reshape(-1).view(torch.uint8))
def fail(row):
    report['status']='EXACT_FAIL';report['first_failure']=row;save();raise AssertionError(row)

@torch.inference_mode()
def main():
    torch.set_num_threads(8);save()
    model=DramaModel(CHECKPOINT,slots=state_pool_size(64),max_length=2048)
    device=DeviceRequests(model.slots,model.config.eos_token_id,model.max_length)
    samples=[json.loads(x) for x in CORPUS.read_bytes().splitlines()][:64]
    prompts=[build_drama3_prompt(s['text'],model.weights.tokenizer,model.config,[s['reference_text']],[torch.tensor(s['reference_codes'])]) for s in samples]
    prefill=BatchedPrefillGraph(model,8,triton.next_power_of_2(max(map(len,prompts))))
    first=DecodeGraph(model,8,first_frame=True,requests=device)
    graphs={n:DecodeGraph(model,n,requests=device) for n in (1,8,32,48,64)}
    active=[SimpleNamespace(slot=i,position=len(p)-1) for i,p in enumerate(prompts)]
    for i,p in enumerate(prompts):
        history=F.pad(p[-16:,0],(max(0,16-len(p)),0),value=-1).cuda();device.initialize(i,p[-1].cuda(),history,len(p)-1,500)
    for start in range(0,64,8):
        hidden=prefill.run(prompts[start:start+8],list(range(start,start+8)));first.run(active[start:start+8],hidden)
    for _ in range(8):graphs[64].run(active)
    tensors=state_tensors(model,device);base=snapshot(tensors.values());rng=torch.cuda.get_rng_state()
    native_decode,native_norm=module.gdn_decode,module.gated_norm
    pending={};case={};visited=[]
    def observe_decode(mixed,a,b,log,bias,state,out,slots):
        assert not pending
        pending.update(mixed=mixed,a=a,b=b,log=log,bias=bias,initial_state=state.clone(),slots=slots.clone(),z=torch.as_strided(a,(len(slots),4096),(a.stride(0),1),storage_offset=a.storage_offset()-4128))
        native_decode(mixed,a,b,log,bias,state,out,slots)
        pending.update(expected_state=state.clone(),expected_raw=out.clone())
    def observe_norm(x,z,weight,eps):
        p=pending;expected=native_norm(x,z,weight,eps)
        assert bit_equal(p['z'],z.reshape(len(z),4096))
        p.update(weight=weight,eps=eps,expected_norm=expected)
        layer=len(visited);label=f"{case['label']}-layer{layer}"
        state_c=p['initial_state'].clone();raw_c=torch.empty_like(p['expected_raw']);out_c=torch.empty_like(expected)
        if len(p['slots'])>32:
            launch(p['mixed'],p['a'],p['b'],p['log'],p['bias'],state_c,p['slots'],p['z'],weight,eps,raw_c,out_c)
        else:
            native_decode(p['mixed'],p['a'],p['b'],p['log'],p['bias'],state_c,raw_c,p['slots'])
            out_c=native_norm(raw_c,p['z'].contiguous(),weight,eps)
        unused=torch.tensor([s for s in range(model.slots) if s not in p['slots'].tolist()],device='cuda')
        row=dict(label=label,path='four_native_v32_warps' if len(p['slots'])>32 else 'original_v16_fallback',state_exact=bit_equal(state_c,p['expected_state']),raw_exact=bit_equal(raw_c,p['expected_raw']),norm_exact=bit_equal(out_c,expected),unused_exact=bit_equal(state_c.index_select(0,unused),p['initial_state'].index_select(0,unused)),finite=bool(torch.isfinite(state_c).all() and torch.isfinite(raw_c).all() and torch.isfinite(out_c).all()))
        if len(p['slots'])>32:
            state_c.copy_(p['initial_state']);out_nodump=torch.empty_like(expected)
            launch(p['mixed'],p['a'],p['b'],p['log'],p['bias'],state_c,p['slots'],p['z'],weight,eps,out_nodump,out_nodump,dump=False)
            row['nodump_state_exact']=bit_equal(state_c,p['expected_state']);row['nodump_norm_exact']=bit_equal(out_nodump,expected)
        row['passed']=all(v for k,v in row.items() if k not in ('label','path'))
        report['layers'].append(row);save();print(json.dumps(row),flush=True)
        if not row['passed']:
            torch.save(dict(inputs={k:(v.cpu() if isinstance(v,torch.Tensor) else v) for k,v in p.items()},actual=dict(state=state_c.cpu(),raw=raw_c.cpu(),norm=out_c.cpu())),ROOT/'warp-tiles-expanded-first-failure.pt');fail(row)
        if case['label']=='b64-n64':
            folder=ROOT/'warp-tiles-native-layer-inputs';folder.mkdir(exist_ok=True)
            compact={k:(v.cpu() if isinstance(v,torch.Tensor) else v) for k,v in p.items() if k not in ('initial_state','expected_state')}
            compact.update(original_slots=p['slots'].cpu(),original_state_slots=model.slots,compact_state_snapshot=True)
            for name in ('initial_state','expected_state'):compact[name]=p[name].index_select(0,p['slots']).cpu()
            compact['slots']=torch.arange(len(p['slots']))
            torch.save(compact,folder/f'{label}.pt')
        visited.append(layer);pending.clear();return expected
    cases=[(64,64),(64,58),(48,40),(32,32),(8,8),(1,1)]
    for size,live in cases:
        graph=graphs[size];graph.run(active[:live]);restore(tensors.values(),base);torch.cuda.set_rng_state(rng)
        case.update(label=f'b{size}-n{live}',live=live);visited.clear()
        module.gdn_decode,module.gated_norm=observe_decode,observe_norm
        try:graph.forward()
        finally:module.gdn_decode,module.gated_norm=native_decode,native_norm
        assert len(visited)==30,visited
    report['status']='ALL_LAYER_EXACT_PASS';save()
    original=model.linear_attention
    def fused_attention(self,x,layer,index,slots,decode,valid_length=None):
        if not decode or len(slots)<=32:return original(x,layer,index,slots,decode,valid_length)
        projected=module.linear(x,layer.packed_input);mixed,z,b,a=projected.split((8192,4096,32,32),dim=-1)
        conv,state=self.states[index];mixed=module.conv_update(mixed,conv,layer.conv1d.weight,slots)
        out=torch.empty((len(slots),1,32,128),device=x.device,dtype=x.dtype)
        launch(mixed,a,b,layer.A_log_fp32,layer.dt_bias_fp32,state,slots,z,layer.norm.weight,layer.norm.eps,out,out,dump=False)
        return module.linear(out.reshape(-1,4096),layer.out_proj.weight)
    model.linear_attention=MethodType(fused_attention,model)
    try:candidates={n:DecodeGraph(model,n,requests=device) for n in (1,8,32,48,64)}
    finally:model.linear_attention=original
    for size,live in cases:
        outputs=[];states=[]
        for graph in (graphs[size],candidates[size]):
            restore(tensors.values(),base);torch.cuda.set_rng_state(rng)
            sequence=[graph.run(active[:live]).clone() for _ in range(8)]
            outputs.append(sequence);states.append(snapshot(tensors.values()))
        row=dict(label=f'graph-b{size}-n{live}',steps=8,codes_exact=all(bit_equal(a,b) for a,b in zip(*outputs)),state_checks=[dict(name=name,exact=bit_equal(a,b)) for (name,_),a,b in zip(tensors.items(),states[0],states[1])])
        row['passed']=row['codes_exact'] and all(x['exact'] for x in row['state_checks']);report['graphs'].append(row);save();print(json.dumps(dict(row,state_checks_count=len(row['state_checks']),state_checks_failed=[x for x in row['state_checks'] if not x['exact']])),flush=True)
        if not row['passed']:
            torch.save(dict(control_outputs=outputs[0],candidate_outputs=outputs[1],state_names=list(tensors),control_state=states[0],candidate_state=states[1]),ROOT/'warp-tiles-graph-first-failure.pt');fail(row)
    report['status']='ALL_LAYER_AND_GRAPH_EXACT_PASS';save()
if __name__=='__main__':
 try:main()
 except Exception as error:
    if report['status']!='EXACT_FAIL':report['status']='ERROR';report['error']=dict(type=type(error).__name__,message=str(error));save()
    raise
