"""Artifact C3L CPU-only: four independent native V32 warp subtiles, then native norm layout.

Recurrence adapted from installed SGLang/FLA fused_recurrent.py, itself adapted
from vLLM and fla-org/flash-linear-attention. Copyright (c) 2023-2025,
Songlin Yang, Yu Zhang. Normalization mirrors drama3.kernels.gated_norm_kernel.
No runtime integration. This file is an unvalidated layout-preserving candidate.
"""
import triton
from triton.experimental import gluon as g
from triton.experimental.gluon import language as gl
from triton.experimental.gluon.language import BlockedLayout, SliceLayout


@g.jit
def rn_mul(a, b):
    return gl.inline_asm_elementwise("mul.rn.f32 $0, $1, $2;", constraints="=f,f,f", args=[a,b], dtype=gl.float32, is_pure=True, pack=1)


@g.jit
def rn_add(a, b):
    return gl.inline_asm_elementwise("add.rn.f32 $0, $1, $2;", constraints="=f,f,f", args=[a,b], dtype=gl.float32, is_pure=True, pack=1)


@g.jit
def full_div(a, b):
    return gl.inline_asm_elementwise("div.full.f32 $0, $1, $2;", constraints="=f,f,f", args=[a,b], dtype=gl.float32, is_pure=True, pack=1)


@g.jit
def fused_kernel(MIXED, A, B, LOG, BIAS, STATE, SLOTS, Z, WEIGHT, RAW, OUT,
                 MS:gl.constexpr, AS:gl.constexpr, BS:gl.constexpr, SS:gl.constexpr,
                 ZS:gl.constexpr, EPS:gl.constexpr, DUMP_RAW:gl.constexpr):
    nh = gl.program_id(0)
    row, head = nh//32, nh%32
    qhead = head//2
    LM:gl.constexpr = BlockedLayout([1,1,8], [1,2,16], [4,1,1], [2,1,0])
    LQ:gl.constexpr = BlockedLayout([1,4], [1,32], [4,1], [1,0])
    LV:gl.constexpr = BlockedLayout([1,1], [1,32], [4,1], [1,0])
    LN:gl.constexpr = BlockedLayout([1], [32], [4], [0])
    w = gl.arange(0,4,layout=SliceLayout(1,SliceLayout(2,LM)))
    v = gl.arange(0,32,layout=SliceLayout(0,SliceLayout(2,LM)))
    k = gl.arange(0,128,layout=SliceLayout(0,SliceLayout(1,LM)))
    wq = gl.arange(0,4,layout=SliceLayout(1,LQ))
    kq = gl.arange(0,128,layout=SliceLayout(0,LQ))
    wv = gl.arange(0,4,layout=SliceLayout(1,LV))
    vv = gl.arange(0,32,layout=SliceLayout(0,LV))
    whole_v = wv[:,None]*32+vv[None,:]
    d = gl.arange(0,128,layout=LN)
    slot = gl.load(SLOTS+row).to(gl.int64)
    op = OUT+(row*32+head)*128+d
    if slot < 0:
        gl.store(op,gl.full((128,),0,gl.float32,LN))
        if DUMP_RAW:
            gl.store(RAW+(row*32+head)*128+d,gl.full((128,),0,gl.float32,LN))
        return
    sp = STATE+slot*SS+head*16384+(w[:,None,None]*32+v[None,:,None])*128+k[None,None,:]
    h = gl.load(sp).to(gl.float32)
    q = gl.load(MIXED+row*MS+qhead*128+kq[None,:]+wq[:,None]*0).to(gl.float32)
    key = gl.load(MIXED+row*MS+2048+qhead*128+kq[None,:]+wq[:,None]*0).to(gl.float32)
    value = gl.load(MIXED+row*MS+4096+head*128+whole_v).to(gl.float32)
    q = q/gl.sqrt(gl.sum(q*q,1)[:,None]+1e-6)
    key = key/gl.sqrt(gl.sum(key*key,1)[:,None]+1e-6)
    q = q*(128**-0.5)
    value = gl.convert_layout(value,SliceLayout(2,LM))
    av = gl.load(A+row*AS+head).to(gl.float32)
    bv = gl.load(B+row*BS+head).to(gl.float32)
    log = gl.load(LOG+head).to(gl.float32)
    bias = gl.load(BIAS+head).to(gl.float32)
    x = av+bias
    softplus = gl.where(x<=20.,gl.log(1.+gl.exp(x)),x)
    decay = -gl.exp(log)*softplus
    beta = (1./(1.+gl.exp(-bv))).to(B.dtype.element_ty).to(gl.float32)
    h = h*gl.exp(decay)
    key = gl.convert_layout(key,SliceLayout(1,LM))
    value = value-gl.sum(h*key[:,None,:],2)
    value = value*beta
    h = gl.fma(value[:,:,None],key[:,None,:],h)
    q = gl.convert_layout(q,SliceLayout(1,LM))
    raw = gl.sum(h*q[:,None,:],2).to(OUT.dtype.element_ty)
    gl.store(sp,h.to(STATE.dtype.element_ty))
    raw = gl.convert_layout(raw,LV)
    raw = gl.reshape(raw,(128,))
    raw = gl.convert_layout(raw,LN)
    if DUMP_RAW:
        gl.store(RAW+(row*32+head)*128+d,raw)
    raw = raw.to(gl.float32)
    square = rn_mul(raw,raw)
    mean = full_div(gl.sum(square,0),128.)
    variance = rn_add(mean,EPS)
    norm = rn_mul(raw,gl.rsqrt(variance)).to(OUT.dtype.element_ty).to(gl.float32)
    weight = gl.load(WEIGHT+d).to(gl.float32)
    scaled = rn_mul(norm,weight).to(OUT.dtype.element_ty).to(gl.float32)
    z = gl.load(Z+row*ZS+head*128+d).to(gl.float32)
    sigmoid = 1./(1.+gl.exp(-z))
    gl.store(op,rn_mul(scaled,rn_mul(z,sigmoid)))


def launch(mixed,a,b,log,bias,state,slots,z,weight,eps,raw,out,dump=True):
    assert len(slots)>32 and mixed.shape==(len(slots),8192)
    assert z.shape==(len(slots),4096) and state.shape[1:]==(32,128,128)
    assert slots.stride(0)==1
    return fused_kernel[(len(slots)*32,)](mixed,a,b,log,bias,state,slots,z,weight,raw,out,
        mixed.stride(0),a.stride(0),b.stride(0),state.stride(0),z.stride(0),eps,dump,
        num_warps=4,num_stages=3,enable_fp_fusion=True)
