"""Independent CPU FP64 math reference with the model's BF16 tensor boundaries.

This diagnostic does not alter the authoritative first-layer EXACT_FAIL.
It evaluates the same native recurrence equation, not a different model.
"""
import hashlib,json
from pathlib import Path
import torch
ROOT=Path(__file__).resolve().parent
torch.set_num_threads(8)
p=torch.load(ROOT/'first-native-inputs.pt',map_location='cpu',weights_only=True)
actual=torch.load(ROOT/'first-native-actuals.pt',map_location='cpu',weights_only=True)
slots=p['slots'];batch=len(slots)
reference_state=[];reference_raw=[];reference_norm=[]
for start in range(0,batch,4):
 end=min(start+4,batch);m=p['mixed'][start:end].double()
 q=m[:,:2048].reshape(-1,16,128);k=m[:,2048:4096].reshape(-1,16,128);v=m[:,4096:].reshape(-1,32,128)
 q=(q/(q.square().sum(-1,keepdim=True)+1e-6).sqrt()*(128**-.5)).repeat_interleave(2,dim=1)
 k=(k/(k.square().sum(-1,keepdim=True)+1e-6).sqrt()).repeat_interleave(2,dim=1)
 x=p['a'][start:end].double()+p['bias'].double()
 softplus=torch.where(x<=20.,torch.log1p(torch.exp(x)),x)
 decay=torch.exp(-torch.exp(p['log'].double())*softplus)
 beta=torch.sigmoid(p['b'][start:end].double()).bfloat16().double()
 h=p['initial_state'].index_select(0,slots[start:end]).double()*decay[...,None,None]
 value=(v-(h*k[...,None,:]).sum(-1))*beta[...,None]
 h=h+value[...,None]*k[...,None,:]
 raw=(h*q[...,None,:]).sum(-1)
 raw_bf16=raw.bfloat16().double()
 norm=raw_bf16*torch.rsqrt(raw_bf16.square().mean(-1,keepdim=True)+p['eps'])
 weighted=(norm.bfloat16().double()*p['weight'].double()).bfloat16().double()
 z=p['z'][start:end].reshape(-1,32,128).double()
 final=weighted*(z*torch.sigmoid(z))
 reference_state.append(h);reference_raw.append(raw);reference_norm.append(final)
ref=dict(state=torch.cat(reference_state),raw=torch.cat(reference_raw),norm=torch.cat(reference_norm),slots=slots)
torch.save(ref,ROOT/'first-reference-fp64.pt')
def rrms(a,b):
 a=a.double().reshape(batch,32,-1);b=b.double().reshape(batch,32,-1)
 return (a-b).square().mean(-1).sqrt()/b.square().mean(-1).sqrt().clamp_min(1e-30)
report=dict(status='CPU_REFERENCE_COMPLETE',cuda_initialized=torch.cuda.is_initialized(),source_sha='463d837cd51fb62196378835a33731cb659a66c8',script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),reference='FP64 real math on CPU, BF16 beta/raw/normalized/weighted-normalized boundaries retained. Compare returned BF16 state/raw/norm against the corresponding unrounded mathematical reference; CPU does not reproduce GPU reduction/FMA ordering.',exact_gate='Original EXACT_FAIL unchanged.',per_head_reference_rrms={},per_head_against_A={})
for arm in ('a','b','c'):
 report['per_head_reference_rrms'][arm]={}
 if arm!='a':report['per_head_against_A'][arm]={}
 for name in ('state','raw','norm'):
  a=p['expected_'+name] if arm=='a' else actual[name+'_'+arm]
  if name=='state':a=a.index_select(0,slots)
  r=rrms(a,ref[name]);report['per_head_reference_rrms'][arm][name]=dict(max=float(r.max()),mean=float(r.mean()),values=r.tolist())
  if arm!='a':
   base=p['expected_'+name];base=base.index_select(0,slots) if name=='state' else base
   d=rrms(a,base);report['per_head_against_A'][arm][name]=dict(max=float(d.max()),mean=float(d.mean()),values=d.tolist())
assert not report['cuda_initialized']
(ROOT/'cpu-fp64-reference.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:{arm:{name:{m:v for m,v in row.items() if m!='values'} for name,row in tensors.items()} for arm,tensors in report[k].items()} for k in ('per_head_reference_rrms','per_head_against_A')},indent=2))
