import datetime,hashlib,json,os,subprocess,threading
from pathlib import Path
root=Path(__file__).resolve().parent
source=root.parent/'source-router-463d837'
python='/home/zjy/code/hsliu/venvs/codex-drama3-standalone/bin/python'
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()
assert sha=='463d837cd51fb62196378835a33731cb659a66c8'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True).strip()
flags=dict(DRAMA3_GDN_STATE_DTYPE='bfloat16',DRAMA3_PREFILL_GDN='fla',DRAMA3_PACKED_MOE_PROJECTION='1',DRAMA3_PREFILL_CONV='triton',DRAMA3_PREFILL_MOE_TUNED='0',DRAMA3_PREFILL_MOE='flashinfer',DRAMA3_FUSED_MOE_INPUT='1',DRAMA3_COMPACT_GDN='1',DRAMA3_FUSED_MIXED_LAYOUT='1',DRAMA3_PACKED_CONV_GUARD='1',DRAMA3_SHORT_PADDING_CONTEXT='1',DRAMA3_FUSED_MOE_RESIDUAL='1',DRAMA3_RESERVED_PADDING_ROUTER='0',DRAMA3_CODEC_SMS='0',DRAMA3_FRAME_PIPELINE='0')
env={k:v for k,v in os.environ.items() if not k.startswith('DRAMA3_')}
env.update(flags,CUDA_VISIBLE_DEVICES='7',OMP_NUM_THREADS='4',PYTHONPATH=f'{source}/src:{source}/scripts:/home/zjy/code/hsliu/drama3-sources/fish-speech')
query=['nvidia-smi','--query-compute-apps=gpu_uuid,pid,process_name,used_gpu_memory','--format=csv,noheader'];before=subprocess.check_output(query,text=True)
assert 'GPU-40e00845-d89c-1393-2c32-a2dca3ee9442' not in before
cmd=[python,str(root/'validate_first_layer.py')]
plan=dict(source_sha=sha,runtime_source=str(source),artifacts_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [root/'validate_first_layer.py',root/'fused_norm.py']},hypothesis='One full-V128 head CTA combines packed recurrent GDN with native gated normalization and strided z loads, removing raw-output roundtrip, independent norm launch and z-contiguous copy while retaining native BF16/FMA boundaries.',isolated_variable='A nativeBV32+zcopy+norm;B nativeBV128/4warp+zcopy+norm attribution;C artifact-onlyBV128/4warp recurrence+norm, no convolution change.',controls='Frozen native463d837, first64 corpus prompts, nativeprefill/firstframe/eight decode steps, identical real mixed/a/b/z/weight/slots and initial state. Same GPU7, dtype and full model computation. No source changes.',gate='First real layer B64: fullstate, raw recurrenceoutput, normoutput all finite and bitwise exact. Onlythen compare fixed-state captured A/C combinedlocal latency and require>=5%reduction before expanding all30 layers and B1/8/32/64/fullB64partial58.',stop='First exact mismatch persists rawinputs/outputs/compilerPTX and stops timing promotion; no service or runtime changes. Speed gatefailure stops expansion; not a tile sweep.',gpu=7,gpu_uuid='GPU-40e00845-d89c-1393-2c32-a2dca3ee9442',before_gpu=before,flags=flags,command=cmd,cpu_affinity=sorted(os.sched_getaffinity(0)),storage={p:subprocess.check_output(['findmnt','-T',p,'-o','TARGET,SOURCE,FSTYPE','--noheadings'],text=True).strip() for p in (python,'/home/zjy/.cache/huggingface/hub','/home/zjy/code/hsliu/cache')})
(root/'experiment.json').write_text(json.dumps(plan,indent=2)+'\n')
stop=threading.Event()
def audit():
 with (root/'process-audit.jsonl').open('w') as f:
  while not stop.is_set():
   p=subprocess.run(query,text=True,capture_output=True);f.write(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),processes=p.stdout.splitlines()))+'\n');f.flush();stop.wait(1)
t=threading.Thread(target=audit);t.start()
try:
 with (root/'first-layer.log').open('w') as f:subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
finally:stop.set();t.join()
