"""Codec-only native capture isolation; records exact failing conv without changing precision/algorithms."""
import argparse,ctypes,hashlib,json,traceback
from pathlib import Path
import torch
import torch.nn.functional as F
from drama3.codec import load_codec,streaming_codec
from drama3.ops.dac_channels_last import DACDecodeGraphs

@torch.inference_mode()
def main():
 p=argparse.ArgumentParser();p.add_argument('--checkpoint',type=Path,required=True);p.add_argument('--fish-source',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--current-green',action='store_true');p.add_argument('--sms',type=int,default=32);args=p.parse_args()
 result=dict(status='INITIALIZING',source_sha='ab6da532083854670348583d9ec9f2a16d184dfb',driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),torch=torch.__version__,cudnn=torch.backends.cudnn.version(),gpu_uuid=str(torch.cuda.get_device_properties(0).uuid),requested_sms=args.sms,current_green=args.current_green,precision='Same native BF16 autocast as existing codec',controls=dict(cudnn_benchmark=torch.backends.cudnn.benchmark,cudnn_deterministic=torch.backends.cudnn.deterministic,cudnn_allow_tf32=torch.backends.cudnn.allow_tf32,matmul_allow_tf32=torch.backends.cuda.matmul.allow_tf32),limits='Codec-only reproduction; no model, MPS daemon, clock or algorithm changes; no service timing claim.')
 def save():args.output.write_text(json.dumps(result,indent=2)+'\n')
 save()
 lib=ctypes.CDLL('libcuda.so.1');getctx=lib.cuCtxGetCurrent;getctx.argtypes=[ctypes.POINTER(ctypes.c_void_p)];getctx.restype=ctypes.c_int
 greenfn=lib.cuStreamGetGreenCtx;greenfn.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_void_p)];greenfn.restype=ctypes.c_int
 resfn=lib.cuGreenCtxGetDevResource;resfn.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_int];resfn.restype=ctypes.c_int
 def context():
  c=ctypes.c_void_p();assert getctx(ctypes.byref(c))==0
  s=torch.cuda.current_stream();g=ctypes.c_void_p();assert greenfn(s.cuda_stream,ctypes.byref(g))==0
  return dict(current_context=c.value,current_stream=s.cuda_stream,stream_green_context=g.value,capturing=torch.cuda.is_current_stream_capturing())
 codec=streaming_codec(load_codec(args.checkpoint,args.fish_source),64)
 result['normal_capture_complete']=True;result['normal_context']=context();save()
 ctx=torch.cuda.GreenContext.create(num_sms=args.sms,device_id=0);stream=ctx.Stream()
 gh=ctypes.c_void_p();assert greenfn(stream.cuda_stream,ctypes.byref(gh))==0
 buf=ctypes.create_string_buffer(512);assert resfn(gh,buf,1)==0
 result['actual_sms']=ctypes.c_uint.from_buffer(buf,96).value;result['green_stream']=stream.cuda_stream;result['green_handle']=gh.value
 cap=DACDecodeGraphs(codec.decoder,num_codebooks=10,frame_buckets=(8,),max_padded_frames=512,max_batch=8,receptive_frames=0,stream=codec.stream)
 def describe(v):
  if isinstance(v,torch.Tensor):return dict(shape=list(v.shape),stride=list(v.stride()),dtype=str(v.dtype),storage_offset=v.storage_offset())
  if isinstance(v,(tuple,list)):return [describe(x) for x in v]
  if isinstance(v,dict):return {k:describe(x) for k,x in v.items()}
  return v
 native_conv=F.conv2d;calls=0;failure=None
 def observed_conv(x,w,*a,**kw):
  nonlocal calls,failure
  calls+=1
  meta=dict(call=calls,input_shape=list(x.shape),input_stride=list(x.stride()),input_dtype=str(x.dtype),input_storage_offset=x.storage_offset(),weight_shape=list(w.shape),weight_stride=list(w.stride()),weight_dtype=str(w.dtype),weight_storage_offset=w.storage_offset(),groups=kw.get('groups',1),args=describe(a),kwargs=describe(kw),context=context())
  try:return native_conv(x,w,*a,**kw)
  except BaseException as e:
   meta['exception']=repr(e);result['failed_conv']=meta;failure=(x,w,a,kw);raise
 F.conv2d=observed_conv
 pushed=False
 try:
  if args.current_green:ctx.set_context();pushed=True
  result['before_capture_context']=context();save()
  with torch.autocast('cuda',dtype=codec.decoder.dtype):cap.capture(torch.device('cuda'),capture_stream=stream)
  result['status']='CAPTURE_PASS';result['after_capture_context']=context()
 except BaseException as e:
  result['status']='CAPTURE_FAIL';result['exception']=repr(e);result['traceback']=traceback.format_exc()
 finally:
  F.conv2d=native_conv
  if pushed:
   try:ctx.pop_context()
   except BaseException as e:result['cleanup_exception']=repr(e)
  result['observed_conv_calls']=calls;save()
 if failure is not None:
  x,w,a,kw=failure
  try:
   # Capture context manager has exited. These are only diagnostic copies.
   torch.cuda.synchronize()
   target=args.output.with_suffix('.pt')
   torch.save(dict(input=x.detach().cpu(),weight=w.detach().cpu(),bias=a[0].detach().cpu() if a and isinstance(a[0],torch.Tensor) else None,kwargs=kw),target)
   result['failed_tensors']=str(target)
  except BaseException as e:result['tensor_copy_exception']=repr(e)
 save();print(json.dumps(result,indent=2))

if __name__=='__main__':main()
