import ctypes,json
from pathlib import Path
import torch
lib=ctypes.CDLL('libcuda.so.1');get=lib.cuCtxGetCurrent;get.argtypes=[ctypes.POINTER(ctypes.c_void_p)];get.restype=ctypes.c_int
setctx=lib.cuCtxSetCurrent;setctx.argtypes=[ctypes.c_void_p];setctx.restype=ctypes.c_int
def current():
 c=ctypes.c_void_p();assert get(ctypes.byref(c))==0;return c.value
torch.zeros(1,device='cuda');primary=current();ctx=torch.cuda.GreenContext.create(num_sms=32,device_id=0);stream=ctx.Stream();x=torch.zeros((8,10,8),device='cuda',dtype=torch.long);idle=torch.tensor([[64],[1],[8],[0]],device='cuda',dtype=torch.long);ctx.set_context();green=current();rows=[]
for name,op in [('torch.cuda.set_device explicit',lambda:torch.cuda.set_device(0)),('torch.cuda.current_stream',lambda:torch.cuda.current_stream()),('stream context enter',lambda:torch.cuda.set_stream(stream)),('torch.zeros cuda unindexed',lambda:torch.zeros((8,10,8),device=torch.device('cuda'),dtype=torch.long)),('torch.zeros cuda indexed',lambda:torch.zeros((8,10,8),device=torch.device('cuda:0'),dtype=torch.long)),('torch.tensor device',lambda:torch.tensor([[64],[1],[8],[0]],device='cuda',dtype=torch.long)),('expand contiguous',lambda:idle.expand(4,8).contiguous()),('clone',lambda:x.clone()),('graph pool handle',lambda:torch.cuda.graph_pool_handle()),('accelerator synchronize',lambda:torch.accelerator.synchronize(torch.device('cuda'))),('cuda synchronize',lambda:torch.cuda.synchronize())]:
 assert setctx(green)==0;before=current();v=op();after=current();rows.append(dict(operation=name,before=before,after=after,preserved=before==after))
assert setctx(green)==0;ctx.pop_context();torch.cuda.synchronize()
r=dict(primary=primary,green=green,operations=rows,limits='Tiny allocation/API isolation, no timing claim or runtime edits');p=Path(__file__).with_suffix('.json');p.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
