"""Exact failed native BF16 convolution, isolated from the decoder."""
import argparse,ctypes,hashlib,json,traceback
from pathlib import Path
import torch
import torch.nn.functional as F

@torch.inference_mode()
def main():
 p=argparse.ArgumentParser();p.add_argument('--mode',choices=['stream','context'],required=True);p.add_argument('--sms',type=int,default=32);p.add_argument('--output',type=Path,required=True);args=p.parse_args()
 base=Path(__file__).parent; data=torch.load(base/'stream-result.pt',map_location='cpu',weights_only=True)
 result=dict(status='RUNNING',mode=args.mode,sms=args.sms,driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),torch=torch.__version__,cudnn=torch.backends.cudnn.version(),tensor_sha256=hashlib.sha256((base/'stream-result.pt').read_bytes()).hexdigest(),controls=dict(cudnn_benchmark=torch.backends.cudnn.benchmark,cudnn_deterministic=torch.backends.cudnn.deterministic,cudnn_allow_tf32=torch.backends.cudnn.allow_tf32,matmul_allow_tf32=torch.backends.cuda.matmul.allow_tf32),stage='load')
 def save():args.output.write_text(json.dumps(result,indent=2)+'\n')
 save();ctx=None;pushed=False
 try:
  x=data['input'].cuda();w=data['weight'].cuda();b=data['bias'];kw=data['kwargs'];result.update(shape=list(x.shape),stride=list(x.stride()),weight_shape=list(w.shape),weight_stride=list(w.stride()),dtype=str(x.dtype))
  # Establish the identical uncapped native operation before any green context exists.
  result['stage']='normal_eager';ref=F.conv2d(x,w,b,**kw);torch.cuda.synchronize()
  normal=torch.cuda.Stream();ng=torch.cuda.CUDAGraph()
  result['stage']='normal_capture'
  with torch.cuda.graph(ng,stream=normal):ny=F.conv2d(x,w,b,**kw)
  with torch.cuda.stream(normal):ng.replay()
  normal.synchronize();result['normal_graph_exact']=torch.equal(ny,ref)
  ctx=torch.cuda.GreenContext.create(num_sms=args.sms,device_id=0);stream=ctx.Stream()
  lib=ctypes.CDLL('libcuda.so.1');gf=lib.cuStreamGetGreenCtx;gf.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_void_p)];gf.restype=ctypes.c_int;gh=ctypes.c_void_p();assert gf(stream.cuda_stream,ctypes.byref(gh))==0
  rf=lib.cuGreenCtxGetDevResource;rf.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_int];rf.restype=ctypes.c_int;buf=ctypes.create_string_buffer(512);assert rf(gh,buf,1)==0
  result.update(actual_sms=ctypes.c_uint.from_buffer(buf,96).value,green_handle=gh.value,green_stream=stream.cuda_stream)
  if args.mode=='context':ctx.set_context();pushed=True
  result['stage']='green_eager';save()
  with torch.cuda.stream(stream):
   for _ in range(2):y=F.conv2d(x,w,b,**kw)
  stream.synchronize();result['green_eager_exact']=torch.equal(y,ref)
  result['stage']='green_capture';save();g=torch.cuda.CUDAGraph()
  with torch.cuda.graph(g,stream=stream):z=F.conv2d(x,w,b,**kw)
  with torch.cuda.stream(stream):g.replay()
  stream.synchronize();result['green_graph_exact']=torch.equal(z,ref);result['status']='PASS';result['stage']='complete'
 except BaseException as e:result.update(status='FAIL',exception=repr(e),traceback=traceback.format_exc())
 finally:
  if pushed:
   try:ctx.pop_context()
   except BaseException as e:result['cleanup_exception']=repr(e)
 save();print(json.dumps(result,indent=2))
if __name__=='__main__':main()
