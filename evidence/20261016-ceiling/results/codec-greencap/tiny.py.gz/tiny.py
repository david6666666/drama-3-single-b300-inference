import ctypes
import gc
import json
from pathlib import Path
import torch
import triton
import triton.language as tl

@triton.jit
def work(x, out, ids, N:tl.constexpr, BLOCK:tl.constexpr):
    pid=tl.program_id(0)
    offsets=pid*BLOCK+tl.arange(0,BLOCK)
    value=tl.load(x+offsets,offsets<N,other=0)
    tl.store(out+offsets,value*2+1,offsets<N)
    sid=tl.inline_asm_elementwise('mov.u32 $0, %smid;',constraints='=r',args=[],dtype=tl.int32,is_pure=False,pack=1)
    tl.store(ids+pid,sid)

@torch.inference_mode()
def main():
    folder=Path(__file__).parent
    outpath=folder/'tiny-result.json'
    result=dict(status='RUNNING',torch=torch.__version__,gpu_uuid=str(torch.cuda.get_device_properties(0).uuid),device_sms=torch.cuda.get_device_properties(0).multi_processor_count,trials=[])
    def save():outpath.write_text(json.dumps(result,indent=2)+'\n')
    save()
    driver=ctypes.CDLL('libcuda.so.1')
    green=driver.cuStreamGetGreenCtx;green.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_void_p)];green.restype=ctypes.c_int
    resource=driver.cuGreenCtxGetDevResource;resource.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_int];resource.restype=ctypes.c_int
    cudart=ctypes.CDLL('/home/zjy/code/hsliu/venvs/codex-drama3-standalone/lib/python3.12/site-packages/nvidia/cu13/lib/libcudart.so.13')
    flagsfn=cudart.cudaGraphExecGetFlags;flagsfn.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_ulonglong)];flagsfn.restype=ctypes.c_int
    n=4096*256
    x=torch.ones(n,device='cuda');y=torch.empty_like(x);ids=torch.empty(4096,dtype=torch.int32,device='cuda')
    normal=torch.cuda.Stream();normal.wait_stream(torch.cuda.current_stream())
    with torch.cuda.stream(normal):
        work[(4096,)](x,y,ids,n,256)
    normal.synchronize()
    graph=torch.cuda.CUDAGraph()
    with torch.cuda.graph(graph,stream=normal):work[(4096,)](x,y,ids,n,256)
    flag=ctypes.c_ulonglong();assert flagsfn(graph.raw_cuda_graph_exec(),ctypes.byref(flag))==0
    result['graph_flags']=flag.value
    contexts=[]
    for sms in [None,32,48]:
        ctx=None if sms is None else torch.cuda.GreenContext.create(num_sms=sms,device_id=0)
        stream=normal if ctx is None else ctx.Stream()
        if ctx is not None:contexts.append(ctx)
        handle=ctypes.c_void_p();assert green(stream.cuda_stream,ctypes.byref(handle))==0
        actual=None
        if ctx is not None:
            assert handle.value
            buf=ctypes.create_string_buffer(512)
            assert resource(handle,buf,1)==0
            # CUdevResource ABI v1: enum + internal padding[92], then sm.smCount.
            actual=ctypes.c_uint.from_buffer(buf,96).value
            assert actual>=sms and actual<=result['device_sms'],actual
        torch.cuda.synchronize();ids.fill_(-1);y.zero_();torch.cuda.synchronize()
        with torch.cuda.stream(stream):graph.replay()
        stream.synchronize()
        touched=sorted(set(ids.cpu().tolist()))
        valid=bool(torch.equal(y,torch.full_like(y,3)))
        row=dict(requested_sms=sms,green_handle=handle.value,resource_sms=actual,sm_ids=touched,observed_unique_sms=len(touched),output_exact=valid)
        result['trials'].append(row);save()
        assert valid and touched[0]>=0
        if actual is not None:assert len(touched)<=actual, 'Primary-captured graph ignored green-context launch cap'
    torch.cuda.synchronize()
    del stream,ctx,contexts,graph
    gc.collect()
    result['status']='PASS';result['limitations']='Tiny primary-captured graph only; SM-ID sample is not proof of disjoint partition or library-graph behavior. No MPS daemon or device-global changes.';save()

if __name__=='__main__':main()
