import argparse,json,traceback
from pathlib import Path
import torch
import torch.nn.functional as F

@torch.inference_mode()
def main():
 p=argparse.ArgumentParser();p.add_argument('--mode',choices=['stream','context'],required=True);args=p.parse_args()
 folder=Path(__file__).parent
 result=dict(mode=args.mode,status='RUNNING',dtype='bfloat16',shape=[8,768,1,262],weight=[768,768,1,7],cudnn=torch.backends.cudnn.version())
 ctx=None; pushed=False
 try:
  x=torch.randn(8,262,768,device='cuda',dtype=torch.bfloat16).transpose(1,2).unsqueeze(2)
  w=torch.randn(768,7,768,device='cuda',dtype=torch.bfloat16).transpose(1,2).unsqueeze(2)
  ref=F.conv2d(x,w);torch.cuda.synchronize()
  ctx=torch.cuda.GreenContext.create(num_sms=32,device_id=0);stream=ctx.Stream()
  if args.mode=='context':ctx.set_context();pushed=True
  with torch.cuda.stream(stream):
   for _ in range(2):y=F.conv2d(x,w)
  stream.synchronize()
  result['eager_exact']=torch.equal(y,ref)
  graph=torch.cuda.CUDAGraph()
  with torch.cuda.graph(graph,stream=stream):z=F.conv2d(x,w)
  with torch.cuda.stream(stream):graph.replay()
  stream.synchronize()
  result['graph_exact']=torch.equal(z,ref);result['status']='PASS'
 except BaseException as e:
  result['status']='FAIL';result['exception']=repr(e);result['traceback']=traceback.format_exc()
 finally:
  if pushed:ctx.pop_context()
  (folder/f'tiny-conv-{args.mode}.json').write_text(json.dumps(result,indent=2)+'\n')
  print(json.dumps(result))

if __name__=='__main__':main()
