"""Artifact: metadata-ready M128 FC2 with captured full metadata dependency.
The vendor prepared full body is an independent reference. No runtime edits.
"""

import gc
import json
import os
import subprocess
import sys
import traceback
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
MODE = sys.argv[1]
os.environ.update(
    CUTE_DSL_ARCH="sm_103a",
    CUTE_DSL_KEEP="ptx,cubin",
    FLASHINFER_PRIMS_TS_COMPILE_OPTIONS="--opt-level 2 --gpu-arch sm_103a",
    CUTE_DSL_DUMP_DIR=str(
        OUT
        / ("driver-cpu-compile" if MODE == "prepare" else "gpu-" + MODE + "-compile")
    ),
)
Path(os.environ["CUTE_DSL_DUMP_DIR"]).mkdir(exist_ok=True)
from types import SimpleNamespace

import body_common as c
import cuda.bindings.driver as drv
import torch
from flashinfer.prims_ts.batched_gemm.batched_gemm_config import make_config
from flashinfer.prims_ts.batched_gemm.batched_gemm_run import (
    _compile_for_launch,
    _launch_arg_tuple,
)
from flashinfer.prims_ts.moe.tensor_adapter import build_fp8_block_scale_launch_io
from flashinfer.tllm_enums import (
    ActivationType,
    DtypeTrtllmGen,
    Fp8QuantizationType,
    RoutingInputMode,
)

ORACLES = sorted((ROOT / "expert-metadata-rebase").glob("oracle-layer*.pt"))
OUTPUTS = ("fc1", "fc1scale", "act", "actscale", "fc2", "out")
SENTINELS = {"fc1": 173, "fc1scale": -17.0, "act": 91, "actscale": -19.0, "fc2": 7.0, "out": 11.0}
report = {
    "status": "PREPARING",
    "mode": MODE,
    "checks": [],
    "timing_allowed": MODE in ("feasibility", "timing"),
    "source_sha": subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=c.SOURCE, text=True
    ).strip(),
    "source_status": subprocess.check_output(
        ["git", "status", "--porcelain"], cwd=c.SOURCE, text=True
    ),
    "pid": os.getpid(),
}


def flush():
    (
        OUT / ("driver-prepare.json" if MODE == "prepare" else MODE + "-result.json")
    ).write_text(json.dumps(report, indent=2) + "\n")


def req(name, value, detail=None):
    report["checks"].append({"name": name, "exact": bool(value), "detail": detail})
    flush()
    if not value:
        raise AssertionError(name)


def chk(name, a, b):
    a = a.contiguous()
    b = b.contiguous()
    ok = (
        a.shape == b.shape
        and a.dtype == b.dtype
        and torch.equal(a.view(torch.uint8), b.view(torch.uint8))
    )
    report["checks"].append(
        {"name": name, "exact": ok, "shape": list(a.shape), "dtype": str(a.dtype)}
    )
    flush()
    if not ok:
        torch.save(
            {"actual": a.cpu(), "expected": b.cpu()},
            OUT / (name.replace("/", "_") + "-mismatch.pt"),
        )
        raise AssertionError(name)


from metadata_ready_config import make_metadata_ready_fc2, validate_io
from metadata_ready_graph import MetadataReadyGraph, record_eager_metadata


def configs():
    return {
        "fc1": make_config(
            **{
                **json.loads(
                    (ROOT / "expert-m128-fc1-expanded/prepare.json").read_text()
                )["config"]["candidate"],
                "use_pdl": 1,
                "do_pdl_wait_for_num_non_exiting_ctas": 1,
            }
        ),
        "fc2": make_metadata_ready_fc2(),
    }


def compile_candidate(fc, io, stream):
    if fc == "fc1":
        return _compile_for_launch(io, stream)
    validate_io(io)
    import importlib.util

    from cutlass import cute
    from cutlass.cutlass_dsl import BaseDSL
    from flashinfer.prims_ts.batched_gemm.batched_gemm_run import (
        _compile_arg_tuple,
        _cute_compile_options,
    )
    from flashinfer.prims_ts.cutlass_dsl import task_scheduling_scope

    name = "flashinfer.prims_ts.batched_gemm.metadata_ready_kernel"
    if name not in sys.modules:
        spec = importlib.util.spec_from_file_location(
            name, OUT / "metadata_ready_kernel.py"
        )
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module
        spec.loader.exec_module(module)
    with task_scheduling_scope(), BaseDSL.enable_pyir():
        return cute.compile(
            sys.modules[name].gemm,
            *_compile_arg_tuple(io, stream),
            options=_cute_compile_options(),
        )


def reset(x):
    for name in OUTPUTS:
        x[name].fill_(SENTINELS[name])


def update(x, d):
    md, _ = c.metadata(d)
    for key, t in md.items():
        x[key].copy_(t)
    x["expanded"].copy_(md["mapping"].to(torch.int32))
    for dst, src in [
        ("q", "q"),
        ("s", "input_scale"),
        ("ids", "ids"),
        ("weights", "weights"),
    ]:
        x[dst].copy_(d[src])
    reset(x)


def allocate(d, w, device):
    md, _ = c.metadata(d)
    x = {key: t.to(device) for key, t in md.items()}
    x.update(
        expanded=md["mapping"].to(device=device, dtype=torch.int32),
        q=d["q"].to(device),
        s=d["input_scale"].to(device),
        ids=d["ids"].to(device),
        weights=d["weights"].to(device),
        w1=w[0],
        s1=w[1],
        w2=w[2],
        s2=w[3],
    )
    specs = {
        "fc1": ((c.CAP, 1024), torch.uint8),
        "fc1scale": ((8 * c.CAP,), torch.float32),
        "act": ((c.CAP, 512), torch.uint8),
        "actscale": ((4 * c.CAP,), torch.float32),
        "fc2": ((c.CAP, 2048), torch.bfloat16),
        "out": ((64, 2048), torch.bfloat16),
    }
    for name, (shape, dtype) in specs.items():
        count = 1
        for dim in shape:
            count *= dim
        raw = torch.full((count + 128,), 37, dtype=dtype, device=device)
        x["guard_" + name] = raw
        x[name] = raw[64:-64].view(shape)
    reset(x)
    return x


def io_for(fc, cfg, x):
    return build_fp8_block_scale_launch_io(
        fc=fc,
        cfg=cfg,
        fp8_quantization_type=Fp8QuantizationType.DeepSeekFp8,
        hidden_states=x["q"],
        hidden_states_scale=x["s"],
        gemm1_weights=x["w1"],
        gemm1_weights_scale=x["s1"],
        gemm2_weights=x["w2"],
        gemm2_weights_scale=x["s2"],
        gemm1_output=x["fc1"],
        gemm1_output_scale=x["fc1scale"],
        activation_output=x["act"],
        activation_output_scale=x["actscale"],
        gemm2_output=x["fc2"],
        tile_idx=x.get("live_tile", x["tile"]),
        mn_limit=x.get("live_mn", x["mn"]),
        route_map=x.get("live_route", x["route"]),
        num_non_exiting_ctas=x.get("live_ncta", x["ncta"]),
        total_num_padded_tokens=x.get("live_padded", x["padded"]),
        routed_token_capacity=c.CAP,
        activation_type=int(ActivationType.Swiglu),
        num_experts=256,
        num_tokens=64,
        top_k=8,
        intermediate_size=512,
        hidden_size=2048,
    )


def compile_pair(x):
    ios = {fc: io_for(fc, v, x) for fc, v in configs().items()}
    fns = {}
    records = {}
    dump = Path(os.environ["CUTE_DSL_DUMP_DIR"])
    for fc, io in ios.items():
        before = set(dump.glob("*.cubin"))
        stream = drv.CUstream(
            0 if MODE == "prepare" else torch.cuda.current_stream().cuda_stream
        )
        fns[fc] = compile_candidate(fc, io, stream)
        after = set(dump.glob("*.cubin"))
        new = after - before
        # Each config has a unique typed kernel. One fresh compile directory is required.
        req(fc + "/one_new_cubin", len(new) == 1)
        binary = new.pop()
        host = dump / (fc + "-host.mlir")
        host.write_text(str(fns[fc].ir_module))
        records[fc] = {"cubin": str(binary), "sha256": c.sha(binary), "host": str(host)}
    return ios, fns, records


def candidate_stages(runtime, x, ios, fns):
    def gemm(fc):
        fns[fc](
            *_launch_arg_tuple(
                ios[fc], drv.CUstream(torch.cuda.current_stream().cuda_stream)
            )
        )

    def activation():
        runtime.moe_op.trtllm_moe_run_deepseek_fp8_activation(
            x["fc1"],
            x["fc1scale"],
            x["act"],
            x["actscale"],
            x.get("live_expanded", x["expanded"]),
            x.get("live_padded", x["padded"]),
            64,
            8,
            512,
            int(ActivationType.Swiglu),
            True,
        )

    def finalize():
        runtime.moe_op.trtllm_moe_run_finalize(
            x["fc2"],
            x["out"],
            x["weights"],
            x.get("live_expanded", x["expanded"]),
            x.get("live_padded", x["padded"]),
            64,
            256,
            8,
            2048,
            True,
            False,
        )

    return {
        "fc1": lambda: gemm("fc1"),
        "activation": activation,
        "fc2": lambda: gemm("fc2"),
        "finalize": finalize,
    }


def candidate_eager(runtime, x, ios, fns, metadata_owner):
    stages = candidate_stages(runtime, x, ios, fns)
    permit = record_eager_metadata(
        metadata_owner["populate"],
        owners=[runtime, x, ios, fns, metadata_owner, stages],
        fc2_validate=lambda: validate_io(ios["fc2"]),
    )

    def chain():
        for role in ("fc1", "activation", "fc2", "finalize"):
            stages[role]()

    permit.wait().launch_once(chain)
    # Keep the completed-metadata permit and its immutable descriptors alive until
    # this eager correctness operation is complete; never used for timing.
    torch.cuda.current_stream().synchronize()
    return permit


def capture_candidate(runtime, x, ios, fns, metadata_owner, label):
    stages = candidate_stages(runtime, x, ios, fns)
    guard = MetadataReadyGraph(
        owners=[runtime, x, ios, fns, metadata_owner, stages],
        fc2_validate=lambda: validate_io(ios["fc2"]),
    )
    with guard.capture():
        guard.record_metadata(metadata_owner["populate"])
        guard.record_fc1(stages["fc1"])
        guard.record_activation(stages["activation"])
        guard.record_fc2(stages["fc2"])
        guard.record_finalize(stages["finalize"])
    evidence = guard.seal()
    evidence["label"] = label
    report.setdefault("metadata_ready_graphs", []).append(evidence)
    flush()
    guard.instantiate()
    return guard


def native_body(runtime, x):
    from flashinfer.fused_moe import core as fi
    from flashinfer.fused_moe.shared.inputs import MoeRunnerInputs

    runner = runtime.MoERunner(
        runtime.moe_op,
        top_k=8,
        num_local_experts=256,
        dtype_act=DtypeTrtllmGen.E4m3,
        dtype_weights=DtypeTrtllmGen.E4m3,
        fp8_quantization_type=Fp8QuantizationType.DeepSeekFp8,
        hidden_size=2048,
        intermediate_size=512,
        num_experts=256,
    )
    output = torch.empty((64, 2048), dtype=torch.bfloat16, device="cuda")
    inp = MoeRunnerInputs(
        output, None, x["ids"], x["weights"], x["q"], x["s"], None, None
    ).to_list()
    kw = {
        "routing_bias": None,
        "num_experts": 256,
        "n_group": None,
        "topk_group": None,
        "routed_scaling_factor": 1.0,
        "routing_method_type": 4,
        "use_shuffled_weight": False,
        "weight_layout": 0,
        "enable_pdl": True,
        "local_expert_offset": 0,
        "do_finalize": True,
        "routing_input_mode": RoutingInputMode.UnpackedPrecomputed,
        "gemm1_weights": x["w1"],
        "gemm1_weights_scale": x["s1"],
        "gemm2_weights": x["w2"],
        "gemm2_weights_scale": x["s2"],
    }
    meta = fi.trtllm_moe_allocate_routing_metadata_multi_tile(
        x["ids"],
        num_experts=256,
        top_k=8,
        local_expert_offset=0,
        num_local_experts=256,
        tile_ns=[8],
        routing_input_mode=RoutingInputMode.UnpackedPrecomputed,
        topk_weights=x["weights"],
    )
    fi.populate_trtllm_moe_routing_metadata_(meta, x["ids"], x["weights"])
    slot = meta.slots[0]
    body = SimpleNamespace(tile_n=8, tactic=5)
    runner = runtime.DABodyRunner(runner)
    ws = tuple(
        t if isinstance(t, torch.Tensor) else torch.from_dlpack(t)
        for t in runner.prepare_body(inp, body, slot, **kw)
    )

    def populate():
        fi.populate_trtllm_moe_routing_metadata_(meta, x["ids"], x["weights"])

    def call():
        populate()
        runner.forward_from_metadata(inp, body, slot, ws, **kw)

    return {
        "output": output,
        "slot": slot,
        "ws": ws,
        "populate": populate,
        "call": call,
        "inputs": inp,
        "runner": runner,
        "meta": meta,
    }


def check_outputs(name, x, expected):
    p = int(x["live_padded"])
    mapping = x["live_expanded"].long()
    valid = torch.zeros(c.CAP, dtype=torch.bool, device="cuda")
    valid[mapping] = True
    for key, oracle, channels in [
        ("fc1", "fc1_bytes", 1024),
        ("act", "activation_bytes", 512),
        ("fc2", "fc2_bf16", 2048),
    ]:
        chk(name + "/" + key, x[key][mapping], expected[oracle].to("cuda"))
        chk(
            name + "/" + key + "_padding",
            x[key][~valid],
            torch.full_like(x[key][~valid], SENTINELS[key]),
        )
    for key, oracle, blocks in [
        ("fc1scale", "fc1_scale", 8),
        ("actscale", "activation_scale", 4),
    ]:
        active = x[key][: p * blocks].reshape(blocks, p)
        chk(name + "/" + key, active.T[mapping], expected[oracle].to("cuda"))
        chk(
            name + "/" + key + "_padding",
            active[:, ~valid[:p]],
            torch.full_like(active[:, ~valid[:p]], SENTINELS[key]),
        )
        chk(
            name + "/" + key + "_tail",
            x[key][p * blocks :],
            torch.full_like(x[key][p * blocks :], SENTINELS[key]),
        )
    for key in OUTPUTS:
        raw = x["guard_" + key]
        chk(
            name + "/" + key + "_guards",
            torch.cat((raw[:64], raw[-64:])),
            torch.full_like(raw[:128], 37),
        )


def check_metadata(name, slot, x, d):
    mp = slot.expanded_idx_to_permuted_idx.long()
    p = int(slot.total_num_padded_tokens)
    n = int(slot.num_non_exiting_ctas)
    req(
        name + "/map_bijection_bounds",
        len(mp) == 512
        and mp.unique().numel() == 512
        and bool(((mp >= 0) & (mp < p)).all())
        and p == n * 8
        and 0 < p <= c.CAP
        and 0 < n <= c.CTA,
    )
    chk(
        name + "/expert_ownership",
        slot.cta_idx_xy_to_batch_idx[mp // 8].long(),
        x["ids"].flatten().long(),
    )
    chk(
        name + "/token_ownership",
        slot.permuted_idx_to_token_idx[mp].long(),
        torch.arange(512, device="cuda") // 8,
    )
    chk(name + "/padded_count", slot.total_num_padded_tokens, x["padded"])
    counts = torch.bincount(mp // 8, minlength=n)
    req(name + "/active_row_prefix", bool((mp % 8 < counts[mp // 8]).all()))
    chk(
        name + "/local_valid_count",
        slot.cta_idx_xy_to_mn_limit[:n].long() - torch.arange(n, device="cuda") * 8,
        counts,
    )


def check_native(name, native, x, d):
    slot = native["slot"]
    ws = native["ws"]
    p = int(slot.total_num_padded_tokens)
    mp = slot.expanded_idx_to_permuted_idx.long()
    check_metadata(name + "/native_metadata", slot, x, d)
    for key, i, ch in [
        ("fc1_bytes", 0, 1024),
        ("activation_bytes", 2, 512),
        ("fc2_bf16", 4, 2048),
    ]:
        chk(
            name + "/native_" + key,
            ws[i].reshape(-1, ch)[mp],
            d["intermediates"][key].to("cuda"),
        )
    for key, i, blocks in [("fc1_scale", 1, 8), ("activation_scale", 3, 4)]:
        chk(
            name + "/native_" + key,
            ws[i].flatten()[: p * blocks].reshape(blocks, p).T[mp],
            d["intermediates"][key].to("cuda"),
        )
    chk(name + "/native_routed", native["output"], d["routed"].to("cuda"))


@torch.inference_mode()
def prepare():
    req("cuda_hidden", os.environ.get("CUDA_VISIBLE_DEVICES") == "")
    req(
        "source_frozen",
        report["source_sha"] == "95fcb0ef2662f2caf9bfb7fe6863dc3ad7805b1b"
        and report["source_status"] == "",
    )
    for fc in ("fc1", "fc2"):
        req(
            fc + "/expanded_pass",
            "EXACT_PASS"
            in json.loads(
                (ROOT / f"expert-m128-{fc}-expanded/result.json").read_text()
            )["status"],
        )
    wprobe = c.weights(0, "cpu")
    req("CPU_real_weight_loader", list(wprobe[0].shape) == [256, 1024, 2048])
    del wprobe
    d = torch.load(ORACLES[0], map_location="cpu", weights_only=False)
    x = allocate(d, c.weights(0, "cpu", empty=True), "cpu")
    _ios, _fns, records = compile_pair(x)
    sys.path.insert(0, str(ROOT / "expert-resident-chain"))
    from resource_audit import audit

    report["kernels"] = records
    report["resources"] = {}
    for fc, v in records.items():
        binary = Path(v["cubin"])
        report["resources"][fc] = audit(
            binary,
            binary.with_suffix(".ptx"),
            v["host"],
            OUT / ("driver-resource-" + fc),
            cluster_size=1,
        )
        previous = json.loads(
            (ROOT / f"expert-m128-{fc}-expanded/prepare.json").read_text()
        )["cpu_cubin_sha256"]
        req(fc + "/PDL_cubin_distinct_from_component", v["sha256"] != previous)
        report.setdefault("previous_non_pdl_cubins", {})[fc] = previous
    report["coverage"] = [
        c.metadata(torch.load(p, map_location="cpu", weights_only=False))[1]
        for p in ORACLES
    ]
    req("fifteen_oracles", len(ORACLES) == 15)
    req("cuda_uninitialized", not torch.cuda.is_initialized())
    report["status"] = "CPU_AOT_PASS"
    flush()


@torch.inference_mode()
def run():
    prep = json.loads((OUT / "driver-prepare.json").read_text())
    req("CPU_AOT_PASS", prep["status"] == "CPU_AOT_PASS")
    req(
        "frozen_hashes",
        all(
            c.sha(k) == v
            for k, v in json.loads((OUT / "frozen-inputs.json").read_text()).items()
        ),
    )
    req(
        "source_frozen",
        report["source_sha"] == prep["source_sha"] and report["source_status"] == "",
    )
    req(
        "GPU2_selected",
        os.environ["CUDA_VISIBLE_DEVICES"]
        == "GPU-bc643dc2-a0d1-5ed6-5ecb-0605ca9f340a",
    )
    report["gpu_uuid"] = str(torch.cuda.get_device_properties(0).uuid)
    from flashinfer.fused_moe import core as fi

    runtime = fi.get_trtllm_moe_sm100_module()
    rng = torch.cuda.get_rng_state().clone()
    for layer in (0, 19, 39):
        datasets = [
            torch.load(p, map_location="cpu", weights_only=False)
            for p in ORACLES
            if p.name.startswith(f"oracle-layer{layer}-")
        ]
        w = c.weights(layer, "cuda")
        wbefore = [t.clone() for t in w]
        x = allocate(datasets[0], w, "cuda")
        native = native_body(runtime, x)
        candidate_meta = native_body(runtime, x)
        slot = candidate_meta["slot"]
        for key, field in [
            ("tile", "cta_idx_xy_to_batch_idx"),
            ("mn", "cta_idx_xy_to_mn_limit"),
            ("route", "permuted_idx_to_token_idx"),
            ("ncta", "num_non_exiting_ctas"),
            ("padded", "total_num_padded_tokens"),
            ("expanded", "expanded_idx_to_permuted_idx"),
        ]:
            x["live_" + key] = getattr(slot, field)
        # Recreate descriptors per layer; first compilation supplies immutable binaries.
        if layer == 0:
            ios, fns, records = compile_pair(x)
            for fc, v in records.items():
                req(
                    fc + "/CPU_GPU_cubin_identical",
                    v["sha256"] == prep["kernels"][fc]["sha256"],
                )
        else:
            ios = {fc: io_for(fc, v, x) for fc, v in configs().items()}
            fns = {
                fc: compile_candidate(
                    fc, io, drv.CUstream(torch.cuda.current_stream().cuda_stream)
                )
                for fc, io in ios.items()
            }

        def call(x=x, ios=ios, fns=fns, candidate_meta=candidate_meta):
            return candidate_eager(runtime, x, ios, fns, candidate_meta)

        native["call"]()
        call()
        torch.cuda.synchronize()
        graph = torch.cuda.CUDAGraph()
        with torch.cuda.graph(graph):
            native["call"]()
        graphs = {
            "native": graph,
            "candidate": capture_candidate(
                runtime, x, ios, fns, candidate_meta, f"L{layer}/exact"
            ),
        }
        for d in datasets:
            name = f"L{layer}/{d['scenario']}"
            update(x, d)
            native["populate"]()
            torch.cuda.synchronize()
            before = {
                k: t.clone()
                for k, t in x.items()
                if k not in OUTPUTS
                and not k.startswith(("guard_", "live_"))
                and k not in ("w1", "s1", "w2", "s2")
            }
            native["call"]()
            call()
            torch.cuda.synchronize()
            check_native(name + "/eager", native, x, d)
            check_metadata(
                name + "/eager/candidate_metadata", candidate_meta["slot"], x, d
            )
            check_outputs(name + "/eager", x, d["intermediates"])
            chk(name + "/eager/routed", x["out"], native["output"])
            reset(x)
            graphs["native"].replay()
            graphs["candidate"].replay()
            torch.cuda.synchronize()
            check_native(name + "/graph", native, x, d)
            check_metadata(
                name + "/graph/candidate_metadata", candidate_meta["slot"], x, d
            )
            check_outputs(name + "/graph", x, d["intermediates"])
            chk(name + "/graph/routed", x["out"], native["output"])
            for k, t in before.items():
                chk(name + "/untouched/" + k, x[k], t)
            print(name + " PASS", flush=True)
        for i, (a, b) in enumerate(zip(w, wbefore)):
            chk(f"L{layer}/weights_unchanged/{i}", a, b)
        chk(f"L{layer}/RNG_unchanged", torch.cuda.get_rng_state(), rng)
        del graphs, graph, native, candidate_meta, call, ios, fns, x, w, wbefore, before
        gc.collect()
    report["status"] = "FULL_NATIVE_M128_METADATA_READY_BODY_EXACT_PASS"
    flush()


@torch.inference_mode()
def timing():
    import statistics
    import time

    if MODE == "timing":
        req(
            "feasibility_pass",
            json.loads((OUT / "feasibility-result.json").read_text())["status"]
            == "FEASIBILITY_PASS",
        )
    full = OUT
    gate = json.loads((full / "gate-result.json").read_text())
    req(
        "full15exact_gate",
        gate["status"] == "M128_METADATA_READY_FULL_AND_EMPTY_EXACT_PASS",
    )
    req(
        "frozen_hashes",
        all(
            c.sha(k) == v
            for k, v in json.loads((OUT / "frozen-inputs.json").read_text()).items()
        ),
    )
    req(
        "source_clean",
        report["source_sha"] == gate["source_sha"] and report["source_status"] == "",
    )
    req(
        "GPU2_selected",
        os.environ["CUDA_VISIBLE_DEVICES"]
        == "GPU-bc643dc2-a0d1-5ed6-5ecb-0605ca9f340a",
    )
    report.update(
        gpu_uuid=str(torch.cuda.get_device_properties(0).uuid),
        timing_rounds=(["AB"] if MODE == "feasibility" else ["AB", "BA", "AB"]),
        warmup_replays=5,
        timed_replays=100,
        cases=[],
        baseline_pdl=True,
        candidate_pdl=True,
    )
    from flashinfer.fused_moe import core as fi

    runtime = fi.get_trtllm_moe_sm100_module()
    rng = torch.cuda.get_rng_state().clone()
    for layer in (0, 19, 39):
        datasets = [
            torch.load(p, map_location="cpu", weights_only=False)
            for p in ORACLES
            if p.name.startswith(f"oracle-layer{layer}-")
        ]
        w = c.weights(layer, "cuda")
        wbefore = [t.clone() for t in w]
        x = allocate(datasets[0], w, "cuda")
        native = native_body(runtime, x)
        candidate_meta = native_body(runtime, x)
        slot = candidate_meta["slot"]
        for key, field in [
            ("tile", "cta_idx_xy_to_batch_idx"),
            ("mn", "cta_idx_xy_to_mn_limit"),
            ("route", "permuted_idx_to_token_idx"),
            ("ncta", "num_non_exiting_ctas"),
            ("padded", "total_num_padded_tokens"),
            ("expanded", "expanded_idx_to_permuted_idx"),
        ]:
            x["live_" + key] = getattr(slot, field)
        fields = (
            "cta_idx_xy_to_batch_idx",
            "cta_idx_xy_to_mn_limit",
            "permuted_idx_to_token_idx",
            "num_non_exiting_ctas",
            "total_num_padded_tokens",
            "expanded_idx_to_permuted_idx",
        )
        live_sets = {
            name: [getattr(arm["slot"], f) for f in fields]
            + list(arm["ws"])
            + [arm["output"]]
            for name, arm in [
                ("native", native),
                ("candidate_metadata_owner", candidate_meta),
            ]
        }
        addresses = {
            name: [
                {"ptr": t.data_ptr(), "bytes": t.numel() * t.element_size()} for t in ts
            ]
            for name, ts in live_sets.items()
        }
        req(
            f"L{layer}/independent_metadata_and_workspace_allocations",
            all(
                a["ptr"] + a["bytes"] <= b["ptr"] or b["ptr"] + b["bytes"] <= a["ptr"]
                for a in addresses["native"]
                for b in addresses["candidate_metadata_owner"]
            ),
            addresses,
        )

        if layer == 0:
            ios, fns, records = compile_pair(x)
            prep = json.loads((full / "driver-prepare.json").read_text())
            for fc, v in records.items():
                req(
                    fc + "/frozen_cubin_identical",
                    v["sha256"] == prep["kernels"][fc]["sha256"],
                )
        else:
            ios = {fc: io_for(fc, v, x) for fc, v in configs().items()}
            fns = {
                fc: compile_candidate(
                    fc, io, drv.CUstream(torch.cuda.current_stream().cuda_stream)
                )
                for fc, io in ios.items()
            }

        def call(x=x, ios=ios, fns=fns, candidate_meta=candidate_meta):
            return candidate_eager(runtime, x, ios, fns, candidate_meta)

        native["call"]()
        call()
        torch.cuda.synchronize()
        graph = torch.cuda.CUDAGraph()
        with torch.cuda.graph(graph):
            native["call"]()
        graphs = {
            "A": graph,
            "B": capture_candidate(
                runtime, x, ios, fns, candidate_meta, f"L{layer}/{MODE}"
            ),
        }
        for d in datasets:
            if MODE == "feasibility" and d["scenario"] != "real":
                continue
            name = f"L{layer}/{d['scenario']}"
            update(x, d)
            native["populate"]()
            before = {
                k: t.clone()
                for k, t in x.items()
                if k not in OUTPUTS
                and not k.startswith(("guard_", "live_"))
                and k not in ("w1", "s1", "w2", "s2")
            }
            graphs["A"].replay()
            graphs["B"].replay()
            torch.cuda.synchronize()
            chk(name + "/before_native", native["output"], d["routed"].to("cuda"))
            chk(name + "/before_candidate", x["out"], native["output"])
            record = {"layer": layer, "scenario": d["scenario"], "rounds": []}
            report["cases"].append(record)
            flush()
            for order in ("AB",) if MODE == "feasibility" else ("AB", "BA", "AB"):
                values = {}
                for arm in order:
                    for _ in range(5):
                        graphs[arm].replay()
                    torch.cuda.synchronize()
                    start = torch.cuda.Event(enable_timing=True)
                    end = torch.cuda.Event(enable_timing=True)
                    wall = time.perf_counter()
                    start.record()
                    for _ in range(100):
                        graphs[arm].replay()
                    end.record()
                    end.synchronize()
                    wall_ms = (time.perf_counter() - wall) * 1000
                    values[arm] = {
                        "device_ms_per_call": start.elapsed_time(end) / 100,
                        "wall_ms_per_call": wall_ms / 100,
                    }
                record["rounds"].append({"order": order, "arms": values})
                flush()
            a = statistics.median(
                v["arms"]["A"]["device_ms_per_call"] for v in record["rounds"]
            )
            b = statistics.median(
                v["arms"]["B"]["device_ms_per_call"] for v in record["rounds"]
            )
            record.update(
                native_median_ms=a,
                candidate_median_ms=b,
                latency_reduction_pct=(1 - b / a) * 100,
                speedup=a / b,
            )
            check_metadata(
                name + "/after/candidate_metadata", candidate_meta["slot"], x, d
            )
            check_outputs(name + "/after", x, d["intermediates"])
            chk(name + "/after_native", native["output"], d["routed"].to("cuda"))
            chk(name + "/after_candidate", x["out"], native["output"])
            for k, t in before.items():
                chk(name + "/untouched/" + k, x[k], t)
            flush()
            print(
                json.dumps(
                    {
                        k: record[k]
                        for k in (
                            "layer",
                            "scenario",
                            "native_median_ms",
                            "candidate_median_ms",
                            "latency_reduction_pct",
                        )
                    }
                ),
                flush=True,
            )
        for i, (a, b) in enumerate(zip(w, wbefore)):
            chk(f"L{layer}/weights_unchanged/{i}", a, b)
        chk(f"L{layer}/RNG_unchanged", torch.cuda.get_rng_state(), rng)
        del graphs, graph, native, candidate_meta, call, ios, fns, x, w, wbefore, before
        gc.collect()
    real = [v for v in report["cases"] if v["scenario"] == "real"]
    stress = [v for v in report["cases"] if v["scenario"] != "real"]
    report["continuation_gate"] = {
        "real_each_at_least5pct": len(real) == 3
        and all(v["latency_reduction_pct"] >= 5 for v in real),
        "stress_none_worse5pct": (
            None
            if MODE == "feasibility"
            else len(stress) == 12
            and all(v["latency_reduction_pct"] >= -5 for v in stress)
        ),
        "stress_performance": ("NOT_RUN" if MODE == "feasibility" else "EVALUATED"),
    }
    report["continuation_gate"]["passed"] = report["continuation_gate"][
        "real_each_at_least5pct"
    ] and (
        MODE == "feasibility" or report["continuation_gate"]["stress_none_worse5pct"]
    )
    report["status"] = (
        (
            "FEASIBILITY_PASS"
            if report["continuation_gate"]["passed"]
            else "FEASIBILITY_FAIL"
        )
        if MODE == "feasibility"
        else "TIMING_COMPLETE"
    )
    flush()


if __name__ == "__main__":
    try:
        if MODE == "prepare":
            prepare()
        elif MODE == "exact":
            run()
        elif MODE in ("feasibility", "timing"):
            timing()
        else:
            raise ValueError(MODE)
    except BaseException as e:
        report.update(
            status="METADATA_READY_" + MODE.upper() + "_FAIL",
            error=repr(e),
            traceback=traceback.format_exc(),
        )
        flush()
        raise
    finally:
        flush()
