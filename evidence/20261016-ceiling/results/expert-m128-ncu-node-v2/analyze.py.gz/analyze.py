"""CPU-only analysis of preserved eight node records; no GPU or source edits."""
from pathlib import Path
import csv
import hashlib
import json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
OLD = ROOT / 'expert-m128-ncu-node'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    metrics = json.loads((HERE / 'metrics.json').read_text())['metrics']
    records = []
    evidence = {}
    exact_count = 0
    audits = []
    for layer in (0, 39):
        experts = {0: 206, 39: 115}[layer]
        for arm in ('native', 'candidate'):
            directory = OLD if layer == 0 and arm == 'native' else HERE
            label = f'L{layer}-{arm}'
            path = directory / (label + '-metrics.csv')
            with path.open() as handle:
                rows = [row for row in csv.DictReader(handle) if row['ID'].isdigit()]
            assert len(rows) == 2
            result_path = directory / label / 'result.json'
            result = json.loads(result_path.read_text())
            assert result['status'] == 'NCU_SINGLE_GRAPH_REPLAY_EXACT_PASS'
            assert all(check['exact'] for check in result['checks'])
            exact_count += len(result['checks'])
            graph_path = directory / label / 'graph.json'
            graph = json.loads(graph_path.read_text())
            assert graph['pre'] == graph['post']
            audit_path = directory / (label + '-process-audit.json')
            audit = json.loads(audit_path.read_text())
            audits.append({'label': label, 'samples': len(audit), 'process_groups': sorted({r['pgid'] for x in audit for r in x['processes']})})
            for extra in [path, result_path, graph_path, audit_path, directory / (label + '-ncu.ncu-repz')]:
                evidence[str(extra)] = sha(extra)
            for fc, row in enumerate(rows, 1):
                numeric = {m: float(row[m].replace(',', '')) for m in metrics}
                assert float(row['profiler__replayer_passes']) == 4
                duration_us = numeric['gpu__time_duration.sum'] / 1000
                read = numeric['dram__bytes_read.sum']
                write = numeric['dram__bytes_write.sum']
                weights = experts * (2 if fc == 1 else 1) * 1048576
                total_bandwidth = (read + write) / (duration_us * 1e6)
                read_bandwidth = read / (duration_us * 1e6)
                inferred_peak = total_bandwidth / (numeric['dram__throughput.avg.pct_of_peak_sustained_elapsed'] / 100)
                record = {'layer': layer, 'arm': arm, 'projection': f'FC{fc}', 'kernel': row['Kernel Name'], 'duration_us': duration_us,
                          'metrics': numeric, 'profiler_passes': 4, 'logical_active_expert_weight_bytes': weights,
                          'dram_read_to_unique_logical_weights': read / weights, 'dram_read_TBps': read_bandwidth,
                          'dram_read_write_TBps': total_bandwidth,
                          'l2_read_bytes_sector_equivalent': numeric['lts__t_sectors_op_read.sum'] * 32,
                          'l2_write_bytes_sector_equivalent': numeric['lts__t_sectors_op_write.sum'] * 32,
                          'conditional_90pct_peak_us': duration_us * numeric['dram__throughput.avg.pct_of_peak_sustained_elapsed'] / 90,
                          'conditional_90pct_peak_savings_us': duration_us * (1 - numeric['dram__throughput.avg.pct_of_peak_sustained_elapsed'] / 90),
                          'reported_peak_inferred_TBps': inferred_peak,
                          'launch_fields': {key: row[key] for key in row if key.startswith('launch__')},
                          'csv_path': str(path)}
                records.append(record)
    comparisons = []
    for layer in (0, 39):
        for fc in ('FC1', 'FC2'):
            a = next(x for x in records if x['layer'] == layer and x['projection'] == fc and x['arm'] == 'native')
            b = next(x for x in records if x['layer'] == layer and x['projection'] == fc and x['arm'] == 'candidate')
            comparisons.append({'layer': layer, 'projection': fc, 'node_latency_reduction_pct': (1-b['duration_us']/a['duration_us'])*100,
                                'dram_read_change_pct': (b['metrics']['dram__bytes_read.sum']/a['metrics']['dram__bytes_read.sum']-1)*100,
                                'l2_read_change_pct': (b['l2_read_bytes_sector_equivalent']/a['l2_read_bytes_sector_equivalent']-1)*100,
                                'l2_write_change_pct': (b['l2_write_bytes_sector_equivalent']/a['l2_write_bytes_sector_equivalent']-1)*100,
                                'dram_read_bandwidth_change_pct': (b['dram_read_TBps']/a['dram_read_TBps']-1)*100})
    frozen = json.loads((HERE / 'frozen-inputs.json').read_text())
    assert all(sha(Path(path)) == digest for path, digest in frozen.items())
    result = {'status': 'COMPLETE_8_SERIALIZED_NODE_RECORDS', 'source_sha': '95fcb0ef2662f2caf9bfb7fe6863dc3ad7805b1b',
              'records': records, 'comparisons': comparisons, 'exact_checks': exact_count, 'frozen_source_hashes_pass': len(frozen),
              'ownership_audit_samples': audits, 'original_launcher_failure_preserved': str(OLD / 'launch-result.json'),
              'continuation_launcher': str(HERE / 'launch-result.json'), 'whole_graph_sampled': False,
              'pc_sampling_collected': False, 'formal_performance_claim': False, 'runtime_promoted': False, 'evidence_sha256': evidence,
              'limits': ['Four replay passes each; node replay serializes original PDL graph and changes cache history.',
                         'SMSP stall ratios normalize by issue-active cycles, not elapsed wall time or disjoint percentages.',
                         'Long scoreboard identifies waiting on L1TEX dependencies, not specifically TMA weight wait.',
                         'L2 sectors and hit rates are aggregate counters; no exact DRAM miss or weight-only hit inference.',
                         'Reads include all traffic; writes can include dirty-cache/replay state effects, not solely output bytes.',
                         'Current actual CTA residency is measured; static waves and register hints do not measure phase tails.',
                         'No kernel-duration sum is interpreted as actual PDL overlap or complete-MoE/service speedup.']}
    (HERE / 'summary.json').write_text(json.dumps(result, indent=2)+'\n')
    with (HERE / 'summary.csv').open('w') as handle:
        writer = csv.writer(handle)
        writer.writerow(['layer','arm','FC','us','DRAM_read_MB','DRAM_write_MB','DRAM_total_TBps','DRAM_peak_pct','L2_read_MB_sector_equiv','L2_write_MB_sector_equiv','L2_hit_pct','active_CTA_per_active_cycle','warp_active_pct','eligible_warps_per_active_cycle','issue_active_pct','long_scoreboard_per_issue_active','short_scoreboard_per_issue_active','barrier_per_issue_active'])
        for x in records:
            m=x['metrics']
            writer.writerow([x['layer'],x['arm'],x['projection'],x['duration_us'],m['dram__bytes_read.sum']/1e6,m['dram__bytes_write.sum']/1e6,x['dram_read_write_TBps'],m['dram__throughput.avg.pct_of_peak_sustained_elapsed'],x['l2_read_bytes_sector_equivalent']/1e6,x['l2_write_bytes_sector_equivalent']/1e6,m['lts__t_sector_hit_rate.pct'],m['sm__ctas_active.avg.per_cycle_active'],m['sm__warps_active.avg.pct_of_peak_sustained_active'],m['smsp__warps_eligible.avg.per_cycle_active'],m['smsp__issue_active.avg.pct_of_peak_sustained_active'],m['smsp__average_warps_issue_stalled_long_scoreboard_per_issue_active.ratio'],m['smsp__average_warps_issue_stalled_short_scoreboard_per_issue_active.ratio'],m['smsp__average_warps_issue_stalled_barrier_per_issue_active.ratio']])
    lines=['# Eight-node MoE counter result','',
           'Completed exactly eight serialized NCU node records across L0/real and L39/real, native and metadata-ready. All404 exact/ownership checks passed; each kernel required four replay passes. All150 frozen input hashes still match. GPU2 is released; final process audits are empty. No whole-graph/PC sample, runtime promotion or performance claim was made.','',
           'The first launcher stopped after successful L0/native sampling because it expected `.ncu-rep`; NCU2026.3 exported `.ncu-repz`. Its original failure, command and report remain untouched in `../expert-m128-ncu-node`. The v2 launcher accepts exactly one compressed/uncompressed report and ran only the remaining six records; the first two were imported on CPU without remeasurement.','',
           '| Layer/FC | Native → candidate µs | DRAM read MB | Total DRAM TB/s | Active CTA/SM | Eligible warps/active cycle | Issue active% | Long-scoreboard ratio |',
           '|---|---:|---:|---:|---:|---:|---:|---:|']
    for layer in (0,39):
        for fc in ('FC1','FC2'):
            a=next(x for x in records if x['layer']==layer and x['projection']==fc and x['arm']=='native');b=next(x for x in records if x['layer']==layer and x['projection']==fc and x['arm']=='candidate')
            am=a['metrics'];bm=b['metrics']
            def pair(key,scale=1):return f"{am[key]/scale:.2f} → {bm[key]/scale:.2f}"
            lines.append(f"| L{layer}/{fc} | {a['duration_us']:.3f} → {b['duration_us']:.3f} | {pair('dram__bytes_read.sum',1e6)} | {a['dram_read_write_TBps']:.3f} → {b['dram_read_write_TBps']:.3f} | {pair('sm__ctas_active.avg.per_cycle_active')} | {pair('smsp__warps_eligible.avg.per_cycle_active')} | {pair('smsp__issue_active.avg.pct_of_peak_sustained_active')} | {pair('smsp__average_warps_issue_stalled_long_scoreboard_per_issue_active.ratio')} |")
    lines += ['',
      'These are actual current-fixture counters. Candidate residency is1.94–1.96 CTAs per active SM cycle versus native1.00; achieved warp occupancy rises from21.84–23.53% to35.59–36.46%. That rules out the earlier unsupported claim that the TS source register hints force a single CTA. It does not establish that more occupancy alone fixes memory supply.',
      '',
      'FC1 has fewer eligible warps and lower issue-active percentage despite increased residency on both layers. The long-scoreboard ratio increases from12.54→30.78 (L0) and9.40→24.01 (L39). FC2 eligible counts change little (.33→.32 and.39→.41), with smaller but still elevated long-scoreboard ratios. This supports investigating the dependency of ordinary L1TEX-backed loads and their consumers. It does not identify TMA-stage starvation, a particular load PC, or a wall-time fraction: these ratios are normalized per issue-active cycle, and lower issue activity itself affects their denominator. Aggregate barrier and short-scoreboard ratios are small by comparison, but are not a complete model of asynchronous dependency cost.',
      '',
      'DRAM reads stay within−0.154% to+2.318% across arms. Native reads are close to one logical active-expert weight copy on all four records. The candidate L39/FC1 reads2.318% more while running5.180% shorter in node replay; reduced repeated-weight traffic therefore is not the explanation. Aggregate L2 read-sector equivalents change only−1.780% to+2.515%; there is no evidence for a large eliminated L2 transfer budget either. The per-kernel write differences must remain visible, especially L0/FC2; writes are not pure output stores under multi-pass replay/cache eviction. `summary.csv` retains both reads and writes and the exact denominator values.',
      '',
      'Candidate isolated node reductions are3.549%/7.885% at L0 and5.180%/7.659% at L39 for FC1/FC2. Their sum is not a full-call or PDL gain. The separately completed unprofiled one-screen full-MoE reductions were only2.729% and4.145% and failed the5% continuation gate. No three-round or service result is inferred.',
      '',
      'The conditional memory budget can now be recomputed from current bytes and duration: `duration × (1 − measured_DRAM_peak_percent/90)` is the hypothetical saving at90% of that record’s implied peak, assuming fixed bytes and no other limit. This remains a scenario, not recoverable critical-path time. `summary.json` records it for each observation; neither these scenarios nor serialized kernel deltas may be added to the complete-call gain. The next substantial hypothesis still needs12.075µs/L0 and7.994µs/L39 to reach10% versus native; current node observations do not establish that budget as achievable.',
      '',
      '**Recommended next discriminator: at most two PC-sampling records, L0/real FC1 native versus candidate, only after source review and authorization.** The repeated FC1 pattern is the clearest unresolved issue: more resident work yet fewer eligible warps, with the same weight volume. Attribute long-scoreboard samples to exact SASS PCs and native/TS load/consumer instructions before proposing a stage/metadata/scale-load change. Use a fixed same-case graph and preserve all predecessor/PDL/exact gates. If sample count is inadequate for these~73–76µs kernels, report inconclusive rather than silently repeating or changing sampling periods. No broad SourceCounters set or tile sweep is proposed.',
      '',
      'Whole-graph profiling would answer a different question—whether actual PDL interaction/launch overlap explains why the complete-call gain is smaller—but does not identify which ordinary load causes the FC1 scoreboard dependency. It is deferred while the source/PC question is addressed. A later graph result still needs the same complete metadata→FC1→activation→FC2→finalizer boundary and typed dependency proof. No tail duration is inferred from static waves or average issue/stall counters.',
      '',
      'This is diagnostic evidence for the next native structural change. The user’s all-concurrency throughput and WER/SIM goals are unchanged. Original negative correctness/performance gates remain preserved.',
    ]
    (HERE/'summary.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps({'status':result['status'],'exact_checks':exact_count,'records':len(records),'comparisons':comparisons},indent=2))


if __name__ == '__main__':
    main()
