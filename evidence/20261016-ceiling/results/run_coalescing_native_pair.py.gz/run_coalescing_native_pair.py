import datetime
import json
import os
import socket
import subprocess
import threading
from pathlib import Path

root = Path('/home/zjy/code/hsliu/artifacts/drama3-ceiling-20261016')
source = Path('/home/zjy/code/hsliu/artifacts/drama3-ceiling-20261016/source-coalescing-service-69d636e')
venv = Path('/home/zjy/code/hsliu/venvs/codex-drama3-standalone')
checkpoint = '/home/zjy/.cache/huggingface/hub/models--fishaudio--drama-3/snapshots/e0a9218aa48888270f06ef1ed9ea67622c0e17d2'
corpus = '/home/zjy/code/hsliu/artifacts/drama3-b300-20261014/seedtts-en1088-codes/requests.jsonl'
flags = dict(DRAMA3_GDN_STATE_DTYPE='bfloat16', DRAMA3_PREFILL_GDN='fla', DRAMA3_PACKED_MOE_PROJECTION='1', DRAMA3_PREFILL_CONV='triton', DRAMA3_PREFILL_MOE_TUNED='0', DRAMA3_PREFILL_MOE='flashinfer', DRAMA3_ADMISSION_MIN_BATCH='6', DRAMA3_PREFILL_BUCKET_192='1', DRAMA3_PACKED_PREFILL='1', DRAMA3_ASYNC_CODEC='1', DRAMA3_AUDIO_DELIVERY_THREAD='1', DRAMA3_FUSED_MOE_INPUT='1', DRAMA3_MIXED_BACKBONE='1', DRAMA3_MIXED_SPAN256='1', DRAMA3_CODEC_DEDICATED_CAPTURE_STREAM='1', DRAMA3_COMPACT_GDN='1', DRAMA3_FUSED_MIXED_LAYOUT='1', DRAMA3_PACKED_CONV_GUARD='1', DRAMA3_DEFER_CODEC_SUBMIT='0', DRAMA3_CODEC_SPLIT_POLICY='dp', DRAMA3_SHORT_PADDING_CONTEXT='1', DRAMA3_FUSED_MOE_RESIDUAL='1', DRAMA3_CODEC_SMS='0', DRAMA3_RESERVED_PADDING_ROUTER='0', DRAMA3_FRAME_PIPELINE='0')
env = {k: v for k, v in os.environ.items() if not k.startswith('DRAMA3_')}
env.update(flags)
env['PYTHONPATH']=str(source/'src')
sha = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip()
assert sha == '69d636ef11875add6e4edf7c9bb028b9574143a3'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=source, text=True)
processes = subprocess.check_output(['nvidia-smi', '--query-compute-apps=gpu_uuid,pid,process_name,used_gpu_memory', '--format=csv,noheader'], text=True)
assert 'GPU-40e00845-d89c-1393-2c32-a2dca3ee9442' not in processes
with socket.socket() as probe:
    assert probe.connect_ex(('127.0.0.1', 18137)) != 0, 'port18137 occupied'
plan = dict(hypothesis='Same-emit adjacent frame-bucket codec coalescing reduces launch overhead enough to improve full1088 C64 service throughput with unchanged native model computation, request chunks and accepted WER/SIM quality.', isolated_variable='Only DRAMA3_CODEC_COALESCE0 vs1; four native flags and fused MoE residual1 in both arms; private async/thread codec, DP, defer0, SMS0, reservedrouter0 and framepipeline0.', source_sha=sha, source=str(source), flags=flags, gpu=7, gpu_uuid='GPU-40e00845-d89c-1393-2c32-a2dca3ee9442', port=18137, cpu_affinity=sorted(os.sched_getaffinity(0)), omp_threads=8, requests=1088, concurrency=64, repeats=1, profile_enabled=False, checkpoint=checkpoint, corpus=corpus, gate='All1088 complete; inspect throughput/TTFA/RTF and total output frames; score all1088 outputs of each arm against unchanged WER/SIM limits before any promotion. This candidate changes native codec floating arithmetic with batch/time shape; exact PCM/state gate failed and remains failed. Independent full-prefix FP32 diagnostic passed; full quality is still required.', stop='Abort on GPU interference, server failures or incomplete output. One feasibility run each is not a statistical speedup claim.', before_gpu=processes, cpu_probe="codec-coalescing-cpu.json", native_validation_references=["codec-minlaunch/coalescing-summary.json", "codec-minlaunch/fp32-coalescing-requests.json", "2374 fused MoE residual checks at6ff8d80 archived by root"], target_c64_frames_s=6765.407263214912)
plan['storage']={p:subprocess.check_output(['findmnt','-T',p,'-o','TARGET,SOURCE,FSTYPE','--noheadings'],text=True).strip() for p in (str(venv),checkpoint,'/home/zjy/.cache/huggingface/hub')}
plan['benchmark_import_path']=env['PYTHONPATH']
(root/'coalescing-native-service-experiment.json').write_text(json.dumps(plan, indent=2)+'\n')
stop = threading.Event()
def audit():
    with (root/'coalescing-native-process-audit.jsonl').open('w') as file:
        while not stop.is_set():
            value = subprocess.run(['nvidia-smi', '--query-compute-apps=gpu_uuid,pid,process_name,used_gpu_memory', '--format=csv,noheader'], capture_output=True, text=True)
            file.write(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), processes=value.stdout.splitlines()))+'\n')
            file.flush()
            stop.wait(1)
thread = threading.Thread(target=audit)
thread.start()
try:
    for enabled, name in [('0', 'coalescing-native-control-gpu7'), ('1', 'coalescing-native-candidate-gpu7')]:
        cmd = [str(venv/'bin/python'), str(source/'scripts/run_baseline.py'), '--backend', 'standalone', '--source', str(source), '--venv', str(venv), '--bench-python', str(venv/'bin/python'), '--checkpoint', checkpoint, '--fish-source', '/home/zjy/code/hsliu/drama3-sources/fish-speech', '--corpus', corpus, '--output', str(root/name), '--gpu', '7', '--port', '18137', '--capacity', '64', '--requests', '1088', '--repeats', '1', '--concurrency', '64', '--skip-reference-warmup']
        (root/f'{name}-command.json').write_text(json.dumps(cmd, indent=2)+'\n')
        print('Starting', name, flush=True)
        subprocess.run(cmd, env=dict(env, DRAMA3_CODEC_COALESCE=enabled), check=True)
        print('Finished', name, flush=True)
finally:
    stop.set()
    thread.join()
