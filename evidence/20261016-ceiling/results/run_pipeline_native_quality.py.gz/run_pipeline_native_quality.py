import hashlib,json,os,subprocess,threading,datetime
from pathlib import Path
root=Path('/home/zjy/code/hsliu/artifacts/drama3-ceiling-20261016')
source=Path('/home/zjy/code/hsliu/artifacts/drama3-ceiling-20261016/source-pipeline-a7118fb')
venv=Path('/home/zjy/code/hsliu/venvs/codex-drama3-standalone')
upstream=Path('/home/zjy/code/hsliu/drama3-sources/sglang-omni')
assets=Path('/home/zjy/code/hsliu/artifacts/drama3-b300-20261014/quality-models.json')
env=dict(os.environ,PYTHONPATH=str(source/'src'),CUDA_VISIBLE_DEVICES='6',OMP_NUM_THREADS='8',HF_MODULES_CACHE='/home/zjy/code/hsliu/artifacts/drama3-b300-20261014/quality-hf-modules',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
processes=subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid,pid,process_name,used_memory','--format=csv,noheader'],text=True)
assert 'GPU-619f7fdc-5f98-8c37-fe89-0465d6130baf' not in processes, 'GPU6 not free'
meta=dict(source_sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),source_script_sha256=hashlib.sha256((source/'scripts/evaluate_audio.py').read_bytes()).hexdigest(),upstream_sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=upstream,text=True).strip(),upstream_status=subprocess.check_output(['git','status','--porcelain'],cwd=upstream,text=True),assets_sha256=hashlib.sha256(assets.read_bytes()).hexdigest(),gpu=6,gpu_uuid='GPU-619f7fdc-5f98-8c37-fe89-0465d6130baf',batch_size=8,labels=['c64-r0'],all_samples=1088,before_gpu=processes,quality_limits=dict(wer_corpus_max=.02950933601272712,sim_min=61.88158934120563),stop='Preserve every sample. Any missing score or failure remains incomplete; no filtering or threshold adjustment.',commands=[])
(root/'pipeline-quality-experiment.json').write_text(json.dumps(meta,indent=2)+'\n')
stop=threading.Event()
def audit():
 with (root/'pipeline-quality-process-audit.jsonl').open('w') as f:
  while not stop.is_set():
   p=subprocess.run(['nvidia-smi','--query-compute-apps=gpu_uuid,pid,process_name,used_memory','--format=csv,noheader'],capture_output=True,text=True)
   f.write(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),processes=p.stdout.splitlines()))+'\n');f.flush();stop.wait(1)
t=threading.Thread(target=audit);t.start()
try:
 for arm in ['control','candidate']:
  cmd=[str(venv/'bin/python'),str(source/'scripts/evaluate_audio.py'),'--upstream',str(upstream),'--assets',str(assets),'--corpus','/home/zjy/code/hsliu/artifacts/drama3-b300-20261014/seedtts-en1088-codes/requests.jsonl','--benchmark',str(root/f'pipeline-{arm}-gpu6'/'benchmark'),'--labels','c64-r0','--output',str(root/f'pipeline-{arm}-quality.json'),'--batch-size','8']
  meta['commands'].append(cmd);(root/'pipeline-quality-experiment.json').write_text(json.dumps(meta,indent=2)+'\n')
  print('Starting quality',arm,flush=True)
  with (root/f'pipeline-{arm}-quality.log').open('w') as f: subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
  print('Finished quality',arm,flush=True)
finally:
 stop.set();t.join()
