"""Artifact-only native ordered MoE finalization + existing residual RMSNorm.

No expert pruning or precision conversion. The live expanded-to-permuted map
belongs to the current call; it cannot be reconstructed from a previous call.
"""

import torch
import triton
import triton.language as tl


@triton.jit
def fused_kernel(
    FC2,
    MAP,
    PROBS,
    SHARED,
    GATE,
    RESIDUAL,
    W,
    OUT,
    GATE_STRIDE: tl.constexpr,
    FC2_STRIDE: tl.constexpr,
    WIDTH: tl.constexpr,
    EPS: tl.constexpr,
    PDL: tl.constexpr,
):
    if PDL:
        tl.extra.cuda.gdc_wait()
    row = tl.program_id(0)
    col = tl.arange(0, WIDTH)
    acc = tl.full((WIDTH,), 0, tl.float32)
    # Native finalize visits top-k in its original order and contracts each
    # multiply/add to FP32 FMA. Masked (-1) expert rows leave the accumulator.
    for k in tl.static_range(8):
        idx = tl.load(MAP + row * 8 + k)
        prob = tl.load(PROBS + row * 8 + k).to(tl.float32)
        value = tl.load(FC2 + idx * FC2_STRIDE + col, idx >= 0, other=0).to(tl.float32)
        term = tl.fma(prob, value, acc)
        acc = tl.where(idx >= 0, term, acc)
    routed = acc.to(tl.bfloat16)
    shared = tl.load(SHARED + row * WIDTH + col)
    gate = tl.sigmoid(tl.load(GATE + row * GATE_STRIDE).to(tl.float32)).to(tl.bfloat16)
    combined = tl.inline_asm_elementwise(
        "fma.rn.bf16 $0, $1, $2, $3;",
        constraints="=h,h,h,h",
        args=[shared, gate, routed],
        dtype=tl.bfloat16,
        is_pure=True,
        pack=1,
    ).to(tl.float32)
    value = (
        (combined + tl.load(RESIDUAL + row * WIDTH + col).to(tl.float32))
        .to(tl.bfloat16)
        .to(tl.float32)
    )
    tl.store(RESIDUAL + row * WIDTH + col, value)
    value *= tl.rsqrt(tl.sum(value * value, 0) / WIDTH + EPS)
    value *= 1.0 + tl.load(W + col).to(tl.float32)
    tl.store(OUT + row * WIDTH + col, value)


def validate(fc2, mapping, probs, shared, gate, residual, weight, out):
    rows, width = shared.shape
    assert width == 2048 and rows > 0
    assert (
        fc2.dtype
        == shared.dtype
        == residual.dtype
        == weight.dtype
        == out.dtype
        == torch.bfloat16
    )
    assert probs.dtype == torch.bfloat16 and gate.dtype == torch.bfloat16
    assert mapping.dtype == torch.int32 and mapping.numel() == rows * 8
    assert probs.shape == (rows, 8) and gate.shape == (rows, 1)
    assert fc2.ndim == 2 and fc2.shape[1] == width and fc2.stride(1) == 1
    assert shared.is_contiguous() and residual.is_contiguous() and out.is_contiguous()
    assert (
        probs.is_contiguous() and mapping.is_contiguous() and weight.shape == (width,)
    )
    assert gate.stride(1) == 1 and weight.is_contiguous()
    assert residual.shape == out.shape == shared.shape
    assert (
        len(
            {
                t.device
                for t in (fc2, mapping, probs, shared, gate, residual, weight, out)
            }
        )
        == 1
    )


def fused_finalize(
    fc2, mapping, probs, shared, gate, residual, weight, out, eps=1e-6, pdl=True
):
    validate(fc2, mapping, probs, shared, gate, residual, weight, out)
    fused_kernel[(len(shared),)](
        fc2,
        mapping,
        probs,
        shared,
        gate,
        residual,
        weight,
        out,
        gate.stride(0),
        fc2.stride(0),
        2048,
        eps,
        pdl,
        num_warps=4,
        enable_fp_fusion=False,
        launch_pdl=pdl,
    )
    return out
