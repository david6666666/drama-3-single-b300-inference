"""Bounded finalization fusion: fixed native intermediates; no model changes."""

import hashlib
import json
import os
import sys
import traceback
from dataclasses import asdict
from pathlib import Path

sys.dont_write_bytecode = True
P = Path(__file__).resolve().parent
protocol = json.loads((P / "protocol.json").read_text())
sys.path.insert(0, protocol["source"] + "/src")
import torch
from drama3.kernels import combine_experts_add_norm_kernel
from fused_finalize import fused_finalize

sys.path.insert(0, str(P.parent / "expert-m128-pdl-metadata-ready"))
from metadata_ready_graph import _CudaBackend

report = {
    "status": "STARTING",
    "checks": [],
    "native_model_or_service_claim": False,
    "pid": os.getpid(),
    "timing": [],
    "performance_gate": None,
}


def save():
    (P / "result.json").write_text(json.dumps(report, indent=2) + "\n")


def require(name, condition, detail=None):
    report["checks"].append({"name": name, "passed": bool(condition), "detail": detail})
    save()
    if not condition:
        raise AssertionError(name)


def exact(name, a, b):
    okay = (
        a.shape == b.shape
        and a.dtype == b.dtype
        and torch.equal(
            a.contiguous().view(torch.uint8), b.contiguous().view(torch.uint8)
        )
    )
    if not okay:
        torch.save(
            {"actual": a.cpu(), "expected": b.cpu()},
            P / (name.replace("/", "_") + "-mismatch.pt"),
        )
    require(name, okay)


def guarded(shape, dtype, fill=37):
    count = 1
    for n in shape:
        count *= n
    raw = torch.full((count + 128,), fill, dtype=dtype, device="cuda")
    return raw[64:-64].reshape(shape), raw


def main():
    for path, digest in protocol["frozen_files"].items():
        require(
            "hash/" + Path(path).name,
            hashlib.sha256(Path(path).read_bytes()).hexdigest() == digest,
        )
    require(
        "gpu_uuid",
        str(torch.cuda.get_device_properties(0).uuid).removeprefix("GPU-") == protocol["gpu_uuid"].removeprefix("GPU-"),
    )
    from flashinfer.fused_moe import core as fi

    runtime = fi.get_trtllm_moe_sm100_module()
    torch.cuda.synchronize()
    rng = torch.cuda.get_rng_state().clone()
    fc2, fc2raw = guarded((2304, 2048), torch.bfloat16)
    mapping = torch.empty(512, dtype=torch.int32, device="cuda")
    probs = torch.empty((64, 8), dtype=torch.bfloat16, device="cuda")
    shared = torch.empty((64, 2048), dtype=torch.bfloat16, device="cuda")
    gate_storage = torch.empty((64, 256), dtype=torch.bfloat16, device="cuda")
    gate = gate_storage[:, :1]
    residual_init = torch.empty_like(shared)
    weight = (
        (torch.arange(2048, device="cuda", dtype=torch.float32) % 23 - 11) / 64
    ).to(torch.bfloat16)
    n = torch.tensor([2304], dtype=torch.int32, device="cuda")
    native, native_raw = guarded((64, 2048), torch.bfloat16)
    res = {}
    out = {}
    raws = [fc2raw, native_raw]
    for arm in ("native", "fused"):
        res[arm], raw = guarded((64, 2048), torch.bfloat16)
        raws.append(raw)
        out[arm], raw = guarded((64, 2048), torch.bfloat16)
        raws.append(raw)

    def call_native():
        runtime.moe_op.trtllm_moe_run_finalize(
            fc2, native, probs, mapping, n, 64, 256, 8, 2048, True, True
        )
        combine_experts_add_norm_kernel[(64,)](
            native,
            shared,
            gate,
            res["native"],
            weight,
            out["native"],
            gate.stride(0),
            1e-6,
            2048,
            num_warps=4,
            enable_fp_fusion=False,
        )

    def call_fused():
        fused_finalize(
            fc2, mapping, probs, shared, gate, res["fused"], weight, out["fused"]
        )

    calls = {"native": call_native, "fused": call_fused}
    graphs = {}
    for path in protocol["oracles"]:
        d = torch.load(path, map_location="cpu", weights_only=False)
        name = f"L{d['layer']}/{d['scenario']}"
        logical = d["intermediates"]["fc2_bf16"].cuda()
        base_map = d["global_meta"]["expanded"].to(device="cuda", dtype=torch.int32)
        probs.copy_(d["weights"])
        shared.copy_(d["x"])
        gate_storage.copy_(d["router"])
        residual_init.copy_(d["x"].flip(1))
        for variant in (
            "archived",
            "reverse_physical",
            "missing_branch",
            "all_missing",
        ):
            mp = base_map if variant == "archived" else 2303 - base_map
            fc2.fill_(37)
            fc2[mp.long()] = logical
            mapping.copy_(mp)
            if variant == "missing_branch":
                mapping[::8] = -1
            if variant == "all_missing":
                mapping.fill_(-1)
            immutable = [
                fc2.clone(),
                mapping.clone(),
                probs.clone(),
                shared.clone(),
                gate_storage.clone(),
                residual_init.clone(),
                weight.clone(),
            ]
            for arm, call in calls.items():
                res[arm].copy_(residual_init)
                call()
            torch.cuda.synchronize()
            if variant == "archived":
                exact(name + "/native_archive", native, d["routed"].cuda())
            exact(name + "/" + variant + "/eager_out", out["fused"], out["native"])
            exact(name + "/" + variant + "/eager_residual", res["fused"], res["native"])
            if not graphs:
                for arm, call in calls.items():
                    stream = torch.cuda.Stream()
                    stream.wait_stream(torch.cuda.current_stream())
                    with torch.cuda.stream(stream):
                        res[arm].copy_(residual_init)
                        call()
                    torch.cuda.current_stream().wait_stream(stream)
                    graph = _CudaBackend()
                    graph.begin()
                    res[arm].copy_(residual_init)
                    call()
                    graph.end((None, None, None))
                    snapshot = asdict(graph.snapshot())
                    (P / (arm + "-graph.json")).write_text(
                        json.dumps(snapshot, indent=2) + "\n"
                    )
                    kernel_names = [
                        n["kernel"] for n in snapshot["nodes"] if n["kind"] == "kernel"
                    ]
                    require(
                        arm + "/graph_kernel",
                        any(
                            ("fused_kernel" if arm == "fused" else "finalizeKernel")
                            in n
                            for n in kernel_names
                        ),
                        kernel_names,
                    )
                    graph.instantiate()
                    graphs[arm] = graph
                torch.cuda.synchronize()
            for repeat in range(3):
                for graph in graphs.values():
                    graph.replay()
                torch.cuda.synchronize()
                exact(
                    name + "/" + variant + f"/graph{repeat}_out",
                    out["fused"],
                    out["native"],
                )
                exact(
                    name + "/" + variant + f"/graph{repeat}_residual",
                    res["fused"],
                    res["native"],
                )
            for i, (actual, expected) in enumerate(
                zip(
                    (fc2, mapping, probs, shared, gate_storage, residual_init, weight),
                    immutable,
                )
            ):
                exact(name + "/" + variant + f"/immutable{i}", actual, expected)
            for i, raw in enumerate(raws):
                require(
                    name + "/" + variant + f"/guard{i}",
                    bool(torch.all(raw[:64] == 37) and torch.all(raw[-64:] == 37)),
                )
    exact("rng_unchanged", torch.cuda.get_rng_state(), rng)
    report["status"] = "EXACT_PASS"
    save()
    # One predeclared AB screen only. Each graph includes the same residual
    # restore to fix work across its100 repetitions; this is not a full MoE.
    for layer in (0, 19, 39):
        path = next(
            p for p in protocol["oracles"] if p.endswith(f"oracle-layer{layer}-real.pt")
        )
        d = torch.load(path, map_location="cpu", weights_only=False)
        fc2.fill_(37)
        mapping.copy_(d["global_meta"]["expanded"])
        fc2[mapping.long()] = d["intermediates"]["fc2_bf16"].cuda()
        probs.copy_(d["weights"])
        shared.copy_(d["x"])
        gate_storage.copy_(d["router"])
        residual_init.copy_(d["x"].flip(1))
        immutable = [
            t.clone()
            for t in (fc2, mapping, probs, shared, gate_storage, residual_init, weight)
        ]
        times = {}
        for arm in ("native", "fused"):
            for _ in range(5):
                graphs[arm].replay()
            torch.cuda.synchronize()
            start, end = (
                torch.cuda.Event(enable_timing=True),
                torch.cuda.Event(enable_timing=True),
            )
            start.record()
            for _ in range(100):
                graphs[arm].replay()
            end.record()
            end.synchronize()
            times[arm] = start.elapsed_time(end) * 1000 / 100
        exact(f"timing/L{layer}/out", out["fused"], out["native"])
        exact(f"timing/L{layer}/residual", res["fused"], res["native"])
        exact(f"timing/L{layer}/native_archive", native, d["routed"].cuda())
        for i, (actual, expected) in enumerate(
            zip(
                (fc2, mapping, probs, shared, gate_storage, residual_init, weight),
                immutable,
            )
        ):
            exact(f"timing/L{layer}/immutable{i}", actual, expected)
        for i, raw in enumerate(raws):
            require(
                f"timing/L{layer}/guard{i}",
                bool(torch.all(raw[:64] == 37) and torch.all(raw[-64:] == 37)),
            )
        exact(f"timing/L{layer}/rng", torch.cuda.get_rng_state(), rng)
        saved = times["native"] - times["fused"]
        report["timing"].append(
            {
                "layer": layer,
                "microseconds": times,
                "saved_microseconds": saved,
                "gate": saved >= 2.5,
            }
        )
        save()
    report["performance_gate"] = all(t["gate"] for t in report["timing"])
    report["status"] = (
        "FEASIBILITY_PASS" if report["performance_gate"] else "FEASIBILITY_FAIL"
    )
    report["full_model_timing"] = "NOT_RUN"
    save()


if __name__ == "__main__":
    try:
        with torch.inference_mode():
            main()
    except BaseException:
        report["status"] = "FAIL"
        report["exception"] = traceback.format_exc()
        save()
        raise
