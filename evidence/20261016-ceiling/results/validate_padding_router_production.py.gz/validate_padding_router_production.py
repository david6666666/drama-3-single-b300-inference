"""Validate frozen production reserved-padding flag with native graph/state controls."""
import hashlib,json,os,statistics,subprocess,sys
from pathlib import Path
from types import SimpleNamespace
ROOT=Path('/home/zjy/code/hsliu/artifacts/drama3-ceiling-20261016')
SOURCE=Path(os.environ['DRAMA3_VALIDATION_SOURCE'])
sys.path[:0]=[str(SOURCE/'src'),str(SOURCE/'scripts')]
import torch,triton
import triton.language as tl
import torch.nn.functional as F
from fish_speech.models.text2semantic.fish_omni.generate import build_drama3_prompt
from validate_mixed_layers import Checks,snapshot,restore,state_tensors
from drama3.engine import BatchedPrefillGraph,DecodeGraph,state_pool_size
from drama3.model import DramaModel
from drama3.mixed_graph import MixedGraph
from drama3.runtime_state import DeviceRequests
import drama3.moe_input as moe_input
CHECKPOINT='/home/zjy/.cache/huggingface/hub/models--fishaudio--drama-3/snapshots/e0a9218aa48888270f06ef1ed9ea67622c0e17d2'
CORPUS=Path('/home/zjy/code/hsliu/artifacts/drama3-b300-20261014/seedtts-en1088-codes/requests.jsonl')

@torch.inference_mode()
def main():
 raw=CORPUS.read_bytes();checks=Checks(ROOT/'padding-router-production.json',dict(source_sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip(),source_status=subprocess.check_output(['git','status','--porcelain'],cwd=SOURCE,text=True),driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),corpus_sha256=hashlib.sha256(raw).hexdigest(),gpu_uuid=str(torch.cuda.get_device_properties(0).uuid),environment={k:v for k,v in os.environ.items() if k.startswith('DRAMA3_')},experiment=json.loads((ROOT/'padding-router-production-experiment.json').read_text())))
 native_prepare=moe_input.prepare_moe_input
 try:
  model=DramaModel(CHECKPOINT,slots=state_pool_size(64),max_length=2048)
  assert model.fused_moe_input and model.prefill_moe=='flashinfer' and model.moe_shared_stream is None and model.reserved_padding_router
  device=DeviceRequests(model.slots,model.config.eos_token_id,model.max_length)
  samples=[json.loads(s) for s in raw.splitlines()][:64]
  prompts=[build_drama3_prompt(s['text'],model.weights.tokenizer,model.config,[s['reference_text']],[torch.tensor(s['reference_codes'])]) for s in samples]
  prefill=BatchedPrefillGraph(model,8,triton.next_power_of_2(max(map(len,prompts))))
  first=DecodeGraph(model,8,first_frame=True,requests=device)
  graphs={}
  for size in (64,8):
   model.reserved_padding_router=False;control=DecodeGraph(model,size,requests=device)
   model.reserved_padding_router=True;candidate=DecodeGraph(model,size,requests=device)
   graphs[size]=(control,candidate)
  model.reserved_padding_router=False;control_mixed=MixedGraph(model,device,64,8,1280,max_length=256)
  model.reserved_padding_router=True;candidate_mixed=MixedGraph(model,device,64,8,1280,max_length=256)
  model.reserved_padding_router=False
  tensors=state_tensors(model,device)
  for size,count in ((64,58),(64,63),(64,64),(8,5)):
   control,candidate=graphs[size]
   model.reserved_padding_router=False
   active=[SimpleNamespace(slot=i,position=len(prompts[i])-1) for i in range(count)]
   for i,p in enumerate(prompts[:count]):
    h=F.pad(p[-16:,0],(max(0,16-len(p)),0),value=-1).cuda();device.initialize(i,p[-1].cuda(),h,len(p)-1,500)
   for start in range(0,count,8):
    end=min(start+8,count);hidden=prefill.run(prompts[start:end],list(range(start,end)));first.run(active[start:end],hidden)
   for _ in range(8):control.run(active)
   # Prepare candidate roster with one disposable replay, then restore exactly.
   initial=snapshot(tensors.values());candidate.run(active);restore(tensors.values(),initial)
   checks.tensor(f'B{count}/same_slots',candidate.slots,control.slots,exact=True)
   real=torch.arange(count,device='cuda');padding=candidate.slots[count:].clone();owned=set(candidate.slots.tolist());other=torch.tensor([s for s in range(model.slots) if s not in owned],device='cuda')
   assert bool((candidate.slots[:count]<model.slots//2).all()) and bool((padding>=model.slots//2).all())
   row=dict(real_rows=count,batch_rows=size,padding_slots=padding.cpu().tolist(),completed_real_slots=device.metadata[:count,3].nonzero().flatten().tolist(),allowed_differences='Participating explicitly reserved dummy outputs/state only; real rows and every nonparticipating slot exact',quantization_checks=0,timings={})
   checks.report['cases'].append(row);checks.flush()
   # Verify every saved authentic MoE input from the earlier independent route census.
   if size==64 and count<64:
    saved=torch.load(ROOT/f'padding-router-b{count}-native-inputs.pt',map_location='cpu',weights_only=True)
    for index,layer in saved.items():
     x=layer['x'].cuda();router=layer['router'].cuda();n=native_prepare(x,router);a=native_prepare(x,router,row_slots=candidate.slots,padding_start=model.slots//2)
     checks.tensor(f'B{count}/layer{index}/native_fp8_bytes',a[0].view(torch.uint8),n[0].view(torch.uint8),exact=True)
     checks.tensor(f'B{count}/layer{index}/native_scales',a[1],n[1],exact=True)
     checks.tensor(f'B{count}/layer{index}/real_logits',a[2][:count],n[2][:count],exact=True)
     checks.tensor(f'B{count}/layer{index}/reserved_logits',a[2][count:],n[2][:1].expand(64-count,-1),exact=True)
     row['quantization_checks']+=1
    del saved,x,router,n,a
   def ownership(label,values):
    for (name,_),value,before in zip(tensors.items(),values,initial,strict=True):
     if name!='sampling_step':checks.tensor(f'B{count}/{label}/untouched/{name}',value.index_select(0,other),before.index_select(0,other),exact=True)
   # Eight replay trajectory catches propagating dummy changes and state leakage.
   expected_outputs=[]
   for _ in range(8):control.graph.replay();expected_outputs.append(control.output.clone())
   expected=snapshot(tensors.values());ownership('control',expected)
   restore(tensors.values(),initial)
   for step in range(8):
    candidate.graph.replay();checks.tensor(f'B{count}/step{step}/real_output',candidate.output[:count],expected_outputs[step][:count],exact=True)
   actual=snapshot(tensors.values());ownership('candidate',actual)
   dummy_diff=[]
   for (name,_),a,e in zip(tensors.items(),actual,expected,strict=True):
    if name=='sampling_step':checks.tensor(f'B{count}/sampler_counter',a,e,exact=True)
    else:
     checks.tensor(f'B{count}/real_state/{name}',a.index_select(0,real),e.index_select(0,real),exact=True)
     if len(padding) and not torch.equal(a.index_select(0,padding),e.index_select(0,padding)):dummy_diff.append(name)
   row['participating_dummy_state_differences']=dummy_diff
   del actual,expected,expected_outputs
   # Candidate eager and graph use identical modified dummy routes, all slots exact.
   restore(tensors.values(),initial);model.reserved_padding_router=True
   try:eager_output=candidate.forward().clone();eager_state=snapshot(tensors.values())
   finally:model.reserved_padding_router=False
   restore(tensors.values(),initial);candidate.graph.replay()
   checks.tensor(f'B{count}/candidate_graph_eager_output',candidate.output,eager_output,exact=True)
   for (name,a),e in zip(tensors.items(),eager_state,strict=True):checks.tensor(f'B{count}/candidate_graph_eager_state/{name}',a,e,exact=True)
   del eager_state,eager_output
   # Fixed-state single-replay timings exclude restore and validation work.
   times={'control':[],'candidate':[]}
   for trial in range(8):
    arms=[('control',control),('candidate',candidate)]
    if trial%2:arms.reverse()
    for label,graph in arms:
     restore(tensors.values(),initial);begin=torch.cuda.Event(enable_timing=True);end=torch.cuda.Event(enable_timing=True);begin.record();graph.graph.replay();end.record();end.synchronize();times[label].append(begin.elapsed_time(end))
   row['timings']={k:dict(raw_ms=v,mean_ms=statistics.mean(v),median_ms=statistics.median(v),min_ms=min(v),max_ms=max(v)) for k,v in times.items()};row['latency_gain_fraction']=1-statistics.mean(times['candidate'])/statistics.mean(times['control']);checks.flush();print(json.dumps(dict(real_rows=count,timings=row['timings'],gain=row['latency_gain_fraction'])),flush=True)
   restore(tensors.values(),initial);del initial
  # Mixed decode+teacher-forced prompt rows use the same explicit source flag.
  count=58;model.reserved_padding_router=False
  active=[SimpleNamespace(slot=i,position=len(prompts[i])-1) for i in range(count)]
  for i,prompt in enumerate(prompts[:count]):
   history=F.pad(prompt[-16:,0],(max(0,16-len(prompt)),0),value=-1).cuda();device.initialize(i,prompt[-1].cuda(),history,len(prompt)-1,500)
  for start in range(0,count,8):
   end=min(start+8,count);hidden=prefill.run(prompts[start:end],list(range(start,end)));first.run(active[start:end],hidden)
  for graph in (control_mixed,candidate_mixed):graph.prepare(active,prompts[58:64],list(range(58,64)))
  initial=snapshot(tensors.values());real=torch.arange(64,device='cuda');owned=set(candidate_mixed.layout.sequence_slots.tolist())|set(candidate_mixed.slots[:64].tolist());other=torch.tensor([i for i in range(model.slots) if i not in owned],device='cuda');reserved=torch.tensor(sorted(i for i in owned if i>=model.slots//2),device='cuda')
  control_mixed.graph.replay();expected_outputs=snapshot(control_mixed.output);expected=snapshot(tensors.values())
  restore(tensors.values(),initial);candidate_mixed.graph.replay();actual=snapshot(tensors.values())
  checks.tensor('mixed/real_decode_hidden',candidate_mixed.output[0][:58],expected_outputs[0][:58],exact=True)
  checks.tensor('mixed/real_prompt_last_hidden',candidate_mixed.output[1][:6],expected_outputs[1][:6],exact=True)
  dummy=[]
  for (name,_),a,e,before in zip(tensors.items(),actual,expected,initial,strict=True):
   if name=='sampling_step':checks.tensor('mixed/sampler_counter',a,e,exact=True)
   else:
    checks.tensor('mixed/real_state/'+name,a.index_select(0,real),e.index_select(0,real),exact=True)
    for label,value in [('control',e),('candidate',a)]:checks.tensor('mixed/'+label+'/untouched/'+name,value.index_select(0,other),before.index_select(0,other),exact=True)
    if not torch.equal(a.index_select(0,reserved),e.index_select(0,reserved)):dummy.append(name)
  del expected,actual
  restore(tensors.values(),initial);model.reserved_padding_router=True
  try:eager_output=snapshot(candidate_mixed.forward());eager_state=snapshot(tensors.values())
  finally:model.reserved_padding_router=False
  restore(tensors.values(),initial);candidate_mixed.graph.replay()
  for i,(a,e) in enumerate(zip(candidate_mixed.output,eager_output,strict=True)):checks.tensor('mixed/graph_eager_output'+str(i),a,e,exact=True)
  for (name,a),e in zip(tensors.items(),eager_state,strict=True):checks.tensor('mixed/graph_eager_state/'+name,a,e,exact=True)
  del eager_output,eager_state,expected_outputs
  times={'control':[],'candidate':[]}
  for trial in range(6):
   arms=[('control',control_mixed),('candidate',candidate_mixed)]
   if trial%2:arms.reverse()
   for label,graph in arms:
    restore(tensors.values(),initial);begin=torch.cuda.Event(enable_timing=True);end=torch.cuda.Event(enable_timing=True);begin.record();graph.graph.replay();end.record();end.synchronize();times[label].append(begin.elapsed_time(end))
  checks.report['cases'].append(dict(case='mixed-d58-p6-d64p1280-span256',allowed_differences='Explicitly participating reserved slots only',reserved_slots=reserved.cpu().tolist(),participating_dummy_state_differences=dummy,timings={k:dict(raw_ms=v,mean_ms=statistics.mean(v),median_ms=statistics.median(v)) for k,v in times.items()}));checks.flush()
  checks.report['status']='PASS';checks.report['limitations']=['Frozen production flag only; no kernel/model-method monkeypatch. Native real-row router/top8/FP8 exact. Fused residual compatibility enabled by recorded environment.','Fixed partial/full B64 inputs and eight-step exact trajectories, not service/full quality acceptance.','Participating dummy state/output differences are intentional and logged; every real and nonparticipating slot must match.'];checks.flush()
 except Exception as e:
  checks.report['status']='FAIL';checks.report['failure']=dict(type=type(e).__name__,message=str(e));checks.flush();raise
 finally:pass
if __name__=='__main__':main()
