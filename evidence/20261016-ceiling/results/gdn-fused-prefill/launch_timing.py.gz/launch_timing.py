import os,json,hashlib,subprocess,time
from pathlib import Path
R=Path(__file__).resolve().parent;S=R.parent/'source-codec-cache'
assert json.loads((R/'real-result.json').read_text())['status']=='PASS'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()=='e7cda1eba083603b88e1f2e89688e1ff2ced7fc2'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True)
apps=subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid,pid,used_memory','--format=csv,noheader'],text=True)
uuid=subprocess.check_output(['nvidia-smi','-i','0','--query-gpu=uuid','--format=csv,noheader'],text=True).strip();assert uuid not in apps
flags=json.loads((R.parent/'current-pipeline-timeline-experiment.json').read_text())['flags'];flags.pop('DRAMA3_TIMELINE_PATH')
proto={'source_sha':'e7cda1eba083603b88e1f2e89688e1ff2ced7fc2','hypothesis':'Having passed522 real-layer/graph checks, fused H/O must improve complete MixedGraph time on fixed inputs to merit integration.','variable':'Replace H/O pair with frozen artifact fused kernel; original compact FLA frontend and full native model unchanged.','controls':'D58/P6,D40/P3,D12/P1 real corpus prompts, same input/state/RNG/source/GPU; all real and padding states retained.','success':'Exact final output/all mutable states/RNG after20 consecutive graph replays per arm. Three alternating A/B repetitions per shape. Diagnostic only; candidate proceeds only if each shape median is lower than native, not a service improvement claim.','stop':'First exact mismatch/error stops; timing regression prevents runtime promotion; preserve all measurements.','timings_allowed':True,'gpu_uuid':uuid,'flags':flags,'precompute_apps':apps,'time':time.time(),'frozen_files':{p:hashlib.sha256((R/p).read_bytes()).hexdigest() for p in ('time_real.py','adapter.py','fused_ho.py','real-result.json','cpu-aot.json')}}
(R/'timing-protocol.json').write_text(json.dumps(proto,indent=2)+'\n')
env=dict(os.environ,**flags,CUDA_VISIBLE_DEVICES='0',OMP_NUM_THREADS='8',HF_MODULES_CACHE=str(R.parent/'hf_modules'))
with (R/'timing.log').open('w') as out:
 p=subprocess.Popen(['/home/zjy/code/hsliu/venvs/codex-drama3-standalone/bin/python',str(R/'time_real.py')],env=env,stdout=out,stderr=subprocess.STDOUT)
 (R/'timing-pid.json').write_text(json.dumps({'pid':p.pid,'launcher_pid':os.getpid()})+'\n');code=p.wait()
(R/'timing-exit.json').write_text(json.dumps({'returncode':code,'time':time.time(),'postcompute_apps':subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid,pid,used_memory','--format=csv,noheader'],text=True)},indent=2)+'\n')
raise SystemExit(code)
