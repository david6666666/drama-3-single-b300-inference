# Adapted from FLA/SGLang chunk_delta_h.py and chunk_o.py.
# Copyright (c) 2023-2025, Songlin Yang, Yu Zhang.
# Artifact-only native H/O fusion candidate; not installed in the runtime.
import triton
import triton.language as tl
from sglang.kernels.ops.attention.fla.op import exp, safe_exp

@triton.jit(do_not_specialize=['T'])
def fused_ho(q, k, u, w, g, state, slots, boundaries, offsets, output,
             h_debug, updated_debug, stride_state, scale, T,
             H: tl.constexpr, HG: tl.constexpr, K: tl.constexpr,
             V: tl.constexpr, BT: tl.constexpr, BV: tl.constexpr,
             DEBUG: tl.constexpr):
    iv, inh = tl.program_id(0), tl.program_id(1)
    seq, head = inh // H, inh % H
    bos = tl.load(boundaries + seq).to(tl.int32)
    eos = tl.load(boundaries + seq + 1).to(tl.int32)
    length = eos - bos
    chunks = tl.cdiv(length, BT)
    slot = tl.load(slots + seq).to(tl.int64)
    valid_state = slot >= 0
    state_ptr = state + slot * stride_state + head * V * K
    h1 = tl.zeros((BV, 64), tl.float32)
    h2 = tl.zeros((BV, 64), tl.float32)
    if valid_state:
        hp1 = tl.make_block_ptr(state_ptr, (V,K), (K,1), (iv*BV,0), (BV,64), (1,0))
        hp2 = tl.make_block_ptr(state_ptr, (V,K), (K,1), (iv*BV,64), (BV,64), (1,0))
        h1 += tl.load(hp1, boundary_check=(0,1)).to(tl.float32)
        h2 += tl.load(hp2, boundary_check=(0,1)).to(tl.float32)
    q += (bos * HG + head // (H // HG)) * K
    k += (bos * HG + head // (H // HG)) * K
    w += (bos * H + head) * K
    u += (bos * H + head) * V
    output += (bos * H + head) * V
    g += bos * H + head
    if DEBUG:
        h_debug += (tl.load(offsets+seq).to(tl.int64)*H+head)*V*K
        updated_debug += (bos*H+head)*V
    for chunk in range(chunks):
        # Native H exports BF16 before computing each chunk's updated values.
        h_bf16 = tl.cat(h1.to(q.dtype.element_ty), h2.to(q.dtype.element_ty), dim=1)
        if DEBUG:
            hp = tl.make_block_ptr(h_debug+chunk*H*V*K, (V,K), (K,1), (iv*BV,0), (BV,K), (1,0))
            tl.store(hp,h_bf16,boundary_check=(0,1))
        wp1 = tl.make_block_ptr(w,(length,K),(H*K,1),(chunk*BT,0),(BT,64),(1,0))
        wp2 = tl.make_block_ptr(w,(length,K),(H*K,1),(chunk*BT,64),(BT,64),(1,0))
        bw1 = tl.load(wp1,boundary_check=(0,1))
        bw2 = tl.load(wp2,boundary_check=(0,1))
        pred = tl.dot(bw1,tl.trans(h1).to(bw1.dtype))
        pred += tl.dot(bw2,tl.trans(h2).to(bw2.dtype))
        vp = tl.make_block_ptr(u,(length,V),(H*V,1),(chunk*BT,iv*BV),(BT,BV),(1,0))
        updated = tl.load(vp,boundary_check=(0,1))-pred
        # A masked global round-trip in native O reads zero past the true end.
        valid_t = chunk*BT+tl.arange(0,BT)<length
        updated_bf16 = tl.where(valid_t[:,None],updated.to(u.dtype.element_ty),0)
        if DEBUG:
            vp_debug = tl.make_block_ptr(updated_debug,(length,V),(H*V,1),(chunk*BT,iv*BV),(BT,BV),(1,0))
            tl.store(vp_debug,updated_bf16,boundary_check=(0,1))
        # Native O uses one BK=128 dot, with the BF16 H and V boundaries intact.
        qp = tl.make_block_ptr(q,(length,K),(HG*K,1),(chunk*BT,0),(BT,K),(1,0))
        kp = tl.make_block_ptr(k,(K,length),(1,HG*K),(0,chunk*BT),(K,BT),(0,1))
        bq = tl.load(qp,boundary_check=(0,1))
        bk = tl.load(kp,boundary_check=(0,1))
        bo = tl.dot(bq,tl.trans(h_bf16))
        ba = tl.dot(bq,bk)
        gp = tl.make_block_ptr(g,(length,),(H,),(chunk*BT,),(BT,),(0,))
        bg = tl.load(gp,boundary_check=(0,))
        bo = bo*exp(bg)[:,None]
        ba = ba*safe_exp(bg[:,None]-bg[None,:])
        t = tl.arange(0,BT)
        ba = tl.where(t[:,None]>=t[None,:],ba,0)
        bo = bo*scale+tl.dot(ba.to(updated_bf16.dtype),updated_bf16)*scale
        op = tl.make_block_ptr(output,(length,V),(H*V,1),(chunk*BT,iv*BV),(BT,BV),(1,0))
        tl.store(op,bo.to(op.dtype.element_ty),boundary_check=(0,1))
        # Native H recurrence keeps FP32 across chunks, with BF16 decay input.
        last = tl.minimum((chunk+1)*BT,length)-1
        bg_last = tl.load(g+last*H)
        decayed = updated*safe_exp(bg_last-bg)[:,None]
        decay = exp(bg_last)
        h1 = h1*decay
        h2 = h2*decay
        bv = decayed.to(k.dtype.element_ty)
        kp1 = tl.make_block_ptr(k,(K,length),(1,HG*K),(0,chunk*BT),(64,BT),(0,1))
        kp2 = tl.make_block_ptr(k,(K,length),(1,HG*K),(64,chunk*BT),(64,BT),(0,1))
        bk1 = tl.load(kp1,boundary_check=(0,1))
        bk2 = tl.load(kp2,boundary_check=(0,1))
        h1 += tl.trans(tl.dot(bk1,bv))
        h2 += tl.trans(tl.dot(bk2,bv))
    if valid_state:
        hp1 = tl.make_block_ptr(state_ptr,(V,K),(K,1),(iv*BV,0),(BV,64),(1,0))
        hp2 = tl.make_block_ptr(state_ptr,(V,K),(K,1),(iv*BV,64),(BV,64),(1,0))
        tl.store(hp1,h1.to(hp1.dtype.element_ty),boundary_check=(0,1))
        tl.store(hp2,h2.to(hp2.dtype.element_ty),boundary_check=(0,1))
