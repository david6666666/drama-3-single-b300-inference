import os,hashlib,json,time,traceback,subprocess
from pathlib import Path
import torch
from sglang.kernels.ops.attention.fla.chunk_delta_h import chunk_gated_delta_rule_fwd_kernel_h_blockdim64 as native_h
from sglang.kernels.ops.attention.fla.chunk_o import chunk_fwd_kernel_o as native_o
from fused_ho import fused_ho
ROOT=Path(__file__).resolve().parent
REPORT={'status':'RUNNING','scope':'synthetic arithmetic feasibility only; no native model or service claim','checks':[],'cases':[],'timings_allowed':False}
def save():(ROOT/'result.json').write_text(json.dumps(REPORT,indent=2)+'\n')
def check(label,a,b):
 same=a.shape==b.shape and a.dtype==b.dtype and torch.equal(a.contiguous().view(torch.uint8),b.contiguous().view(torch.uint8))
 row={'label':label,'pass':same,'elements':a.numel()};REPORT['checks'].append(row)
 if not same:
  row.update(mismatch=int((a.contiguous().view(torch.uint8)!=b.contiguous().view(torch.uint8)).sum().item()),max_abs=float((a.float()-b.float()).abs().max().item()),rrms=float((a.float()-b.float()).square().mean().sqrt().item()/max(b.float().square().mean().sqrt().item(),1e-30)))
  torch.save({'actual':a.cpu(),'expected':b.cpu()},ROOT/'first-failure.pt');save();raise AssertionError(label)
def fixture(lengths,seed):
 gen=torch.Generator().manual_seed(seed)
 T=sum(lengths);S=len(lengths)+2
 q=torch.nn.functional.normalize(torch.randn(T,16,128,generator=gen),dim=-1).to(torch.bfloat16)
 k=torch.nn.functional.normalize(torch.randn(T,16,128,generator=gen),dim=-1).to(torch.bfloat16)
 u=(torch.randn(T,32,128,generator=gen)*.1).to(torch.bfloat16)
 w=(torch.randn(T,32,128,generator=gen)*.03).to(torch.bfloat16)
 initial=(torch.randn(S,32,128,128,generator=gen)*.05).to(torch.bfloat16)
 g=torch.empty(T,32,dtype=torch.float32);cursor=0;indices=[];offset=[0];bounds=[0]
 for seq,L in enumerate(lengths):
  for start in range(0,L,64):
   n=min(64,L-start);g[cursor+start:cursor+start+n]=-(torch.rand(n,32,generator=gen)*.025+.005).cumsum(0)
   indices.append((seq,start//64))
  cursor+=L;bounds.append(cursor);offset.append(len(indices))
 slots=torch.arange(len(lengths),dtype=torch.int64)+1;slots[-1]=-1
 cpu=dict(q=q,k=k,u=u,w=w,g=g,initial=initial,slots=slots,boundaries=torch.tensor(bounds,dtype=torch.int64),offsets=torch.tensor(offset,dtype=torch.int64),indices=torch.tensor(indices,dtype=torch.int64))
 return {key:v.cuda() for key,v in cpu.items()}
def allocate(d):
 T=d['q'].shape[0];C=len(d['indices'])
 return {'state':d['initial'].clone(),'out':torch.full((T,32,128),-3,dtype=torch.bfloat16,device='cuda'),'h':torch.full((C,32,128,128),-7,dtype=torch.bfloat16,device='cuda'),'updated':torch.full((T,32,128),-11,dtype=torch.bfloat16,device='cuda')}
def native(d,x):
 T=d['q'].shape[0]
 native_h[(4,len(d['slots'])*32)](k=d['k'],v=d['u'],w=d['w'],v_new=x['updated'],g=d['g'],gk=None,h=x['h'],initial_state=x['state'],initial_state_indices=d['slots'],stride_init_state=x['state'].stride(0),cu_seqlens=d['boundaries'],chunk_offsets=d['offsets'],track_state=None,track_chunk_idx=None,stride_track_state=0,T=T,H=32,Hg=16,K=128,V=128,BT=64,USE_G=True,USE_GK=False,USE_INITIAL_STATE=True,INPLACE_UPDATE=True,SAVE_NEW_VALUE=True,IS_VARLEN=True,NT_BUCKET=0,USE_EXP2=False,TRACK_STATE=False)
 native_o[(2,len(d['indices']),32)](d['q'],d['k'],x['updated'],x['h'],d['g'],x['out'],d['boundaries'],d['indices'],128**-.5,T=T,H=32,Hg=16,K=128,V=128,BT=64,BK=128,BV=64,USE_G=True,IS_VARLEN=True,num_warps=4,num_stages=2)
def candidate(d,x,debug):
 return fused_ho[(4,len(d['slots'])*32)](d['q'],d['k'],d['u'],d['w'],d['g'],x['state'],d['slots'],d['boundaries'],d['offsets'],x['out'],x['h'],x['updated'],x['state'].stride(0),128**-.5,d['q'].shape[0],H=32,HG=16,K=128,V=128,BT=64,BV=32,DEBUG=debug,num_warps=4,num_stages=2)
try:
 proto=json.loads((ROOT/'protocol.json').read_text())
 for name,digest in proto['frozen_files'].items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
 uuid=str(torch.cuda.get_device_properties(0).uuid).removeprefix('GPU-');assert uuid==proto['gpu_uuid'].removeprefix('GPU-')
 REPORT['gpu_uuid']=uuid;REPORT['start_time']=time.time();save()
 for idx,lengths in enumerate(([128,107,0,1,63,64,65],[256,193,17,0],[333,1,129,128])):
  label=f'case{idx}';d=fixture(lengths,177+idx);inputs={k:v.clone() for k,v in d.items()};rng=torch.cuda.get_rng_state().clone();ref=allocate(d);native(d,ref)
  for debug in (True,False):
   actual=allocate(d);kernel=candidate(d,actual,debug);torch.cuda.synchronize()
   if idx==0:
    stem='runtime-debug' if debug else 'runtime-production'
    (ROOT/f'{stem}.ptx').write_text(kernel.asm['ptx']);(ROOT/f'{stem}.cubin').write_bytes(kernel.asm['cubin'])
    REPORT[stem]={'n_regs':kernel.n_regs,'n_spills':kernel.n_spills,'metadata':str(kernel.metadata),'cubin_sha256':hashlib.sha256(kernel.asm['cubin']).hexdigest()}
   for name in ('state','out','h','updated') if debug else ('state','out'):
    check(f'{label}/debug{debug}/{name}',actual[name],ref[name])
   if not debug:
    graph=torch.cuda.CUDAGraph();actual['state'].copy_(d['initial'])
    with torch.cuda.graph(graph):candidate(d,actual,False)
    actual['state'].copy_(d['initial']);graph.replay();torch.cuda.synchronize()
    for name in ('state','out'):check(f'{label}/graph/{name}',actual[name],ref[name])
  for name,value in d.items():check(f'{label}/input/{name}',value,inputs[name])
  check(f'{label}/rng',torch.cuda.get_rng_state(),rng)
  REPORT['cases'].append({'lengths':lengths,'status':'PASS'});save()
 REPORT['status']='PASS'
except BaseException as e:
 REPORT.update(status='FAIL',error=repr(e),traceback=traceback.format_exc());raise
finally:
 REPORT['end_time']=time.time();save();print(json.dumps({k:v for k,v in REPORT.items() if k not in ('checks',)},indent=2))
