"""Artifact-only packed FLA frontend with a fused H/O body; native math retained."""
import torch
from drama3.gdn import l2norm_fwd, chunk_local_cumsum
from drama3.gdn_compact import compact_intra
from fused_ho import fused_ho

def fused_prefill(q,k,v,decay,beta,state,slots,length,backend='fla',packed_layout=None):
    assert backend=='fla' and packed_layout is not None and packed_layout.chunk_indices is not None
    sequences,span=q.shape[:2];capacity=sequences*span
    boundaries=packed_layout.boundaries;state_slots=packed_layout.sequence_slots
    indices=packed_layout.chunk_indices;offsets=packed_layout.chunk_offsets
    q,k,v,decay,beta=(x.contiguous() for x in (q,k,v,decay,beta))
    q,k=l2norm_fwd(q),l2norm_fwd(k)
    g=chunk_local_cumsum(decay,chunk_size=64,cu_seqlens=boundaries,chunk_indices=indices)
    w,u=compact_intra(k,v,beta,g,boundaries,indices)
    output=torch.zeros_like(v)
    fused_ho[(4,len(state_slots)*32)](q,k,u,w,g,state,state_slots,boundaries,offsets,output,output,output,state.stride(0),128**-.5,capacity,H=32,HG=16,K=128,V=128,BT=64,BV=32,DEBUG=False,num_warps=4,num_stages=2)
    return output.reshape(sequences,span,32,128)
