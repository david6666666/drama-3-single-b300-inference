import sys,os,json,hashlib,traceback,time
from pathlib import Path
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parent;SOURCE=ROOT.parent/'source-codec-cache'
sys.path[:0]=[str(SOURCE/'src'),str(SOURCE/'scripts'),'/home/zjy/code/hsliu/drama3-sources/fish-speech']
import torch,triton
import torch.nn.functional as F
from fish_speech.models.text2semantic.fish_omni.generate import build_drama3_prompt
import drama3.mixed_model as mm
from drama3.engine import BatchedPrefillGraph,DecodeGraph,state_pool_size
from drama3.mixed_graph import MixedGraph
from drama3.model import DramaModel
from drama3.runtime_state import DeviceRequests
from validate_mixed_layers import state_tensors,snapshot,restore
from adapter import fused_prefill
CORPUS=Path('/home/zjy/code/hsliu/artifacts/drama3-b300-20261014/seedtts-en1088-codes/requests.jsonl')
CKPT='/home/zjy/.cache/huggingface/hub/models--fishaudio--drama-3/snapshots/e0a9218aa48888270f06ef1ed9ea67622c0e17d2'
REPORT={'status':'RUNNING','timings_allowed':False,'checks':[],'cases':[],'start_time':time.time()}
def save():(ROOT/'real-result.json').write_text(json.dumps(REPORT,indent=2)+'\n')
def eq(label,a,b):
 same=a.shape==b.shape and a.dtype==b.dtype and torch.equal(a.contiguous().reshape(-1).view(torch.uint8),b.contiguous().reshape(-1).view(torch.uint8))
 row={'name':label,'pass':same,'elements':a.numel()};REPORT['checks'].append(row)
 if not same:
  row.update(max_abs=float((a.float()-b.float()).abs().max()),rrms=float((a.float()-b.float()).square().mean().sqrt()/b.float().square().mean().sqrt().clamp_min(1e-30)))
  torch.save({'actual':a.cpu(),'expected':b.cpu()},ROOT/'real-first-failure.pt');save();raise AssertionError(label)
@torch.inference_mode()
def main():
 protocol=json.loads((ROOT/'real-protocol.json').read_text())
 for p,digest in protocol['frozen_files'].items():assert hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==digest,p
 assert str(torch.cuda.get_device_properties(0).uuid).removeprefix('GPU-')==protocol['gpu_uuid'].removeprefix('GPU-')
 torch.set_num_threads(8)
 model=DramaModel(CKPT,slots=state_pool_size(64),max_length=2048)
 assert model.prefill_gdn=='fla' and model.prefill_moe=='flashinfer' and not model.tuned_prefill_moe
 device=DeviceRequests(model.slots,model.config.eos_token_id,model.max_length)
 samples=[json.loads(x) for x in CORPUS.read_bytes().splitlines()][:64]
 prompts=[build_drama3_prompt(s['text'],model.weights.tokenizer,model.config,[s['reference_text']],[torch.tensor(s['reference_codes'])]) for s in samples]
 prefill=BatchedPrefillGraph(model,8,triton.next_power_of_2(max(map(len,prompts))))
 first=DecodeGraph(model,8,first_frame=True,requests=device);decode=DecodeGraph(model,64,requests=device)
 native=mm.gdn_prefill;tensors=state_tensors(model,device)
 for count,arriving in ((58,6),(40,3),(12,1)):
  selected=prompts[count:count+arriving];slots=list(range(count,count+arriving))
  cap=triton.cdiv(sum(map(len,selected)),256)*256;bucket=next(n for n in (16,32,48,64) if n>=count)
  label=f'd{count}p{arriving}';print(label,flush=True)
  control=MixedGraph(model,device,bucket,8,cap,max_length=256)
  mm.gdn_prefill=fused_prefill
  try:candidate=MixedGraph(model,device,bucket,8,cap,max_length=256)
  finally:mm.gdn_prefill=native
  active=[SimpleNamespace(slot=i,position=len(p)-1) for i,p in enumerate(prompts)]
  for i,p in enumerate(prompts):
   history=F.pad(p[-16:,0],(max(0,16-len(p)),0),value=-1).cuda();device.initialize(i,p[-1].cuda(),history,len(p)-1,500)
  for start in range(0,64,8):
   hidden=prefill.run(prompts[start:start+8],list(range(start,start+8)));first.run(active[start:start+8],hidden)
  for _ in range(3):decode.run(active)
  base=snapshot(tensors.values());rng=torch.cuda.get_rng_state().clone()
  control.prepare(active[:count],selected,slots)
  visited=[]
  def probe(q,k,v,decay,beta,state,sslots,length,*,backend,packed_layout):
   before=state.clone();cand_state=before.clone()
   actual=fused_prefill(q,k,v,decay,beta,cand_state,sslots,length,backend=backend,packed_layout=packed_layout)
   expected=native(q,k,v,decay,beta,state,sslots,length,backend=backend,packed_layout=packed_layout)
   layer=next(i for i,pair in model.states.items() if pair[1] is state)
   eq(f'{label}/layer{layer}/out',actual,expected);eq(f'{label}/layer{layer}/all_state',cand_state,state)
   visited.append(layer);save();return expected
  mm.gdn_prefill=probe
  try:control.forward()
  finally:mm.gdn_prefill=native
  assert len(visited)==len(set(visited))==30
  restore(tensors.values(),base);torch.cuda.set_rng_state(rng)
  expected=control.run(active[:count],selected,slots);expected_state=snapshot(tensors.values());expected_rng=torch.cuda.get_rng_state().clone()
  restore(tensors.values(),base);torch.cuda.set_rng_state(rng)
  actual=candidate.run(active[:count],selected,slots)
  for i,(a,b) in enumerate(zip(actual,expected)):eq(f'{label}/graph/output{i}',a,b)
  for (name,value),ref in zip(tensors.items(),expected_state):eq(f'{label}/graph/{name}',value,ref)
  eq(f'{label}/graph/rng',torch.cuda.get_rng_state(),expected_rng)
  REPORT['cases'].append({'label':label,'capacity':cap,'layers':visited,'status':'PASS'});save()
  del base,expected_state,expected,actual,control,candidate
 REPORT['status']='PASS';save()
try:main()
except BaseException as e:
 REPORT.update(status='FAIL',error=repr(e),traceback=traceback.format_exc());raise
finally:
 REPORT['end_time']=time.time();save();print(json.dumps({k:v for k,v in REPORT.items() if k!='checks'},indent=2))
