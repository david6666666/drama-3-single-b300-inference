import os,sys,json,hashlib,traceback,time
from pathlib import Path
OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(OUT.parent/'expert-resident-chain'))
os.environ['CUTE_DSL_ARCH']='sm_103a'
os.environ['CUTE_DSL_KEEP']='ptx,cubin'
os.environ['CUTE_DSL_DUMP_DIR']=str(OUT/'activation-helper-aot')
os.environ['CUTE_DSL_CACHE_DIR']=str(OUT/'activation-helper-cache')
sys.path.insert(0,'/home/zjy/code/hsliu/venvs/codex-drama3-vllm/lib/python3.12/site-packages/nvidia_cutlass_dsl/dsl_packages')
import torch,cutlass
import cutlass.cute as cute
from cutlass import Uint8,Uint32,Float32,Int32
from cutlass.utils import SmemAllocator
from cutlass.cute.runtime import make_fake_tensor
import cuda.bindings.driver as cuda_drv
from activation_shared_dsl import activation_shared_8x128

class Probe:
    @cute.kernel
    def kernel(self,q:cute.Tensor,s:cute.Tensor,n:cute.Tensor,y:cute.Tensor,ys:cute.Tensor,guards:cute.Tensor):
        tid,_,_=cute.arch.thread_idx();group,_,_=cute.arch.block_idx()
        smem=SmemAllocator()
        before=smem.allocate_tensor(Uint32,cute.make_layout((16,)),16)
        sx=smem.allocate_tensor(Uint8,cute.make_layout((8,256),stride=(256,1)),16)
        ss=smem.allocate_tensor(Float32,cute.make_layout((2,8),stride=(8,1)),16)
        sy=smem.allocate_tensor(Uint8,cute.make_layout((8,128),stride=(128,1)),16)
        sysf=smem.allocate_tensor(Float32,cute.make_layout((8,)),16)
        after=smem.allocate_tensor(Uint32,cute.make_layout((16,)),16)
        if tid<Int32(16):
            before[tid]=Uint32(0x5a7b9cad);after[tid]=Uint32(0x5a7b9cad)
        for i in cutlass.range_constexpr(4):
            index=tid+Int32(512*i);sx[index//Int32(256),index%Int32(256)]=q[group,index//Int32(256),index%Int32(256)]
        if tid<Int32(16):ss[tid//Int32(8),tid%Int32(8)]=s[group,tid//Int32(8),tid%Int32(8)]
        for i in cutlass.range_constexpr(2):
            index=tid+Int32(512*i);sy[index//Int32(128),index%Int32(128)]=Uint8(165)
        if tid<Int32(8):sysf[tid]=Float32(-17.)
        cute.arch.sync_threads()
        activation_shared_8x128(sx,ss,sy,sysf,n[group],tid)
        cute.arch.sync_threads()
        for i in cutlass.range_constexpr(2):
            index=tid+Int32(512*i);y[group,index//Int32(128),index%Int32(128)]=sy[index//Int32(128),index%Int32(128)]
        if tid<Int32(8):ys[group,tid]=sysf[tid]
        if tid<Int32(16):guards[group,tid]=Int32((before[tid]==Uint32(0x5a7b9cad)) & (after[tid]==Uint32(0x5a7b9cad)))
    @cute.jit
    def __call__(self,q:cute.Tensor,s:cute.Tensor,n:cute.Tensor,y:cute.Tensor,ys:cute.Tensor,guards:cute.Tensor,stream:cuda_drv.CUstream):
        self.kernel(q,s,n,y,ys,guards).launch(grid=(64,1,1),block=(512,1,1),stream=stream)

