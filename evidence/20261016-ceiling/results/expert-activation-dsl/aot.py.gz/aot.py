from probe import *
report=dict(status='PREPARING',gpu_launched=False,source_sha256=hashlib.sha256((OUT.parent/'expert-resident-chain/activation_shared_dsl.py').read_bytes()).hexdigest(),harness_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
def save(): (OUT/'activation-helper-aot-result.json').write_text(json.dumps(report,indent=2)+'\n')
try:
 assert os.environ.get('CUDA_VISIBLE_DEVICES')==''
 assert not torch.cuda.is_initialized()
 q=make_fake_tensor(Uint8,(64,8,256),(2048,256,1),assumed_align=16)
 s=make_fake_tensor(Float32,(64,2,8),(16,8,1),assumed_align=16)
 n=make_fake_tensor(Int32,(64,),(1,),assumed_align=16)
 y=make_fake_tensor(Uint8,(64,8,128),(1024,128,1),assumed_align=16)
 ys=make_fake_tensor(Float32,(64,8),(8,1),assumed_align=16)
 guards=make_fake_tensor(Int32,(64,16),(16,1),assumed_align=16)
 start=time.monotonic();fn=cute.compile(Probe(),q,s,n,y,ys,guards,cuda_drv.CUstream(0),options='--gpu-arch sm_103a --opt-level 2')
 report.update(status='CPU_AOT_PASS',seconds=time.monotonic()-start,kernel_info=str(fn.kernel_info),cuda_initialized=torch.cuda.is_initialized())
 assert not report['cuda_initialized']
 (OUT/'activation-helper-aot').mkdir(exist_ok=True)
 (OUT/'activation-helper-aot/host.mlir').write_text(str(fn.ir_module))
 report['artifacts']={str(p.relative_to(OUT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (OUT/'activation-helper-aot').rglob('*') if p.is_file()}
except BaseException:
 report.update(status='CPU_AOT_FAIL',error=traceback.format_exc(),cuda_initialized=torch.cuda.is_initialized());raise
finally:save()
print(json.dumps(report,indent=2))
