import os,subprocess
from pathlib import Path
r=Path('/home/zjy/code/hsliu/artifacts/drama3-ceiling-20261016');s=r/'source-rich-timeline'
env=dict(os.environ,CUDA_VISIBLE_DEVICES='6',OMP_NUM_THREADS='8',PYTHONPATH=str(s/'src')+':'+str(s/'scripts')+':/home/zjy/code/hsliu/drama3-sources/fish-speech',DRAMA3_GDN_STATE_DTYPE='bfloat16',DRAMA3_PACKED_MOE_PROJECTION='1',DRAMA3_PREFILL_CONV='triton',DRAMA3_PREFILL_MOE_TUNED='0',DRAMA3_PREFILL_MOE='flashinfer',DRAMA3_FUSED_MOE_INPUT='1',DRAMA3_CODEC_DEDICATED_CAPTURE_STREAM='1')
cmd=['/home/zjy/code/hsliu/venvs/codex-drama3-standalone/bin/python',str(r/'codec-priority/driver.py'),'--checkpoint','/home/zjy/.cache/huggingface/hub/models--fishaudio--drama-3/snapshots/e0a9218aa48888270f06ef1ed9ea67622c0e17d2','--fish-source','/home/zjy/code/hsliu/drama3-sources/fish-speech','--corpus','/home/zjy/code/hsliu/artifacts/drama3-b300-20261014/seedtts-en1088-codes/requests.jsonl','--output',str(r/'codec-priority/result.json')]
with (r/'codec-priority/stdout.log').open('w') as out: subprocess.run(cmd,env=env,stdout=out,stderr=subprocess.STDOUT,check=True)
