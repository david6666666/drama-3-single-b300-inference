"""Artifact-only FC1 native-contract probe; never modifies installed packages."""
import sys
from pathlib import Path
CUTLASS_ROOT=Path('/home/zjy/code/hsliu/venvs/codex-drama3-vllm/lib/python3.12/site-packages/nvidia_cutlass_dsl/dsl_packages')
sys.path.insert(0,str(CUTLASS_ROOT))
import dataclasses,json,hashlib
import torch
from safetensors import safe_open
from contextlib import ExitStack
from flashinfer.prims_ts.moe.config_mapper import map_trtllm_deepseek_fp8_moe_tactic
from flashinfer.prims_ts.batched_gemm.batched_gemm_config import make_config
from flashinfer.prims_ts.batched_gemm.batched_gemm_kernel import build_batched_gemm_task_manager
from flashinfer.prims_ts.moe.tensor_adapter import build_fp8_block_scale_launch_io
from flashinfer.tllm_enums import Fp8QuantizationType,ActivationType
# Artifact-local class replacement; installed FI source is never modified.
import importlib.util
import flashinfer.prims_ts.batched_gemm.batched_gemm_kernel as _bg_kernel
_module_path=Path(__file__).resolve().parent/'gmem_c_resources_native_v2.py'
_module_name='flashinfer.prims_ts.batched_gemm.gmem_c_resources_native_v2'
_spec=importlib.util.spec_from_file_location(_module_name,_module_path)
_module=importlib.util.module_from_spec(_spec)
sys.modules[_module_name]=_module
_spec.loader.exec_module(_module)
_bg_kernel.GmemCResource=_module.GmemCResource
ROOT=Path('/home/zjy/code/hsliu/artifacts/drama3-ceiling-20261016')
OUT=Path(__file__).resolve().parent
SOURCE=ROOT/'source-metadata-rebase-95fcb0e'
ORACLE=ROOT/'expert-metadata-rebase/oracle-layer0-real.pt'
CKPT=Path('/home/zjy/.cache/huggingface/hub/models--fishaudio--drama-3/snapshots/e0a9218aa48888270f06ef1ed9ea67622c0e17d2')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def config():
 pair=map_trtllm_deepseek_fp8_moe_tactic((8,5),num_tokens=64,top_k=8,num_local_experts=256,enable_pdl=False,weight_layout=0)
 original=dict(pair.fc1.cfg.kwargs)
 candidate={**original,'num_stages_a':4,'num_stages_b':4,'num_stages_smem_sfa':4,'num_stages_smem_sfb':4,'num_stages_tmem_sfa':4,'num_stages_tmem_sfb':4}
 cfg=make_config(**candidate)
 assert (cfg.mma_m,cfg.mma_n,cfg.mma_k,cfg.tile_k)==(64,8,32,128)
 manager=build_batched_gemm_task_manager(num_experts=1,num_tokens=8,top_k=1,verbose=False,**candidate)
 allocator=manager.smem_allocator
 nbytes=int(allocator.total_smem_bytes)+int(allocator.barrier_smem_bytes)
 assert nbytes<=80*1024,(nbytes,'exceeds predeclared80KiB')
 return cfg,dict(original=original,candidate=candidate,resolved=dataclasses.asdict(cfg),static_smem_bytes=nbytes,tmem_allocator=str(manager._tmem_allocator))
def cpu_data():
 d=torch.load(ORACLE,map_location='cpu',weights_only=False)
 ids=d['ids'].long().flatten(); expanded=torch.where(ids==205)[0];tokens=expanded//8
 assert len(expanded)==8 and len(set(tokens.tolist()))==8
 index=json.loads((CKPT/'model.safetensors.index.json').read_text())['weight_map']
 keys=[f'model.language_model.layers.0.mlp.experts.205.{p}.{s}' for p in ('up_proj','gate_proj','down_proj') for s in ('weight','weight_scale_inv')]
 with ExitStack() as stack:
  handles={f:stack.enter_context(safe_open(str(CKPT/f),framework='pt',device='cpu')) for f in sorted({index[k] for k in keys})}
  def tensor(p,s):
   key=f'model.language_model.layers.0.mlp.experts.205.{p}.{s}';return handles[index[key]].get_tensor(key)
  w1=torch.cat((tensor('up_proj','weight'),tensor('gate_proj','weight')),0)[None].contiguous()
  s1=torch.cat((tensor('up_proj','weight_scale_inv'),tensor('gate_proj','weight_scale_inv')),0)[None].contiguous()
  w2=tensor('down_proj','weight')[None].contiguous();s2=tensor('down_proj','weight_scale_inv')[None].contiguous()
 return dict(q=d['q'].view(torch.uint8)[tokens].contiguous().view(torch.float8_e4m3fn),s=d['input_scale'][:,tokens].contiguous(),w1=w1,s1=s1,w2=w2,s2=s2,
  expected_bytes=d['intermediates']['fc1_bytes'][expanded].contiguous(),expected_scale=d['intermediates']['fc1_scale'][expanded].T.contiguous(),expanded=expanded,tokens=tokens)
def io_for(cfg,data,device):
 x={k:v.to(device) for k,v in data.items()}
 x.update(fc1=torch.full((8,1024),173,dtype=torch.uint8,device=device),fc1scale=torch.full((8,8),-17.0,dtype=torch.float32,device=device),
  act=torch.zeros((8,512),dtype=torch.uint8,device=device),actscale=torch.zeros((4,8),dtype=torch.float32,device=device),fc2=torch.zeros((8,2048),dtype=torch.bfloat16,device=device),
  tile=torch.zeros(1,dtype=torch.int32,device=device),mn=torch.full((1,),8,dtype=torch.int32,device=device),route=torch.arange(9,dtype=torch.int32,device=device),ncta=torch.ones(1,dtype=torch.int32,device=device),padded=torch.full((1,),8,dtype=torch.int32,device=device))
 x['route'][-1]=0
 io=build_fp8_block_scale_launch_io(fc='fc1',cfg=cfg,fp8_quantization_type=Fp8QuantizationType.DeepSeekFp8,
  hidden_states=x['q'],hidden_states_scale=x['s'],gemm1_weights=x['w1'],gemm1_weights_scale=x['s1'],gemm2_weights=x['w2'],gemm2_weights_scale=x['s2'],
  gemm1_output=x['fc1'],gemm1_output_scale=x['fc1scale'],activation_output=x['act'],activation_output_scale=x['actscale'],gemm2_output=x['fc2'],
  tile_idx=x['tile'],mn_limit=x['mn'],route_map=x['route'],num_non_exiting_ctas=x['ncta'],total_num_padded_tokens=x['padded'],routed_token_capacity=8,
  activation_type=int(ActivationType.Swiglu),num_experts=1,num_tokens=8,top_k=1,intermediate_size=512,hidden_size=2048)
 return io,x
