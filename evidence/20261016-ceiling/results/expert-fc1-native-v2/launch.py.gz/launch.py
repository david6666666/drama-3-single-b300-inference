from pathlib import Path
import os,json,hashlib,subprocess,sys
out=Path(__file__).resolve().parent;source=out.parent/'source-metadata-rebase-95fcb0e'
assert json.loads((out/'prepare-v2-result.json').read_text())['status']=='CPU_AOT_PASS'
env=os.environ.copy();env.update(CUDA_VISIBLE_DEVICES='GPU-bc643dc2-a0d1-5ed6-5ecb-0605ca9f340a',PYTHONPATH=str(source/'src'),PYTHONUNBUFFERED='1',OMP_NUM_THREADS='4',HF_MODULES_CACHE=str(out.parent/'hf_modules'),HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
for key in list(env):
 if key.startswith('DRAMA3_'):del env[key]
argv=['/home/zjy/code/hsliu/venvs/codex-drama3-standalone/bin/python',str(out/'run.py')]
protocol={'hypothesis':'Source-backed FP8 output store and dequant-scale fixes reproduce immutable native FC1 bytes/scales; original failure remains archived' ,
 'isolated_variable':'Artifact-local Prims TS epilogue: native16-byte logical store layout and dq=rcp.approx(q); same packed E4M3 converter and MMA' ,
 'fixed':{'source_sha':'95fcb0ef2662f2caf9bfb7fe6863dc3ad7805b1b','layer':0,'expert':205,'real_routes':8,'original_global_topk':8,'all_reference_experts':256,'input':'Extract existing native q/scale rows; no re-quantization or rerouting','native_tactic':[8,5],'FC1_weights':'original E4M3, original FP32 scales, up512 then gate512','K_order':'16 K128 blocks, each4 nativeK32 MMA; FP32 block scaling; native FP8 output boundary','candidate_tile':[128,8,128],'candidate_mma':[64,8,32],'cluster_size':1,'pdl':False,'why_pdl_off':'Standalone arithmetic correctness, no preceding/following kernel dependency; no timing comparison','cutlass':'4.7.1 process-only overlay; original standalone4.6.2 and nativeFI installation unchanged','shared_limit_bytes':81920,'actual_total_shared_bytes':73592},
 'gates':['CPU/AOT compile, CUDA uninitialized; resource≤80KiB','GPU CUBIN hash exactly matches frozenCPU CUBIN','All8192FC1 bytes and64FP32 scales bitwise match archivednative oracle','Input/weight/unparticipating storage and CUDA RNG unchanged','Only after exactpass same-inputCUDAgraph replay also exact'],
 'stop':'First numerical mismatch preservesFAIL and differences; no timing, cluster build, new tolerance or runtime promotion',
 'benefit_limit':'FC1-only arithmetic probe never claimsservicegain. Future4-CTA resident design keeps192weightTMA tiles/expertgroup butreducesproducerparallelism; bandwidth mayworsen.',
 'commands':{'argv':argv,'environment':{k:env[k] for k in ['CUDA_VISIBLE_DEVICES','PYTHONPATH','OMP_NUM_THREADS','HF_MODULES_CACHE']}},'owner':'/root/vllm_scaling'}
(out/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
paths=[Path('/home/zjy/code/hsliu/venvs/codex-drama3-standalone/lib/python3.12/site-packages/flashinfer/prims_ts/batched_gemm/gmem_c_resources.py'),out/'resource-usage.txt',out/'candidate-fc1.sass',out/'gmem_c_resources_native_v2.py',out/'epilogue.patch',out/'native-cubin.json',out/'native-fc1.sass',out/'contract.json',out/'common.py',out/'run.py',out/'launch.py',out/'prepare_v2.py',out/'prepare-v2-result.json',out/'inputs.pt',out/'protocol.json',*list((out/'compile-artifacts-v2').glob('*'))]
(out/'frozen-inputs.json').write_text(json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths if p.is_file()},indent=2)+'\n')
with (out/'run.log').open('w') as f:
 p=subprocess.Popen(argv,env=env,stdout=f,stderr=subprocess.STDOUT);(out/'process.json').write_text(json.dumps({'pid':p.pid,'owner':'/root/vllm_scaling','gpu_uuid':env['CUDA_VISIBLE_DEVICES']},indent=2)+'\n');code=p.wait()
print(json.dumps({'exit_code':code,'log':str(out/'run.log')}));sys.exit(code)
