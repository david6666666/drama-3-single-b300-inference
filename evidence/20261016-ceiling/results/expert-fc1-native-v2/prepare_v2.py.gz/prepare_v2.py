import os,time,traceback,subprocess
from pathlib import Path
os.environ['CUTE_DSL_ARCH']='sm_103a'
os.environ['CUTE_DSL_KEEP']='ptx,cubin'
os.environ['CUTE_DSL_DUMP_DIR']=str(Path(__file__).resolve().parent/'compile-artifacts-v2')
os.environ['CUTE_DSL_CACHE_DIR']=str(Path(__file__).resolve().parent/'compile-cache')
os.environ['FLASHINFER_PRIMS_TS_COMPILE_OPTIONS']='--opt-level 2 --gpu-arch sm_103a'
from common import *
from flashinfer.prims_ts.batched_gemm.batched_gemm_run import _compile_for_launch
import cuda.bindings.driver as cuda_drv
OUT.joinpath('compile-artifacts-v2').mkdir(exist_ok=True)
report={'status':'PREPARING','source_sha':subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip(),'source_status':subprocess.check_output(['git','status','--porcelain'],cwd=SOURCE,text=True),'oracle_sha256':sha(ORACLE),'script_sha256':sha(__file__),'common_sha256':sha(OUT/'common.py'),'cutlass_overlay':str(CUTLASS_ROOT),'cutlass_version':'4.7.1','original_standalone_cutlass':'4.6.2; unchanged','compile_options':os.environ['FLASHINFER_PRIMS_TS_COMPILE_OPTIONS'],'timings_allowed':False}
def flush(): (OUT/'prepare-v2-result.json').write_text(json.dumps(report,indent=2)+'\n')
try:
 assert os.environ.get('CUDA_VISIBLE_DEVICES')==''
 assert report['source_sha']=='95fcb0ef2662f2caf9bfb7fe6863dc3ad7805b1b' and not report['source_status']
 cfg,info=config();report['config']=info;flush()
 data=cpu_data();torch.save(data,OUT/'inputs.pt');report['inputs_sha256']=sha(OUT/'inputs.pt')
 io,bindings=io_for(cfg,data,'cpu');report['shape']=io['shape']
 assert not torch.cuda.is_initialized()
 t=time.monotonic();fn=_compile_for_launch(io,cuda_drv.CUstream(0));report['compile_seconds']=time.monotonic()-t
 report['kernel_info']=str(fn.kernel_info)
 (OUT/'compile-artifacts-v2/host-module.mlir').write_text(str(fn.ir_module))
 # CUBIN/PTX retained directly; initial C-header export failure is preserved separately.
 report['compiled_artifacts']={str(p.relative_to(OUT)):sha(p) for p in (OUT/'compile-artifacts-v2').rglob('*') if p.is_file()}
 report['cuda_initialized']=torch.cuda.is_initialized();assert not report['cuda_initialized']
 report['status']='CPU_AOT_PASS'
except BaseException as e:
 report.update(status='CPU_AOT_FAIL',error=repr(e),traceback=traceback.format_exc(),cuda_initialized=torch.cuda.is_initialized());raise
finally: flush()
print(json.dumps(report,indent=2))
