import json,os,subprocess,hashlib
from pathlib import Path
r=Path(__file__).resolve().parent
p='/home/zjy/code/hsliu/venvs/codex-drama3-standalone/bin/python'
env=dict(os.environ,CUDA_VISIBLE_DEVICES='GPU-53ed8fd9-9f5a-9c77-430d-095ad4fc860d',OMP_NUM_THREADS='8',PYTHONPATH='/home/zjy/code/hsliu/artifacts/drama3-ceiling-20261016/source-codec-sm-69d636e/src:/home/zjy/code/hsliu/drama3-sources/fish-speech',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_MODULES_CACHE='/home/zjy/code/hsliu/artifacts/drama3-b300-20261014/quality-hf-modules')
proc=subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid,pid,process_name','--format=csv,noheader'],text=True)
assert env['CUDA_VISIBLE_DEVICES'] not in proc,proc
cmd=[p,str(r/'driver.py')]
record=dict(command=cmd,environment={k:env[k] for k in ['CUDA_VISIBLE_DEVICES','OMP_NUM_THREADS','PYTHONPATH','HF_HUB_OFFLINE','TRANSFORMERS_OFFLINE','HF_MODULES_CACHE']},driver_sha256=hashlib.sha256((r/'driver.py').read_bytes()).hexdigest(),before_processes=proc)
with (r/'stdout.log').open('w') as f:q=subprocess.Popen(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
record['pid']=q.pid;(r/'command.json').write_text(json.dumps(record,indent=2)+'\n');print(q.pid)
