"""Timing only: native FI vs FLA current mixed; numerical failure retained."""

import argparse
import hashlib
import json
import os
import statistics
import subprocess
import sys
from pathlib import Path
from types import SimpleNamespace

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--source", type=Path, required=True)
parser.add_argument("--checkpoint", required=True)
parser.add_argument("--corpus", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
sys.path.insert(0, str(args.source / "src"))
sys.path.insert(0, str(args.source / "scripts"))
import torch
import torch.nn.functional as F
import triton
from fish_speech.models.text2semantic.fish_omni.generate import build_drama3_prompt
from validate_mixed_layers import Checks, restore, snapshot, state_tensors
from drama3.engine import BatchedPrefillGraph, DecodeGraph, state_pool_size
from drama3.mixed_graph import MixedGraph
from drama3.model import DramaModel
from drama3.runtime_state import DeviceRequests


@torch.inference_mode()
def main():
    raw = args.corpus.read_bytes()
    report = Checks(
        args.output,
        dict(
            source_sha=subprocess.check_output(
                ["git", "rev-parse", "HEAD"], cwd=args.source, text=True
            ).strip(),
            source_status=subprocess.check_output(
                ["git", "status", "--porcelain"], cwd=args.source, text=True
            ),
            driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            corpus_sha256=hashlib.sha256(raw).hexdigest(),
            runtime_sha256={
                str(p.relative_to(args.source)): hashlib.sha256(
                    p.read_bytes()
                ).hexdigest()
                for p in sorted((args.source / "src/drama3").glob("*.py"))
            },
            gpu_uuid=str(torch.cuda.get_device_properties(0).uuid),
            environment={
                k: v for k, v in os.environ.items() if k.startswith("DRAMA3_")
            },
            experiment=json.loads(
                (Path(__file__).parent / "fi-mixed-timing-experiment.json").read_text()
            ),
        ),
    )
    try:
        if os.environ.get("DRAMA3_COMPACT_GDN") != "0":
            raise ValueError("Compaction must be off")
        model = DramaModel(args.checkpoint, slots=state_pool_size(64), max_length=2048)
        if model.prefill_moe != "flashinfer" or model.tuned_prefill_moe:
            raise ValueError("Native untuned MoE required")
        device = DeviceRequests(
            model.slots, model.config.eos_token_id, model.max_length
        )
        samples = [json.loads(line) for line in raw.splitlines()][:64]
        prompts = [
            build_drama3_prompt(
                s["text"],
                model.weights.tokenizer,
                model.config,
                [s["reference_text"]],
                [torch.tensor(s["reference_codes"])],
            )
            for s in samples
        ]
        model.prefill_gdn = "fla"
        prefill = BatchedPrefillGraph(
            model, 8, triton.next_power_of_2(max(map(len, prompts)))
        )
        first = DecodeGraph(model, 8, first_frame=True, requests=device)
        control = MixedGraph(model, device, 64, 8, 1280, max_length=256)
        model.prefill_gdn = "flashinfer"
        candidate = MixedGraph(model, device, 64, 8, 1280, max_length=256)
        count = 58
        selected = prompts[58:64]
        active = [
            SimpleNamespace(slot=i, position=len(prompts[i]) - 1) for i in range(count)
        ]
        for i, p in enumerate(prompts[:count]):
            history = F.pad(p[-16:, 0], (max(0, 16 - len(p)), 0), value=-1).cuda()
            device.initialize(i, p[-1].cuda(), history, len(p) - 1, 500)
        for start in range(0, count, 8):
            end = min(start + 8, count)
            hidden = prefill.run(prompts[start:end], list(range(start, end)))
            first.run(active[start:end], hidden)
        for graph in (control, candidate):
            graph.prepare(active, selected, list(range(58, 64)))
        tensors = state_tensors(model, device)
        initial = snapshot(tensors.values())
        timings = {"fla_ms": [], "flashinfer_ms": []}
        for iteration in range(6):
            arms = [("fla_ms", control), ("flashinfer_ms", candidate)]
            if iteration % 2:
                arms.reverse()
            for name, graph in arms:
                restore(tensors.values(), initial)
                begin, end = (torch.cuda.Event(enable_timing=True) for _ in range(2))
                begin.record()
                graph.graph.replay()
                end.record()
                end.synchronize()
                if iteration:
                    timings[name].append(begin.elapsed_time(end))
        medians = {k: statistics.median(v) for k, v in timings.items()}
        row = dict(
            case="d58-p6",
            decode_rows=64,
            capacity=1280,
            span=256,
            prompt_lengths=list(map(len, selected)),
            timings=timings,
            median_ms=medians,
            latency_decrease_fraction=1 - medians["flashinfer_ms"] / medians["fla_ms"],
            quality="unresolved; original numeric FAIL retained",
        )
        report.report["cases"].append(row)
        report.report["status"] = "TIMING_ONLY_COMPLETE"
        report.flush()
        print(json.dumps(row), flush=True)
    except Exception as error:
        report.report["status"] = "ERROR"
        report.report["failure"] = dict(type=type(error).__name__, message=str(error))
        report.flush()
        raise


if __name__ == "__main__":
    main()
