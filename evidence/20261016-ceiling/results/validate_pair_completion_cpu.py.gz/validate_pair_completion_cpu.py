"""Exercise actual Engine.complete_decode on CPU synthetic token pairs only."""
import ast
from contextlib import nullcontext
import hashlib
import itertools
import json
from pathlib import Path
import subprocess
from types import SimpleNamespace

import torch

ROOT = Path(__file__).resolve().parent
SOURCE = Path("/home/zjy/code/hsliu/drama-3-single-b300-inference")
path = SOURCE / "src/drama3/engine.py"
tree = ast.parse(path.read_text())
engine = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == "Engine")
method = next(n for n in engine.body if isinstance(n, ast.FunctionDef) and n.name == "complete_decode")
namespace = {}
exec(compile(ast.fix_missing_locations(ast.Module(body=[method], type_ignores=[])), str(path), "exec"), namespace)

class Harness:
    complete_decode = namespace["complete_decode"]
    def __init__(self):
        self.model = SimpleNamespace(config=SimpleNamespace(eos_token_id=0))
        self.async_codec = True
        self.emissions = []
        self.finished = []
    def measure(self, *args):
        return nullcontext()
    def emit_audio_batch(self, requests):
        self.emissions.extend((r.slot, r.frame_count, r.position) for r in requests)
    def finish_audio(self, request):
        self.finished.append(request.slot)

checks = []

def check(label, tokens, starts, limits, emits):
    harness = Harness()
    requests = [SimpleNamespace(slot=i, frame_count=start, position=100+start,
                               max_frames=limit, next_emit=emit)
                for i, (start, limit, emit) in enumerate(zip(starts, limits, emits, strict=True))]
    # Tokens indexed [step,batch]; codebook values are irrelevant to CPU completion.
    frames = torch.ones((2, len(requests), 11), dtype=torch.int64)
    frames[:, :, 0] = torch.tensor(tokens, dtype=torch.int64)
    free = []
    survivors = harness.complete_decode(requests, frames, free)
    want_finished, want_emissions, want_survivors = [], [], []
    for i, (request, start, limit, emit) in enumerate(zip(requests, starts, limits, emits, strict=True)):
        accepted = 0
        ended = False
        for step in range(2):
            if tokens[step][i] == 0:
                ended = True
                break
            accepted += 1
            if start + accepted >= limit:
                ended = True
                break
        assert request.frame_count == start + accepted, label
        assert request.position == 100 + start + accepted, label
        if ended or start + accepted >= emit:
            want_emissions.append((i, start+accepted, 100+start+accepted))
        if ended:
            want_finished.append(i)
        else:
            want_survivors.append(i)
    assert harness.emissions == want_emissions, label
    assert harness.finished == want_finished, label
    assert free == want_finished, label
    assert [r.slot for r in survivors] == want_survivors, label
    checks.append(dict(name=label, passed=True, input_tokens=tokens,
                       final_counts=[r.frame_count for r in requests],
                       emitted_slots=[i for i, _, _ in harness.emissions],
                       finished_slots=harness.finished, survivor_slots=want_survivors))

for pair, start, headroom, until_emit in itertools.product(
    itertools.product((0, 7, 11), repeat=2), (0, 4), (1, 2, 8), (1, 2, 8)
):
    check(f"pair{pair}-count{start}-limit{headroom}-emit{until_emit}",
          [[pair[0]], [pair[1]]], [start], [start+headroom], [start+until_emit])
check("mixed_first_eos_second_eos_normal_and_limit",
      [[0, 7, 7, 11, 0, 11], [11, 0, 7, 11, 0, 7]],
      [4]*6, [100,100,100,5,100,6], [6]*6)
report = dict(status="PASS", cpu_only=True, cuda_initialized=torch.cuda.is_initialized(),
    source_sha=subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=SOURCE, text=True).strip(),
    engine_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
    driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    scope="Actual complete_decode CPU semantics; no GPU append-mask, model EOS or timing validation",
    checks=checks)
assert not report["cuda_initialized"]
(ROOT / "pair-completion-cpu.json").write_text(json.dumps(report, indent=2)+"\n")
print(json.dumps(dict(status=report["status"], cases=len(checks), cuda_initialized=False)))
