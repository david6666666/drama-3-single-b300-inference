"""Frozen-source compact GDN exactness gate and diagnostic graph timings."""

import argparse
import hashlib
import json
import os
import statistics
import subprocess
import sys
from pathlib import Path
from types import SimpleNamespace

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--source", type=Path, required=True)
parser.add_argument("--checkpoint", required=True)
parser.add_argument("--corpus", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
sys.path.insert(0, str(args.source / "src"))
sys.path.insert(0, str(args.source / "scripts"))

import torch
import torch.nn.functional as F
import triton
from fish_speech.models.text2semantic.fish_omni.generate import build_drama3_prompt
from validate_mixed_layers import Checks, restore, snapshot, state_tensors
import drama3.mixed_model as mixed_model
from drama3.engine import BatchedPrefillGraph, DecodeGraph, state_pool_size
from drama3.mixed_graph import MixedGraph
from drama3.model import DramaModel
from drama3.packed_prefill import PackedLayout, PackedPrefillGraph
from drama3.runtime_state import DeviceRequests


def outputs(graph):
    return graph.output if isinstance(graph.output, tuple) else (graph.output,)


@torch.inference_mode()
def main():
    raw = args.corpus.read_bytes()
    checks = Checks(
        args.output,
        dict(
            source_sha=subprocess.check_output(
                ["git", "rev-parse", "HEAD"], cwd=args.source, text=True
            ).strip(),
            source_status=subprocess.check_output(
                ["git", "status", "--porcelain"], cwd=args.source, text=True
            ),
            corpus_sha256=hashlib.sha256(raw).hexdigest(),
            driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            runtime_sha256={
                str(p.relative_to(args.source)): hashlib.sha256(
                    p.read_bytes()
                ).hexdigest()
                for p in sorted((args.source / "src/drama3").glob("*.py"))
            },
            gpu_uuid=str(torch.cuda.get_device_properties(0).uuid),
            environment={
                k: v for k, v in os.environ.items() if k.startswith("DRAMA3_")
            },
            gate="Every GDN output/state and full graph output/state exact. Stop on first failure. No timing gate substitution.",
            timing="Five alternating CUDA-event graph samples after one warmup each, restore identical initial state outside events. Diagnostic, not service acceptance.",
            hypothesis="Compact descriptors and skip invalid chunks while retaining the original FLA arithmetic and full native model.",
        ),
    )
    try:
        model = DramaModel(args.checkpoint, slots=state_pool_size(64), max_length=2048)
        if (
            model.prefill_moe != "flashinfer"
            or model.tuned_prefill_moe
            or model.prefill_gdn != "fla"
        ):
            raise ValueError("Require untuned FlashInfer MoE and FLA GDN")
        device = DeviceRequests(
            model.slots, model.config.eos_token_id, model.max_length
        )
        samples = [json.loads(line) for line in raw.splitlines()]

        def prompt(sample):
            return build_drama3_prompt(
                sample["text"],
                model.weights.tokenizer,
                model.config,
                [sample["reference_text"]],
                [torch.tensor(sample["reference_codes"])],
            )

        prompts = [prompt(s) for s in samples[:64]]
        longer = None
        for sample in samples[64:256]:
            value = prompt(sample)
            if 256 < len(value) <= 512:
                longer = value
                break
        os.environ["DRAMA3_COMPACT_GDN"] = "0"
        prefill = BatchedPrefillGraph(
            model, 8, triton.next_power_of_2(max(map(len, prompts)))
        )
        first = DecodeGraph(model, 8, first_frame=True, requests=device)
        tensors = state_tensors(model, device)

        def initialize(count):
            active = [
                SimpleNamespace(slot=i, position=len(prompts[i]) - 1)
                for i in range(count)
            ]
            for i, p in enumerate(prompts[:count]):
                history = F.pad(p[-16:, 0], (max(0, 16 - len(p)), 0), value=-1).cuda()
                device.initialize(i, p[-1].cuda(), history, len(p) - 1, 500)
            for start in range(0, count, 8):
                end = min(start + 8, count)
                hidden = prefill.run(prompts[start:end], list(range(start, end)))
                first.run(active[start:end], hidden)
            return active

        def ownership(label, initial, owned):
            other = torch.tensor(
                [s for s in range(model.slots) if s not in owned], device="cuda"
            )
            for (name, value), saved in zip(tensors.items(), initial, strict=True):
                if name.startswith(("conv/", "gdn/", "key/", "value/")):
                    checks.tensor(
                        label + "/" + name + "/untouched",
                        value.index_select(0, other),
                        saved.index_select(0, other),
                        exact=True,
                    )
                else:
                    checks.tensor(
                        label + "/" + name + "/unchanged", value, saved, exact=True
                    )

        def layers(graph, label, initial):
            original = mixed_model.gdn_prefill
            visited = []

            def probe(
                q,
                k,
                v,
                decay,
                beta,
                state,
                slots,
                valid_length,
                *,
                backend,
                packed_layout,
            ):
                before = state.clone()
                actual = original(
                    q,
                    k,
                    v,
                    decay,
                    beta,
                    state,
                    slots,
                    valid_length,
                    backend=backend,
                    packed_layout=packed_layout,
                )
                candidate = state.clone()
                layer = next(
                    index for index, pair in model.states.items() if pair[1] is state
                )
                control_layout = PackedLayout(
                    packed_layout.boundaries,
                    packed_layout.sequence_slots,
                    packed_layout.max_length,
                )
                try:
                    state.copy_(before)
                    expected = original(
                        q,
                        k,
                        v,
                        decay,
                        beta,
                        state,
                        slots,
                        valid_length,
                        backend=backend,
                        packed_layout=control_layout,
                    )
                    checks.tensor(
                        f"{label}/layer{layer}/output", actual, expected, exact=True
                    )
                    checks.tensor(
                        f"{label}/layer{layer}/all_state", candidate, state, exact=True
                    )
                    untouched = torch.tensor(
                        [
                            s
                            for s in range(model.slots)
                            if s not in packed_layout.sequence_slots.tolist()
                        ],
                        device="cuda",
                    )
                    checks.tensor(
                        f"{label}/layer{layer}/untouched",
                        candidate.index_select(0, untouched),
                        before.index_select(0, untouched),
                        exact=True,
                    )
                    visited.append(layer)
                finally:
                    state.copy_(candidate)
                return actual

            mixed_model.gdn_prefill = probe
            try:
                graph.forward()
            finally:
                mixed_model.gdn_prefill = original
                restore(tensors.values(), initial)
            if len(visited) != 30 or len(set(visited)) != 30:
                raise AssertionError(("GDN layers missing", visited))
            checks.report["layer_indices"] = visited
            checks.flush()

        def compare(
            label,
            control,
            candidate,
            selected,
            active_count,
            probe_layers=False,
            packed=False,
        ):
            print(label, flush=True)
            active = initialize(active_count)
            slots = list(range(active_count, active_count + len(selected)))
            initial = snapshot(tensors.values())
            if packed:
                control.run(selected, slots)
                restore(tensors.values(), initial)
                candidate.run(selected, slots)
                restore(tensors.values(), initial)
            else:
                control.prepare(active, selected, slots)
                candidate.prepare(active, selected, slots)
            owned = set(candidate.layout.sequence_slots.tolist())
            if not packed:
                owned.update(candidate.slots[: candidate.decode_size].tolist())
            if probe_layers:
                layers(candidate, label, initial)
            control.graph.replay()
            expected_output = snapshot(outputs(control))
            expected_state = snapshot(tensors.values())
            ownership(label + "/control", initial, owned)
            restore(tensors.values(), initial)
            candidate.graph.replay()
            for index, (actual, expected) in enumerate(
                zip(outputs(candidate), expected_output, strict=True)
            ):
                checks.tensor(
                    f"{label}/graph_output{index}", actual, expected, exact=True
                )
            for (name, actual), expected in zip(
                tensors.items(), expected_state, strict=True
            ):
                checks.tensor(
                    label + "/graph_state/" + name, actual, expected, exact=True
                )
            ownership(label + "/candidate", initial, owned)
            timings = {"static_ms": [], "compact_ms": []}
            for iteration in range(6):
                arms = [("static_ms", control), ("compact_ms", candidate)]
                if iteration % 2:
                    arms.reverse()
                for name, graph in arms:
                    restore(tensors.values(), initial)
                    begin, end = (
                        torch.cuda.Event(enable_timing=True) for _ in range(2)
                    )
                    begin.record()
                    graph.graph.replay()
                    end.record()
                    end.synchronize()
                    if iteration:
                        timings[name].append(begin.elapsed_time(end))
            bounds = candidate.layout.boundaries.tolist()
            lengths = [b - a for a, b in zip(bounds[:-1], bounds[1:])]
            row = dict(
                case=label,
                active=active_count,
                arriving=len(selected),
                prompt_lengths=list(map(len, selected)),
                capacity=control.capacity,
                span=control.layout.max_length,
                lengths=lengths,
                static_chunks=len(lengths) * triton.cdiv(control.layout.max_length, 64),
                compact_capacity=len(candidate.layout.chunk_indices),
                actual_chunks=sum(triton.cdiv(n, 64) for n in lengths),
                timings=timings,
                median_ms={k: statistics.median(v) for k, v in timings.items()},
                passed=True,
            )
            checks.report["cases"].append(row)
            checks.flush()
            print(json.dumps(row), flush=True)
            del initial, expected_state, expected_output

        cases = [
            ("d58-p6", 58, prompts[58:64], 256),
            ("d40-p3", 40, prompts[40:43], 256),
            ("d12-p1", 12, prompts[12:13], 256),
            (
                "span512-fallback",
                12,
                [longer] if longer is not None else prompts[12:13],
                512,
            ),
        ]
        for label, count, selected, span in cases:
            capacity = triton.cdiv(sum(map(len, selected)), 256) * 256
            d = next(n for n in (16, 32, 48, 64) if n >= count)
            os.environ["DRAMA3_COMPACT_GDN"] = "0"
            control = MixedGraph(model, device, d, 8, capacity, max_length=span)
            os.environ["DRAMA3_COMPACT_GDN"] = "1"
            candidate = MixedGraph(model, device, d, 8, capacity, max_length=span)
            compare(
                label,
                control,
                candidate,
                selected,
                count,
                probe_layers=label == "d58-p6",
            )
            if label == "d58-p6":
                pointers = (
                    candidate.layout.chunk_indices.data_ptr(),
                    candidate.layout.chunk_offsets.data_ptr(),
                )
                compare(
                    label + "-descriptor-update",
                    control,
                    candidate,
                    list(reversed(selected)),
                    count,
                )
                if pointers != (
                    candidate.layout.chunk_indices.data_ptr(),
                    candidate.layout.chunk_offsets.data_ptr(),
                ):
                    raise AssertionError("Descriptor storage changed after capture")
            del control, candidate
            torch.cuda.empty_cache()
        os.environ["DRAMA3_COMPACT_GDN"] = "0"
        control = PackedPrefillGraph(model, 8, 1280, max_length=256)
        os.environ["DRAMA3_COMPACT_GDN"] = "1"
        candidate = PackedPrefillGraph(model, 8, 1280, max_length=256)
        compare(
            "parent-packed-d58-p6", control, candidate, prompts[58:64], 58, packed=True
        )
        checks.report["status"] = "PASS"
        checks.flush()
    except Exception as error:
        checks.report["status"] = "FAIL"
        checks.report["failure"] = dict(type=type(error).__name__, message=str(error))
        checks.flush()
        raise


if __name__ == "__main__":
    main()
