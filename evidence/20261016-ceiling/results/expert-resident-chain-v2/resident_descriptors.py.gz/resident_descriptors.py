# SPDX-License-Identifier: Apache-2.0
import flashinfer.prims_ts.batched_gemm.batched_gemm_kernel as _native
globals().update({k:v for k,v in vars(_native).items() if not k.startswith('__')})

@cute.jit
def resident_native_descriptors(
    a_raw_ptr: cute.Pointer,
    b_raw_ptr: cute.Pointer,
    sfa_raw_ptr: cute.Pointer,
    sfb_raw_ptr: cute.Pointer,
    c_raw_ptr: cute.Pointer,
    sf_c_raw_ptr: cute.Pointer,
    tile_idx_raw_ptr: cute.Pointer,
    route_map_raw_ptr: cute.Pointer,  # Int32 route map (gather only)
    mn_limit_raw_ptr: cute.Pointer,  # Int32 per-tile mn limit (gather only)
    num_non_exiting_ctas_raw_ptr: cute.Pointer,  # Int32 scalar for early exit
    total_num_padded_tokens_raw_ptr: cute.Pointer,  # Int32 scalar for routed token stride
    act_raw_ptr: cute.Pointer,  # BF16 activation ptr (gather only)
    per_token_sf_a_raw_ptr: cute.Pointer,
    per_token_sf_b_raw_ptr: cute.Pointer,
    bias_raw_ptr,
    scale_c_raw_ptr,
    scale_gate_raw_ptr,
    gemm1_alpha_raw_ptr,
    gemm1_beta_raw_ptr,
    gemm1_clamp_limit_raw_ptr,
    problem_size: tuple,
    early_exit_max_token_ctas: cutlass.Int32,
    cfg: cutlass.Constexpr[BatchedGemmConfig],
    stream,
):
    """Host-side: create TMA descs and launch kernel."""
    m, n, k, num_experts_dim, num_tokens = problem_size
    compute_warp_layout(cfg)
    validate_config(cfg, problem_mnk=(m, n, k))
    from cutlass.experimental.cuda import TensorMapDataFormat

    # Typed pointers passed from host-side make_ptr (cute.runtime.make_ptr)
    a_ptr = a_raw_ptr
    b_ptr = b_raw_ptr
    sfa_ptr = sfa_raw_ptr
    sfb_ptr = sfb_raw_ptr
    per_token_sf_a_ptr = per_token_sf_a_raw_ptr
    per_token_sf_b_ptr = per_token_sf_b_raw_ptr

    # TMA route (gather4): the routed operand is 2D (K, total_rows) flat.
    # TmaOobOpt: non-routed activations use a 4D out-of-bounds TMA descriptor.
    # Non-swapAB: A=activations (routed 2D), B=weights (3D).
    # SwapAB:     A=weights (3D), B=activations (routed 2D).
    # No route:   activation operand may be 4D OOB; weights stay 3D.
    if cutlass.const_expr(cfg.uses_block_major_k_weight_a):
        a_block_k = cfg.block_major_k_elems
        a_layout = cute.make_layout(
            (a_block_k, m, cute.assume(k // a_block_k, 1), num_experts_dim),
            stride=(
                1,
                a_block_k,
                cute.assume(m * a_block_k, 32),
                cute.assume(m * k, 32),
            ),
        )
        a_tensor = cute.make_tensor(a_ptr, a_layout)
    elif cutlass.const_expr(cfg.has_tma_route and not cfg.is_swap_ab):
        a_layout = cute.make_layout(
            (cute.assume(k, 32), m), stride=(1, cute.assume(k, 32))
        )
        a_tensor = cute.make_tensor(a_ptr, a_layout)
    elif cutlass.const_expr(cfg.use_bf16_kbox_tma_a):
        a_layout = cute.make_layout(
            (64, m, cute.assume(k // 64, 1), num_experts_dim),
            stride=(1, cute.assume(k, 32), 64, cute.assume(m * k, 32)),
        )
        a_tensor = cute.make_tensor(a_ptr, a_layout)
    elif cutlass.const_expr(cfg.use_tma_oob_opt_a):
        a_layout = cute.make_layout(
            (cute.assume(k, 32), cfg.tile_m, TMA_DIM_MAX, TMA_DIM_MAX),
            stride=(1, cute.assume(k, 32), TMA_XLARGE_N - k, cute.assume(k, 32)),
        )
        a_tensor = cute.make_tensor(a_ptr, a_layout)
    else:
        a_layout = cute.make_layout(
            (cute.assume(k, 32), m, num_experts_dim),
            stride=(1, cute.assume(k, 32), cute.assume(m * k, 32)),
        )
        a_tensor = cute.make_tensor(a_ptr, a_layout)

    if cutlass.const_expr(cfg.uses_block_major_k_weight_b):
        b_block_k = cfg.block_major_k_elems
        b_layout = cute.make_layout(
            (b_block_k, n, cute.assume(k // b_block_k, 1), num_experts_dim),
            stride=(
                1,
                b_block_k,
                cute.assume(n * b_block_k, 32),
                cute.assume(n * k, 32),
            ),
        )
    elif cutlass.const_expr(cfg.has_tma_route and cfg.is_swap_ab):
        b_layout = cute.make_layout(
            (cute.assume(k, 32), n), stride=(1, cute.assume(k, 32))
        )
    elif cutlass.const_expr(cfg.use_tma_oob_opt_b):
        b_layout = cute.make_layout(
            (cute.assume(k, 32), cfg.tile_n, TMA_DIM_MAX, TMA_DIM_MAX),
            stride=(1, cute.assume(k, 32), TMA_XLARGE_N - k, cute.assume(k, 32)),
        )
    else:
        b_layout = cute.make_layout(
            (cute.assume(k, 32), n, num_experts_dim),
            stride=(1, cute.assume(k, 32), cute.assume(n * k, 32)),
        )
    b_tensor = cute.make_tensor(b_ptr, b_layout)

    def _tma_format_for_dtype(dtype_kind: int, native_fp4: bool = False):
        if cutlass.const_expr(dtype_kind == int(DType.BF16)):
            return TensorMapDataFormat.DEFAULT
        if cutlass.const_expr(dtype_kind in (int(DType.MXE4M3), int(DType.E4M3))):
            return TensorMapDataFormat.BYTE
        if cutlass.const_expr(dtype_kind == int(DType.MXE2M1)):
            if cutlass.const_expr(native_fp4):
                return TensorMapDataFormat.B4X16
            return TensorMapDataFormat.B4X16_P64
        return TensorMapDataFormat.B4X16

    def _tma_box_k_for_dtype(dtype_kind: int, native_fp4: bool = False):
        if cutlass.const_expr(dtype_kind == int(DType.BF16)):
            return 64
        if cutlass.const_expr(native_fp4):
            return cfg.tile_k
        if cutlass.const_expr(
            dtype_kind in (int(DType.MXE2M1), int(DType.MXE4M3), int(DType.E4M3))
        ):
            return 128
        return 256

    def _tma_swizzle_for_fastest_dim_bytes(num_bytes: int):
        if cutlass.const_expr(num_bytes % 128 == 0):
            return cuda.TensorMapSwizzle.s128b
        if cutlass.const_expr(num_bytes % 64 == 0):
            return cuda.TensorMapSwizzle.s64b
        if cutlass.const_expr(num_bytes % 32 == 0):
            return cuda.TensorMapSwizzle.s32b
        return cuda.TensorMapSwizzle.none

    # TMA descriptors for A and B: MX FP4 expands to 8-bit SMEM staging, so
    # A/B formats and box widths must be selected independently.
    tma_format_a = _tma_format_for_dtype(cfg.dtype_a_kind, cfg.has_cast_a)
    tma_format_b = _tma_format_for_dtype(cfg.dtype_b_kind)
    tma_swizzle = cuda.TensorMapSwizzle.s128b
    a_box_k = _tma_box_k_for_dtype(cfg.dtype_a_kind, cfg.has_cast_a)
    b_box_k = _tma_box_k_for_dtype(cfg.dtype_b_kind)

    if cutlass.const_expr(cfg.uses_block_major_k_weight_a):
        a_tile_block_k = cfg.block_major_k_tile_block_elems
        tma_a_desc = cuda.create_tensor_map_tiled_from_tensor(
            tensor=a_tensor,
            box_dims=(
                a_tile_block_k,
                cfg.tile_m,
                cfg.block_major_k_tile_slices,
                1,
            ),
            stride_order=(0, 1, 2, 3),
            swizzle=tma_swizzle,
            tma_format=tma_format_a,
        )
    elif cutlass.const_expr(cfg.has_tma_route and not cfg.is_swap_ab):
        tma_a_desc = cuda.create_tensor_map_tiled_from_tensor(
            tensor=a_tensor,
            box_dims=(a_box_k, 1),
            stride_order=(0, 1),
            swizzle=tma_swizzle,
            tma_format=tma_format_a,
        )
    elif cutlass.const_expr(cfg.use_bf16_kbox_tma_a):
        tma_a_desc = cuda.create_tensor_map_tiled_from_tensor(
            tensor=a_tensor,
            box_dims=(64, cfg.tile_m, cfg.tile_k // 64, 1),
            stride_order=(0, 1, 2, 3),
            swizzle=tma_swizzle,
            tma_format=tma_format_a,
        )
    elif cutlass.const_expr(cfg.use_tma_oob_opt_a):
        tma_a_desc = cuda.create_tensor_map_tiled_from_tensor(
            tensor=a_tensor,
            box_dims=(a_box_k, cfg.tile_m, 1, 1),
            stride_order=(0, 1, 2, 3),
            swizzle=tma_swizzle,
            tma_format=tma_format_a,
        )
    else:
        tma_a_desc = cuda.create_tensor_map_tiled_from_tensor(
            tensor=a_tensor,
            box_dims=(a_box_k, cfg.tile_m, 1),
            stride_order=(0, 1, 2),
            swizzle=tma_swizzle,
            tma_format=tma_format_a,
        )

    if cutlass.const_expr(cfg.has_tma_route and cfg.is_swap_ab):
        tma_b_desc = cuda.create_tensor_map_tiled_from_tensor(
            tensor=b_tensor,
            box_dims=(b_box_k, 1),
            stride_order=(0, 1),
            swizzle=tma_swizzle,
            tma_format=tma_format_b,
        )
    else:
        b_box_rows = cfg.tile_n
        if cutlass.const_expr(cfg.split_b_across_ctas):
            b_box_rows = cfg.tile_n // cfg.cluster_m
        if cutlass.const_expr(cfg.uses_block_major_k_weight_b):
            b_tile_block_k = cfg.block_major_k_tile_block_elems
            tma_b_desc = cuda.create_tensor_map_tiled_from_tensor(
                tensor=b_tensor,
                box_dims=(
                    b_tile_block_k,
                    b_box_rows,
                    cfg.block_major_k_tile_slices,
                    1,
                ),
                stride_order=(0, 1, 2, 3),
                swizzle=tma_swizzle,
                tma_format=tma_format_b,
            )
        elif cutlass.const_expr(cfg.use_tma_oob_opt_b):
            tma_b_desc = cuda.create_tensor_map_tiled_from_tensor(
                tensor=b_tensor,
                box_dims=(b_box_k, b_box_rows, 1, 1),
                stride_order=(0, 1, 2, 3),
                swizzle=tma_swizzle,
                tma_format=tma_format_b,
            )
        else:
            tma_b_desc = cuda.create_tensor_map_tiled_from_tensor(
                tensor=b_tensor,
                box_dims=(b_box_k, b_box_rows, 1),
                stride_order=(0, 1, 2),
                swizzle=tma_swizzle,
                tma_format=tma_format_b,
            )

    # SF TMA descriptors (only for FP4/FP8/CastA with scale factors).
    # E8M0 scale factors are packed 2 per uint16 for TMA transport.
    tma_sfa_desc = None
    tma_sfb_desc = None
    if cutlass.const_expr(cfg.has_scale_factor_a):
        sf_vec_size = cfg.sf_vec_size
        sf_tma_ptr_dtype = cutlass.Uint8
        # Each K-block = 4 SF atoms. dim0 = tile_mn * 4 / 2 (uint16 packing)
        k_atoms_per_block = 4
        rest_k_blocks = k // sf_vec_size // k_atoms_per_block
        rest_k_per_tile = cfg.tile_k // sf_vec_size // k_atoms_per_block

        sf_k_per_tile = cfg.tile_k // sf_vec_size  # SF elements per K-tile
        routed_sf_swizzle = _tma_swizzle_for_fastest_dim_bytes(sf_k_per_tile)

        # Folds expert L into the weight operand's outer row
        # extent. The no-route activation operand is already expanded/padded
        # by token row and does not use a separate expert dimension.
        sfa_outer_rows = m
        if cutlass.const_expr(cfg.is_swap_ab):
            sfa_outer_rows = m * num_experts_dim
        sfb_outer_rows = n
        if cutlass.const_expr(not cfg.is_swap_ab):
            sfb_outer_rows = n * num_experts_dim

        # SFA descriptor: routed TMA gather4 (2D linear) or regular tiled SF layout.
        # LDGSTS-routed SF bypasses TensorMap encoding and uses raw GMEM tensors.
        if cutlass.const_expr(uses_routed_sfa_tma_desc(cfg)):
            # 2D linear layout: (K/sf_vec_size, total_tokens) for gather4.
            # Pad sf_k to 16-byte alignment (TMA requirement).
            sf_k_total = ((k // sf_vec_size + 15) // 16) * 16
            sfa_2d_layout = cute.make_layout(
                (sf_k_total, m),
                stride=(1, sf_k_total),
            )
            sfa_tensor = cute.make_tensor(
                cute.recast_ptr(sfa_ptr, dtype=sf_tma_ptr_dtype), sfa_2d_layout
            )
            tma_sfa_desc = cuda.create_tensor_map_tiled_from_tensor(
                tensor=sfa_tensor,
                box_dims=(sf_k_per_tile, 1),
                stride_order=(0, 1),
                swizzle=routed_sf_swizzle,
                tma_format=cuda.TensorMapDataFormat.BYTE,
            )
        else:
            # Tiled SF layout. L is folded into the outer dimension for
            # weights and absent for expanded activations. Only the generated
            # split R128c4 descriptor remains rank-4; the legacy tiled
            # descriptor is rank-3.
            if cutlass.const_expr(
                cfg.use_tile256_tmem_overlap
                or cfg.is_mx_mma
                or cfg.has_cast_a
                or cfg.is_nvfp4_mma
            ):
                # Generated R128c4 SF TMA shape is [256, 2, K/(sfBlock*4), outer/128].
                # The split keeps the 512B scale-factor block TMA-legal and is
                # used for NVFP4 as well as MX/CastA paths.
                sfa_outer_tiles = (sfa_outer_rows + 127) // 128
                tma_sfa_desc = cuda.create_tensor_map_tiled(
                    global_address=sfa_ptr.toint(),
                    dtype=cutlass.Uint8,
                    tma_format=cuda.TensorMapDataFormat.BYTE,
                    global_dims=(
                        256,
                        2,
                        cute.assume(rest_k_blocks, 4),
                        sfa_outer_tiles,
                    ),
                    # create_tensor_map_tiled expects strides in 16-byte units.
                    global_strides=(
                        16,
                        32,
                        cute.assume(32 * rest_k_blocks, 32 * 4),
                    ),
                    box_dims=(256, 2, rest_k_per_tile, 1),
                    swizzle=cuda.TensorMapSwizzle.none,
                )
            else:
                sfa_dim0 = cfg.tile_m * k_atoms_per_block // 2
                sfa_rest_m = sfa_outer_rows // cfg.tile_m
                sfa_ptr_fp16 = cute.recast_ptr(sfa_ptr, dtype=cutlass.Float16)
                sfa_layout = cute.make_layout(
                    (
                        sfa_dim0,
                        cute.assume(rest_k_blocks, 4),
                        sfa_rest_m,
                    ),
                    stride=(
                        1,
                        sfa_dim0,
                        cute.assume(sfa_dim0 * rest_k_blocks, sfa_dim0 * 4),
                    ),
                )
                sfa_tensor_fp16 = cute.make_tensor(sfa_ptr_fp16, sfa_layout)
                tma_sfa_desc = cuda.create_tensor_map_tiled_from_tensor(
                    tensor=sfa_tensor_fp16,
                    box_dims=(sfa_dim0, rest_k_per_tile, 1),
                    stride_order=(0, 1, 2),
                    swizzle=cuda.TensorMapSwizzle.none,
                    tma_format=cuda.TensorMapDataFormat.DEFAULT,
                )

        # SFB descriptor: routed TMA gather4 (2D linear) or regular tiled SF layout.
        # LDGSTS-routed SF bypasses TensorMap encoding and uses raw GMEM tensors.
        if cutlass.const_expr(uses_routed_sfb_tma_desc(cfg)):
            # 2D linear layout: (K/sf_vec_size, total_tokens) for gather4
            sf_k_total = ((k // sf_vec_size + 15) // 16) * 16
            sfb_2d_layout = cute.make_layout(
                (sf_k_total, n),
                stride=(1, sf_k_total),
            )
            sfb_tensor = cute.make_tensor(
                cute.recast_ptr(sfb_ptr, dtype=sf_tma_ptr_dtype), sfb_2d_layout
            )
            tma_sfb_desc = cuda.create_tensor_map_tiled_from_tensor(
                tensor=sfb_tensor,
                box_dims=(sf_k_per_tile, 1),
                stride_order=(0, 1),
                swizzle=routed_sf_swizzle,
                tma_format=cuda.TensorMapDataFormat.BYTE,
            )
        else:
            # Tiled SF layout with the same folded-weight/no-L-activation
            # convention as SFA. Legacy tiled descriptors are rank-3.
            if cutlass.const_expr(cfg.use_tile256_tmem_overlap):
                sfb_outer_tiles = (sfb_outer_rows + 127) // 128
                sfb_tile_outer = (cfg.tile_n + 127) // 128
                sfb_layout = cute.make_layout(
                    (256, 2, cute.assume(rest_k_blocks, 4), sfb_outer_tiles),
                    stride=(
                        1,
                        256,
                        512,
                        cute.assume(512 * rest_k_blocks, 512 * 4),
                    ),
                )
                sfb_tensor = cute.make_tensor(
                    cute.recast_ptr(sfb_ptr, dtype=sf_tma_ptr_dtype),
                    sfb_layout,
                )
                tma_sfb_desc = cuda.create_tensor_map_tiled_from_tensor(
                    tensor=sfb_tensor,
                    box_dims=(256, 2, rest_k_per_tile, sfb_tile_outer),
                    stride_order=(0, 1, 2, 3),
                    swizzle=cuda.TensorMapSwizzle.none,
                    tma_format=cuda.TensorMapDataFormat.BYTE,
                )
            elif cutlass.const_expr(cfg.uses_sfb_8x4_load):
                sfb_outer_tiles = (sfb_outer_rows + 7) // 8
                sfb_outer_per_tile = (cfg.tile_n + 7) // 8
                sfb_layout = cute.make_layout(
                    (
                        32,
                        cute.assume(rest_k_blocks, 4),
                        sfb_outer_tiles,
                    ),
                    stride=(
                        1,
                        32,
                        cute.assume(32 * rest_k_blocks, 32 * 4),
                    ),
                )
                sfb_tensor = cute.make_tensor(
                    cute.recast_ptr(sfb_ptr, dtype=sf_tma_ptr_dtype),
                    sfb_layout,
                )
                tma_sfb_desc = cuda.create_tensor_map_tiled_from_tensor(
                    tensor=sfb_tensor,
                    box_dims=(32, rest_k_per_tile, sfb_outer_per_tile),
                    stride_order=(0, 1, 2),
                    swizzle=cuda.TensorMapSwizzle.none,
                    tma_format=cuda.TensorMapDataFormat.BYTE,
                )
            elif cutlass.const_expr(
                (cfg.is_mx_mma or cfg.has_cast_a)
                and cfg.smem_sfb_layout == int(SfLayout.R128c4)
            ):
                sfb_outer_tiles = (sfb_outer_rows + 127) // 128
                sfb_tile_outer = (cfg.tile_n + 127) // 128
                sfb_layout = cute.make_layout(
                    (256, 2, cute.assume(rest_k_blocks, 4), sfb_outer_tiles),
                    stride=(
                        1,
                        256,
                        512,
                        cute.assume(512 * rest_k_blocks, 512 * 4),
                    ),
                )
                sfb_tensor = cute.make_tensor(
                    cute.recast_ptr(sfb_ptr, dtype=sf_tma_ptr_dtype),
                    sfb_layout,
                )
                tma_sfb_desc = cuda.create_tensor_map_tiled_from_tensor(
                    tensor=sfb_tensor,
                    box_dims=(256, 2, rest_k_per_tile, sfb_tile_outer),
                    stride_order=(0, 1, 2, 3),
                    swizzle=cuda.TensorMapSwizzle.none,
                    tma_format=cuda.TensorMapDataFormat.BYTE,
                )
            else:
                sfb_dim0 = cfg.tile_n * k_atoms_per_block // 2
                sfb_rest_n = sfb_outer_rows // cfg.tile_n
                sfb_ptr_fp16 = cute.recast_ptr(sfb_ptr, dtype=cutlass.Float16)
                sfb_layout = cute.make_layout(
                    (
                        sfb_dim0,
                        cute.assume(rest_k_blocks, 4),
                        sfb_rest_n,
                    ),
                    stride=(
                        1,
                        sfb_dim0,
                        cute.assume(sfb_dim0 * rest_k_blocks, sfb_dim0 * 4),
                    ),
                )
                sfb_tensor_fp16 = cute.make_tensor(sfb_ptr_fp16, sfb_layout)
                tma_sfb_desc = cuda.create_tensor_map_tiled_from_tensor(
                    tensor=sfb_tensor_fp16,
                    box_dims=(sfb_dim0, rest_k_per_tile, 1),
                    stride_order=(0, 1, 2),
                    swizzle=cuda.TensorMapSwizzle.none,
                    tma_format=cuda.TensorMapDataFormat.DEFAULT,
                )

    # Grid and tile scheduler
    num_tiles_m = (m + cfg.tile_m - 1) // cfg.tile_m
    num_tiles_n = (n + cfg.tile_n - 1) // cfg.tile_n
    launch_num_tiles_m = num_tiles_m
    launch_num_tiles_n = num_tiles_n
    if cutlass.const_expr(cfg.use_early_exit):
        if cutlass.const_expr(cfg.is_swap_ab):
            launch_num_tiles_n = early_exit_max_token_ctas
        else:
            launch_num_tiles_m = early_exit_max_token_ctas
    block = cfg.threads_per_cta
    cluster_shape = (cfg.cluster_m, 1, 1)

    if cutlass.const_expr(cfg.is_persistent):
        clc_raster_along_m = True
        tile_sched_params = utils.ClcDynamicPersistentTileSchedulerParams(
            (launch_num_tiles_m, launch_num_tiles_n, 1),
            cluster_shape,
            1,
            clc_raster_along_m,
        )
        grid = utils.ClcDynamicPersistentTileScheduler.get_grid_shape(tile_sched_params)
    else:
        # Non-persistent: launch one CTA per logical output tile.
        tile_sched_params = utils.PersistentTileSchedulerParams(
            (launch_num_tiles_m, launch_num_tiles_n, 1),
            cluster_shape,
        )
        grid = (launch_num_tiles_m, launch_num_tiles_n, 1)

    # C output tensor
    output_m_for_c = m
    if cutlass.const_expr(cfg.is_swap_ab and cfg.has_gated_epilogue):
        output_m_for_c = m // Int32(2)
    if cutlass.const_expr(cfg.is_swap_ab):
        # SwapAB: C is (M, N) in M-major (column-major) layout.
        # M = hidden dim (stride-1), N = tokens (stride-M).
        if cutlass.const_expr(cfg.use_tma_store and cfg.use_tma_oob_opt):
            if cutlass.const_expr(cfg.has_epilogue_quant):
                c_layout = cute.make_layout(
                    (
                        cute.assume(output_m_for_c, 32),
                        cfg.tile_n,
                        TMA_DIM_MAX,
                        TMA_DIM_MAX,
                    ),
                    stride=(
                        1,
                        cute.assume(output_m_for_c, 32),
                        TMA_XLARGE_N - output_m_for_c,
                        cute.assume(output_m_for_c, 32),
                    ),
                )
            else:
                c_layout = cute.make_layout(
                    (
                        cute.assume(output_m_for_c, 32),
                        cfg.tile_n,
                        TMA_DIM_MAX,
                        TMA_DIM_MAX,
                    ),
                    stride=(
                        1,
                        cute.assume(output_m_for_c, 32),
                        TMA_XLARGE_N - output_m_for_c,
                        cute.assume(output_m_for_c, 32),
                    ),
                )
        else:
            c_layout = cute.make_layout(
                (cute.assume(output_m_for_c, 32), cute.assume(n, 16)),
                stride=(1, cute.assume(output_m_for_c, 32)),
            )
    else:
        # Non-swapAB: C is (M, N) row-major.
        c_layout = cute.make_layout(
            (cute.assume(m, 32), cute.assume(n, 16)),
            stride=(cute.assume(n, 16), 1),
        )
    if cutlass.const_expr(cfg.has_epilogue_quant or cfg.uses_fp8_output):
        c_quant_dtype = (
            cutlass.Float8E4M3FN
            if cfg.uses_mxfp8_output_quant or cfg.uses_fp8_output
            else cutlass.Float4E2M1FN
        )
        c_tensor = cute.make_tensor(
            cute.recast_ptr(c_raw_ptr, dtype=c_quant_dtype),
            c_layout,
        )
    else:
        c_tensor = cute.make_tensor(c_raw_ptr, c_layout)
    if cutlass.const_expr(cfg.is_swap_ab and cfg.use_tma_store):
        tma_store_cols = cfg.epi_tile_n
    else:
        tma_store_cols = min(16, max(8, cfg.tile_n))
    if cutlass.const_expr(cfg.has_epilogue_quant):
        if cutlass.const_expr(cfg.use_tma_store):
            if cutlass.const_expr(cfg.uses_mxfp8_output_quant):
                tma_c_swizzle = cuda.TensorMapSwizzle.s64b
                tma_c_format = cuda.TensorMapDataFormat.BYTE
            else:
                tma_c_swizzle = cuda.TensorMapSwizzle.s32b
                tma_c_format = cuda.TensorMapDataFormat.B4X16
            if cutlass.const_expr(cfg.use_tma_oob_opt):
                tma_c_desc = cuda.create_tensor_map_tiled_from_tensor(
                    tensor=c_tensor,
                    box_dims=(cfg.tile_m // 2, cfg.epi_tile_n, 1, 1),
                    stride_order=(0, 1, 2, 3),
                    swizzle=tma_c_swizzle,
                    tma_format=tma_c_format,
                )
            else:
                tma_c_desc = cuda.create_tensor_map_tiled_from_tensor(
                    tensor=c_tensor,
                    box_dims=(cfg.tile_m // 2, cfg.epi_tile_n),
                    stride_order=(0, 1),
                    swizzle=tma_c_swizzle,
                    tma_format=tma_c_format,
                )
        else:
            # Quantized FC1 may use direct packed STG for C; keep a dummy
            # descriptor so the common kernel signature stays stable.
            tma_c_desc = tma_a_desc
    else:
        if cutlass.const_expr(cfg.is_swap_ab and cfg.use_tma_store):
            if cutlass.const_expr(cfg.uses_fp8_output):
                tma_c_format = cuda.TensorMapDataFormat.BYTE
                tma_c_swizzle = cuda.TensorMapSwizzle.s64b
            else:
                tma_c_format = cuda.TensorMapDataFormat.DEFAULT
                tma_c_swizzle = cuda.TensorMapSwizzle.s128b
            if cutlass.const_expr(cfg.use_tma_oob_opt):
                tma_c_desc = cuda.create_tensor_map_tiled_from_tensor(
                    tensor=c_tensor,
                    box_dims=(64, tma_store_cols, 1, 1),
                    stride_order=(0, 1, 2, 3),
                    swizzle=tma_c_swizzle,
                    tma_format=tma_c_format,
                )
            else:
                tma_c_desc = cuda.create_tensor_map_tiled_from_tensor(
                    tensor=c_tensor,
                    box_dims=(64, tma_store_cols),
                    stride_order=(0, 1),
                    swizzle=tma_c_swizzle,
                    tma_format=tma_c_format,
                )
        else:
            if cutlass.const_expr(cfg.uses_fp8_output):
                tma_c_format = cuda.TensorMapDataFormat.BYTE
            else:
                tma_c_format = cuda.TensorMapDataFormat.DEFAULT
            tma_c_desc = cuda.create_tensor_map_tiled_from_tensor(
                tensor=c_tensor,
                box_dims=(cfg.tile_m, tma_store_cols),
                stride_order=(1, 0),
                swizzle=cuda.TensorMapSwizzle.none,
                tma_format=tma_c_format,
            )

    output_m_for_sf = m
    if cutlass.const_expr(cfg.is_swap_ab and cfg.has_gated_epilogue):
        output_m_for_sf = m // Int32(2)
    if cutlass.const_expr(cfg.has_epilogue_quant):
        sf_block_m = Int32(cfg.output_sf_block_size_c)
        sf_group_m = sf_block_m * Int32(4)
        if cutlass.const_expr(cfg.sf_layout_c == int(SfLayout.R8c4)):
            sf_c_elems = ((n + Int32(7)) // Int32(8)) * (
                ((output_m_for_sf + sf_group_m - Int32(1)) // sf_group_m) * Int32(32)
            )
        else:
            sf_c_elems = ((n + Int32(127)) // Int32(128)) * (
                ((output_m_for_sf + sf_group_m - Int32(1)) // sf_group_m) * Int32(512)
            )
        sf_c_layout = cute.make_layout((sf_c_elems,), stride=(1,))
    elif cutlass.const_expr(cfg.has_deepseek_fp8_c_scale):
        if cutlass.const_expr(cfg.is_swap_ab):
            sf_c_elems = ((output_m_for_sf + Int32(127)) // Int32(128)) * n
        else:
            sf_c_elems = ((n + Int32(127)) // Int32(128)) * output_m_for_sf
        sf_c_layout = cute.make_layout((sf_c_elems,), stride=(1,))
    else:
        sf_c_layout = cute.make_layout((1,), stride=(1,))
    sf_c_tensor = cute.make_tensor(
        cute.recast_ptr(
            sf_c_raw_ptr,
            dtype=(
                cutlass.Float32
                if cfg.has_deepseek_fp8_c_scale
                else (
                    cutlass.Float8E8M0FNU
                    if cfg.uses_mx_output_quant
                    else cutlass.Float8E4M3FN
                )
            ),
        ),
        sf_c_layout,
    )

    bias_layout = cute.make_layout(
        (cute.assume(m, 32), num_experts_dim),
        stride=(1, cute.assume(m, 32)),
    )
    bias_tensor = cute.make_tensor(bias_raw_ptr, bias_layout)

    global_scale_layout = cute.make_layout((num_experts_dim,), stride=(1,))
    scale_c_tensor = cute.make_tensor(scale_c_raw_ptr, global_scale_layout)
    scale_gate_tensor = cute.make_tensor(scale_gate_raw_ptr, global_scale_layout)
    gemm1_alpha_tensor = cute.make_tensor(gemm1_alpha_raw_ptr, global_scale_layout)
    gemm1_beta_tensor = cute.make_tensor(gemm1_beta_raw_ptr, global_scale_layout)
    gemm1_clamp_limit_tensor = cute.make_tensor(
        gemm1_clamp_limit_raw_ptr,
        global_scale_layout,
    )

    if cutlass.const_expr(cfg.per_token_sf_dtype == int(DType.BF16)):
        per_token_sf_dtype = cutlass.BFloat16
    elif cutlass.const_expr(cfg.per_token_sf_dtype == int(DType.FP16)):
        per_token_sf_dtype = cutlass.Float16
    else:
        per_token_sf_dtype = cutlass.Float32
    per_token_sf_layout = cute.make_layout((max(m, n),), stride=(1,))
    per_token_sf_a_tensor = cute.make_tensor(
        cute.recast_ptr(per_token_sf_a_ptr, dtype=per_token_sf_dtype),
        per_token_sf_layout,
    )
    per_token_sf_b_tensor = cute.make_tensor(
        cute.recast_ptr(per_token_sf_b_ptr, dtype=per_token_sf_dtype),
        per_token_sf_layout,
    )

    # tile_idx and mn_limit: indexed by the TOKEN dimension tiles.
    # non-swapAB: tokens = M → num_tiles_m.  swapAB: tokens = N → num_tiles_n.
    if cutlass.const_expr(cfg.is_swap_ab):
        num_token_tiles = num_tiles_n
    else:
        num_token_tiles = num_tiles_m
    tile_idx_layout = cute.make_layout((num_token_tiles,), stride=(1,))
    tile_idx_tensor = cute.make_tensor(tile_idx_raw_ptr, tile_idx_layout)

    # Route map (gather only; dummy 1-element when off)
    if cutlass.const_expr(cfg.has_routed_act):
        num_total_tokens = n if cutlass.const_expr(cfg.is_swap_ab) else m
        route_map_layout = cute.make_layout((num_total_tokens,), stride=(1,))
    else:
        route_map_layout = cute.make_layout((1,), stride=(1,))
    route_map_tensor = cute.make_tensor(route_map_raw_ptr, route_map_layout)

    # mn_limit: TRT-LLM Gen absolute end-row limit per token tile.
    mn_limit_layout = cute.make_layout((num_token_tiles,), stride=(1,))
    mn_limit_tensor = cute.make_tensor(mn_limit_raw_ptr, mn_limit_layout)
    num_non_exiting_ctas_tensor = cute.make_tensor(
        num_non_exiting_ctas_raw_ptr, cute.make_layout((1,), stride=(1,))
    )
    total_num_padded_tokens_tensor = cute.make_tensor(
        total_num_padded_tokens_raw_ptr, cute.make_layout((1,), stride=(1,))
    )
    # Activation tensor for gather: flat (total_elems,) view
    act_layout = cute.make_layout((1,), stride=(1,))
    act_tensor = cute.make_tensor(
        cute.recast_ptr(act_raw_ptr, dtype=cutlass.Uint8), act_layout
    )

    # SF TMA descriptors: real only for operands that have scale factors.
    if cutlass.const_expr(not cfg.has_scale_factor_a):
        tma_sfa_desc = tma_a_desc  # dummy, never accessed
    if cutlass.const_expr(not cfg.has_scale_factor_b):
        tma_sfb_desc = tma_b_desc  # dummy, never accessed

    # SF GMEM tensors for LDGSTS SF loading.
    if cutlass.const_expr(cfg.has_deepseek_fp8):
        # DeepSeek FP8 uses FP32 per-K dequant scales;
        # routed MX/NVFP4 uses packed E4M3/E8M0 bytes.
        ds_k_blocks = (k + Int32(cfg.tile_k - 1)) // Int32(cfg.tile_k)
        ds_weight_tiles = (
            (m + Int32(cfg.tile_m - 1)) // Int32(cfg.tile_m)
            if cfg.is_swap_ab
            else (n + Int32(cfg.tile_n - 1)) // Int32(cfg.tile_n)
        )
        if cutlass.const_expr(cfg.has_routed_act):
            ds_act_rows = num_tokens
        else:
            ds_act_rows = n if cfg.is_swap_ab else m
        sfa_gmem_layout = cute.make_layout(
            (num_experts_dim * ds_weight_tiles * ds_k_blocks,),
            stride=(1,),
        )
        sfb_gmem_layout = cute.make_layout((ds_act_rows * ds_k_blocks,), stride=(1,))
        sfa_gmem_tensor = cute.make_tensor(
            cute.recast_ptr(sfa_ptr, dtype=cutlass.Float32), sfa_gmem_layout
        )
        sfb_gmem_tensor = cute.make_tensor(
            cute.recast_ptr(sfb_ptr, dtype=cutlass.Float32), sfb_gmem_layout
        )
    elif cutlass.const_expr(cfg.has_routed_sfs and cfg.uses_ldgsts_routed_sfs):
        # (flat 1D E4M3 view)
        sf_dtype = (
            cutlass.Float8E8M0FNU if cfg.uses_mx_scale_factors else cutlass.Float8E4M3FN
        )
        sfa_gmem_layout = cute.make_layout((m * (k // cfg.sf_vec_size),), stride=(1,))
        sfb_gmem_layout = cute.make_layout((n * (k // cfg.sf_vec_size),), stride=(1,))
        sfa_gmem_tensor = cute.make_tensor(
            cute.recast_ptr(sfa_ptr, dtype=sf_dtype), sfa_gmem_layout
        )
        sfb_gmem_tensor = cute.make_tensor(
            cute.recast_ptr(sfb_ptr, dtype=sf_dtype), sfb_gmem_layout
        )
    else:
        # Dummy 1-element tensors (never accessed)
        sfa_gmem_tensor = cute.make_tensor(
            cute.recast_ptr(a_ptr, dtype=cutlass.Float8E4M3FN),
            cute.make_layout((1,), stride=(1,)),
        )
        sfb_gmem_tensor = cute.make_tensor(
            cute.recast_ptr(b_ptr, dtype=cutlass.Float8E4M3FN),
            cute.make_layout((1,), stride=(1,)),
        )

    return (
        tma_a_desc,
        tma_b_desc,
        tma_c_desc,
        tma_sfa_desc,
        tma_sfb_desc,
        c_tensor,
        sf_c_tensor,
        bias_tensor,
        scale_c_tensor,
        scale_gate_tensor,
        gemm1_alpha_tensor,
        gemm1_beta_tensor,
        gemm1_clamp_limit_tensor,
        per_token_sf_a_tensor,
        per_token_sf_b_tensor,
        tile_idx_tensor,
        route_map_tensor,
        mn_limit_tensor,
        num_non_exiting_ctas_tensor,
        total_num_padded_tokens_tensor,
        act_tensor,
        sfa_gmem_tensor,
        sfb_gmem_tensor,
        m,
        n,
        k,
        num_tokens,
        num_experts_dim,
        tile_sched_params,
        cfg,
        early_exit_max_token_ctas,
    )
