"""Frozen, bounded one-expert native exact gate. No timing or service calls."""
import os,json,hashlib
from pathlib import Path
OUT=Path(__file__).resolve().parent
os.environ.update(CUTE_DSL_ARCH='sm_103a',CUTE_DSL_KEEP='ptx,cubin',CUTE_DSL_DUMP_DIR=str(OUT/'chain-gpu-compile'))
(OUT/'chain-gpu-compile').mkdir(exist_ok=True)
import chain_common as c
import validate_chain
CPU_CUBIN=json.loads((OUT/'chain-aot-result.json').read_text())['cubin_sha256']
def build(data,debug_boundaries=True):
 candidate=c.build_chain(data,debug_boundaries)
 bins=list((OUT/'chain-gpu-compile').glob('*.cubin'))
 assert len(bins)==1
 actual=hashlib.sha256(bins[0].read_bytes()).hexdigest()
 assert actual==CPU_CUBIN,('CPU/GPU compiler mismatch',actual,CPU_CUBIN)
 return candidate
if __name__=='__main__':
 expected='GPU-bc643dc2-a0d1-5ed6-5ecb-0605ca9f340a'
 assert os.environ.get('CUDA_VISIBLE_DEVICES')==expected
 result=validate_chain.run_single(build,OUT/'single-gate',OUT/'chain-frozen-inputs.json',expected)
 result['cpu_gpu_cubin_sha256']=CPU_CUBIN
 (OUT/'single-gate/result.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({'status':result['status'],'checks':len(result['checks']),'passed':result['passed']}))
