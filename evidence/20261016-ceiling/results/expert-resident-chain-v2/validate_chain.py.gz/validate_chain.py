"""Coordinator-callable exact resident-chain harness. Default CLI is CPU-only.

Candidate ABI: build_chain(data, debug_boundaries=True) returns an object with
launch(CUstream), outputs, immutable_tensors and owned_tensors. owned_tensors only
keeps storage alive; it is never silently treated as immutable. No GPU launch is
performed by importing this module. GPU execution belongs to the coordinator.
"""
import json
import subprocess
import traceback
from pathlib import Path

import torch
import validation_contract as contract

OUT = Path(__file__).resolve().parent

class Recorder:
    def __init__(self, directory):
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)
        self.report = {'status': 'PREPARING', 'passed': False, 'checks': [],
                       'timings_allowed': False, 'cases': []}
        self.flush()

    def flush(self):
        (self.directory / 'result.json').write_text(json.dumps(self.report, indent=2) + '\n')

    def exact(self, name, actual, expected):
        a, b = actual.detach().cpu().contiguous(), expected.detach().cpu().contiguous()
        ok = contract.tensor_bytes_equal(a, b)
        row = {'name': name, 'exact': ok, 'shape': list(a.shape), 'dtype': str(a.dtype)}
        if not ok:
            torch.save({'actual': a, 'expected': b}, self.directory / (name.replace('/', '_') + '-mismatch.pt'))
            if a.shape == b.shape and a.dtype == b.dtype:
                row['changed_bytes'] = int((a.view(torch.uint8) != b.view(torch.uint8)).sum())
        self.report['checks'].append(row)
        self.flush()
        if not ok:
            raise AssertionError(name)

    def require(self, name, value, detail=None):
        self.report['checks'].append({'name': name, 'exact': bool(value), 'detail': detail})
        self.flush()
        if not value:
            raise AssertionError(name)


def _preflight(rec, manifest, expected_gpu_uuid):
    frozen = json.loads(Path(manifest).read_text())
    rec.require('frozen_hashes', all(contract.sha(path) == digest for path, digest in frozen.items()))
    sha = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=contract.SOURCE, text=True).strip()
    dirty = subprocess.check_output(['git', 'status', '--porcelain'], cwd=contract.SOURCE, text=True)
    rec.require('source_frozen', sha == contract.SOURCE_SHA and not dirty)
    props = torch.cuda.get_device_properties(0)
    rec.require('assigned_gpu', str(props.uuid).removeprefix('GPU-') == expected_gpu_uuid.removeprefix('GPU-'))
    rec.report.update(source_sha=sha, gpu_uuid=str(props.uuid), device_name=props.name)
    rec.flush()


def _stream():
    import cuda.bindings.driver as cuda_drv
    return cuda_drv.CUstream(torch.cuda.current_stream().cuda_stream)


def _to_device(data):
    return {key: value.to('cuda') if isinstance(value, torch.Tensor) else value
            for key, value in data.items()}


def _immutable(candidate, payload):
    assert hasattr(candidate, 'owned_tensors') and candidate.owned_tensors is not None
    assert isinstance(candidate.immutable_tensors, dict)
    immutable = {f'input/{key}': value for key, value in payload.items() if isinstance(value, torch.Tensor)}
    immutable.update({f'private/{key}': value for key, value in candidate.immutable_tensors.items()})
    assert all(isinstance(value, torch.Tensor) for value in immutable.values())
    contract.require_disjoint_outputs(candidate.outputs, immutable)
    return immutable


def native_finalize(fc2, weights, mapping, padded, output=None):
    """Original installed finalizer; no Python/Triton replacement or partial sum.

    Exact ABI copied from FI prims_ts/moe/runner.py:2383-2397 (DeepSeek FP8 path).
    Uses original route weights and expanded top8 ordering, PDL disabled only
    because this is an isolated correctness invocation.
    """
    from flashinfer.fused_moe import core as fi
    if output is None:
        output = torch.empty((64, 2048), dtype=torch.bfloat16, device=fc2.device)
    fi.get_trtllm_moe_sm100_module().trtllm_moe_run_finalize(
        fc2, output, weights, mapping, padded, 64, 256, 8, 2048, False, False)
    return output


def _single_hybrid_finalize(d, selected, branch_output):
    md = contract.metadata(d)
    fc2 = torch.zeros((contract.CAP, 2048), dtype=torch.bfloat16, device='cuda')
    mapping = md['mapping'].to(device='cuda', dtype=torch.int32)
    fc2[mapping.long()] = d['intermediates']['fc2_bf16'].to('cuda')
    if selected.numel():
        fc2[mapping[selected.to('cuda')].long()] = branch_output[:len(selected)]
    output = native_finalize(fc2, d['weights'].to('cuda'), mapping, md['padded'].to('cuda'))
    torch.cuda.synchronize()
    return output


@torch.inference_mode()
def run_single(build_chain, directory, manifest, expected_gpu_uuid,
               oracle_path=contract.ORACLE_DIR / 'oracle-layer0-real.pt', expert=205,
               valid_counts=(8, 7, 6, 5, 4, 3, 2, 1, 0)):
    """First real eight-route gate, then partial0..7; no timing, no fallback.

    The finalizer check is explicitly oracle-assisted: only tested branches
    replace native branches; this never claims that all256experts ran candidate.
    """
    rec = Recorder(directory)
    rec.report['scope'] = 'single_expert_chain_plus_oracle_assisted_native_finalizer'
    try:
        _preflight(rec, manifest, expected_gpu_uuid)
        d = contract.load_oracle(oracle_path)
        weights = contract.single_weights(d['layer'], expert)
        rng = torch.cuda.get_rng_state().clone()
        for count in valid_counts:
            cpu, expected, selected = contract.single_fixture(d, expert=expert, valid_rows=count, weights=weights)
            data = _to_device(cpu)
            before_build = {key: value.clone() for key, value in data.items() if isinstance(value, torch.Tensor)}
            candidate = build_chain(data, debug_boundaries=True)
            immutable = _immutable(candidate, data)
            for key, value in before_build.items():
                rec.exact(f'B{count}/build_untouched/{key}', data[key], value)
            before = {key: value.clone() for key, value in immutable.items()}
            contract.initialize_outputs(candidate.outputs)
            candidate.launch(_stream())
            torch.cuda.synchronize()
            for key in contract.BOUNDARIES:
                rec.exact(f'B{count}/eager/{key}', candidate.outputs[key], expected[key])
            for key, value in before.items():
                rec.exact(f'B{count}/eager_untouched/{key}', immutable[key], value)
            rec.exact(f'B{count}/eager_rng', torch.cuda.get_rng_state(), rng)
            rec.exact(f'B{count}/oracle_assisted_native_finalizer',
                      _single_hybrid_finalize(d, selected, candidate.outputs['fc2']), d['routed'])
            # Capture after eager exact. Debug boundaries must have independent
            # lifetime; no scratch reuse can hide a prior stage's mismatch.
            graph = torch.cuda.CUDAGraph()
            with torch.cuda.graph(graph):
                candidate.launch(_stream())
            contract.initialize_outputs(candidate.outputs)
            graph.replay()
            torch.cuda.synchronize()
            for key in contract.BOUNDARIES:
                rec.exact(f'B{count}/graph/{key}', candidate.outputs[key], expected[key])
            for key, value in before.items():
                rec.exact(f'B{count}/graph_untouched/{key}', immutable[key], value)
            rec.exact(f'B{count}/graph_rng', torch.cuda.get_rng_state(), rng)
            rec.exact(f'B{count}/graph_oracle_assisted_native_finalizer',
                      _single_hybrid_finalize(d, selected, candidate.outputs['fc2']), d['routed'])
            rec.report['cases'].append({'valid_rows': count, 'expanded': selected.tolist()})
            rec.flush()
            del graph, candidate, before, immutable, before_build, data
        rec.report.update(status='SINGLE_CHAIN_EXACT_PASS', passed=True)
    except BaseException as exc:
        rec.report.update(status='EXACT_FAIL', error=repr(exc), traceback=traceback.format_exc())
        raise
    finally:
        rec.flush()
    return rec.report


def check_full_boundaries(rec, name, outputs, d):
    """All-route debug ABI: rowsCAP, scale buffers flat with runtime padded stride."""
    md = contract.metadata(d)
    mapping, valid = md['mapping'], md['valid']
    padded = int(md['padded'])
    for key, (_, dtype, sentinel) in contract.BOUNDARIES.items():
        value = outputs[key].detach().cpu()
        blocks = 8 if key == 'fc1_sf' else 4
        if key.endswith('_sf'):
            assert value.shape == (blocks * contract.CAP,) and value.dtype == dtype
            active = value[:blocks * padded].reshape(blocks, padded)
            rec.exact(name + '/' + key, active.T[mapping], d['intermediates'][contract.ORACLE_KEYS[key]])
            rec.exact(name + '/' + key + '_padding', active[:, ~valid[:padded]],
                      torch.full_like(active[:, ~valid[:padded]], sentinel))
            rec.exact(name + '/' + key + '_tail', value[blocks * padded:],
                      torch.full_like(value[blocks * padded:], sentinel))
        else:
            width = contract.BOUNDARIES[key][0][1]
            assert value.shape == (contract.CAP, width) and value.dtype == dtype
            rec.exact(name + '/' + key, value[mapping], d['intermediates'][contract.ORACLE_KEYS[key]])
            rec.exact(name + '/' + key + '_padding_tail', value[~valid],
                      torch.full_like(value[~valid], sentinel))



def _full_payload(d, weights):
    md = contract.metadata(d)
    payload = dict(q=d['q'], input_sf=d['input_scale'], ids=d['ids'],
                   route_weights=d['weights'], **weights, **md)
    payload['mapping'] = md['mapping'].to(torch.int32)
    required_weights = {'w1': ((256, 1024, 2048), torch.float8_e4m3fn),
                        'sf1': ((256, 8, 16), torch.float32),
                        'w2': ((256, 2048, 512), torch.float8_e4m3fn),
                        'sf2': ((256, 16, 4), torch.float32)}
    for name, (shape, dtype) in required_weights.items():
        assert tuple(payload[name].shape) == shape and payload[name].dtype == dtype
    return _to_device(payload)


def _initialize_full(outputs):
    assert set(outputs) == set(contract.BOUNDARIES)
    for key, (shape, dtype, sentinel) in contract.BOUNDARIES.items():
        expected = (shape[0] * contract.CAP,) if key.endswith('_sf') else (contract.CAP, shape[1])
        assert tuple(outputs[key].shape) == expected and outputs[key].dtype == dtype
        outputs[key].fill_(sentinel)


@torch.inference_mode()
def run_full(build_full_chain, load_weights, directory, manifest, expected_gpu_uuid):
    """Future full-routing candidate ABI; only coordinator may invoke on GPU.

    build_full_chain receives fixed-address payload tensors. The same graph sees
    allfive changing routing distributions perlayer. load_weights(layer) returns
    the four original unmodified w1/sf1/w2/sf2 tensors for all256experts.
    """
    rec = Recorder(directory)
    rec.report['scope'] = 'full256experts_all15nativeoracles_plus_original_finalizer'
    try:
        _preflight(rec, manifest, expected_gpu_uuid)
        rng = torch.cuda.get_rng_state().clone()
        for layer in (0, 19, 39):
            paths = sorted(contract.ORACLE_DIR.glob(f'oracle-layer{layer}-*.pt'))
            rec.require(f'L{layer}/five_oracles', len(paths) == 5)
            datasets = [contract.load_oracle(path) for path in paths]
            weights = load_weights(layer)
            data = _full_payload(datasets[0], weights)
            before_build = {key: value.clone() for key, value in data.items()}
            candidate = build_full_chain(data, debug_boundaries=True)
            for key, value in before_build.items():
                rec.exact(f'L{layer}/build_untouched/{key}', data[key], value)
            immutable = _immutable(candidate, data)
            graph = None
            routed = torch.empty((64, 2048), dtype=torch.bfloat16, device='cuda')
            for d in datasets:
                name = f"L{layer}/{d['scenario']}"
                md = contract.metadata(d)
                updates = dict(q=d['q'], input_sf=d['input_scale'], ids=d['ids'],
                               route_weights=d['weights'], **md)
                updates['mapping'] = md['mapping'].to(torch.int32)
                for key, value in updates.items():
                    data[key].copy_(value)
                before = {key: value.clone() for key, value in immutable.items()}
                _initialize_full(candidate.outputs)
                candidate.launch(_stream())
                torch.cuda.synchronize()
                check_full_boundaries(rec, name + '/eager', candidate.outputs, d)
                native_finalize(candidate.outputs['fc2'], data['route_weights'],
                                data['mapping'], data['padded'], routed)
                torch.cuda.synchronize()
                rec.exact(name + '/eager_native_finalizer', routed, d['routed'])
                for key, value in before.items():
                    rec.exact(name + '/eager_untouched/' + key, immutable[key], value)
                rec.exact(name + '/eager_rng', torch.cuda.get_rng_state(), rng)
                if graph is None:
                    graph = torch.cuda.CUDAGraph()
                    with torch.cuda.graph(graph):
                        candidate.launch(_stream())
                        native_finalize(candidate.outputs['fc2'], data['route_weights'],
                                        data['mapping'], data['padded'], routed)
                _initialize_full(candidate.outputs)
                routed.fill_(-29.)
                graph.replay()
                torch.cuda.synchronize()
                check_full_boundaries(rec, name + '/graph', candidate.outputs, d)
                rec.exact(name + '/graph_native_finalizer', routed, d['routed'])
                for key, value in before.items():
                    rec.exact(name + '/graph_untouched/' + key, immutable[key], value)
                rec.exact(name + '/graph_rng', torch.cuda.get_rng_state(), rng)
                rec.report['cases'].append(name)
                rec.flush()
            del graph, candidate, before, before_build, immutable, data, weights, routed
        rec.report.update(status='FULL_CHAIN_EXACT_PASS', passed=True)
    except BaseException as exc:
        rec.report.update(status='EXACT_FAIL', error=repr(exc), traceback=traceback.format_exc())
        raise
    finally:
        rec.flush()
    return rec.report

def cpu_check(directory=OUT / 'cpu-contract'):
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    result = contract.cpu_contract()
    result['validation_contract_sha256'] = contract.sha(Path(contract.__file__))
    result['validate_chain_sha256'] = contract.sha(Path(__file__))
    (directory / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    return result


if __name__ == '__main__':
    # Intentionally no command-line GPU mode: vllm_scaling owns the single
    # chain launch protocol and must supply its frozen candidate callable.
    result = cpu_check()
    print(json.dumps({'status': result['status'], 'oracles': len(result['cases']),
                      'partial_cases': len(result['single_expert_fixtures']),
                      'cuda_initialized': result['cuda_initialized']}, indent=2))
