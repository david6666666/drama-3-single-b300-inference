"""Bounded one-expert native resident chain; explicit immutable inputs/lifetimes."""
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT/'expert-fc1-native-v3'))
import common as fc1_common
import torch
import cutlass.cute as cute
import cuda.bindings.driver as cuda_drv
from flashinfer.prims_ts.moe.config_mapper import map_trtllm_deepseek_fp8_moe_tactic
from flashinfer.prims_ts.batched_gemm.batched_gemm_config import make_config,TileScheduler
from flashinfer.prims_ts.batched_gemm.batched_gemm_run import _compile_arg_tuple, _launch_arg_tuple
from flashinfer.prims_ts.moe.tensor_adapter import build_fp8_block_scale_launch_io
from flashinfer.prims_ts.cutlass_dsl import task_scheduling_scope
from cutlass.cutlass_dsl import BaseDSL
from flashinfer.tllm_enums import Fp8QuantizationType,ActivationType
from resident_chain_host import resident_chain_host

def configs():
 pair=map_trtllm_deepseek_fp8_moe_tactic((8,5),num_tokens=64,top_k=8,num_local_experts=256,enable_pdl=False,weight_layout=0)
 result=[]
 for original in (pair.fc1.cfg.kwargs,pair.fc2.cfg.kwargs):
  d=dict(original)
  d.update({k:4 for k in ('num_stages_a','num_stages_b','num_stages_smem_sfa','num_stages_smem_sfb','num_stages_tmem_sfa','num_stages_tmem_sfb')})
  d.update(tile_scheduler=int(TileScheduler.STATIC),use_clc_fast_drain=0,num_stages_workid=1)
  result.append((make_config(**d),d))
 return result

def cpu_data():
 d=fc1_common.cpu_data()
 return dict(q=d['q'].clone(),input_sf=d['s'].clone(),w1=d['w1'][0].clone(),sf1=d['s1'][0].clone(),w2=d['w2'][0].clone(),sf2=d['s2'][0].clone(),valid_rows=8)

def prepare(data):
 # This bounded first gate is exactly one selected expert and one token tile.
 # It is not the future full-routing ABI or a service implementation.
 required={'q':((8,2048),torch.float8_e4m3fn),'input_sf':((16,8),torch.float32),
  'w1':((1024,2048),torch.float8_e4m3fn),'sf1':((8,16),torch.float32),
  'w2':((2048,512),torch.float8_e4m3fn),'sf2':((16,4),torch.float32)}
 assert isinstance(data['valid_rows'],int) and 0 <= data['valid_rows'] <= 8
 for key,(shape,dtype) in required.items():
  assert tuple(data[key].shape)==shape and data[key].dtype==dtype,(key,shape,dtype)
  assert data[key].is_contiguous() and data[key].device==data['q'].device
 device=data['q'].device
 immutable={k:data[k] for k in ('q','input_sf','w1','sf1','w2','sf2')}
 x=dict(q=data['q'],s=data['input_sf'],w1=data['w1'][None],s1=data['sf1'][None],w2=data['w2'][None],s2=data['sf2'][None])
 x.update(fc1=torch.full((8,1024),173,dtype=torch.uint8,device=device),fc1scale=torch.full((8,8),-17.0,dtype=torch.float32,device=device),
  act=torch.full((8,512),173,dtype=torch.uint8,device=device),actscale=torch.full((4,8),-17.0,dtype=torch.float32,device=device),fc2=torch.full((8,2048),-17.0,dtype=torch.bfloat16,device=device),
  tile=torch.zeros(1,dtype=torch.int32,device=device),mn=torch.full((1,),int(data['valid_rows']),dtype=torch.int32,device=device),route=torch.arange(9,dtype=torch.int32,device=device),ncta=torch.ones(1,dtype=torch.int32,device=device),padded=torch.full((1,),8,dtype=torch.int32,device=device))
 x['route'][-1]=0
 immutable.update({key:x[key] for key in ('tile','mn','route','ncta','padded')})
 ios=[];cfgs=configs()
 for fc,(cfg,_) in zip(('fc1','fc2'),cfgs):
  ios.append(build_fp8_block_scale_launch_io(fc=fc,cfg=cfg,fp8_quantization_type=Fp8QuantizationType.DeepSeekFp8,
   hidden_states=x['q'],hidden_states_scale=x['s'],gemm1_weights=x['w1'],gemm1_weights_scale=x['s1'],gemm2_weights=x['w2'],gemm2_weights_scale=x['s2'],
   gemm1_output=x['fc1'],gemm1_output_scale=x['fc1scale'],activation_output=x['act'],activation_output_scale=x['actscale'],gemm2_output=x['fc2'],
   tile_idx=x['tile'],mn_limit=x['mn'],route_map=x['route'],num_non_exiting_ctas=x['ncta'],total_num_padded_tokens=x['padded'],routed_token_capacity=8,
   activation_type=int(ActivationType.Swiglu),num_experts=1,num_tokens=8,top_k=1,intermediate_size=512,hidden_size=2048))
 return ios,x,immutable,cfgs

def compile_arguments(ios,stream):
 return (*_compile_arg_tuple(ios[0],stream)[:-1],*_compile_arg_tuple(ios[1],stream)[:-1],stream)

class ResidentChain:
 def __init__(self,data,debug_boundaries=True):
  assert debug_boundaries, 'First exact gate requires all native boundaries.'
  self.ios,self.owned_tensors,self.immutable_tensors,self.configs=prepare(data)
  self.outputs={k:self.owned_tensors[v] for k,v in dict(fc1_bytes='fc1',fc1_sf='fc1scale',act_bytes='act',act_sf='actscale',fc2='fc2').items()}
  with task_scheduling_scope(),BaseDSL.enable_pyir():
   self.fn=cute.compile(resident_chain_host,*compile_arguments(self.ios,cuda_drv.CUstream(0)),options='--opt-level 2 --gpu-arch sm_103a')
 def launch(self,stream):
  handle=cuda_drv.CUstream(int(stream.cuda_stream)) if hasattr(stream,'cuda_stream') else stream
  self.fn(*_launch_arg_tuple(self.ios[0],handle)[:-1],*_launch_arg_tuple(self.ios[1],handle)[:-1],handle)

def build_chain(data,debug_boundaries=True):return ResidentChain(data,debug_boundaries)
