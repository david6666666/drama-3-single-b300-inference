"""Original bounded resident adapters that depend on the installed CUTLASS API.

Only a static, single-tile schedule without interleaved/fork pipelines is
supported. Unsupported schedules fail at trace time instead of borrowing their
implementation. No installed Task body is vendored or monkey-patched.
"""
from typing import Optional

import cutlass
import cutlass.cute as cute
from cutlass.experimental.task_scheduling.enums import PipelineGroupMode
from cutlass.experimental.task_scheduling.memory import ResourceContext, SmemAllocator
from cutlass.experimental.task_scheduling.task import Task
from cutlass.utils.static_persistent_tile_scheduler import WorkTileInfo


class ArtifactTask(Task):
    resident_tile_offset = 0

    @cute.jit
    def _run_task_body_non_persistent(self, context: Optional[ResourceContext] = None):
        # This adapter supports exactly the bounded resident static schedule.
        assert self.work_queue is None, 'Resident adapter does not support persistent work queues'
        for endpoint in self.src_resources + self.dst_resources:
            group = endpoint.pipeline_group
            if cutlass.const_expr(group is not None):
                assert group.mode != PipelineGroupMode.Fork, 'Resident adapter does not support fork pipelines'
            config = endpoint.pipeline_config
            if cutlass.const_expr(config is not None):
                assert config.producer_acquire_interleave_stride == 1, 'Resident adapter does not support interleaved producers'
        x, y, z = cute.arch.block_idx()
        coordinate = (x + self.resident_tile_offset, y, z)
        self._run_task_body_impl(WorkTileInfo(coordinate, cutlass.Boolean(True)), context=context)
        # Every supported producer must complete its installed drain primitive
        # before the outer CTA barrier permits scratch reuse by the next stage.
        for destination in self.dst_resources:
            config = destination.pipeline_config
            if cutlass.const_expr(config is not None):
                if cutlass.const_expr(config.advance_on_acquire):
                    self._thread_advance_on_acquire_state(destination)
                self._producer_tail(destination)


class BorrowedSmemAllocator(SmemAllocator):
    """Use outer stage[0:reserved_bytes); each instance owns its barrier metadata."""

    def __init__(self, resident_base, reserved_bytes=72704):
        super().__init__()
        if not isinstance(resident_base, cutlass.Array):
            raise TypeError('resident_base must be the outer preallocated cutlass.Array')
        if not isinstance(reserved_bytes, int) or reserved_bytes <= 0 :
            raise ValueError('reserved_bytes must be a positive constexpr')
        if resident_base.dtype != cutlass.Uint8:
            raise TypeError('resident_base must be a byte-addressed Uint8 Array')
        shape = resident_base.shape
        if shape is None or len(shape) != 1 or int(shape[0]) < reserved_bytes:
            raise ValueError('outer resident_base does not cover the reserved stage bytes')
        self.reserved_bytes = reserved_bytes
        self._smem_base = resident_base

    def allocate(self):
        if not self._layout_computed:
            raise RuntimeError('Call compute_layout() before allocate()')
        unified_bytes = ((self._total + 7) // 8) * 8 + self._barrier_bytes
        if unified_bytes > self.reserved_bytes:
            raise ValueError(f'stage needs {unified_bytes}bytes, reserved{self.reserved_bytes}')
        allocations = list(self._allocations)
        for group in self._alias_groups:
            for phase in group:
                for allocation in phase:
                    if allocation not in allocations:
                        allocations.append(allocation)
        if any(self._alloc_alignment(allocation) > 1024 for allocation in allocations):
            raise ValueError('stage alignment exceeds the outer1024-byte base-alignment contract')
        return self._smem_base
