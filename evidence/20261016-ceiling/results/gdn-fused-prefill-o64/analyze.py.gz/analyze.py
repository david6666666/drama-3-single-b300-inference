import json,statistics,hashlib
from pathlib import Path
r=Path(__file__).resolve().parent
ds={name:json.loads((r/name).read_text()) for name in ('result.json','real-result.json','timing-result.json')}
s={'source_sha':'e7cda1eba083603b88e1f2e89688e1ff2ced7fc2','scope':'complete isolated MixedGraph, not service','synthetic_exact_checks':len(ds['result.json']['checks']),'real_exact_checks':len(ds['real-result.json']['checks']),'timed_trajectory_exact_checks':len(ds['timing-result.json']['checks']),'all_exact':all(d['status']=='PASS' for d in ds.values()),'real_layer_cases':90,'real_graph_cases':3,'repetitions':3,'replays_per_measurement':20,'registers_per_thread':206,'dynamic_shared_bytes':132884,'static_shared_bytes':1024,'tmem_columns':512,'spill_bytes':0,'runtime_promoted':False,'all_concurrency_target_met':False,'cases':[],'hashes':{n:hashlib.sha256((r/n).read_bytes()).hexdigest() for n in ds}}
for c in ds['timing-result.json']['cases']:
 a=[x['ms_per_replay']['native'] for x in c['measurements']];b=[x['ms_per_replay']['fused'] for x in c['measurements']]
 s['cases'].append({'case':c['label'],'native_median_ms':statistics.median(a),'fused_median_ms':statistics.median(b),'time_increase_fraction':statistics.median(b)/statistics.median(a)-1,'native_ms':a,'fused_ms':b})
s['local_performance_pass']=all(x['time_increase_fraction']<0 for x in s['cases'])
(r/'summary.json').write_text(json.dumps(s,indent=2)+'\n')
rows='\n'.join(f"|{x['case']}|{x['native_median_ms']:.6f}|{x['fused_median_ms']:.6f}|{x['time_increase_fraction']*100:+.3f}%|" for x in s['cases'])
(r/'report.md').write_text('''# Native GDN H/O fusion with original O V64 tile

This separate artifact follows the V32 fusion's exact-but-slower result. It preserves the original O V64 tile, using8 warps and combining two H V32 slices into V64. The H K64+K64 and O BK128 arithmetic/rounding boundaries remain explicit. No runtime or installed package is modified. The motivation is source-backed: V32 duplicated O's QK matrix twice as often as the native V64 path. This is one structural follow-up, not a tile sweep.

All57 synthetic,522 actual layer/fullgraph and1026 timed-trajectory checks pass bit-exact. Real coverage is three mixed shapes×30 GDN layers and every captured output,111 mutable state tensors and RNG. Timing uses three alternating A/B repetitions per shape,20 consecutive graph replays per measurement, same initial state restored outside events, on exclusive GPU0 and frozen e7cda1e.

|Mixed shape|Native median ms|Fused median ms|Time change|
|---|---:|---:|---:|
'''+rows+'''

The primary D58/P6 shape is still slower; the other differences are effectively flat and cannot support a useful improvement claim. The predeclared all-shape local continuation condition fails. Both H/O fusion candidates remain artifact-only; no service run is justified by these results.

The candidate compiles at206 registers/thread, zero spill/stack,132884B dynamic plus1024B static shared memory, and512 TMEM columns. This allows only one CTA per SM by shared/TMEM capacity. V32 had245 registers,115492B dynamic+1024B static shared,256 TMEM columns. Eliminating duplicate QK work did not create a useful complete-graph gain. The source also serializes O with each H chunk, where native O can parallelize all chunks after H. These are structural costs, not measured hardware stall attribution; a new profile would be required to apportion them.

A CPU/theoretical count of eliminated H/updated-V traffic is therefore not a measured DRAM saving or guaranteed time budget. Native intermediate cache residency, added live values, CTA residency and chunk parallelism can offset fusion. The full model still performs its original dense/MoE/attention/teacher work. No claim is made about end-to-end service, WER/SIM, or the unchanged6765.407frames/s target.

Protocol, CPU compile, exact checks, raw timings and cleanup are preserved. The first V32 experiment and all original failures elsewhere remain unchanged. No more tuning sweep follows this result.
''')
print(json.dumps({'all_exact':s['all_exact'],'local_performance_pass':s['local_performance_pass'],'cases':s['cases']},indent=2))
