import hashlib,json,os,subprocess,traceback
from pathlib import Path
assert os.environ.get('CUDA_VISIBLE_DEVICES')==''
import torch,triton
from triton.backends.compiler import GPUTarget
from triton.compiler import ASTSource
from fused_ho import fused_ho
root=Path(__file__).resolve().parent
source=root.parent/'source-codec-cache'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
report={'status':'PREPARING','source_sha':subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),'source_status':subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True),'candidate_sha256':sha(root/'fused_ho.py'),'driver_sha256':sha(__file__),'timings_allowed':False,'synthetic_only':True}
try:
 assert not report['source_status']
 signature={n:('*i64' if n in ('slots','boundaries','offsets') else '*fp32' if n=='g' else '*bf16') for n in fused_ho.arg_names[:12]}
 signature.update(stride_state='i32',scale='fp32',T='i32')
 constants=dict(H=32,HG=16,K=128,V=128,BT=64,BV=64)
 attrs={(i,):[['tt.divisibility',16]] for i in range(12)}
 report['variants']={}
 for debug in (True,False):
  label='debug' if debug else 'production'
  k=triton.compile(ASTSource(fused_ho,signature,{**constants,'DEBUG':debug},attrs),target=GPUTarget('cuda',103,32),options=dict(num_warps=8,num_stages=2,enable_fp_fusion=True))
  for ext in ('ptx','ttgir','llir'):(root/f'{label}.{ext}').write_text(k.asm[ext])
  (root/f'{label}.cubin').write_bytes(k.asm['cubin'])
  report['variants'][label]={'metadata':k.metadata._asdict(),'kernel_hash':k.hash,'cubin_sha256':sha(root/f'{label}.cubin')}
 assert not torch.cuda.is_initialized()
 report['status']='CPU_AOT_PASS'
except BaseException as e:
 report.update(status='CPU_AOT_FAIL',error=repr(e),traceback=traceback.format_exc());raise
finally:
 report['cuda_initialized']=torch.cuda.is_initialized();(root/'cpu-aot.json').write_text(json.dumps(report,indent=2,default=str)+'\n')
 print(json.dumps(report,indent=2,default=str))
