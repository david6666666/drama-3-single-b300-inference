import hashlib,json,os,subprocess,time
from pathlib import Path
root=Path(__file__).resolve().parent
venv='/home/zjy/code/hsliu/venvs/codex-drama3-standalone/bin/python'
source=root.parent/'source-codec-cache'
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip();assert sha=='e7cda1eba083603b88e1f2e89688e1ff2ced7fc2'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True)
aot=json.loads((root/'cpu-aot.json').read_text());assert aot['status']=='CPU_AOT_PASS' and not aot['cuda_initialized']
uuid=subprocess.check_output(['nvidia-smi','-i','0','--query-gpu=uuid','--format=csv,noheader'],text=True).strip()
apps=subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid,pid,used_memory','--format=csv,noheader'],text=True);assert uuid not in apps
proto={'source_sha':sha,'hypothesis':'Native H recurrence and O in one kernel can avoid H/updated-v global traffic while preserving all BF16 boundaries and ordered dot arithmetic. First arithmetic gate only.','variable':'H+O fusion; O BV64 preserved, H tile32->64 with8 warps (same K64 arithmetic order). No autotuning.','controls':'Same inputs, original SGLang kernels/exp functions, original BF16 intermediates, FP32 interchunk state, all rows including partial and empty.','success':'Every eager and captured output, H, updated-v and all final/untouched states bit exact; input/RNG unchanged.','stop':'First mismatch or process/kernel error; preserve FAIL; no timing.','gpu_uuid':uuid,'feasibility_repetitions':1,'timings_allowed':False,'synthetic_only':True,'frozen_files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [root/'run.py',root/'fused_ho.py',root/'prepare.py',root/'cpu-aot.json',root/'production.cubin',root/'debug.cubin']},'prelaunch_compute_apps':apps,'aot_resources':{'registers_per_thread':206,'dynamic_shared_bytes':132884,'static_shared_bytes':1024,'local_bytes':0,'stack_bytes':0,'tmem_columns':512},'storage':{p:subprocess.check_output(['findmnt','-T',p],text=True) for p in [str(root),venv,str(source)]},'time':time.time()}
(root/'protocol.json').write_text(json.dumps(proto,indent=2)+'\n')
env=dict(os.environ,CUDA_VISIBLE_DEVICES='0',OMP_NUM_THREADS='8',HF_MODULES_CACHE=str(root.parent/'hf_modules'))
with (root/'run.log').open('w') as out:
 child=subprocess.Popen([venv,str(root/'run.py')],env=env,stdout=out,stderr=subprocess.STDOUT)
 (root/'pid.json').write_text(json.dumps({'pid':child.pid,'launcher_pid':os.getpid(),'time':time.time()},indent=2)+'\n')
 status=child.wait()
(root/'exit.json').write_text(json.dumps({'returncode':status,'time':time.time(),'post_compute_apps':subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid,pid,used_memory','--format=csv,noheader'],text=True)},indent=2)+'\n')
raise SystemExit(status)
