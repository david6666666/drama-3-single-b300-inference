import sys,os,json,hashlib,traceback,time
from pathlib import Path
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parent;SOURCE=ROOT.parent/'source-codec-cache'
sys.path[:0]=[str(SOURCE/'src'),str(SOURCE/'scripts'),'/home/zjy/code/hsliu/drama3-sources/fish-speech']
import torch,triton
import torch.nn.functional as F
from fish_speech.models.text2semantic.fish_omni.generate import build_drama3_prompt
import drama3.mixed_model as mm
from drama3.engine import BatchedPrefillGraph,DecodeGraph,state_pool_size
from drama3.mixed_graph import MixedGraph
from drama3.model import DramaModel
from drama3.runtime_state import DeviceRequests
from validate_mixed_layers import state_tensors,snapshot,restore
from adapter import fused_prefill
CORPUS=Path('/home/zjy/code/hsliu/artifacts/drama3-b300-20261014/seedtts-en1088-codes/requests.jsonl')
CKPT='/home/zjy/.cache/huggingface/hub/models--fishaudio--drama-3/snapshots/e0a9218aa48888270f06ef1ed9ea67622c0e17d2'
REPORT={'status':'RUNNING','timings_allowed':True,'checks':[],'cases':[],'start_time':time.time()}
def save():(ROOT/'timing-result.json').write_text(json.dumps(REPORT,indent=2)+'\n')
def eq(label,a,b):
 same=a.shape==b.shape and a.dtype==b.dtype and torch.equal(a.contiguous().reshape(-1).view(torch.uint8),b.contiguous().reshape(-1).view(torch.uint8))
 row={'name':label,'pass':same,'elements':a.numel()};REPORT['checks'].append(row)
 if not same:
  row.update(max_abs=float((a.float()-b.float()).abs().max()),rrms=float((a.float()-b.float()).square().mean().sqrt()/b.float().square().mean().sqrt().clamp_min(1e-30)))
  torch.save({'actual':a.cpu(),'expected':b.cpu()},ROOT/'timing-first-failure.pt');save();raise AssertionError(label)
@torch.inference_mode()
def main():
 protocol=json.loads((ROOT/'timing-protocol.json').read_text())
 for p,digest in protocol['frozen_files'].items():assert hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==digest,p
 assert str(torch.cuda.get_device_properties(0).uuid).removeprefix('GPU-')==protocol['gpu_uuid'].removeprefix('GPU-')
 torch.set_num_threads(8)
 model=DramaModel(CKPT,slots=state_pool_size(64),max_length=2048)
 assert model.prefill_gdn=='fla' and model.prefill_moe=='flashinfer' and not model.tuned_prefill_moe
 device=DeviceRequests(model.slots,model.config.eos_token_id,model.max_length)
 samples=[json.loads(x) for x in CORPUS.read_bytes().splitlines()][:64]
 prompts=[build_drama3_prompt(s['text'],model.weights.tokenizer,model.config,[s['reference_text']],[torch.tensor(s['reference_codes'])]) for s in samples]
 prefill=BatchedPrefillGraph(model,8,triton.next_power_of_2(max(map(len,prompts))))
 first=DecodeGraph(model,8,first_frame=True,requests=device);decode=DecodeGraph(model,64,requests=device)
 native=mm.gdn_prefill;tensors=state_tensors(model,device)
 for count,arriving in ((58,6),(40,3),(12,1)):
  selected=prompts[count:count+arriving];slots=list(range(count,count+arriving))
  cap=triton.cdiv(sum(map(len,selected)),256)*256;bucket=next(n for n in (16,32,48,64) if n>=count)
  label=f'd{count}p{arriving}';print(label,flush=True)
  control=MixedGraph(model,device,bucket,8,cap,max_length=256)
  mm.gdn_prefill=fused_prefill
  try:candidate=MixedGraph(model,device,bucket,8,cap,max_length=256)
  finally:mm.gdn_prefill=native
  active=[SimpleNamespace(slot=i,position=len(p)-1) for i,p in enumerate(prompts)]
  for i,p in enumerate(prompts):
   history=F.pad(p[-16:,0],(max(0,16-len(p)),0),value=-1).cuda();device.initialize(i,p[-1].cuda(),history,len(p)-1,500)
  for start in range(0,64,8):
   hidden=prefill.run(prompts[start:start+8],list(range(start,start+8)));first.run(active[start:start+8],hidden)
  for _ in range(3):decode.run(active)
  base=snapshot(tensors.values());rng=torch.cuda.get_rng_state().clone()
  control.prepare(active[:count],selected,slots);candidate.prepare(active[:count],selected,slots)
  for graph in (control,candidate):
   restore(tensors.values(),base);graph.graph.replay()
  torch.cuda.synchronize()
  measurements=[]
  for rep in range(3):
   order=(('native',control),('fused',candidate)) if rep%2==0 else (('fused',candidate),('native',control))
   results={};final={}
   for name,graph in order:
    restore(tensors.values(),base);torch.cuda.set_rng_state(rng);torch.cuda.synchronize()
    begin,end=torch.cuda.Event(enable_timing=True),torch.cuda.Event(enable_timing=True)
    begin.record()
    for _ in range(20):graph.graph.replay()
    end.record();end.synchronize()
    results[name]=begin.elapsed_time(end)/20
    final[name]=(snapshot(graph.output),snapshot(tensors.values()),torch.cuda.get_rng_state().clone())
   for i,(actual,expected) in enumerate(zip(final['fused'][0],final['native'][0])):eq(f'{label}/rep{rep}/out{i}',actual,expected)
   for name,actual,expected in zip(tensors,final['fused'][1],final['native'][1]):eq(f'{label}/rep{rep}/{name}',actual,expected)
   eq(f'{label}/rep{rep}/rng',final['fused'][2],final['native'][2])
   measurements.append({'rep':rep,'order':[x[0] for x in order],'replays':20,'ms_per_replay':results,'speedup':results['native']/results['fused']});save()
   del final
  REPORT['cases'].append({'label':label,'capacity':cap,'measurements':measurements});save()
  del base,control,candidate
 REPORT['status']='PASS';save()
try:main()
except BaseException as e:
 REPORT.update(status='FAIL',error=repr(e),traceback=traceback.format_exc());raise
finally:
 REPORT['end_time']=time.time();save();print(json.dumps({k:v for k,v in REPORT.items() if k!='checks'},indent=2))
