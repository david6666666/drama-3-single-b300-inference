"""Archive explicit diagnostic artifacts without frozen source trees or audio/tensors."""
import gzip,hashlib,json
from pathlib import Path
r=Path(__file__).resolve().parent
o=Path('/home/zjy/code/hsliu/drama-3-single-b300-inference/evidence/20261016-ceiling/results')
o.mkdir(parents=True,exist_ok=True)
roots=['latest-timeline-gpu0','layout-control-gpu0','layout-combined-gpu0','deferred-control-gpu6','deferred-candidate-gpu6','rich-timeline-gpu0','mixed-profile','mixed-layout','deferred-codec','codec-priority','codec-minlaunch','short-padding-control-gpu7','short-padding-candidate-gpu7','combined-native-control-gpu0','combined-native-candidate-gpu0','codec-greencap','codec-sm-dynamic','codec-sm-dynamic-fixed','coalescing-native-control-gpu7','coalescing-native-candidate-gpu7','green-sm-control-gpu0','green-sm-candidate-gpu0','gdn-fused-norm','pipeline-control-gpu6','pipeline-candidate-gpu6','codec-kernel-profile','codec-constant-fold','codec-cached-linear','codec-cache-dynamic','expert-partition','pipeline-admission-control-gpu6','pipeline-admission-candidate-gpu6','expert-metadata-rebase','codec-cache-control-gpu6','codec-cache-candidate-gpu6','codec-cudnn-select','codec-cudnn-fresh-thread','cpu-service-ceiling','expert-resident-cpu','current-pipeline-timeline-gpu0','reference-prefix','expert-fc1-native']
paths=[p for p in r.iterdir() if p.is_file()]
for n in roots: paths.extend((r/n).rglob('*'))
rows=[]
for p in sorted(set(paths)):
 if not p.is_file() or p.suffix not in ('.json','.jsonl','.md','.py','.log','.txt','.yaml','.csv','.ptx','.ttgir','.ttir','.cu','.cpp','.h','.mlir','.sass'): continue
 if '__pycache__' in p.parts or 'numeric-arrays' in p.parts: continue
 data=p.read_bytes();rel=p.relative_to(r);dest=o/rel;dest.parent.mkdir(parents=True,exist_ok=True)
 if p.suffix in ('.jsonl','.log','.py','.txt','.ptx','.ttgir','.ttir','.cu','.cpp','.h','.mlir','.sass') or p.name.endswith('-quality.json') or (len(data)>64*1024 and not p.name.endswith('service-ledger.json')):
  raw=dest;dest=dest.with_name(dest.name+'.gz');raw.unlink(missing_ok=True);dest.write_bytes(gzip.compress(data,mtime=0))
 else: dest.write_bytes(data)
 rows.append(dict(source=str(rel),artifact=str(dest.relative_to(o)),uncompressed_sha256=hashlib.sha256(data).hexdigest(),bytes=len(data)))
(o/'files.json').write_text(json.dumps(rows,indent=2)+'\n')
for row in rows:
 p=o/row['artifact'];data=gzip.decompress(p.read_bytes()) if p.suffix=='.gz' else p.read_bytes()
 assert hashlib.sha256(data).hexdigest()==row['uncompressed_sha256'],row
print('Archived and verified',len(rows),'artifacts')
