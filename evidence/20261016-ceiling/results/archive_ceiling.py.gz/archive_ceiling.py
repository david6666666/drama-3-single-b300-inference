"""Archive explicit diagnostic artifacts without frozen source trees or audio/tensors."""
import gzip,hashlib,json
from pathlib import Path
r=Path(__file__).resolve().parent
o=Path('/home/zjy/code/hsliu/drama-3-single-b300-inference/evidence/20261016-ceiling/results')
o.mkdir(parents=True,exist_ok=True)
roots=['latest-timeline-gpu0','layout-control-gpu0','layout-combined-gpu0','deferred-control-gpu6','deferred-candidate-gpu6','rich-timeline-gpu0','mixed-profile','mixed-layout','deferred-codec','codec-priority','codec-minlaunch','short-padding-control-gpu7','short-padding-candidate-gpu7','combined-native-control-gpu0','combined-native-candidate-gpu0','codec-greencap','codec-sm-dynamic','codec-sm-dynamic-fixed','coalescing-native-control-gpu7','coalescing-native-candidate-gpu7','green-sm-control-gpu0','green-sm-candidate-gpu0','gdn-fused-norm','pipeline-control-gpu6','pipeline-candidate-gpu6','codec-kernel-profile','codec-constant-fold','codec-cached-linear','codec-cache-dynamic','expert-partition','pipeline-admission-control-gpu6','pipeline-admission-candidate-gpu6','expert-metadata-rebase','codec-cache-control-gpu6','codec-cache-candidate-gpu6','codec-cudnn-select','codec-cudnn-fresh-thread','cpu-service-ceiling','expert-resident-cpu','current-pipeline-timeline-gpu0','reference-prefix','expert-fc1-native']
roots += ['expert-fc1-native-v2','expert-fc1-expanded','expert-fc1-native-v3','expert-fc2-native','expert-fc2-native-v2','expert-fc2-expanded','expert-activation-native','gdn-fused-prefill','gdn-fused-prefill-o64','expert-activation-dsl','expert-resident-chain','expert-resident-chain-v2','expert-m128-resource','expert-m128-fc2','expert-m128-fc2-expanded']
roots += ['expert-resident-full','expert-resident-timing','expert-resident-timing-v2','expert-m128-native-v2','expert-m128-fc1-expanded','expert-m128-body','expert-m128-body-v2','expert-m128-body-v3','expert-m128-body-timing','register-lowering-audit']
roots += ['expert-m128-pdl','expert-m128-pdl-metadata-ready','native-lt-b64','native-lt-dtype-contract','native-lt-real-contract']
roots += ['expert-m128-ncu-node', 'expert-m128-ncu-node-v2', 'expert-m128-route-cache', 'native-row-reuse-audit', 'native-finalize-norm', 'native-finalize-norm-v2', 'native-finalize-norm-v3']
roots += ['native-row-reuse-exact', 'native-row-reuse-exact-v2', 'expert-m128-fc1-pcsampling', 'ncu-fc1-pcsampling-plan', 'native-tower-budget-audit']
roots += ['native-row-reuse-mixed']
roots += ['prefix-dag-cpu-audit']
paths=[p for p in r.iterdir() if p.is_file()]
for n in roots: paths.extend((r/n).rglob('*'))
rows=[]
for p in sorted(set(paths)):
 if not p.is_file() or p.suffix not in ('.json','.jsonl','.md','.py','.log','.txt','.yaml','.csv','.ptx','.ttgir','.ttir','.cu','.cpp','.h','.mlir','.sass','.patch'): continue
 if '__pycache__' in p.parts or 'numeric-arrays' in p.parts: continue
 if 'triton-cache' in p.parts and p.relative_to(r).parts[0].startswith('native-finalize-norm'): continue
 data=p.read_bytes();rel=p.relative_to(r);dest=o/rel;dest.parent.mkdir(parents=True,exist_ok=True)
 if p.suffix in ('.jsonl','.log','.py','.txt','.ptx','.ttgir','.ttir','.cu','.cpp','.h','.mlir','.sass','.patch') or p.name.endswith('-quality.json') or (len(data)>64*1024 and not p.name.endswith('service-ledger.json')):
  raw=dest;dest=dest.with_name(dest.name+'.gz');raw.unlink(missing_ok=True);dest.write_bytes(gzip.compress(data,mtime=0))
 else: dest.write_bytes(data)
 rows.append(dict(source=str(rel),artifact=str(dest.relative_to(o)),uncompressed_sha256=hashlib.sha256(data).hexdigest(),bytes=len(data)))
(o/'files.json').write_text(json.dumps(rows,indent=2)+'\n')
for row in rows:
 p=o/row['artifact'];data=gzip.decompress(p.read_bytes()) if p.suffix=='.gz' else p.read_bytes()
 assert hashlib.sha256(data).hexdigest()==row['uncompressed_sha256'],row
print('Archived and verified',len(rows),'artifacts')
