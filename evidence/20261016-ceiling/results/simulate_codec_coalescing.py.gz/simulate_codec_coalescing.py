"""CPU-only ready-at-one-emit codec partition accounting; not measured speedup."""
import json,math
from pathlib import Path
from collections import defaultdict,Counter
root=Path(__file__).parent
ledger=json.loads((root/'rich-timeline-service-ledger.json').read_text())
start=ledger['time']['first_dispatch_s'];end=ledger['time']['last_completion_s']
records=json.loads((root/'rich-timeline.json').read_text())['records']
emits=defaultdict(lambda:defaultdict(list))
for row in records:
 if row['stage']=='codec_gpu_and_copy' and start<=row['cpu_start_s']<=end:
  emits[row['emit_id']][row['frame_bucket']].extend(row['valid_frames'])

def partition(n,f):
 limit=min(16,512//f);sizes=sorted(set(x for x in (1,2,4,8,12,16) if x<=limit)|{limit})
 full,tail=divmod(n,limit)
 return [limit]*full+([next(x for x in sizes if x>=tail)] if tail else [])

def simulate(ratio):
 launches=padded=frame_padded=merged=0;hist=Counter();examples=[]
 for emit,groups in emits.items():
  buckets=sorted(groups);clusters=[]
  for bucket in buckets:
   if clusters and bucket/clusters[-1][0]<=ratio:
    clusters[-1].append(bucket)
   else:clusters.append([bucket])
  for fs in clusters:
   f=max(fs);values=[v for b in fs for v in groups[b]];sizes=partition(len(values),f)
   launches+=len(sizes);padded+=sum(sizes)*f;frame_padded+=len(values)*f
   if len(fs)>1:
    merged+=len(fs)-1;hist[str(fs)]+=1
    if len(examples)<12:examples.append(dict(emit=emit,buckets=fs,valid_frames=values,padded_batches=sizes))
 return dict(max_bucket_ratio=ratio,launches=launches,padded_bucket_frames=padded,frame_padded_frames=frame_padded,
   combined_padding_fraction=padded/ledger['output']['total_acoustic_frames']-1,
   collapsed_frame_groups=merged,merge_histogram=dict(hist),examples=examples)
result=dict(status='CPU_ACCOUNTING_ONLY',source='rich-timeline.json inside measured client window',
 actual_codec_calls=ledger['timeline']['codec_recorded_partition_accounting']['codec_calls'],
 actual_padded_bucket_frames=ledger['timeline']['codec_recorded_partition_accounting']['padded_bucket_frames'],
 policies=[simulate(r) for r in (1,4/3,1.5,2,100)],
 limitations=['No latency or quality measurement; fewer calls can lose to extra padded convolution work.',
 'Same ready emit only; does not delay chunks, cross emitted boundaries, or combine jobs from different emit generations.',
 'Native per-row valid frame/state semantics still require PCM/state and complete WER/SIM verification.',
 'Greedy adjacent bucket clusters by minimum-to-maximum ratio; not a latency-optimal planner.'])
(root/'codec-coalescing-accounting.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps([{k:v for k,v in p.items() if k not in ('merge_histogram','examples')} for p in result['policies']],indent=2))
