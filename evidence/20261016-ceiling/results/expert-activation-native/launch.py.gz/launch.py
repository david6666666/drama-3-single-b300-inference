import hashlib,json,os,subprocess,time
from pathlib import Path
OUT=Path(__file__).resolve().parent;ROOT=OUT.parent
GPU='GPU-619f7fdc-5f98-8c37-fe89-0465d6130baf'
PYTHON='/home/zjy/code/hsliu/venvs/codex-drama3-standalone/bin/python'
SOURCE=ROOT/'source-metadata-rebase-95fcb0e'
def apps():return subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid,pid,used_memory','--format=csv,noheader'],text=True)
before=apps();assert GPU not in before,before
assert not subprocess.check_output(['git','status','--porcelain'],cwd=SOURCE,text=True)
files=[OUT/n for n in ('run.py','shared_activation.cu','shared_activation.so','inputs.pt','cpu-contract.json','compile-command.json')]
files.append(ROOT/'expert-metadata-rebase/extension/drama3_metadata_rebase_native.so')
protocol=dict(hypothesis='The NEW shared-input/output activation body with one warp per token preserves native FC1->activation bytes/scales despite changed reduction ownership.',isolated_variable='Original activation scalar arithmetic/converter, FP8 boundaries and source inputs held; input/output move through shared memory and max reduction maps128 channels to32lanes.',source_sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip(),gpu_uuid=GPU,scope='Single untimed arithmetic/layout feasibility. No runtime edits, service or performance claims. Original native host helper is used only to create additional synthetic zero/NaN oracles.',controls='15 archived native oracles / all4rank fragments;512threadCTA with8active epiloguewarps; compiledsm103a -use_fast_math; original FP8bytes/FP32scales, nativefulltop8 provenance. No weight/model loading, no cacheflush, no clock control.',gate='Every activation byte and FP32scale bit exact;partialvalid0..8,globalandsharedcanaries,input/scales/counts/RNG unchanged;capturedgraph with changedinputs; separate signedzero/FLT_MIN/NaN diagnostics.',stop='First mismatch preserves failed tensors/result; no timing or service continuation.',before_gpu=before,hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},command=[PYTHON,str(OUT/'run.py')],storage={str(p):subprocess.check_output(['findmnt','-T',str(p),'-n','-o','SOURCE,FSTYPE,TARGET'],text=True).strip() for p in (Path(PYTHON),OUT,ROOT/'expert-metadata-rebase')})
(OUT/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
env={**os.environ,'CUDA_VISIBLE_DEVICES':GPU,'OMP_NUM_THREADS':'4','HF_MODULES_CACHE':'/home/zjy/.cache/huggingface/modules'}
with (OUT/'run.log').open('w') as log:
 child=subprocess.Popen(protocol['command'],cwd=OUT,env=env,stdout=log,stderr=subprocess.STDOUT)
 (OUT/'pid.json').write_text(json.dumps(dict(pid=child.pid,gpu_uuid=GPU))+'\n')
 with (OUT/'process-audit.jsonl').open('w') as audit:
  while child.poll() is None:
   audit.write(json.dumps(dict(time=time.time(),gpu_processes=apps()))+'\n');audit.flush();time.sleep(1)
 rc=child.wait()
(OUT/'exit.json').write_text(json.dumps(dict(returncode=rc,after_gpu=apps()))+'\n')
