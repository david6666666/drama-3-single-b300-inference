"""CPU-only native domain/layout preparation; no CUDA context or model loading."""
import hashlib,json,subprocess
from pathlib import Path
import torch
OUT=Path(__file__).resolve().parent;ROOT=OUT.parent
SOURCE=ROOT/'source-metadata-rebase-95fcb0e'
FI=Path('/home/zjy/code/hsliu/venvs/codex-drama3-standalone/lib/python3.12/site-packages/flashinfer')
rows=[];inputs=[]
assert not torch.cuda.is_initialized()
for path in sorted((ROOT/'expert-metadata-rebase').glob('oracle-layer*.pt')):
 data=torch.load(path,map_location='cpu',weights_only=False);m=data['intermediates']
 q=m['fc1_bytes'];s=m['fc1_scale'];a=m['activation_bytes'];sc=m['activation_scale']
 assert q.shape==(512,1024) and s.shape==(512,8) and a.shape==(512,512) and sc.shape==(512,4)
 assert q.dtype==a.dtype==torch.uint8 and s.dtype==sc.dtype==torch.float32
 rows.append(dict(file=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),layer=data['layer'],scenario=data['scenario'],fc1_nan_bytes=int(((q&127)==127).sum()),fc1_negative_zero_bytes=int((q==128).sum()),fc1_zero_bytes=int(((q&127)==0).sum()),fc1_scale_nonfinite=int((~s.isfinite()).sum()),fc1_scale_min=float(s.min()),fc1_scale_max=float(s.max()),activation_nan_bytes=int(((a&127)==127).sum()),activation_negative_zero_bytes=int((a==128).sum()),activation_scale_nonfinite=int((~sc.isfinite()).sum()),activation_scale_min=float(sc.min()),activation_scale_max=float(sc.max())))
 for rank in range(4):
  fc1=torch.cat((q[:,rank*128:(rank+1)*128],q[:,512+rank*128:512+(rank+1)*128]),dim=1).reshape(64,8,256).contiguous()
  scales=torch.stack((s[:,rank],s[:,rank+4])).reshape(2,64,8).permute(1,0,2).contiguous()
  inputs.append(dict(name=path.stem+f'/rank{rank}',fc1=fc1,scale=scales,expected=a[:,rank*128:(rank+1)*128].reshape(64,8,128).contiguous(),expected_scale=sc[:,rank].reshape(64,8).contiguous()))
assert len(rows)==15 and len(inputs)==60
# Additional same-oracle partial ownership cases, including empty and partial token8 groups.
for base in inputs[:4]:inputs.append({**base,'name':base['name']+'/partial0to8','valid_rows':torch.arange(64,dtype=torch.int32)%9})
torch.save(inputs,OUT/'inputs.pt')
paths=[OUT/'shared_activation.cu',OUT/'shared_activation.so',OUT/'compile.log',OUT/'inputs.pt',FI/'data/csrc/fused_moe/trtllm_backend/trtllm_fused_moe_dev_kernel.cu',FI/'data/csrc/trtllm_fused_moe_kernel_launcher.cu',FI/'data/cutlass/include/cutlass/float8.h',ROOT/'expert-metadata-rebase/extension/trtllm_backend_trtllm_fused_moe_dev_kernel.cuda.o']
manifest=dict(source_sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip(),source_status=subprocess.check_output(['git','status','--porcelain'],cwd=SOURCE,text=True),cuda_initialized=torch.cuda.is_initialized(),oracles=rows,cases=len(inputs),hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},layout=dict(fc1='[groups,8,256] bytes: per row up128 then gate128',fc1_scale='[groups,2,8] FP32: up or gate then token',activation='[groups,8,128] bytes',activation_scale='[groups,8] FP32',rank_gather='Four rank fragments become token-major [8,512] and block-major scales [4,8]',threads='512 CTA threads, only warps0..7 execute activation; all512 participate in two outer publication barriers'),resource=dict(ptxas_registers_per_thread=32,stack_bytes=0,spill_load_bytes=0,spill_store_bytes=0,ptxas_static_shared_bytes=3296,cuobjdump_static_shared_bytes=4320,logical_fc1_fragment_bytes=2112,logical_activation_fragment_bytes=1056,diagnostic_canary_shared_bytes=128),limits=['Standalone shared body does not prove cluster DSM or FC1 epilogue integration.','Finite native oracle domain plus separate zero/NaN diagnostic needed; no performance claim.','FC1 uses original two independent FP8 boundaries; no bypass or BF16 replacement.'])
assert not manifest['cuda_initialized'];(OUT/'cpu-contract.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(oracles=len(rows),cases=len(inputs),cuda_initialized=manifest['cuda_initialized'],fc1_nan_bytes=sum(r['fc1_nan_bytes'] for r in rows),activation_nan_bytes=sum(r['activation_nan_bytes'] for r in rows),negative_zero_fc1=sum(r['fc1_negative_zero_bytes'] for r in rows),negative_zero_activation=sum(r['activation_negative_zero_bytes'] for r in rows),resources=manifest['resource']),indent=2))
