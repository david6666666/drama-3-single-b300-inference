/*
 * SPDX-License-Identifier: Apache-2.0
 * Arithmetic adapted from FlashInfer's trtllm_fused_moe_dev_kernel.cu,
 * activationDeepSeekKernel / silu. Original Apache-2.0 license applies.
 * Artifact-only shared-memory interface probe; not a production kernel.
 */
#include <cuda_runtime.h>
#include <cutlass/float8.h>
#include <cfloat>
#include <cstdint>
#include <cmath>

// Precondition: CTA has >=256 threads, complete active warps 0..7. The caller
// publishes FC1 E4M3 values + their two original FP32 dequant scales before entry.
// No CTA barrier inside: nonparticipant warps must join the caller's later barrier.
// Layout: x[token][up128,gate128], sf[up_or_gate][token], y[token][channel], sy[token].
__device__ __forceinline__ void activation_shared_8x128(
    uint8_t const* x, float const* sf, uint8_t* y, float* sy, int valid_rows) {
  int const warp = threadIdx.x / 32;
  int const lane = threadIdx.x % 32;
  if (warp < valid_rows && warp < 8) {
    auto const* values = reinterpret_cast<cutlass::float_e4m3_t const*>(x);
    auto* output = reinterpret_cast<cutlass::float_e4m3_t*>(y);
    float result[4];
    float amax = 0.0f;
#pragma unroll
    for (int i = 0; i < 4; ++i) {
      int const channel = lane * 4 + i;
      float const x1 = sf[warp] * static_cast<float>(values[warp * 256 + channel]);
      float const x2 = sf[8 + warp] * static_cast<float>(values[warp * 256 + 128 + channel]);
      // Preserve original operation order and compiler fast-math contract.
      result[i] = (x2 / (1.0f + expf(-x2))) * x1;
      amax = fmaxf(amax, fabsf(result[i]));
    }
#pragma unroll
    for (int delta = 16; delta > 0; delta >>= 1)
      amax = fmaxf(amax, __shfl_down_sync(0xffffffffu, amax, delta));
    amax = __shfl_sync(0xffffffffu, amax, 0);
    float const scale = fmaxf(amax / 448.f, FLT_MIN);
    if (lane == 0) sy[warp] = scale;
#pragma unroll
    for (int i = 0; i < 4; ++i)
      output[warp * 128 + lane * 4 + i] = static_cast<cutlass::float_e4m3_t>(result[i] / scale);
  }
}

struct SharedStorage {
  uint32_t before[16];
  alignas(16) uint8_t fc1[8 * 256];
  float fc1_scale[2 * 8];
  alignas(16) uint8_t activation[8 * 128];
  float activation_scale[8];
  uint32_t after[16];
};

__global__ __launch_bounds__(512) void shared_activation_probe(
    uint8_t const* fc1, float const* fc1_scale, int const* valid_rows,
    uint8_t* activation, float* activation_scale, int* guard_status) {
  __shared__ SharedStorage s;
  int const group = blockIdx.x;
  int const tid = threadIdx.x;
  for (int i = tid; i < 8 * 256; i += blockDim.x) s.fc1[i] = fc1[group * 8 * 256 + i];
  if (tid < 16) { s.before[tid] = 0x5a7b9cadu; s.after[tid] = 0x5a7b9cadu; s.fc1_scale[tid] = fc1_scale[group * 16 + tid]; }
  for (int i = tid; i < 8 * 128; i += blockDim.x) s.activation[i] = 0xa5u;
  if (tid < 8) s.activation_scale[tid] = -17.f;
  __syncthreads();  // Stand-in for native FC1 producer/epilogue completion.
  activation_shared_8x128(s.fc1, s.fc1_scale, s.activation, s.activation_scale, valid_rows[group]);
  __syncthreads();  // Consumer-visible publication; all 512 threads participate.
  for (int i = tid; i < 8 * 128; i += blockDim.x) activation[group * 8 * 128 + i] = s.activation[i];
  if (tid < 8) activation_scale[group * 8 + tid] = s.activation_scale[tid];
  if (tid < 16) guard_status[group * 16 + tid] = (s.before[tid] == 0x5a7b9cadu && s.after[tid] == 0x5a7b9cadu);
}

extern "C" int launch_shared_activation(
    void const* fc1, void const* fc1_scale, void const* valid_rows,
    void* activation, void* activation_scale, void* guard_status,
    int groups, int threads, void* stream) {
  if (groups <= 0 || (threads != 256 && threads != 512)) return int(cudaErrorInvalidValue);
  shared_activation_probe<<<groups,threads,0,reinterpret_cast<cudaStream_t>(stream)>>>(
      static_cast<uint8_t const*>(fc1), static_cast<float const*>(fc1_scale),
      static_cast<int const*>(valid_rows), static_cast<uint8_t*>(activation),
      static_cast<float*>(activation_scale), static_cast<int*>(guard_status));
  return int(cudaGetLastError());
}
