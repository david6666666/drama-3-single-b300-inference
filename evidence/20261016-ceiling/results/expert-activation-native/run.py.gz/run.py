"""One untimed exact gate of the NEW shared-input/output activation body."""
import ctypes,hashlib,json,os,subprocess,traceback
from pathlib import Path
import torch
OUT=Path(__file__).resolve().parent
report=dict(status='STARTING',pid=os.getpid(),checks=[],cases=[],timing_allowed=False)
def save(): (OUT/'result.json').write_text(json.dumps(report,indent=2)+'\n')
def check(name,a,b):
 av=a.detach().contiguous();bv=b.detach().contiguous()
 equal=av.shape==bv.shape and av.dtype==bv.dtype and torch.equal(av.view(torch.uint8),bv.view(torch.uint8))
 row=dict(name=name,exact=equal,shape=list(av.shape),dtype=str(av.dtype))
 report['checks'].append(row);save()
 if not equal:
  torch.save(dict(actual=av.cpu(),expected=bv.cpu()),OUT/(name.replace('/','_')+'-FAIL.pt'))
  row['changed_bytes']=int((av.view(torch.uint8)!=bv.view(torch.uint8)).sum()) if av.shape==bv.shape else None
  save();raise AssertionError(name)
def require(name,value):
 report['checks'].append(dict(name=name,exact=bool(value)));save()
 if not value:raise AssertionError(name)
@torch.inference_mode()
def main():
 declaration=json.loads((OUT/'protocol.json').read_text())
 for path,digest in declaration['hashes'].items():require('hash/'+Path(path).name,hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest)
 report.update(source_sha=declaration['source_sha'],device=torch.cuda.get_device_name(0),gpu_uuid=str(torch.cuda.get_device_properties(0).uuid),scope=declaration['scope'])
 require('GPU6_uuid',report['gpu_uuid']==declaration['gpu_uuid'])
 lib=ctypes.CDLL(str(OUT/'shared_activation.so'))
 launch=lib.launch_shared_activation
 launch.argtypes=[ctypes.c_void_p]*6+[ctypes.c_int,ctypes.c_int,ctypes.c_void_p];launch.restype=ctypes.c_int
 cases=torch.load(OUT/'inputs.pt',map_location='cpu',weights_only=False)
 groups=64
 raw_x=torch.full((64+groups*8*256+64,),0xd3,device='cuda',dtype=torch.uint8);x=raw_x[64:-64].view(groups,8,256)
 raw_s=torch.full((16+groups*16+16,),-29.,device='cuda');s=raw_s[16:-16].view(groups,2,8)
 raw_y=torch.full((64+groups*8*128+64,),0xc7,device='cuda',dtype=torch.uint8);y=raw_y[64:-64].view(groups,8,128)
 raw_sy=torch.full((16+groups*8+16,),-31.,device='cuda');sy=raw_sy[16:-16].view(groups,8)
 counts=torch.full((groups,),8,device='cuda',dtype=torch.int32);guards=torch.zeros((groups,16),device='cuda',dtype=torch.int32)
 rng=torch.cuda.get_rng_state().clone()
 def call():
  code=launch(x.data_ptr(),s.data_ptr(),counts.data_ptr(),y.data_ptr(),sy.data_ptr(),guards.data_ptr(),groups,512,torch.cuda.current_stream().cuda_stream)
  if code:raise RuntimeError(f'CUDA launch error {code}')
 def stage(case):
  x.copy_(case['fc1']);s.copy_(case['scale']);counts.copy_(case.get('valid_rows',torch.full((groups,),8,dtype=torch.int32)))
  y.fill_(0xa5);sy.fill_(-17.);guards.zero_()
 def verify(case,label):
  n=case.get('valid_rows',torch.full((groups,),8,dtype=torch.int32));valid=torch.arange(8)[None,:]<n[:,None]
  expected=case['expected'].clone();expected_scale=case['expected_scale'].clone()
  expected[~valid]=0xa5;expected_scale[~valid]=-17.
  check(label+'/bytes',y,expected.cuda());check(label+'/scales_bits',sy,expected_scale.cuda())
  check(label+'/shared_canaries',guards,torch.ones_like(guards))
  check(label+'/input_bytes',x,case['fc1'].cuda());check(label+'/input_scales',s,case['scale'].cuda());check(label+'/row_counts',counts,n.cuda())
  for name,tensor,prefix,suffix,value in [('x',raw_x,64,64,0xd3),('s',raw_s,16,16,-29.),('y',raw_y,64,64,0xc7),('sy',raw_sy,16,16,-31.)]:
   check(label+'/'+name+'_prefix',tensor[:prefix],torch.full_like(tensor[:prefix],value));check(label+'/'+name+'_suffix',tensor[-suffix:],torch.full_like(tensor[-suffix:],value))
  check(label+'/rng',torch.cuda.get_rng_state(),rng)
  report['cases'].append(dict(name=label,passed=True,valid_rows=int(n.sum())));save()
 stage(cases[0]);call();torch.cuda.synchronize();verify(cases[0],'eager/'+cases[0]['name'])
 stream=torch.cuda.Stream();stream.wait_stream(torch.cuda.current_stream());graph=torch.cuda.CUDAGraph()
 with torch.cuda.graph(graph,stream=stream):call()
 torch.cuda.current_stream().wait_stream(stream);torch.cuda.synchronize()
 for case in cases:
  stage(case);call();torch.cuda.synchronize();verify(case,'eager/'+case['name'])
  stage(case);graph.replay();torch.cuda.synchronize();verify(case,'graph/'+case['name'])
 print(json.dumps(dict(stage='native_oracle_shared_PASS',cases=len(report['cases']),checks=len(report['checks']))),flush=True)
 # Separate synthetic boundary diagnostic: native reference needed only here,
 # not as a redundant rerun of the 15 already archived native oracle bodies.
 import tvm_ffi
 native=tvm_ffi.load_module(str(OUT.parent/'expert-metadata-rebase/extension/drama3_metadata_rebase_native.so'))
 fq=torch.zeros((512,1024),device='cuda',dtype=torch.uint8);fs=torch.ones((8,512),device='cuda')
 fq[1,:512]=128;fq[2,512:]=128;fq[3,:]=128
 fq[4,:]=1;fs[:,4]=torch.finfo(torch.float32).tiny
 fq[5,512]=127;fq[6,512:640]=127;fq[7,:128]=255
 fq[8,:512]=126;fq[8,512:]=254
 fq[9,:512]=254;fq[9,512:]=126
 native_out=torch.empty((512,512),device='cuda',dtype=torch.uint8);native_scale=torch.empty((4,512),device='cuda')
 mapping=torch.arange(512,device='cuda',dtype=torch.int32);padded=torch.tensor([512],device='cuda',dtype=torch.int32)
 native.trtllm_moe_run_deepseek_fp8_activation(fq,fs,native_out,native_scale,mapping,padded,64,8,512,3,False)
 torch.cuda.synchronize()
 torch.save(dict(fc1=fq.cpu(),scale=fs.cpu(),activation=native_out.cpu(),activation_scale=native_scale.cpu()),OUT/'synthetic-native-oracle.pt')
 report['synthetic_domain']='All-zero, each signed-zero placement, FLT_MIN-scaled subnormals, one/all-block gate NaNs, negative up NaNs, and both signs of saturated E4M3 gate/up. Native helper used only as synthetic reference.';save()
 for rank in range(4):
  case=dict(name=f'synthetic/rank{rank}',fc1=torch.cat((fq[:,rank*128:(rank+1)*128],fq[:,512+rank*128:512+(rank+1)*128]),1).reshape(64,8,256).cpu(),scale=torch.stack((fs[rank],fs[rank+4])).reshape(2,64,8).permute(1,0,2).contiguous().cpu(),expected=native_out[:,rank*128:(rank+1)*128].reshape(64,8,128).contiguous().cpu(),expected_scale=native_scale[rank].reshape(64,8).contiguous().cpu())
  stage(case);call();torch.cuda.synchronize();verify(case,'eager/'+case['name'])
  stage(case);graph.replay();torch.cuda.synchronize();verify(case,'graph/'+case['name'])
 report.update(status='PASS',passed=True,source_status_after=subprocess.check_output(['git','status','--porcelain'],cwd=OUT.parent/'source-metadata-rebase-95fcb0e',text=True));save()
 print(json.dumps(dict(status='PASS',cases=len(report['cases']),checks=len(report['checks']),timing_allowed=False)),flush=True)
try:main()
except BaseException:
 report.update(status='FAIL',passed=False,error=traceback.format_exc());save();raise
