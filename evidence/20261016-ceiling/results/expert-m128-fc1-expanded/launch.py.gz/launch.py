import os,sys,json,subprocess,hashlib,time
from pathlib import Path
OUT=Path(__file__).resolve().parent;ROOT=OUT.parent
GPU='GPU-53ed8fd9-9f5a-9c77-430d-095ad4fc860d'
os.environ['CUDA_VISIBLE_DEVICES']=''
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def processes():
 rows=subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid,pid,process_name,used_memory','--format=csv,noheader,nounits'],text=True)
 return [x for x in rows.splitlines() if x.startswith(GPU)]
assert not processes(), 'GPU0 has active compute process'
prep=json.loads((OUT/'prepare.json').read_text());assert prep['status']=='CPU_AOT_PASS'
sys.path.insert(0,str(OUT));import common as c
assert json.loads((OUT/'resource-audit/result.json').read_text())['status']=='CPU_RESOURCE_PASS'
assert not c.torch.cuda.is_initialized()
argv=['/home/zjy/code/hsliu/venvs/codex-drama3-standalone/bin/python',str(OUT/'probe.py'),'run']
env=os.environ.copy();env.update(CUDA_VISIBLE_DEVICES=GPU,OMP_NUM_THREADS='4',HF_MODULES_CACHE=str(ROOT/'hf_modules'),HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',PYTHONUNBUFFERED='1')
protocol={'hypothesis':'M128 native MMA and corrected single-epilogue store generalize from selected expert to all 15 native full-routing oracles while preserving all FC1 FP8 bytes/scales. No speed claim.', 'isolated_variable':'M128 MMA/epilogue with M128-specific logical row store, versus original native archived FC1 outputs; K32 reduction and K128 scales unchanged.', 'fixed_controls':{'source_sha':prep['source_sha'],'layers':[0,19,39],'oracles':15,'experts':256,'topk':8,'batch':64,'mma':[128,8,32],'tile':[128,8,128],'stages':4,'shared_bytes':prep['shared_bytes']},'gpu_uuid':GPU,'gate':'All native bytes and FP32 scale bits exact; empty/partial/padded rows ownership, same captured graph with changing metadata, input/weight/RNG ownership; archived zero/tiny native oracles. CPU/GPU cubin identical.','stop':'First failure preserved; no tolerance relaxation, timing or service claims','scope':'FC1 component only; complete native MoE body remains a separate gate','argv':argv,'environment':{k:env[k] for k in ('CUDA_VISIBLE_DEVICES','OMP_NUM_THREADS','HF_MODULES_CACHE')},'cpu_affinity':sorted(os.sched_getaffinity(0)),'storage':[subprocess.check_output(['findmnt','-T',str(p),'--json'],text=True) for p in (Path(sys.executable),c.CKPT,ROOT)],'timing_allowed':False}
(OUT/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
index=json.loads((c.CKPT/'model.safetensors.index.json').read_text())['weight_map']
shards={f for k,f in index.items() if any(k.startswith(f'model.language_model.layers.{layer}.mlp.experts.') for layer in (0,19,39))}
files=[OUT/'probe.py',OUT/'launch.py',OUT/'protocol.json',OUT/'prepare.json',OUT/'common.py',OUT/'gmem_c_resources_m128_v2.py',OUT/'epilogue.patch',ROOT/'expert-m128-native-v2/gpu-result.json',*list((OUT/'cpu-compile').glob('*')),*list((OUT/'resource-audit').glob('*')),*list((ROOT/'expert-metadata-rebase').glob('oracle-layer*.pt')),*list((ROOT/'expert-fc1-native-v3').glob('synthetic-*-oracle.pt')),c.CKPT/'model.safetensors.index.json',*[c.CKPT/f for f in sorted(shards)]]
files += [Path(m.__file__) for name,m in sys.modules.copy().items() if name.startswith(('flashinfer.prims_ts','cutlass.experimental.task_scheduling','cutlass.pipeline')) and getattr(m,'__file__',None) and str(m.__file__).endswith('.py')]
(OUT/'frozen-inputs.json').write_text(json.dumps({str(p):sha(p) for p in files if p.is_file()},indent=2)+'\n')
assert not processes()
with (OUT/'gpu.log').open('w') as f,(OUT/'process-audit.jsonl').open('w') as a:
 p=subprocess.Popen(argv,env=env,stdout=f,stderr=subprocess.STDOUT);(OUT/'pid.json').write_text(json.dumps({'pid':p.pid,'gpu_uuid':GPU})+'\n')
 while p.poll() is None:
  a.write(json.dumps({'time':time.time(),'processes':processes()})+'\n');a.flush()
  if any(int(x.split(',')[1])!=p.pid for x in processes()):
   p.terminate();raise RuntimeError('Competing GPU0 process; no timing claim')
  time.sleep(2)
 code=p.wait();after=processes()
(OUT/'exit.json').write_text(json.dumps({'exit_code':code,'post_processes':after})+'\n');print('exit',code);sys.exit(code)
