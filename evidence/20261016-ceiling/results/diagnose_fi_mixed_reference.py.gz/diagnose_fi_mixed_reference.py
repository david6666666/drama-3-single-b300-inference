"""Independent FP32 and padding-isolation investigation; original FI FAIL retained."""

import argparse
import hashlib
import json
import math
import os
import subprocess
import sys
from pathlib import Path
from types import SimpleNamespace

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--source", type=Path, required=True)
parser.add_argument("--checkpoint", required=True)
parser.add_argument("--corpus", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
sys.path.insert(0, str(args.source / "src"))
sys.path.insert(0, str(args.source / "scripts"))
import torch
import torch.nn.functional as F
import triton
from fish_speech.models.text2semantic.fish_omni.generate import build_drama3_prompt
from validate_mixed_layers import Checks, restore, snapshot, state_tensors
import drama3.mixed_model as mixed_model
from drama3.engine import BatchedPrefillGraph, DecodeGraph, state_pool_size
from drama3.mixed_graph import MixedGraph
from drama3.model import DramaModel
from drama3.runtime_state import DeviceRequests


def metric(actual, expected):
    finite = bool(torch.isfinite(actual).all() & torch.isfinite(expected).all())
    a, b = actual.float(), expected.float()
    rrms = float(((a - b).square().mean() / b.square().mean().clamp_min(1e-12)).sqrt())
    return dict(
        finite=finite,
        rrms=rrms if math.isfinite(rrms) else None,
        actual_rms=float(a.square().mean().sqrt()),
        reference_rms=float(b.square().mean().sqrt()),
        error_rms=float((a - b).square().mean().sqrt()),
        max_abs_error=float((a - b).abs().max()),
    )


def fp32_reference(
    q, k, v, decay, beta, before, layout, actual, actual_state, expected, expected_state
):
    from sglang.kernels.ops.attention.fla.l2norm import l2norm_fwd

    qn = l2norm_fwd(q.contiguous()).float().repeat_interleave(2, dim=2)[0]
    kn = l2norm_fwd(k.contiguous()).float().repeat_interleave(2, dim=2)[0]
    alpha = decay.exp()[0]
    rows = []
    boundaries = layout.boundaries.tolist()
    saved = dict(
        q=q.cpu(),
        k=k.cpu(),
        v=v.cpu(),
        decay=decay.cpu(),
        beta=beta.cpu(),
        boundaries=layout.boundaries.cpu(),
        state_slots=layout.sequence_slots.cpu(),
        initial_states=before.index_select(0, layout.sequence_slots).cpu(),
        fi_output=actual.cpu(),
        fla_output=expected.cpu(),
        fi_state=actual_state.index_select(0, layout.sequence_slots).cpu(),
        fla_state=expected_state.index_select(0, layout.sequence_slots).cpu(),
    )
    reference_outputs = []
    reference_states = []
    for seq, (start, end) in enumerate(zip(boundaries[:-1], boundaries[1:])):
        slot = int(layout.sequence_slots[seq])
        state = before[slot].float().clone()
        values = []
        for token in range(start, end):
            decayed = state * alpha[token, :, None, None]
            residual = v[0, token].float() - (decayed * kn[token, :, None, :]).sum(-1)
            state = (
                decayed
                + (residual * beta[0, token, :, None])[:, :, None]
                * kn[token, :, None, :]
            )
            values.append((state * qn[token, :, None, :]).sum(-1) * (128**-0.5))
        if not values:
            continue
        reference = torch.stack(values)
        rows.append(
            dict(
                sequence=seq,
                kind="real" if seq < 6 else "padding",
                length=end - start,
                slot=slot,
                fi_output=metric(actual[0, start:end], reference),
                fla_output=metric(expected[0, start:end], reference),
                fi_state=metric(actual_state[slot], state),
                fla_state=metric(expected_state[slot], state),
            )
        )
        reference_outputs.append(reference.cpu())
        reference_states.append(state.cpu())
    saved.update(reference_outputs=reference_outputs, reference_states=reference_states)
    torch.save(saved, Path(__file__).parent / "fi-mixed-layer0-reference-inputs.pt")
    return rows


@torch.inference_mode()
def main():
    raw = args.corpus.read_bytes()
    checks = Checks(
        args.output,
        dict(
            source_sha=subprocess.check_output(
                ["git", "rev-parse", "HEAD"], cwd=args.source, text=True
            ).strip(),
            source_status=subprocess.check_output(
                ["git", "status", "--porcelain"], cwd=args.source, text=True
            ),
            corpus_sha256=hashlib.sha256(raw).hexdigest(),
            driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            runtime_sha256={
                str(p.relative_to(args.source)): hashlib.sha256(
                    p.read_bytes()
                ).hexdigest()
                for p in sorted((args.source / "src/drama3").glob("*.py"))
            },
            gpu_uuid=str(torch.cuda.get_device_properties(0).uuid),
            environment={
                k: v for k, v in os.environ.items() if k.startswith("DRAMA3_")
            },
            experiment=json.loads(
                (
                    Path(__file__).parent / "fi-mixed-reference-experiment.json"
                ).read_text()
            ),
        ),
    )
    try:
        if os.environ.get("DRAMA3_COMPACT_GDN") != "0":
            raise ValueError("Compaction must be off")
        model = DramaModel(args.checkpoint, slots=state_pool_size(64), max_length=2048)
        if model.prefill_moe != "flashinfer" or model.tuned_prefill_moe:
            raise ValueError("Require native untuned FI MoE")
        device = DeviceRequests(
            model.slots, model.config.eos_token_id, model.max_length
        )
        samples = [json.loads(line) for line in raw.splitlines()][:64]
        prompts = [
            build_drama3_prompt(
                s["text"],
                model.weights.tokenizer,
                model.config,
                [s["reference_text"]],
                [torch.tensor(s["reference_codes"])],
            )
            for s in samples
        ]
        model.prefill_gdn = "fla"
        prefill = BatchedPrefillGraph(
            model, 8, triton.next_power_of_2(max(map(len, prompts)))
        )
        first = DecodeGraph(model, 8, first_frame=True, requests=device)
        tensors = state_tensors(model, device)

        def ownership(label, before, owned):
            other = torch.tensor(
                [s for s in range(model.slots) if s not in owned], device="cuda"
            )
            for (name, value), saved in zip(tensors.items(), before, strict=True):
                if name.startswith(("conv/", "gdn/", "key/", "value/")):
                    checks.tensor(
                        label + "/" + name + "/untouched",
                        value.index_select(0, other),
                        saved.index_select(0, other),
                        exact=True,
                    )
                else:
                    checks.tensor(
                        label + "/" + name + "/unchanged", value, saved, exact=True
                    )

        def same_input_layers(graph, label, initial):
            original = mixed_model.gdn_prefill
            visited = []

            def probe(
                q, k, v, decay, beta, state, slots, length, *, backend, packed_layout
            ):
                before = state.clone()
                actual = original(
                    q,
                    k,
                    v,
                    decay,
                    beta,
                    state,
                    slots,
                    length,
                    backend="flashinfer",
                    packed_layout=packed_layout,
                )
                candidate = state.clone()
                layer = next(i for i, pair in model.states.items() if pair[1] is state)
                try:
                    state.copy_(before)
                    expected = original(
                        q,
                        k,
                        v,
                        decay,
                        beta,
                        state,
                        slots,
                        length,
                        backend="fla",
                        packed_layout=packed_layout,
                    )
                    bounds = packed_layout.boundaries.tolist()
                    output_rows = [
                        metric(actual[:, a:b], expected[:, a:b])
                        for a, b in zip(bounds[:-1], bounds[1:])
                        if b > a
                    ]
                    state_rows = [
                        metric(candidate[s], state[s])
                        for s in packed_layout.sequence_slots.tolist()
                    ]
                    row = dict(
                        name=f"{label}/layer{layer}/same_input",
                        layer=layer,
                        output=metric(actual, expected),
                        output_sequences=output_rows,
                        state_sequences=state_rows,
                    )
                    if layer == 0:
                        checks.report["fp32_reference"] = fp32_reference(
                            q,
                            k,
                            v,
                            decay,
                            beta,
                            before,
                            packed_layout,
                            actual,
                            candidate,
                            expected,
                            state,
                        )
                        checks.flush()
                    row["real_domain_gate"] = all(
                        r["finite"] and r["rrms"] is not None and r["rrms"] < 0.01
                        for r in [*output_rows[:6], *state_rows[:6]]
                    )
                    row["padding_finite"] = all(
                        r["finite"] for r in [*output_rows[6:], *state_rows[6:]]
                    )
                    row["passed"] = row["real_domain_gate"] and row["padding_finite"]
                    print(
                        json.dumps(
                            dict(
                                layer=layer,
                                real_output_max=max(r["rrms"] for r in output_rows[:6]),
                                real_state_max=max(r["rrms"] for r in state_rows[:6]),
                                padding_output=output_rows[-1]["rrms"],
                            )
                        ),
                        flush=True,
                    )
                    checks.report["checks"].append(row)
                    checks.flush()
                    if not row["passed"]:
                        raise AssertionError(row)
                    untouched = torch.tensor(
                        [
                            s
                            for s in range(model.slots)
                            if s not in packed_layout.sequence_slots.tolist()
                        ],
                        device="cuda",
                    )
                    checks.tensor(
                        f"{label}/layer{layer}/untouched",
                        candidate.index_select(0, untouched),
                        before.index_select(0, untouched),
                        exact=True,
                    )
                    visited.append(layer)
                finally:
                    state.copy_(candidate)
                return actual

            mixed_model.gdn_prefill = probe
            model.prefill_gdn = "flashinfer"
            try:
                result = graph.forward()
                eager_output = snapshot(result)
                eager_state = snapshot(tensors.values())
            finally:
                mixed_model.gdn_prefill = original
                restore(tensors.values(), initial)
            if len(visited) != 30 or len(set(visited)) != 30:
                raise AssertionError(("Missing layers", visited))
            graph.graph.replay()
            for index, (actual, expected) in enumerate(
                zip(graph.output, eager_output, strict=True)
            ):
                checks.tensor(
                    f"{label}/fi_eager_replay/output{index}",
                    actual,
                    expected,
                    exact=True,
                )
            for (name, actual), expected in zip(
                tensors.items(), eager_state, strict=True
            ):
                checks.tensor(
                    f"{label}/fi_eager_replay/{name}", actual, expected, exact=True
                )
            restore(tensors.values(), initial)
            checks.report["layer_indices"] = visited
            checks.flush()

        for count, arriving in [(58, 6)]:
            selected = prompts[count : count + arriving]
            capacity = triton.cdiv(sum(map(len, selected)), 256) * 256
            d = next(n for n in (16, 32, 48, 64) if n >= count)
            label = f"d{count}-p{arriving}"
            print(label, flush=True)
            model.prefill_gdn = "fla"
            control = MixedGraph(model, device, d, 8, capacity, max_length=256)
            model.prefill_gdn = "flashinfer"
            candidate = MixedGraph(model, device, d, 8, capacity, max_length=256)
            active = [
                SimpleNamespace(slot=i, position=len(prompts[i]) - 1)
                for i in range(count)
            ]
            for i, p in enumerate(prompts[:count]):
                history = F.pad(p[-16:, 0], (max(0, 16 - len(p)), 0), value=-1).cuda()
                device.initialize(i, p[-1].cuda(), history, len(p) - 1, 500)
            for start in range(0, count, 8):
                end = min(start + 8, count)
                hidden = prefill.run(prompts[start:end], list(range(start, end)))
                first.run(active[start:end], hidden)
            slots = list(range(count, count + arriving))
            control.prepare(active, selected, slots)
            candidate.prepare(active, selected, slots)
            initial = snapshot(tensors.values())
            owned = set(
                candidate.slots[:d].tolist() + candidate.layout.sequence_slots.tolist()
            )
            if count == 58:
                same_input_layers(candidate, label, initial)
            control.graph.replay()
            expected_out = snapshot(control.output)
            expected_state = snapshot(tensors.values())
            ownership(label + "/fla", initial, owned)
            restore(tensors.values(), initial)
            candidate.graph.replay()
            ownership(label + "/fi", initial, owned)
            drift = dict(
                output=[
                    metric(a, b)
                    for a, b in zip(candidate.output, expected_out, strict=True)
                ],
                state={},
            )
            selected_slots = torch.tensor(sorted(owned), device="cuda")
            for (name, actual), expected in zip(
                tensors.items(), expected_state, strict=True
            ):
                if name.startswith(("conv/", "gdn/", "key/", "value/")):
                    drift["state"][name] = metric(
                        actual.index_select(0, selected_slots),
                        expected.index_select(0, selected_slots),
                    )
            if not all(
                r["finite"] for r in [*drift["output"], *drift["state"].values()]
            ):
                raise AssertionError("Non-finite trajectory")
            baseline_output = snapshot(candidate.output)
            real_slots = torch.arange(count + arriving, device="cuda")
            baseline_real = {
                name: value.index_select(0, real_slots).clone()
                for name, value in tensors.items()
                if name.startswith(("conv/", "gdn/", "key/", "value/"))
            }
            restore(tensors.values(), initial)
            original = mixed_model.gdn_prefill

            def zero_padding(*inputs, **kwargs):
                result = original(*inputs, **kwargs)
                start = int(kwargs["packed_layout"].boundaries[-2])
                result[:, start:] = 0
                return result

            mixed_model.gdn_prefill = zero_padding
            model.prefill_gdn = "flashinfer"
            try:
                changed_output = candidate.forward()
            finally:
                mixed_model.gdn_prefill = original
            checks.tensor(
                label + "/padding_intervention/decode_real",
                changed_output[0][:count],
                baseline_output[0][:count],
                exact=True,
            )
            checks.tensor(
                label + "/padding_intervention/prefill_real",
                changed_output[1][:arriving],
                baseline_output[1][:arriving],
                exact=True,
            )
            for name, expected in baseline_real.items():
                checks.tensor(
                    label + "/padding_intervention/" + name,
                    tensors[name].index_select(0, real_slots),
                    expected,
                    exact=True,
                )
            checks.report["padding_intervention"] = (
                "Exact real outputs/state after zeroing only private trailing GDN outputs in all30layers"
            )
            row = dict(
                case=label,
                active=count,
                arriving=arriving,
                capacity=capacity,
                span=256,
                prompt_lengths=list(map(len, selected)),
                trajectory_drift=drift,
                passed=True,
            )
            checks.report["cases"].append(row)
            checks.flush()
            print(
                json.dumps({k: v for k, v in row.items() if k != "trajectory_drift"}),
                flush=True,
            )
            del initial, expected_state, expected_out, control, candidate
        checks.report["status"] = "DIAGNOSTIC_COMPLETE"
        checks.flush()
    except Exception as error:
        checks.report["status"] = "FAIL"
        checks.report["failure"] = dict(type=type(error).__name__, message=str(error))
        checks.flush()
        raise


if __name__ == "__main__":
    main()
