"""Observe native mixed MoE row identity; no deduplication and no timing."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent
SOURCE = ROOT / 'source-codec-cache'
SOURCE_SHA = 'e7cda1eba083603b88e1f2e89688e1ff2ced7fc2'
CORPUS = Path('/home/zjy/code/hsliu/artifacts/drama3-b300-20261014/seedtts-en1088-codes/requests.jsonl')
CHECKPOINT = '/home/zjy/.cache/huggingface/hub/models--fishaudio--drama-3/snapshots/e0a9218aa48888270f06ef1ed9ea67622c0e17d2'
sys.path[:0] = [str(SOURCE / 'src'), str(SOURCE / 'scripts')]
import torch

CASES = [
    ('proxy190', list(range(1040, 1048)), list(range(56, 64))),
    ('proxy190_reversed_reused_graph', list(reversed(range(1040, 1048))), list(reversed(range(56, 64)))),
    ('proxy192_changed_conditioning_reused_graph', list(range(1053, 1061)), list(range(56, 64))),
]
D, P, SPAN, ACTIVE = 64, 1536, 256, 56


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def tensor_bytes(x):
    return x.contiguous().view(torch.uint8).numpy().tobytes()


def alias_plan(prompts, corpus_indices, rows):
    """Exact full causal bytes; only within-request prefix and positions >=0."""
    owners, aliases, negatives, descriptions = {}, [], [], []
    starts, offset = [], D
    for prompt, corpus_index in zip(prompts, corpus_indices, strict=True):
        starts.append(offset)
        entry = rows[corpus_index]
        prefix = entry['prefix_rows']
        assert len(prompt) == entry['prompt_rows'] and 25 <= prefix < len(prompt)
        prefix_blob = tensor_bytes(prompt[:prefix])
        assert hashlib.sha256(prefix_blob).hexdigest() == entry['prefix_sha256']
        descriptions.append(dict(corpus_index=corpus_index, prompt_rows=len(prompt),
            prefix_rows=prefix, prefix_sha256=entry['prefix_sha256'],
            full_prompt_sha256=hashlib.sha256(tensor_bytes(prompt)).hexdigest(),
            reference_sha256=entry['reference_sha256'], absolute_position_start=0,
            initial_recurrent_state='zero; native MixedGraph.forward reset',
            initial_valid_KV_length=0, history_used_by_backbone=False))
        for position in range(prefix):
            # Cross-reference reuse remains capped at the previously counted 25 rows.
            group = 'common25' if position < 25 else entry['prefix_sha256']
            key = (group, position, tensor_bytes(prompt[:position + 1]))
            row = offset + position
            if key in owners:
                aliases.append((row, owners[key], position))
            else:
                owners[key] = row
        offset += len(prompt)
    for a in range(len(prompts)):
        for b in range(a + 1, len(prompts)):
            unequal = (prompts[a][:min(len(prompts[a]), len(prompts[b]))] !=
                       prompts[b][:min(len(prompts[a]), len(prompts[b]))]).any(-1)
            positions = unequal.nonzero().flatten()
            if len(positions):
                position = int(positions[0])
                pair = (starts[b] + position, starts[a] + position, position)
                assert pair not in aliases
                negatives.append(pair)
    assert aliases and negatives
    assert all(a >= D and b >= D and a != b for a, b, _ in aliases)
    return aliases, negatives, descriptions


def cpu_check():
    a = torch.arange(12 * 11, dtype=torch.int64).reshape(12, 11)
    assert tensor_bytes(a) == tensor_bytes(a.clone())
    assert tensor_bytes(a[:1]) != tensor_bytes(a[1:2])
    assert not torch.cuda.is_initialized()
    return dict(import_without_cuda=True, source_sha=subprocess.check_output(
        ['git', 'rev-parse', 'HEAD'], cwd=SOURCE, text=True).strip(),
        cases=CASES, shape=[40, D + P, 2048])


@torch.inference_mode()
def main():
    import torch.nn.functional as F
    import triton
    from fish_speech.models.text2semantic.fish_omni.generate import build_drama3_prompt
    from drama3.engine import BatchedPrefillGraph, DecodeGraph, state_pool_size
    from drama3.mixed_graph import MixedGraph
    from drama3.model import DramaModel
    from drama3.runtime_state import DeviceRequests
    report = dict(status='RUNNING', scope='Original native mixed computation plus copy-only observation; no compaction, timing or service claim',
        source_sha=SOURCE_SHA, source_status=subprocess.check_output(['git', 'status', '--porcelain'], cwd=SOURCE, text=True),
        driver_sha256=sha(__file__), corpus_sha256=sha(CORPUS), pid=os.getpid(),
        environment={k:v for k,v in os.environ.items() if k.startswith(('DRAMA3_', 'CUDA_'))},
        cases=[], exact_gate='Every proposed alias has identical BF16 bytes at all 40 actual MoE inputs',
        fifo_caveat='Corpus groups match the proxy, not measured admission request IDs',
        source_files={str(p.relative_to(SOURCE)):sha(p) for p in sorted((SOURCE/'src/drama3').glob('*.py'))})
    result = OUT / 'capture-result.json'
    def flush():
        result.write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
    flush()
    try:
        assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip() == SOURCE_SHA
        assert not report['source_status']
        protocol = json.loads((OUT/'protocol.json').read_text())
        for path, expected in protocol['frozen_files'].items():
            assert sha(path) == expected, path
        props = torch.cuda.get_device_properties(0)
        report['device'] = dict(name=props.name, uuid=str(props.uuid), logical_device=0)
        samples = [json.loads(row) for row in CORPUS.read_bytes().splitlines()]
        rows = json.loads((ROOT/'reference-prefix/per-request.json').read_text())
        model = DramaModel(CHECKPOINT, slots=state_pool_size(64), max_length=2048)
        assert model.fused_moe_residual and model.fused_moe_input and model.reserved_padding_router
        assert model.prefill_moe == 'flashinfer' and model.prefill_gdn == 'fla'
        assert model.moe_shared_stream is None
        device = DeviceRequests(model.slots, model.config.eos_token_id, model.max_length)
        indices = sorted(set(range(ACTIVE)) | {i for _, group, _ in CASES for i in group})
        prompts = {i:build_drama3_prompt(samples[i]['text'],model.weights.tokenizer,model.config,
                    [samples[i]['reference_text']],[torch.tensor(samples[i]['reference_codes'])]) for i in indices}
        prefill = BatchedPrefillGraph(model, 8, triton.next_power_of_2(max(len(prompts[i]) for i in range(ACTIVE))))
        first = DecodeGraph(model, 8, first_frame=True, requests=device)
        observed = torch.empty((40, D + P, 2048), device='cuda', dtype=torch.bfloat16)
        calls = []
        layer_ids = {id(layer.mlp):i for i,layer in enumerate(model.backbone.layers)}
        original = model.moe_parts
        def observe(x, layer, decode=False, *, row_slots=None):
            index = layer_ids[id(layer)]
            assert decode and x.shape == observed[index].shape and x.dtype == torch.bfloat16
            assert row_slots is not None and row_slots.shape == (D+P,)
            assert x.data_ptr() != observed[index].data_ptr()
            observed[index].copy_(x)
            calls.append(index)
            return original(x, layer, decode=decode, row_slots=row_slots)
        model.moe_parts = observe
        try:
            graph = MixedGraph(model, device, D, 8, P, max_length=SPAN)
        finally:
            model.moe_parts = original
        assert calls == list(range(40)) * 3, calls
        # All capture writes precede initialization of authentic decode and prompt slots.
        for case_name, group, slots in CASES:
            selected = [prompts[i] for i in group]
            aliases, negatives, descriptions = alias_plan(selected, group, rows)
            entry = dict(case=case_name, corpus_indices=group, arriving_slots=slots,
                conditioning=descriptions, aliases=aliases, nonshared_controls=negatives,
                alias_count=len(aliases), layer_checks=[], passed=False,
                graph_identity=id(graph.graph), state_reinitialized_after_capture=True)
            report['cases'].append(entry); flush()
            print(json.dumps(dict(stage='initialize',case=case_name,aliases=len(aliases))), flush=True)
            for pair in model.states.values():
                for state in pair: state.zero_()
            for pair in model.kv.values():
                for state in pair: state.zero_()
            device.last.zero_(); device.last[:,0] = model.config.eos_token_id
            device.history.fill_(-1); device.metadata.zero_(); device.metadata[:,0] = model.max_length-1
            device.metadata[:,2] = 500; device.codes.zero_()
            active = [SimpleNamespace(slot=i,position=len(prompts[i])-1) for i in range(ACTIVE)]
            for i in range(ACTIVE):
                prompt=prompts[i]
                history=F.pad(prompt[-16:,0],(max(0,16-len(prompt)),0),value=-1).cuda()
                device.initialize(i,prompt[-1].cuda(),history,len(prompt)-1,500)
            for start in range(0,ACTIVE,8):
                end=min(start+8,ACTIVE)
                hidden=prefill.run([prompts[i] for i in range(start,end)],list(range(start,end)))
                first.run(active[start:end],hidden)
            graph.prepare(active,selected,slots)
            decode_slots=graph.slots[:D].cpu().tolist()
            prefill_slots=graph.layout.sequence_slots.cpu().tolist()
            assert len(set(decode_slots+prefill_slots)) == len(decode_slots)+len(prefill_slots)
            expected_frames=torch.cat(selected)
            expected_positions=torch.cat([torch.arange(len(p)) for p in selected])
            request_before={name:getattr(device,name).clone() for name in ('last','history','metadata','codes')}
            sampler_before=model.sampling_step.clone()
            graph.graph.replay()
            torch.cuda.synchronize()
            captured = observed.cpu()
            torch.save(captured,OUT/f'{case_name}-moe-inputs.pt')
            frames,positions,row_slots = graph.frames.cpu(),graph.positions.cpu(),graph.slots.cpu()
            assert torch.equal(frames[D:D+len(expected_frames)],expected_frames)
            assert torch.equal(positions[D:D+len(expected_frames)],expected_positions)
            for name,before in request_before.items():
                assert torch.equal(getattr(device,name),before),name
            assert torch.equal(model.sampling_step,sampler_before)
            torch.save(dict(frames=frames,positions=positions,row_slots=row_slots,
                boundaries=graph.layout.boundaries.cpu(),sequence_slots=graph.layout.sequence_slots.cpu(),
                decode_history=graph.history.cpu(),request_metadata=request_before['metadata'].cpu(),
                aliases=aliases,negative_controls=negatives,conditioning=descriptions),OUT/f'{case_name}-inputs.pt')
            left=torch.tensor([x[0] for x in aliases]); right=torch.tensor([x[1] for x in aliases])
            pos=torch.tensor([x[2] for x in aliases])
            assert torch.equal(positions[left],pos) and torch.equal(positions[right],pos)
            assert torch.equal(frames[left],frames[right])
            nleft=torch.tensor([x[0] for x in negatives]); nright=torch.tensor([x[1] for x in negatives])
            failure_rows=[]
            for index in range(40):
                a,b=captured[index,left],captured[index,right]
                equal=(a.view(torch.uint8)==b.view(torch.uint8)).all(-1)
                delta=(a.float()-b.float()).abs()
                row=dict(layer=index,alias_count=len(aliases),equal_rows=int(equal.sum()),
                    different_rows=int((~equal).sum()),byte_exact=bool(equal.all()),
                    max_abs=float(delta.max()),finite=bool(torch.isfinite(a).all() & torch.isfinite(b).all()),
                    nonshared_control_different_rows=int((captured[index,nleft].view(torch.uint8) != captured[index,nright].view(torch.uint8)).any(-1).sum()),
                    input_sha256=hashlib.sha256(tensor_bytes(captured[index])).hexdigest())
                entry['layer_checks'].append(row)
                if not row['byte_exact']:
                    bad=(~equal).nonzero().flatten()[:8]
                    failure_rows.append(dict(layer=index,aliases=[aliases[j] for j in bad.tolist()],left=a[bad],right=b[bad]))
            entry['source_conditioning_and_positions_exact']=True
            entry['request_state_and_sampling_counter_read_only']=True
            entry['passed']=all(x['byte_exact'] and x['finite'] for x in entry['layer_checks'])
            flush()
            if not entry['passed']:
                torch.save(failure_rows,OUT/f'{case_name}-failure-rows.pt')
                raise AssertionError('Native alias identity failed; remaining cases and compaction are not run')
            print(json.dumps(dict(stage='case_passed',case=case_name,aliases=len(aliases))),flush=True)
        report['status']='PASS'
    except Exception as error:
        report['status']='FAIL'
        report['failure']=dict(type=type(error).__name__,message=str(error))
        flush()
        raise
    flush()
    return model, device


if __name__ == '__main__':
    if '--cpu-check' in sys.argv:
        print(json.dumps(cpu_check(),indent=2))
    else:
        main()
