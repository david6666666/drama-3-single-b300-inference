"""CPU bidirectional causal mapping; preserve all decode and original padding."""
import json
from pathlib import Path
import torch
ROOT=Path(__file__).resolve().parent.parent
OUT=Path(__file__).resolve().parent
FULL=1600
COMPACT=1088


def build_mapping(case):
    alias={a:b for a,b,_ in case['aliases']}
    assert len(alias)==case['alias_count']
    assert all(64<=b<a<FULL and b not in alias for a,b in alias.items())
    keep=[i for i in range(FULL) if i not in alias]
    unique=len(keep)
    assert unique<=COMPACT and COMPACT%64==0
    assert keep[:64]==list(range(64))
    padding_start=64+sum(x['prompt_rows'] for x in case['conditioning'])
    assert all(i in keep for i in range(padding_start,FULL))
    inverse_owner={row:i for i,row in enumerate(keep)}
    inverse=[inverse_owner[alias.get(i,i)] for i in range(FULL)]
    keep += [0]*(COMPACT-len(keep))
    assert all(keep[inverse[i]]==alias.get(i,i) for i in range(FULL))
    for a,b,_ in case['nonshared_controls']: assert inverse[a]!=inverse[b]
    return torch.tensor(keep),torch.tensor(inverse),unique


def main():
    report=json.loads((ROOT/'native-row-reuse-audit/alias-result.json').read_text())
    assert report['status']=='PASS'
    result=[]
    for case in report['cases']:
        keep,inverse,unique=build_mapping(case)
        original=torch.arange(FULL)
        expanded=original[keep][inverse]
        for a,b,_ in case['aliases']:assert expanded[a]==b
        assert torch.equal(expanded[:64],original[:64])
        result.append(dict(case=case['case'],unique_rows=unique,compact_rows=COMPACT,
            appended_row0_copies=COMPACT-unique,aliases=case['alias_count'],
            all_decode_and_original_padding_kept=True,bidirectional_mapping_exact=True))
    assert not torch.cuda.is_initialized()
    output=dict(status='CPU_PASS',cuda_initialized=False,cases=result,
        negative_controls_excluded=True,capacity='Fixed1088, 64aligned, same graph supports all cases')
    (OUT/'mapping-cpu.json').write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps(output,indent=2))
if __name__=='__main__':main()
