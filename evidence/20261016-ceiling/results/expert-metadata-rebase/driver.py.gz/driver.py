"""Native prepared no-finalize bodies; local metadata versus shared native rebase."""
import hashlib,json,os,subprocess,time,traceback,statistics
from pathlib import Path
from types import SimpleNamespace
from contextlib import ExitStack
import torch,triton
import triton.language as tl
from safetensors import safe_open
from flashinfer.fused_moe import core as fi
from flashinfer.fused_moe.shared.inputs import MoeRunnerInputs
from flashinfer.tllm_enums import DtypeTrtllmGen,Fp8QuantizationType,RoutingInputMode
from drama3.moe_input import prepare_moe_input, prepare_kernel
import tvm_ffi
ROOT=Path('/home/zjy/code/hsliu/artifacts/drama3-ceiling-20261016')
OUT=Path(__file__).resolve().parent
SOURCE=ROOT/'source-metadata-rebase-95fcb0e'
CKPT=Path('/home/zjy/.cache/huggingface/hub/models--fishaudio--drama-3/snapshots/e0a9218aa48888270f06ef1ed9ea67622c0e17d2')
INPUT=ROOT/'padding-router-b63-native-inputs.pt'
report=dict(status='PREPARING',source_sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip(),source_status=subprocess.check_output(['git','status','--porcelain'],cwd=SOURCE,text=True),driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),input_sha256=hashlib.sha256(INPUT.read_bytes()).hexdigest(),pid=os.getpid(),cases=[],checks=[],timings_allowed=False)
def flush():
 (OUT/'result.json').write_text(json.dumps(report,indent=2)+'\n')
def chk(name,a,b):
 av=a.detach().contiguous();bv=b.detach().contiguous()
 equal=av.shape==bv.shape and av.dtype==bv.dtype and torch.equal(av.view(torch.uint8),bv.view(torch.uint8))
 row=dict(name=name,exact=equal,shape=list(av.shape),dtype=str(av.dtype))
 if not equal:
  if av.shape==bv.shape:
   diff=av.float()-bv.float();row.update(maxabs=diff.abs().max().item(),rrms=(diff.square().mean().sqrt()/(bv.float().square().mean().sqrt()+1e-30)).item(),changed=int((av!=bv).sum().item()))
  torch.save({'a':av.cpu(),'b':bv.cpu()},OUT/(name.replace('/','_')+'-mismatch.pt'))
 report['checks'].append(row);flush()
 if not equal:raise AssertionError(row)
def require(name,condition,detail=None):
 report['checks'].append(dict(name=name,exact=bool(condition),detail=detail));flush()
 if not condition:raise AssertionError(name)
def sha_tensor(t):return hashlib.sha256(t.detach().contiguous().view(torch.uint8).cpu().numpy().tobytes()).hexdigest()
@triton.jit
def finalize2(F0,F1,M0,M1,W,O,B:tl.constexpr):
 token=tl.program_id(0);h=tl.program_id(1)*B+tl.arange(0,B)
 acc=tl.full((B,),0,tl.float32)
 for k in tl.static_range(8):
  p0=tl.load(M0+token*8+k);p1=tl.load(M1+token*8+k)
  a=tl.load(F0+p0*2048+h,mask=p0>=0,other=0).to(tl.float32)
  b=tl.load(F1+p1*2048+h,mask=p1>=0,other=0).to(tl.float32)
  v=tl.where(p0>=0,a,b);w=tl.load(W+token*8+k).to(tl.float32)
  acc=tl.fma(w,v,acc)
 tl.store(O+token*2048+h,acc)
def finish(p0,p1,w):
 out=torch.empty((64,2048),device='cuda',dtype=torch.bfloat16)
 finalize2[(64,8)](p0[0],p1[0],p0[2],p1[2],w,out,256)
 return out

def load_weights(layer):
 index=json.loads((CKPT/'model.safetensors.index.json').read_text())['weight_map']
 def key(e,p,s):return f'model.language_model.layers.{layer}.mlp.experts.{e}.{p}.{s}'
 keys=[key(e,p,s) for e in range(256) for p in ('up_proj','gate_proj','down_proj') for s in ('weight','weight_scale_inv')]
 with ExitStack() as stack:
  handles={f:stack.enter_context(safe_open(str(CKPT/f),framework='pt',device='cpu')) for f in sorted({index[k] for k in keys})}
  def tensor(e,p,s):
   k=key(e,p,s);return handles[index[k]].get_tensor(k)
  w1=torch.stack([torch.cat((tensor(e,'up_proj','weight'),tensor(e,'gate_proj','weight')),0) for e in range(256)])
  s1=torch.stack([torch.cat((tensor(e,'up_proj','weight_scale_inv'),tensor(e,'gate_proj','weight_scale_inv')),0) for e in range(256)])
  w2=torch.stack([tensor(e,'down_proj','weight') for e in range(256)])
  s2=torch.stack([tensor(e,'down_proj','weight_scale_inv') for e in range(256)])
 return [t.cuda() for t in (w1,s1,w2,s2)]
def as_torch(t):return t if isinstance(t,torch.Tensor) else torch.from_dlpack(t)

@triton.jit
def rebase_impl(GCTA,GMN,GN,GMAP,GTOK,IDS,LP,LMAP,LTOK,LCTA,LMN,LN,PART:tl.constexpr):
 c=tl.arange(0,512)
 gn=tl.load(GN)
 experts=tl.load(GCTA+c,mask=c<gn,other=256)
 split=tl.sum(((c<gn)&(experts<128)).to(tl.int32),0)
 first=tl.where(PART==0,0,split)
 count=tl.where(PART==0,split,gn-split)
 base=first*8;p=count*8
 tl.store(LP,p);tl.store(LN,count)
 vals=tl.load(GCTA+first+c,mask=c<count,other=PART*128)-PART*128
 limits=tl.load(GMN+first+c,mask=c<count,other=base)-base
 tl.store(LCTA+c,vals,mask=c<288);tl.store(LMN+c,limits,mask=c<288)
 e=tl.load(IDS+c);gmap=tl.load(GMAP+c)
 local=(e>=PART*128)&(e<(PART+1)*128)
 tl.store(LMAP+c,tl.where(local,gmap-base,-1))
 r=tl.arange(0,4096)
 tokens=tl.load(GTOK+base+r,mask=r<p,other=0)
 # The vendor guard element exists at full capacity+1; initialize all padding.
 tl.store(LTOK+r,tokens,mask=r<2305)

@triton.jit
def rebase_pair(GCTA,GMN,GN,GMAP,GTOK,IDS,P0,M0,T0,C0,N0,K0,P1,M1,T1,C1,N1,K1):
 if tl.program_id(0)==0:
  rebase_impl(GCTA,GMN,GN,GMAP,GTOK,IDS,P0,M0,T0,C0,N0,K0,0)
 else:
  rebase_impl(GCTA,GMN,GN,GMAP,GTOK,IDS,P1,M1,T1,C1,N1,K1,1)

def tensors_of_slot(slot):
 return dict(padded=slot.total_num_padded_tokens,expanded=slot.expanded_idx_to_permuted_idx,tokens=slot.permuted_idx_to_token_idx,cta=slot.cta_idx_xy_to_batch_idx,mn=slot.cta_idx_xy_to_mn_limit,ncta=slot.num_non_exiting_ctas)

def gather(slot,ws):
 p=int(slot.total_num_padded_tokens.item());mapping=slot.expanded_idx_to_permuted_idx.long().flatten();valid=mapping>=0
 require('native_valid_map_bounds',bool((mapping[valid]<p).all()))
 out={}
 for name,wi,channels in (('fc1_bytes',0,1024),('activation_bytes',2,512),('fc2_bf16',4,2048)):
  out[name]=ws[wi].reshape(-1,channels)[mapping[valid]].clone()
 for name,wi,blocks in (('fc1_scale',1,8),('activation_scale',3,4)):
  out[name]=ws[wi].flatten()[:p*blocks].reshape(blocks,p).T[mapping[valid]].clone()
 return out,valid

def realize_counts(counts):
 counts=list(counts);rows=[]
 for _ in range(64):
  ids=sorted(range(256),key=lambda i:(-counts[i],i))[:8]
  assert all(counts[i]>0 for i in ids)
  for i in ids:counts[i]-=1
  rows.append(ids)
 assert not any(counts)
 return torch.tensor(rows,device='cuda')

@torch.inference_mode()
def main():
 start=time.monotonic();flush()
 require('cpu_bounds_pass',json.loads((OUT/'cpu-bounds.json').read_text())['passed'])
 build=json.loads((OUT/'extension-build.json').read_text());require('extension_build_pass',build['exit_code']==0 and build['installed_source_hash_unchanged'])
 report.update(extension=build,gpu_uuid=str(torch.cuda.get_device_properties(0).uuid),device_name=torch.cuda.get_device_name(0),torch_version=torch.__version__)
 runtime=fi.get_trtllm_moe_sm100_module()
 extension_path=OUT/'extension/drama3_metadata_rebase_native.so'
 custom=tvm_ffi.load_module(str(extension_path));fi.setup_cubin_loader(str(extension_path))
 report['extension_loaded_seconds']=time.monotonic()-start
 data=torch.load(INPUT,map_location='cpu',weights_only=False);cases=[]
 for layer in (0,19,39):
  print(json.dumps({'stage':'layer_setup','layer':layer}),flush=True)
  row=dict(layer=layer,real_rows=63,padding_rows=1,scenarios=[]);report['cases'].append(row);flush()
  x=data[layer]['x'].cuda();router=data[layer]['router'].cuda();weights=load_weights(layer)
  originals=[t.clone() for t in (x,router)];weight_hashes=[sha_tensor(t) for t in weights];rng=torch.cuda.get_rng_state().clone()
  q,s,logits=prepare_moe_input(x,router)
  def prep():
   prepare_kernel[(64,)](x,router,q,s,logits,None,64,x.stride(0),router.stride(0),0,num_warps=4)
  canonical=fi.allocate_trtllm_moe_canonical_routing(logits,top_k=8,tile_n=8)
  ids=torch.empty((64,8),device='cuda',dtype=torch.int32);cw=canonical.expert_weights
  def route_live():
   fi.canonicalize_trtllm_moe_routing_(canonical,logits,None,q,top_k=8,n_group=None,topk_group=None,local_expert_offset=0,local_num_experts=256,routed_scaling_factor=1.0,routing_method_type=4,use_routing_scales_on_input=False,use_deep_seek_fp8=True,norm_topk_prob=True,enable_pdl=True)
   ids.copy_(canonical.routing_replay_ids)
  route_live()
  require('canonical_scratch_width',len(canonical.scratch)==8)
  # Native initialized fields: scratch[5]CTA, [6]MnLimit,[7]nonExiting;
  # [1]padded,[2]expanded,[3]permutedToken. [0]perExpertCounts is NOT read.
  global_fields=dict(cta=canonical.scratch[5],mn=canonical.scratch[6],ncta=canonical.scratch[7],padded=canonical.scratch[1],expanded=canonical.scratch[2],tokens=canonical.scratch[3])
  common=dict(routing_bias=None,num_experts=256,top_k=8,n_group=None,topk_group=None,intermediate_size=512,routed_scaling_factor=1.0,routing_method_type=4,use_shuffled_weight=False,weight_layout=0,enable_pdl=True)
  publickw={**common,'hidden_states':q,'hidden_states_scale':s,'gemm1_weights':weights[0],'gemm1_weights_scale':weights[1],'gemm2_weights':weights[2],'gemm2_weights_scale':weights[3],'local_expert_offset':0,'local_num_experts':256,'tune_max_num_tokens':4096}
  def native_call():
   prep();value=fi.trtllm_fp8_block_scale_moe(routing_logits=logits,**publickw)
   return value[0] if isinstance(value,list) else value
  target=native_call();chk(f'L{layer}/archived_native',target,data[layer]['routed'].cuda())
  def make_body(module,offset,count,finalized):
   runner=runtime.MoERunner(module,top_k=8,num_local_experts=count,dtype_act=DtypeTrtllmGen.E4m3,dtype_weights=DtypeTrtllmGen.E4m3,fp8_quantization_type=Fp8QuantizationType.DeepSeekFp8,hidden_size=2048,intermediate_size=512,num_experts=256)
   inp=MoeRunnerInputs(torch.empty((64,2048 if finalized else 0),device='cuda',dtype=torch.bfloat16),None,ids,cw,q,s,None,None).to_list()
   tactic=runner.get_factorized_tactic_space(inp).anchor(8).tactic;require('unchanged_tactic',tuple(tactic)==(8,5))
   kw={k:v for k,v in common.items() if k not in ('top_k','intermediate_size')}
   kw.update(local_expert_offset=offset,do_finalize=finalized,routing_input_mode=RoutingInputMode.UnpackedPrecomputed,gemm1_weights=weights[0][offset:offset+count],gemm1_weights_scale=weights[1][offset:offset+count],gemm2_weights=weights[2][offset:offset+count],gemm2_weights_scale=weights[3][offset:offset+count])
   meta=fi.trtllm_moe_allocate_routing_metadata_multi_tile(ids,num_experts=256,top_k=8,local_expert_offset=offset,num_local_experts=count,tile_ns=[8],routing_input_mode=RoutingInputMode.UnpackedPrecomputed,topk_weights=cw)
   fi.populate_trtllm_moe_routing_metadata_(meta,ids,cw)
   slot=meta.slots[0];body=SimpleNamespace(tile_n=8,tactic=5);br=runtime.DABodyRunner(runner)
   ws=tuple(as_torch(t) for t in br.prepare_body(inp,body,slot,**kw))
   return dict(runner=runner,inputs=inp,kw=kw,meta=meta,slot=slot,body=body,br=br,ws=ws,offset=offset,count=count,finalized=finalized)
  def runbody(d):d['br'].forward_from_metadata(d['inputs'],d['body'],d['slot'],d['ws'],**d['kw'])
  ref=make_body(runtime.moe_op,0,256,True)
  test_full=make_body(custom,0,256,True)
  def populate_native(d):fi.populate_trtllm_moe_routing_metadata_(d['meta'],ids,cw)
  def populate_rebase(parts):
   args=[]
   for d in parts:
    sl=d['slot'];args.extend((sl.total_num_padded_tokens,sl.expanded_idx_to_permuted_idx,sl.permuted_idx_to_token_idx,sl.cta_idx_xy_to_batch_idx,sl.cta_idx_xy_to_mn_limit,sl.num_non_exiting_ctas))
   rebase_pair[(2,)](global_fields['cta'],global_fields['mn'],global_fields['ncta'],global_fields['expanded'],global_fields['tokens'],ids,*args,num_warps=8)
  # Distinct metadata/body state for every captured arm; only q/weights are shared read-only after fork.
  arms={name:[make_body(custom,0,128,False),make_body(custom,128,128,False)] for name in ('local_serial','local_parallel','shared_serial','shared_parallel')}
  streams={name:[torch.cuda.Stream(),torch.cuda.Stream()] for name in arms}
  def partition_call(name):
   prep();route_live();parts=arms[name];shared=name.startswith('shared');parallel=name.endswith('parallel');current=torch.cuda.current_stream()
   # Metadata build is identical placement in both arms; it completes before body fork.
   if shared:populate_rebase(parts)
   else:
    for part in parts:populate_native(part)
   for i,part in enumerate(parts):
    if parallel:
     streams[name][i].wait_stream(current)
     with torch.cuda.stream(streams[name][i]):runbody(part)
    else:runbody(part)
   if parallel:
    for st in streams[name]:current.wait_stream(st)
   return finish([parts[0]['ws'][4],cw,parts[0]['slot'].expanded_idx_to_permuted_idx],[parts[1]['ws'][4],cw,parts[1]['slot'].expanded_idx_to_permuted_idx],cw)
  # One shared transform kernel writes two disjoint metadata records.
  variants={'real':originals[1],'rows_reversed':originals[1].flip(0),'left_only':originals[1]+torch.cat((torch.full((128,),64.,device='cuda'),torch.zeros(128,device='cuda'))),'right_only':originals[1]+torch.cat((torch.zeros(128,device='cuda'),torch.full((128,),64.,device='cuda')))}
  worst_ids=realize_counts([57]*4+[33]+[1]*251)
  worst=torch.full_like(router,-100);worst.scatter_(1,worst_ids,torch.arange(8,0,-1,device='cuda',dtype=router.dtype).expand(64,8));variants['worst_global288']=worst
  for label,variant in variants.items():
   router.copy_(variant);prep();route_live();reference=native_call().clone();populate_native(ref);runbody(ref);populate_native(test_full);runbody(test_full)
   chk(f'L{layer}/{label}/prepared_reference',ref['inputs'][0],reference)
   chk(f'L{layer}/{label}/custom_module_reference',test_full['inputs'][0],reference)
   expected,valid=gather(ref['slot'],ref['ws']);require('reference_all_valid',bool(valid.all()))
   new_expected,_=gather(test_full['slot'],test_full['ws'])
   for key in expected:chk(f'L{layer}/{label}/extension_{key}',new_expected[key],expected[key])
   n=int(global_fields['ncta'].item());p=int(global_fields['padded'].item());ctas=global_fields['cta'][:n].cpu()
   require('global_native_capacity',0<=n<=288 and p==8*n)
   row['scenarios'].append(dict(name=label,global_cta_count=n,total_padded=p,split_ctas=[int((ctas<128).sum()),int((ctas>=128).sum())],ids_sha256=sha_tensor(ids),counter_provenance='native CTA batch IDs + non_exiting count; not num_tokens_per_expert'))
   for name,parts in arms.items():
    result=partition_call(name);chk(f'L{layer}/{label}/{name}_routed',result,reference)
    owns=[]
    for i,part in enumerate(parts):
     got,valid=gather(part['slot'],part['ws']);owns.append(valid)
     expect_owned=(ids.flatten()>=i*128)&(ids.flatten()<(i+1)*128)
     chk(f'L{layer}/{label}/{name}_owner{i}',valid,expect_owned)
     require('local_native_capacity',int(part['slot'].num_non_exiting_ctas.item())<=176)
     for key in expected:chk(f'L{layer}/{label}/{name}_part{i}_{key}',got[key],expected[key][valid])
    require('each_route_one_owner',bool((owns[0].int()+owns[1].int()==1).all()))
   # Persist full effective reference values for future native arithmetic oracle.
   torch.save(dict(layer=layer,scenario=label,x=x.cpu(),router=router.cpu(),q=q.cpu(),input_scale=s.cpu(),ids=ids.cpu(),weights=cw.cpu(),intermediates={k:v.cpu() for k,v in expected.items()},routed=reference.cpu(),global_meta={k:v.cpu() for k,v in global_fields.items() if k not in ('cta','mn','tokens')},cta=global_fields['cta'][:n].cpu(),mn=global_fields['mn'][:n].cpu()),OUT/f'oracle-layer{layer}-{label}.pt')
  router.copy_(originals[1]);prep();route_live()
  graphs={};outputs={}
  for name in ('native',*arms):
   fn=native_call if name=='native' else lambda name=name:partition_call(name)
   st=torch.cuda.Stream();st.wait_stream(torch.cuda.current_stream())
   with torch.cuda.stream(st):
    for _ in range(2):fn()
   torch.cuda.current_stream().wait_stream(st);torch.cuda.synchronize();g=torch.cuda.CUDAGraph()
   with torch.cuda.graph(g,pool=torch.cuda.graph_pool_handle(),stream=st):outputs[name]=fn()
   graphs[name]=g
  # Replays include actual expert-count changes, not just row permutations.
  for label in ('real','left_only','right_only','worst_global288','real'):
   router.copy_(variants[label]);target=native_call().clone()
   for name,g in graphs.items():g.replay();torch.cuda.synchronize();chk(f'L{layer}/graph_{label}_{name}',outputs[name],target)
  router.copy_(originals[1]);prep();route_live()
  owned=[]
  for parts in arms.values():
   for d in parts:
    owned.extend(t.untyped_storage().data_ptr() for t in (*d['ws'],d['slot'].expanded_idx_to_permuted_idx,d['slot'].permuted_idx_to_token_idx,d['slot'].cta_idx_xy_to_batch_idx,d['slot'].cta_idx_xy_to_mn_limit) if t.numel())
  require('live_scratch_disjoint',len(owned)==len(set(owned)))
  chk(f'L{layer}/x_untouched',x,originals[0]);chk(f'L{layer}/router_restored',router,originals[1]);chk(f'L{layer}/rng_untouched',torch.cuda.get_rng_state(),rng)
  require('weight_hashes_untouched',[sha_tensor(t) for t in weights]==weight_hashes)
  row['exact_gate']='PASS';flush();print(json.dumps({'stage':'exact_pass','layer':layer,'checks':len(report['checks'])}),flush=True)
  cases.append(dict(layer=layer,row=row,graphs=graphs,outputs=outputs,arms=arms,streams=streams,ref=ref,test_full=test_full,weights=weights,x=x,router=router,q=q,s=s,logits=logits,ids=ids,canonical=canonical))
 report['timings_allowed']=True;report['status']='TIMING';flush()
 for case in cases:
  raw=[];names=list(case['graphs'])
  for trial in range(15):
   values={}
   for name in (names if trial%2==0 else list(reversed(names))):
    g=case['graphs'][name]
    for _ in range(5):g.replay()
    a=torch.cuda.Event(enable_timing=True);b=torch.cuda.Event(enable_timing=True);a.record()
    for _ in range(20):g.replay()
    b.record();b.synchronize();values[name]=a.elapsed_time(b)/20
   raw.append(values)
  med={name:statistics.median(v[name] for v in raw) for name in names}
  case['row'].update(raw_ms=raw,median_ms=med,gain_vs_original=1-med['shared_parallel']/med['native'],gain_vs_local=1-med['shared_parallel']/med['local_parallel'])
  flush();print(json.dumps({'stage':'timed','layer':case['layer'],'median_ms':med}),flush=True)
 report.update(status='COMPLETE',all_exact=True,proposal_gate_pass=all(c['row']['gain_vs_original']>=.05 for c in cases),duration_seconds=time.monotonic()-start,limits=['Three real partialB64 layers plus synthetic changed-histogram correctness scenarios.','One fixed split, native GEMM grid/tactic preserved; no service/fullmodel/quality claim.','Shared rebase uses one two-CTA transform kernel; single-variable routing construction comparison includes all overhead.'])
 flush()
if __name__=='__main__':
 try:main()
 except Exception as exc:
  report.update(status='FAIL',failure={'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()});flush();raise
