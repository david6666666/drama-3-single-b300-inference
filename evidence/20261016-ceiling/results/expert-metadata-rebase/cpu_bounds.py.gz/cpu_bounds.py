"""CPU independent route-layout transform and capacity checks; no CUDA init."""
from pathlib import Path
import collections,hashlib,json,math
import torch
OUT=Path(__file__).resolve().parent
ROOT=OUT.parent

def check(ids):
 assert len(ids)==64 and all(len(row)==8 for row in ids)
 assert all(0<=e<256 for row in ids for e in row)
 assert all(len(set(row))==8 for row in ids)
 flat=[e for row in ids for e in row];by=[[] for _ in range(256)]
 for i,e in enumerate(flat):by[e].append(i)
 globmap=[-1]*512;ptok=[];cta=[];mn=[]
 for e,routes in enumerate(by):
  # Deliberately reverse per-expert row order: the transform must preserve it,
  # independent of native routing's choice of order.
  routes=list(reversed(routes));base=len(ptok)
  for j,i in enumerate(routes):globmap[i]=base+j;ptok.append(i//8)
  for j in range(math.ceil(len(routes)/8)):
   cta.append(e);mn.append(min(base+(j+1)*8,base+len(routes)))
  ptok += [-2]*((-len(routes))%8)
 assert len(ptok)==8*len(cta) and len(cta)<=288
 split=sum(e<128 for e in cta);views=[]
 for part in (0,1):
  start=0 if part==0 else split;stop=split if part==0 else len(cta);base=start*8
  localmap=[p-base if part*128<=e<(part+1)*128 else -1 for e,p in zip(flat,globmap)]
  lc=[e-part*128 for e in cta[start:stop]];lm=[v-base for v in mn[start:stop]]
  assert len(lc)<=176 and all(0<=e<128 for e in lc)
  for i,p in enumerate(localmap):
   if p>=0:
    assert p<(stop-start)*8 and lc[p//8]==flat[i]-part*128 and p<lm[p//8]
    assert ptok[base+p]==i//8
  views.append(localmap)
 assert all((views[0][i]>=0)+(views[1][i]>=0)==1 for i in range(512))
 return dict(global_tiles=len(cta),local_tiles=[split,len(cta)-split],route_counts=[sum(e<128 for e in flat),sum(e>=128 for e in flat)])

def realize(counts):
 counts=list(counts);rows=[]
 for _ in range(64):
  ids=sorted(range(256),key=lambda i:(-counts[i],i))[:8]
  assert all(counts[i]>0 for i in ids)
  for i in ids:counts[i]-=1
  rows.append(ids)
 assert not any(counts)
 return rows
cases=[]
for name in ('padding-router-b58-native-inputs.pt','padding-router-b63-native-inputs.pt'):
 data=torch.load(ROOT/name,map_location='cpu',weights_only=False)
 for layer,v in sorted(data.items()):cases.append(dict(name=f'{name}/L{layer}',**check(v['ids'].tolist())))
counts=[57]*6+[49]+[1]*121+[0]*128
for offset in (0,128):
 ids=realize(counts[offset:]+counts[:offset])
 c=check(ids);assert max(c['local_tiles'])==176;cases.append(dict(name=f'worst_local_{offset}',**c))
c=check(realize([57]*4+[33]+[1]*251));assert c['global_tiles']==288;cases.append(dict(name='worst_global',**c))
invalid=[]
for label,mutate in [('negative',lambda x:x[0].__setitem__(0,-1)),('expert256',lambda x:x[0].__setitem__(0,256)),('duplicate',lambda x:x[0].__setitem__(1,x[0][0]))]:
 ids=[[e for e in range(8)] for _ in range(64)];mutate(ids)
 try:check(ids)
 except AssertionError:invalid.append(label)
 else:raise AssertionError('Invalid IDs not rejected')
report=dict(passed=True,cuda_initialized=torch.cuda.is_initialized(),cases=cases,invalid_rejected=invalid,counter_provenance='Use initialized native CTA-to-expert map and non_exiting count. Do not read allocated num_tokens_per_expert scratch: routing method4 does not forward it.',driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
(OUT/'cpu-bounds.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'passed':True,'cases':len(cases),'invalid_rejected':invalid,'cuda_initialized':report['cuda_initialized'],'max_local_tiles':max(max(c['local_tiles']) for c in cases)},indent=2))
