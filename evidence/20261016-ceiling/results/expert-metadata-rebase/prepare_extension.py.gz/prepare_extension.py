"""CPU-only isolated launcher build; reuse byte-identical native objects."""
from pathlib import Path
import hashlib,json,shutil,subprocess,time
OUT=Path(__file__).resolve().parent
BUILD=OUT/'extension';BUILD.mkdir(exist_ok=True)
ORIG=Path('/home/zjy/.cache/flashinfer/0.7.0.post1/103a/cached_ops/fused_moe_trtllm_sm100')
SRC=Path('/home/zjy/code/hsliu/venvs/codex-drama3-standalone/lib/python3.12/site-packages/flashinfer/data/csrc/trtllm_fused_moe_kernel_launcher.cu')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
s=SRC.read_text();needle='    TVM_FFI_ICHECK(args->do_finalize) << "DeepSeek FP8 DA bodies require finalized output.";'
assert s.count(needle)==2
new=s.replace(needle,'    // Artifact-only: native body already supports do_finalize=false; caller retains FC2 workspace.')
copy=BUILD/'trtllm_fused_moe_kernel_launcher.cu';copy.write_text(new)
ninja=(ORIG/'build.ninja').read_text();header=ninja.split('\nbuild ')[0].replace('name = fused_moe_trtllm_sm100','name = drama3_metadata_rebase_native')
linkline=next(line for line in ninja.splitlines() if ': link ' in line)
objects=[];hashes={str(SRC):sha(SRC),str(ORIG/'build.ninja'):sha(ORIG/'build.ninja')}
for item in linkline.split(': link ',1)[1].split():
 p=Path(item)
 if 'csrc_trtllm_fused_moe_kernel_launcher.cuda.o'==p.name:
  objects.append(BUILD/'candidate_launcher.cuda.o')
 else:
  target=BUILD/p.name;shutil.copy2(p,target);assert sha(target)==sha(p);hashes[str(p)]=sha(p);objects.append(target)
so=BUILD/'drama3_metadata_rebase_native.so'
content=header+'\nbuild '+str(BUILD/'candidate_launcher.cuda.o')+': cuda_compile '+str(copy)+'\n'
content+='build '+str(so)+': link '+' '.join(map(str,objects))+'\ndefault '+str(so)+'\n'
(BUILD/'build.ninja').write_text(content)
manifest=dict(namespace='drama3_metadata_rebase_native',source_changes='Exactly two prepared DeepSeek finalized-output assertions removed; no numeric kernel changes.',native_objects_copied=True,installed_sources_modified=False,inputs_sha256=hashes,candidate_launcher_sha256=sha(copy),ninja_sha256=sha(BUILD/'build.ninja'),command=['ninja','-j','2','-f',str(BUILD/'build.ninja')])
(OUT/'extension-build.json').write_text(json.dumps(manifest,indent=2)+'\n')
start=time.monotonic()
with (OUT/'extension-build.log').open('w') as f:
 code=subprocess.call(manifest['command'],cwd=BUILD,stdout=f,stderr=subprocess.STDOUT)
manifest.update(exit_code=code,duration_seconds=time.monotonic()-start,installed_source_hash_unchanged=sha(SRC)==hashes[str(SRC)])
if code==0:manifest['so_sha256']=sha(so)
(OUT/'extension-build.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:v for k,v in manifest.items() if k in ('exit_code','duration_seconds','installed_source_hash_unchanged','so_sha256')}))
raise SystemExit(code)
