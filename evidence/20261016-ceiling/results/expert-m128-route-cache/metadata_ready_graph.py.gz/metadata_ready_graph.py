"""Artifact-only host guard for FC2's metadata-ready specialization.

The guard owns capture and never accepts a caller-selected producer subset.
Each callback's node delta is recorded on the same CUDA capture generation.
Only seal() may add edges; only a sealed, unchanged graph may instantiate.
The instantiated executable is private and immutable through this API, so replay
checks identity/state rather than repeating graph queries in a timing loop.
This is an accidental-misuse guard, not a security sandbox. Callbacks are trusted;
raw handles stay private and callers must not mutate graph parameters externally.
Snapshots cover topology and listed kernel launch attributes, not the bytes of
kernel argument arrays or memcpy/memset parameters. Tensor contents may change
for replay; captured storage/descriptors must retain their identity and lifetime.

Usage:
    guard = MetadataReadyGraph(owners=[all_inputs, descriptors, compiled_functions],
                               fc2_validate=lambda: validate_io(fc2_io))
    with guard.capture():
        guard.record_metadata(populate)
        guard.record_fc1(fc1)
        guard.record_activation(activation)
        guard.record_fc2(restricted_fc2)
        guard.record_finalize(finalize)
    evidence = guard.seal()
    guard.instantiate()
    guard.replay()

"gemm_empty_probe" is a separate metadata -> FC1 -> FC2 capture, with real
in-graph metadata/count producers and retained, already initialized activation
storage. It must not be used as a complete-MoE timing graph.
"""

from contextlib import contextmanager
from copy import deepcopy
from dataclasses import dataclass
from itertools import pairwise

FULL = 0
PROGRAMMATIC = 1
ROLE_NAMES = {
    "fc1": "batched_gemm_kernel_bf16",
    "activation": "activationDeepSeekKernel",
    "fc2": "metadata_ready_fc2_kernel",
    "finalize": "finalizeKernel",
}
ORDERS = {
    "full_body": ("metadata", "fc1", "activation", "fc2", "finalize"),
    "gemm_empty_probe": ("metadata", "fc1", "fc2"),
}


class ContractError(RuntimeError):
    """A capture or readiness proof does not satisfy the restricted contract."""


def require(value, message):
    if not value:
        raise ContractError(message)


@dataclass(frozen=True)
class Edge:
    source: int
    target: int
    kind: int
    source_port: int = 0
    target_port: int = 0


@dataclass(frozen=True)
class Node:
    identity: int
    kind: str
    kernel: str = ""
    function: int = 0
    grid: tuple = ()
    block: tuple = ()
    shared_bytes: int = 0


@dataclass(frozen=True)
class Snapshot:
    identity: tuple
    nodes: tuple
    edges: tuple


def has_path(edges, source, target):
    seen, pending = set(), [source]
    while pending:
        node = pending.pop()
        if node == target:
            return True
        if node not in seen:
            seen.add(node)
            pending.extend(edge.target for edge in edges if edge.source == node)
    return False


def verify_topology(snapshot, identity, recorded, mode, require_full=False):
    """CPU-only checker. Provenance comes from controlled callback node deltas."""
    require(mode in ORDERS, "unknown graph mode")
    require(snapshot.identity == identity, "unrelated graph or capture generation")
    require(
        tuple(recorded) == ORDERS[mode], "incomplete or reordered callback provenance"
    )
    nodes = {node.identity: node for node in snapshot.nodes}
    require(len(nodes) == len(snapshot.nodes), "duplicate graph node")
    flattened = [node for values in recorded.values() for node in values]
    require(len(flattened) == len(set(flattened)), "node claimed by multiple callbacks")
    require(set(flattened) == set(nodes), "unknown or omitted graph node")
    prefix = recorded["metadata"]
    require(bool(prefix), "metadata must have actual captured producer nodes")
    for node in prefix:
        require(
            nodes[node].kind in ("kernel", "memset", "memcpy"),
            "unsupported metadata node type",
        )
    body = {}
    for role in ORDERS[mode][1:]:
        require(len(recorded[role]) == 1, role + " must record exactly one kernel")
        node = nodes[recorded[role][0]]
        require(
            node.kind == "kernel" and ROLE_NAMES[role] in node.kernel,
            "wrong " + role + " kernel identity",
        )
        body[role] = node.identity
    for edge in snapshot.edges:
        require(
            edge.source in nodes and edge.target in nodes, "edge contains unknown node"
        )
        require(edge.source != edge.target, "self edge")
        require(not has_path(snapshot.edges, edge.target, edge.source), "cyclic graph")
    for node in prefix:
        require(
            has_path(snapshot.edges, node, body["fc1"]),
            "metadata producer does not precede FC1",
        )
        require(
            not has_path(snapshot.edges, body["fc2"], node),
            "metadata producer follows FC2",
        )
    roles = ORDERS[mode][1:]
    retained = tuple(
        Edge(body[source], body[target], PROGRAMMATIC, 1, 0)
        for source, target in pairwise(roles)
    )
    require(
        set(retained) <= set(snapshot.edges),
        "missing native programmatic body dependency with ports 1 -> 0",
    )
    dependency = body["activation"] if mode == "full_body" else body["fc1"]
    require(
        not any(
            edge.source == dependency
            and edge.target == body["fc2"]
            and edge.kind == FULL
            for edge in snapshot.edges
        ),
        "unexpected full dependency serializes the programmatic FC2 input edge",
    )
    needed = tuple(Edge(node, body["fc2"], FULL) for node in prefix)
    if require_full:
        require(
            set(needed) <= set(snapshot.edges),
            "missing full-memory metadata dependency",
        )
    return needed, retained


def _retained(values):
    result, seen = [], set()

    def visit(value):
        if id(value) in seen:
            return
        seen.add(id(value))
        result.append(value)
        if isinstance(value, dict):
            for item in value.values():
                visit(item)
        elif isinstance(value, (list, tuple)):
            for item in value:
                visit(item)

    visit(values)
    return result


class MetadataReadyGraph:
    """Single-generation capture owner; no public raw graph/executable handle."""

    def __init__(self, *, owners, fc2_validate, mode="full_body", backend=None):
        require(mode in ORDERS, "unsupported graph mode")
        require(bool(owners), "retain IO tensors, descriptors and compiled functions")
        require(
            callable(fc2_validate), "a fixed restricted FC2 IO validator is required"
        )
        self._fc2_validate = fc2_validate
        self._owners = _retained([*owners, fc2_validate])
        self._mode = mode
        self._backend = backend if backend is not None else _CudaBackend()
        self._state = "new"
        self._recorded = {}
        self._last = None
        self._sealed = None

    @contextmanager
    def capture(self):
        require(self._state == "new", "guard captures only one generation")
        self._state = "capturing"
        error = (None, None, None)
        try:
            self._backend.begin()
            self._last = self._backend.snapshot()
            require(
                not self._last.nodes and not self._last.edges,
                "capture did not start empty",
            )
            yield self
        except BaseException as exc:
            error = (type(exc), exc, exc.__traceback__)
            self._state = "failed"
            raise
        finally:
            self._backend.end(error)
            if self._state == "capturing":
                self._state = "captured"

    def _record(self, role, call):
        require(
            self._state == "capturing",
            "restricted launch requires owned active capture",
        )
        order = ORDERS[self._mode]
        require(
            len(self._recorded) < len(order) and role == order[len(self._recorded)],
            "callback order or mode violation",
        )
        before = self._backend.snapshot()
        require(before == self._last, "unrecorded graph change before callback")
        self._owners.append(call)
        call()
        after = self._backend.snapshot()
        require(
            after.identity == before.identity,
            "capture generation changed during callback",
        )
        old_nodes = set(before.nodes)
        require(old_nodes <= set(after.nodes), "callback replaced an existing node")
        require(
            set(before.edges) <= set(after.edges),
            "callback removed or changed an existing edge",
        )
        self._recorded[role] = tuple(
            node.identity for node in after.nodes if node not in old_nodes
        )
        self._last = after

    def record_metadata(self, call):
        self._record("metadata", call)

    def record_fc1(self, call):
        self._record("fc1", call)

    def record_activation(self, call):
        self._record("activation", call)

    def record_fc2(self, call):
        require(
            self._state == "capturing",
            "restricted launch requires owned active capture",
        )
        self._fc2_validate()
        self._record("fc2", call)

    def record_finalize(self, call):
        self._record("finalize", call)

    def seal(self):
        require(
            self._state == "captured", "seal requires completed, uninstantiated capture"
        )
        self._fc2_validate()
        current = self._backend.snapshot()
        require(current == self._last, "capture changed after recorded callbacks")
        needed, original_pdl = verify_topology(
            current, current.identity, self._recorded, self._mode
        )
        missing = tuple(edge for edge in needed if edge not in current.edges)
        self._backend.add_full_edges(missing)
        sealed = self._backend.snapshot()
        require(
            sealed.nodes == current.nodes and sealed.identity == current.identity,
            "edge insertion changed graph/node identity",
        )
        require(
            set(sealed.edges) == set(current.edges) | set(missing),
            "unexpected graph mutation while sealing",
        )
        verify_topology(
            sealed, current.identity, self._recorded, self._mode, require_full=True
        )
        require(
            set(original_pdl) <= set(sealed.edges),
            "native activation dependency was changed",
        )
        self._sealed = sealed
        self._state = "sealed"
        return self.evidence()

    def instantiate(self):
        require(self._state == "sealed", "instantiate requires a sealed graph")
        self._fc2_validate()
        require(self._backend.snapshot() == self._sealed, "sealed graph was changed")
        self._backend.instantiate()
        self._state = "instantiated"

    def replay(self):
        require(self._state == "instantiated", "replay requires sealed instantiation")
        require(
            self._backend.identity() == self._sealed.identity,
            "graph generation changed",
        )
        self._backend.replay()

    def evidence(self):
        require(
            self._state in ("sealed", "instantiated"),
            "unsealed graph has no readiness proof",
        )
        return deepcopy(
            {
                "mode": self._mode,
                "identity": self._sealed.identity,
                "recorded_nodes": self._recorded,
                "nodes": [vars(node) for node in self._sealed.nodes],
                "edges": [vars(edge) for edge in self._sealed.edges],
                "full_moe_timing_allowed": self._mode == "full_body",
                "retained_owners": len(self._owners),
            }
        )


class _CudaBackend:
    """CUDA calls remain lazy: importing this module does not initialize CUDA."""

    def __init__(self):
        self._graph = None
        self._context = None
        self._capturing = False
        self._generation = None
        self._handle = None

    @staticmethod
    def _checked(result):
        require(int(result[0]) == 0, "CUDA graph API failed: " + str(result[0]))
        return result[1:]

    def begin(self):
        import torch
        from cuda.bindings import driver

        self._torch, self._driver = torch, driver
        self._graph = torch.cuda.CUDAGraph(keep_graph=True)
        self._context = torch.cuda.graph(self._graph)
        self._context.__enter__()
        self._capturing = True
        self._stream = driver.CUstream(torch.cuda.current_stream().cuda_stream)
        status, generation, handle, _, _, _ = self._checked(
            driver.cuStreamGetCaptureInfo(self._stream)
        )
        require(
            status == driver.CUstreamCaptureStatus.CU_STREAM_CAPTURE_STATUS_ACTIVE,
            "capture is not active",
        )
        self._generation, self._handle = int(generation), handle

    def end(self, error):
        if self._context is not None:
            self._context.__exit__(*error)
            self._capturing = False

    def identity(self):
        require(self._graph is not None, "no owned CUDA graph")
        if self._capturing:
            status, generation, handle, _, _, _ = self._checked(
                self._driver.cuStreamGetCaptureInfo(self._stream)
            )
            require(
                status
                == self._driver.CUstreamCaptureStatus.CU_STREAM_CAPTURE_STATUS_ACTIVE,
                "capture ended outside guard",
            )
            return int(handle), int(generation)
        return int(self._graph.raw_cuda_graph()), self._generation

    def snapshot(self):
        drv, check = self._driver, self._checked
        identity = self.identity()
        require(
            identity == (int(self._handle), self._generation),
            "wrong graph/capture generation",
        )
        _, count = check(drv.cuGraphGetNodes(self._handle, 0))
        raw_nodes, count = check(drv.cuGraphGetNodes(self._handle, count))
        nodes = []
        for node in raw_nodes[:count]:
            (kind,) = check(drv.cuGraphNodeGetType(node))
            names = {
                drv.CUgraphNodeType.CU_GRAPH_NODE_TYPE_KERNEL: "kernel",
                drv.CUgraphNodeType.CU_GRAPH_NODE_TYPE_MEMSET: "memset",
                drv.CUgraphNodeType.CU_GRAPH_NODE_TYPE_MEMCPY: "memcpy",
            }
            label = names.get(kind, str(kind))
            if label == "kernel":
                (params,) = check(drv.cuGraphKernelNodeGetParams(node))
                (name,) = check(drv.cuFuncGetName(params.func))
                nodes.append(
                    Node(
                        int(node),
                        label,
                        name.decode() if isinstance(name, bytes) else str(name),
                        int(params.func),
                        (params.gridDimX, params.gridDimY, params.gridDimZ),
                        (params.blockDimX, params.blockDimY, params.blockDimZ),
                        params.sharedMemBytes,
                    )
                )
            else:
                nodes.append(Node(int(node), label))
        _, _, _, count = check(drv.cuGraphGetEdges(self._handle, 0))
        starts, ends, data, count = check(drv.cuGraphGetEdges(self._handle, count))
        edges = [
            Edge(int(a), int(b), int(info.type), int(info.from_port), int(info.to_port))
            for a, b, info in zip(starts[:count], ends[:count], data[:count])
        ]
        return Snapshot(
            identity,
            tuple(sorted(nodes, key=lambda node: node.identity)),
            tuple(sorted(edges, key=lambda edge: tuple(vars(edge).values()))),
        )

    def add_full_edges(self, edges):
        require(not self._capturing, "seal only after capture ends")
        if edges:
            drv = self._driver
            require(
                all(
                    edge.kind == FULL and edge.source_port == edge.target_port == 0
                    for edge in edges
                ),
                "only DEFAULT full-memory dependencies may be added",
            )
            self._checked(
                drv.cuGraphAddDependencies(
                    self._handle,
                    [drv.CUgraphNode(edge.source) for edge in edges],
                    [drv.CUgraphNode(edge.target) for edge in edges],
                    None,
                    len(edges),
                )
            )

    def instantiate(self):
        self._graph.instantiate()

    def replay(self):
        self._graph.replay()


class _EagerPermit:
    def __init__(self, event, owners, torch_module, fc2_validate):
        self._event, self._owners, self._torch = event, _retained(owners), torch_module
        self._fc2_validate = fc2_validate
        self._used = False

    def wait(self):
        require(not self._used, "eager permit already consumed")
        self._event.synchronize()
        return self

    def launch_once(self, chain):
        require(not self._used, "eager permit already consumed")
        require(
            not self._torch.cuda.is_current_stream_capturing(),
            "eager permit cannot authorize capture",
        )
        require(self._event.query(), "metadata event has not completed")
        self._fc2_validate()
        self._used = True
        self._owners.append(chain)
        return chain()


def record_eager_metadata(metadata_call, *, owners, fc2_validate):
    """Record our own event after the metadata callback; no forged external event.

    Retain the returned permit through completion of its one launch chain. This
    entry does not authorize captured execution or a graph replay. The caller must
    not overwrite metadata between this producer and the permitted launch chain.
    """
    import torch

    require(bool(owners), "eager launch requires retained owners")
    require(callable(fc2_validate), "eager launch requires the restricted IO validator")
    fc2_validate()
    require(
        not torch.cuda.is_current_stream_capturing(), "eager entry is not capture-safe"
    )
    metadata_call()
    event = torch.cuda.Event()
    event.record(torch.cuda.current_stream())
    return _EagerPermit(
        event, [*owners, metadata_call, fc2_validate], torch, fc2_validate
    )


class _MockBackend:
    """In-memory topology only; no torch/CUDA imports or execution."""

    def __init__(self):
        self.generation = (101, 7)
        self.nodes, self.edges = [], []
        self.instantiated = False
        self.replays = 0

    def begin(self):
        pass

    def end(self, error):
        pass

    def identity(self):
        return self.generation

    def snapshot(self):
        return Snapshot(self.generation, tuple(self.nodes), tuple(self.edges))

    def emit(self, kind, kernel="", pdl=False):
        node = len(self.nodes)
        self.nodes.append(Node(node, kind, kernel))
        if node:
            self.edges.append(
                Edge(node - 1, node, PROGRAMMATIC if pdl else FULL, 1 if pdl else 0)
            )

    def add_full_edges(self, edges):
        self.edges.extend(edges)

    def instantiate(self):
        self.instantiated = True

    def replay(self):
        require(self.instantiated, "mock graph not instantiated")
        self.replays += 1


def run_cpu_tests():
    """Focused positive/negative safety contracts, without allocating a GPU."""
    from types import SimpleNamespace

    checks = []

    def check(name, value):
        require(value, name)
        checks.append({"name": name, "passed": True})

    def reject(name, call):
        try:
            call()
        except ContractError:
            checks.append({"name": name, "passed": True})
        else:
            raise AssertionError(name + " was accepted")

    def build(mode="full_body", validator=lambda: None):
        backend = _MockBackend()
        guard = MetadataReadyGraph(
            owners=[object()], fc2_validate=validator, mode=mode, backend=backend
        )
        with guard.capture():

            def metadata():
                backend.emit("memset")
                backend.emit("kernel", "native_live_metadata")

            guard.record_metadata(metadata)
            guard.record_fc1(lambda: backend.emit("kernel", ROLE_NAMES["fc1"]))
            if mode == "full_body":
                guard.record_activation(
                    lambda: backend.emit("kernel", ROLE_NAMES["activation"], True)
                )
            guard.record_fc2(lambda: backend.emit("kernel", ROLE_NAMES["fc2"], True))
            if mode == "full_body":
                guard.record_finalize(
                    lambda: backend.emit("kernel", ROLE_NAMES["finalize"], True)
                )
        return guard, backend

    for mode in ORDERS:
        guard, backend = build(mode)
        reject(mode + "/replay_before_seal", guard.replay)
        reject(mode + "/instantiate_before_seal", guard.instantiate)
        reject(
            mode + "/restricted_outside_capture",
            lambda guard=guard: guard.record_fc2(lambda: None),
        )
        original = set(backend.edges)
        proof = guard.seal()
        check(
            mode + "/prefix_not_caller_subset",
            len(proof["recorded_nodes"]["metadata"]) == 2,
        )
        check(mode + "/native_edges_preserved", original <= set(backend.edges))
        check(
            mode + "/full_scope",
            proof["full_moe_timing_allowed"] == (mode == "full_body"),
        )
        for node in proof["recorded_nodes"]["metadata"]:
            check(
                mode + f"/all_producer_full_edge_{node}",
                Edge(node, proof["recorded_nodes"]["fc2"][0], FULL) in backend.edges,
            )
        guard.instantiate()
        guard.replay()
        check(mode + "/sealed_replay", backend.replays == 1)
        reject(
            mode + "/cannot_recapture", lambda guard=guard: guard.capture().__enter__()
        )
        backend.generation = (101, 8)
        reject(mode + "/different_generation_replay", guard.replay)

    guard, backend = build()
    snap = backend.snapshot()
    provenance = deepcopy(guard._recorded)
    missing = deepcopy(provenance)
    missing["metadata"] = missing["metadata"][1:]
    reject(
        "omitted_metadata_producer",
        lambda: verify_topology(snap, snap.identity, missing, "full_body"),
    )
    reject(
        "wrong_graph_identity",
        lambda: verify_topology(snap, (102, 7), provenance, "full_body"),
    )
    reject(
        "programmatic_is_not_full_metadata_edge",
        lambda: verify_topology(
            snap, snap.identity, provenance, "full_body", require_full=True
        ),
    )
    no_pdl = Snapshot(
        snap.identity,
        snap.nodes,
        tuple(Edge(e.source, e.target, FULL) for e in snap.edges),
    )
    reject(
        "activation_full_edge_cannot_replace_programmatic",
        lambda: verify_topology(no_pdl, snap.identity, provenance, "full_body"),
    )
    for predecessor, successor in (("fc1", "activation"), ("fc2", "finalize")):
        source, target = provenance[predecessor][0], provenance[successor][0]
        missing_body_edge = Snapshot(
            snap.identity,
            snap.nodes,
            tuple(e for e in snap.edges if (e.source, e.target) != (source, target)),
        )
        reject(
            predecessor + "_to_" + successor + "_missing",
            lambda candidate=missing_body_edge: verify_topology(
                candidate, snap.identity, provenance, "full_body"
            ),
        )
    for port in ("source", "target"):
        wrong_port = Snapshot(
            snap.identity,
            snap.nodes,
            tuple(
                Edge(
                    e.source,
                    e.target,
                    e.kind,
                    0 if port == "source" else 1,
                    1 if port == "target" else 0,
                )
                if e.kind == PROGRAMMATIC
                else e
                for e in snap.edges
            ),
        )
        reject(
            "wrong_programmatic_" + port + "_port",
            lambda candidate=wrong_port: verify_topology(
                candidate, snap.identity, provenance, "full_body"
            ),
        )
    serialized_input = Snapshot(
        snap.identity,
        snap.nodes,
        snap.edges + (Edge(provenance["activation"][0], provenance["fc2"][0], FULL),),
    )
    reject(
        "extra_full_activation_dependency",
        lambda: verify_topology(
            serialized_input, snap.identity, provenance, "full_body"
        ),
    )
    detached = Snapshot(
        snap.identity,
        snap.nodes,
        tuple(e for e in snap.edges if e.source != provenance["metadata"][0]),
    )
    reject(
        "metadata_must_precede_fc1",
        lambda: verify_topology(detached, snap.identity, provenance, "full_body"),
    )
    wrong = list(snap.nodes)
    index = provenance["fc2"][0]
    wrong[index] = Node(index, "kernel", "unrestricted_original_fc2")
    reject(
        "wrong_fc2_kernel",
        lambda: verify_topology(
            Snapshot(snap.identity, tuple(wrong), snap.edges),
            snap.identity,
            provenance,
            "full_body",
        ),
    )
    backend.emit("kernel", "unknown_after_capture")
    reject("unrecorded_graph_change_before_seal", guard.seal)
    guard, backend = build()
    guard.seal()
    backend.edges.pop()
    reject("sealed_graph_mutation", guard.instantiate)
    state = {"valid": True, "calls": 0}

    def validator():
        state["calls"] += 1
        require(state["valid"], "restricted IO was changed")

    guard, backend = build(validator=validator)
    check("validator_before_capture_fc2", state["calls"] == 1)
    state["valid"] = False
    reject("changed_io_before_seal", guard.seal)
    state["valid"] = True
    guard.seal()
    state["valid"] = False
    reject("changed_io_before_instantiate", guard.instantiate)

    class Event:
        def __init__(self):
            self.ready = False

        def query(self):
            return self.ready

        def synchronize(self):
            self.ready = True

    event = Event()
    capture = {"active": False}
    torch_mock = SimpleNamespace(
        cuda=SimpleNamespace(is_current_stream_capturing=lambda: capture["active"])
    )
    permit = _EagerPermit(event, [object()], torch_mock, lambda: None)
    launches = []
    reject(
        "eager_metadata_not_completed",
        lambda: permit.launch_once(lambda: launches.append(1)),
    )
    check("unready_eager_did_not_launch", not launches)
    permit.wait()
    capture["active"] = True
    reject(
        "eager_permit_cannot_authorize_capture",
        lambda: permit.launch_once(lambda: launches.append(1)),
    )
    capture["active"] = False
    permit.launch_once(lambda: launches.append(1))
    check("ready_eager_single_launch", launches == [1])
    reject("eager_permit_reuse", lambda: permit.launch_once(lambda: launches.append(1)))
    import gc
    import weakref

    class Owner:
        pass

    owner = Owner()
    reference = weakref.ref(owner)
    container = {"tensor": owner}
    retained = _retained([container])
    del container["tensor"], owner
    gc.collect()
    check("owner_leaf_survives_container_rebinding", reference() is not None)
    del retained
    return {
        "status": "CPU_TOPOLOGY_AND_READINESS_CONTRACT_PASS",
        "gpu_used": False,
        "checks": checks,
        "limitations": [
            "Mock topology does not prove actual CUDA capture/API behavior or kernel correctness.",
            "GPU complete/empty native gates remain required before any timing.",
        ],
    }


if __name__ == "__main__":
    import json

    print(json.dumps(run_cpu_tests(), indent=2))
