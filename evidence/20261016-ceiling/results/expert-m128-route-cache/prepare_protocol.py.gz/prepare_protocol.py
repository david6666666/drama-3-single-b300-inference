"""CPU resource/address proof and freeze for one FC1 metadata-cache candidate."""
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import sys

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
OLD = ROOT / 'expert-m128-pdl-metadata-ready'
os.environ['CUDA_VISIBLE_DEVICES'] = ''
sys.dont_write_bytecode = True
sys.argv = [str(OUT / 'metadata_driver.py'), 'prepare']
sys.path.insert(0, str(OUT))
import metadata_driver as d
from metadata_ready_graph import run_cpu_tests


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')


checks = []


def require(name, value, detail=None):
    checks.append({'name': name, 'passed': bool(value), 'detail': detail})
    if not value:
        save('cpu-route-cache-proof.json', {'status': 'FAIL', 'checks': checks})
        raise AssertionError(name)


prep = json.loads((OUT / 'driver-prepare.json').read_text())
previous = json.loads((OLD / 'driver-prepare.json').read_text())
require('CPU_AOT_PASS', prep['status'] == 'CPU_AOT_PASS')
require('frozen_native_source', prep['source_sha'] == '95fcb0ef2662f2caf9bfb7fe6863dc3ad7805b1b' and not prep['source_status'])
for fc in ('fc1', 'fc2'):
    r, oldr = prep['resources'][fc], previous['resources'][fc]
    require(fc + '/same_compiled_residency_resources', all(r[k] == oldr[k] for k in ('total_shared_bytes_per_cta', 'dynamic_shared_bytes', 'static_shared_bytes', 'base_registers')), {k: r[k] for k in ('total_shared_bytes_per_cta', 'base_registers')})
    require(fc + '/no_spill', all(r[k] == 0 for k in ('stack_bytes', 'local_bytes', 'ptx_local_ops', 'sass_spill_ops')))
    ptx = Path(prep['kernels'][fc]['cubin']).with_suffix('.ptx').read_text()
    sass = (OUT / ('driver-resource-' + fc) / 'kernel.sass').read_text()
    require(fc + '/actual_SASS_no_register_reconfiguration', not re.search(r'\bU?SETMAXN?REG\b', sass))
    require(fc + '/same_PDL', ptx.count('griddepcontrol.wait;') == (1 if fc == 'fc1' else 2) and ptx.count('griddepcontrol.launch_dependents;') == 2)
    host = Path(prep['kernels'][fc]['host']).read_text()
    oldhost = Path(previous['kernels'][fc]['host']).read_text()
    # Host embeds the changed FC1 binary; only that data line is expected to differ.
    def launch_host(text):
        return '\n'.join(line for line in text.splitlines() if not line.lstrip().startswith('llvm.mlir.global internal constant @kernels_binary('))
    require(fc + '/host_launch_unchanged_except_embedded_CUBIN', launch_host(host) == launch_host(oldhost))
require('FC2_CUBIN_unchanged', prep['kernels']['fc2']['sha256'] == previous['kernels']['fc2']['sha256'])
require('FC1_CUBIN_changed', prep['kernels']['fc1']['sha256'] != previous['kernels']['fc1']['sha256'])


def sf_loads(directory, record):
    ptx = Path(record['cubin']).with_suffix('.ptx').read_text()
    bodies = re.findall(r'// SmemDeepSeekSfAb_producer_work\n(.*?)// SmemDeepSeekSfAb_producer_commit', ptx, re.S)
    auxiliary = re.findall(r'// SmemDeepSeekSfAb_producer_aux_work\n(.*?)(?=// SmemDeepSeekSfAb_producer_try_acquire)', ptx, re.S)
    sass = (directory / 'driver-resource-fc1/kernel.sass').read_text()
    return {'static_K_body_count': len(bodies), 'K_body_ldglobal_count': sum(len(re.findall(r'\bld\.global\.', b)) for b in bodies), 'auxiliary_ldglobal_count': sum(len(re.findall(r'\bld\.global\.', b)) for b in auxiliary), 'total_SASS_LDG_count': len(re.findall(r'\bLDG(?:\.|\b)', sass))}


oldloads = sf_loads(OLD, previous['kernels']['fc1'])
newloads = sf_loads(OUT, prep['kernels']['fc1'])
require('old_K_body_contains_route_reads', oldloads['K_body_ldglobal_count'] > 0, oldloads)
require('new_K_body_no_global_reads', newloads['static_K_body_count'] == oldloads['static_K_body_count'] and newloads['K_body_ldglobal_count'] == 0, newloads)
require('route_read_moves_to_prepare', newloads['auxiliary_ldglobal_count'] == oldloads['auxiliary_ldglobal_count'] + 1)
require('SASS_removes_repeated_LDG', newloads['total_SASS_LDG_count'] < oldloads['total_SASS_LDG_count'])

# Address-only replay proves cache refresh at native work-tile boundaries.
# Values/scales/MMA still require the independently frozen GPU exact gate.
for path in d.ORACLES:
    data = d.torch.load(path, map_location='cpu', weights_only=False)
    md, info = d.c.metadata(data)
    n = int(md['ncta'])
    for permutation in ('original', 'within_expert_reverse'):
        route = md['route'].clone()
        if permutation != 'original':
            for tile in range(n):
                start, stop = tile * 8, int(md['mn'][tile])
                route[start:stop] = route[start:stop].flip(0)
        for tile in range(n):
            count = int(md['mn'][tile]) - tile * 8
            cached = [None] * 32
            read_count = 0
            for lane in range(32):
                if lane < count:
                    cached[lane] = int(route[tile * 8 + lane]); read_count += 1
            assert read_count == count
            for k in range(16):
                for lane in range(32):
                    if lane < count:
                        assert cached[lane] + k * 64 == int(route[tile * 8 + lane]) + k * 64
                    else:
                        assert cached[lane] is None
        require(info['name'] + '/' + permutation + '/scale_addresses_exact', True)
for count in range(9):
    # Invalid source entries deliberately absent; successful evaluation proves
    # no lookup is required outside the original valid prefix.
    source = {i: (63 - i) for i in range(count)}
    cached = [source[i] if i < count else None for i in range(32)]
    require(f'partial{count}/masked_read_domain', all(cached[i] is None for i in range(count, 32)))
require('cuda_uninitialized', not d.torch.cuda.is_initialized())
graph_checks = run_cpu_tests()
require('graph_guard_CPU', graph_checks['status'] == 'CPU_TOPOLOGY_AND_READINESS_CONTRACT_PASS')
save('cpu-graph-guard.json', graph_checks)
save('cpu-route-cache-proof.json', {'status': 'CPU_ROUTE_CACHE_RESOURCE_ADDRESS_PASS', 'gpu_used': False, 'checks': checks, 'ldg_static_counts': {'before': oldloads, 'after': newloads}, 'dynamic_route_contract': '16→1 loads per valid scale lane per work tile; no reuse across work tiles', 'limitations': ['Source/IR dependency removal is not proof of performance cause.', 'Same compiled resources do not prove measured occupancy.', 'CPU address equality is not the GPU exact numerical gate.']})
protocol = json.loads((OLD / 'protocol.json').read_text())
protocol.update(status='FROZEN_FC1_SCALE_ROUTE_CACHE', hypothesis='Moving invariant valid route-row loads from each K128 scale copy to the same work-tile prepare removes a dependent ordinary LDG chain. Aggregate scoreboard ratios do not prove this chain is dominant.', isolated_change='Relative to the frozen metadata-ready candidate, only FC1 SmemDeepSeekSfAb route lookup is cached per work tile. All copy masks, native FP8/scales/FMA, four stages, PDL and metadata-ready FC2 graph remain fixed.', candidate={**protocol['candidate'], 'implementation': 'M128 FC1 cached scale-route rows / native activation / unchanged metadata-ready FC2 / native ordered finalizer'})
protocol['cpu_prerequisites'] = {'proof': 'cpu-route-cache-proof.json', 'FC2_CUBIN_unchanged': True, 'base_registers': 32, 'shared_FC1_bytes': 74616, 'shared_FC2_bytes': 74664, 'spills': 0}
protocol['parent_protocol_sha256'] = sha(OLD / 'protocol.json')
protocol['parent_failure_retained'] = str(OLD / 'feasibility-result.json')
save('protocol.json', protocol)
for path in OUT.glob('*.py'):
    ast.parse(path.read_text())
files = {Path(p) for p in json.loads((OLD / 'frozen-inputs.json').read_text())}
files.update(OUT.glob('*.py'))
files.update(OUT / n for n in ('driver-prepare.json', 'source-fork.json', 'CPU-CONTRACT.md', 'cpu-graph-guard.json', 'cpu-route-cache-proof.json', 'protocol.json'))
for fc, record in prep['kernels'].items():
    files.update((Path(record['cubin']), Path(record['cubin']).with_suffix('.ptx'), Path(record['host'])))
    files.update((OUT / ('driver-resource-' + fc)).glob('*'))
for name, module in sys.modules.copy().items():
    p = getattr(module, '__file__', None)
    if p and p.endswith('.py') and name.startswith(('flashinfer.prims_ts', 'cutlass.experimental.task_scheduling', 'cutlass.pipeline')):
        files.add(Path(p))
save('frozen-inputs.json', {str(p): sha(p) for p in sorted(files) if p.is_file()})
print(json.dumps({'status': 'CPU_ROUTE_CACHE_FROZEN', 'checks': len(checks), 'files': len(files), 'protocol_sha256': sha(OUT / 'protocol.json'), 'manifest_sha256': sha(OUT / 'frozen-inputs.json'), 'gpu_used': False}))
