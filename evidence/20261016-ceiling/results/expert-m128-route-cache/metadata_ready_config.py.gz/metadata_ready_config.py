"""Artifact-only FC2 contract; generic installed validation stays unchanged.

This specialization may read routing metadata before the activation dependency
wait ONLY behind a separately verified full graph dependency (or completed
metadata event for eager correctness). The public launch guard is implemented
in metadata_ready_graph.py. A compile-time flag is not a runtime proof.
"""

from dataclasses import dataclass, fields

from flashinfer.prims_ts.batched_gemm.batched_gemm_config import (
    BatchedGemmConfig,
    compute_warp_layout,
)
from flashinfer.prims_ts.batched_gemm.batched_gemm_config import (
    validate_config as validate_native_config,
)

EXPECTED_FC2 = {
    "batch_mode": 0,
    "dtype_a": 7,
    "dtype_b": 7,
    "dtype_c": 3,
    "weight_layout": 0,
    "sf_bits": 8,
    "sf_block_size_a": 0,
    "sf_block_size_b": 0,
    "sf_block_size_c": 0,
    "mma_k": 32,
    "route_act": 0,
    "route_sfs_act": 0,
    "tile_scheduler": 1,
    "act_kind": 0,
    "bias_type": 0,
    "sf_layout_a": 3,
    "sf_layout_b": 3,
    "sf_layout_c": 1,
    "cluster_m": 1,
    "tile_m": 128,
    "tile_n": 8,
    "tile_k": 128,
    "epi_tile_m": 128,
    "epi_tile_n": 8,
    "mma_m": 128,
    "mma_n": 8,
    "num_stages_a": 4,
    "num_stages_b": 4,
    "num_stages_smem_sfa": 4,
    "num_stages_smem_sfb": 4,
    "num_stages_tmem_sfa": 4,
    "num_stages_tmem_sfb": 4,
    "num_stages_tmem_acc": 4,
    "use_unroll_loop_2x_for_mma": 0,
    "transpose_mma_output": 1,
    "use_tma_oob_opt": 1,
    "use_early_exit": 1,
    "use_clc_fast_drain": 0,
    "use_two_tma_load_warps": 1,
    "use_tma_store": 1,
    "use_global_scales": 1,
    "use_work_throttle": 1,
    "use_max_tmem_overlap": 0,
    "fuse_sf_copy_to_mma": 0,
    "fuse_operand_sf_loads": 0,
    "epilogue_regs": 160,
    "mma_regs": 48,
    "load_regs": 48,
    "load_sf_regs": 48,
    "load_a_regs": 48,
    "load_b_regs": 48,
    "load_sfa_regs": 48,
    "load_sfb_regs": 48,
    "cast_a_regs": 160,
    "copy_sf_regs": 48,
    "padding_regs": 48,
    "workid_regs": 48,
    "gather_regs": 48,
    "num_stages_c_smem": 1,
    "use_deepseek_fp8": 1,
    "num_load_sfab_warps": 1,
    "load_sfab_regs": 48,
    "use_pdl": 1,
    "do_pdl_wait_for_num_non_exiting_ctas": 0,
    "ldgsts_sfb_producer_commit_prefetch_depth": 0,
}


@dataclass(kw_only=True)
class MetadataReadyFc2Config(BatchedGemmConfig):
    metadata_ready_by_full_dependency: int = 0


def make_metadata_ready_fc2():
    return MetadataReadyFc2Config(**EXPECTED_FC2, metadata_ready_by_full_dependency=1)


def validate_metadata_ready_fc2(cfg, problem_mnk=None):
    """Extend one PDL metadata contract, preserving all native validators.

    Validate the original equivalent wait-before-metadata configuration using a
    separate native object. Only the original derived field is copied back;
    caller configuration and the installed validator are never monkeypatched.
    """
    if type(cfg) is not MetadataReadyFc2Config:
        raise TypeError("restricted FC2 requires MetadataReadyFc2Config")
    if cfg.metadata_ready_by_full_dependency != 1:
        raise ValueError("explicit full metadata dependency contract is required")
    # Native assembly recomputes warp-layout fields. Accept exactly the
    # canonical pre-assembly defaults or their canonical computed values,
    # while pinning every other native field (including optional defaults).
    canonical_raw = BatchedGemmConfig(**EXPECTED_FC2)
    canonical_layout = BatchedGemmConfig(**EXPECTED_FC2)
    compute_warp_layout(canonical_layout)
    for field in fields(BatchedGemmConfig):
        allowed = (
            getattr(canonical_raw, field.name),
            getattr(canonical_layout, field.name),
        )
        if getattr(cfg, field.name) not in allowed:
            raise ValueError(f"restricted FC2 {field.name} must be canonical {allowed}")
    if not (cfg.is_persistent and cfg.is_swap_ab and cfg.has_deepseek_fp8):
        raise ValueError("restricted FC2 requires persistent SwapAB DeepSeek FP8")
    if cfg.has_gather or cfg.has_routed_act or cfg.has_routed_sfs:
        raise ValueError("restricted FC2 cannot gather activation or scale inputs")
    values = {
        field.name: getattr(cfg, field.name) for field in fields(BatchedGemmConfig)
    }
    values["do_pdl_wait_for_num_non_exiting_ctas"] = 1
    native_cfg = BatchedGemmConfig(**values)
    validate_native_config(native_cfg, problem_mnk=problem_mnk)
    # derive_problem_shape_constants is the only native validation mutation.
    cfg.ldgsts_sfb_producer_commit_prefetch_depth = (
        native_cfg.ldgsts_sfb_producer_commit_prefetch_depth
    )


def validate_io(io):
    """Bound the artifact to complete native B64/top8/256 FC2 descriptors."""
    validate_metadata_ready_fc2(io["cfg"], problem_mnk=io["shape"][:3])
    if tuple(io["shape"]) != (2048, 2304, 512, 256, 64):
        raise ValueError(f"unsupported FC2 shape: {io['shape']}")
    if io["launch_early_exit_max_token_ctas"] != 288:
        raise ValueError("restricted FC2 must preserve fixed 288-token-CTA extent")
