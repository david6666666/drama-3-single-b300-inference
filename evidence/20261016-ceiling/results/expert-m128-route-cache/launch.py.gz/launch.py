"""Coordinator-invoked staged watchdog. No GPU work until this script is run."""

import hashlib
import json
import os
import signal
import subprocess
import time
from pathlib import Path

OUT = Path(__file__).resolve().parent
PYTHON = "/home/zjy/code/hsliu/venvs/codex-drama3-standalone/bin/python"
GPU = "GPU-bc643dc2-a0d1-5ed6-5ecb-0605ca9f340a"


def compute_apps():
    result = subprocess.run(
        [
            "nvidia-smi",
            "--query-compute-apps=gpu_uuid,pid,process_name,used_gpu_memory",
            "--format=csv,noheader",
        ],
        text=True,
        capture_output=True,
        timeout=10,
        check=False,
    )
    lines = [line for line in result.stdout.splitlines() if GPU in line]
    pids = [int(line.split(",")[1].strip()) for line in lines]
    return {
        "returncode": result.returncode,
        "matching_lines": lines,
        "pids": pids,
        "stderr": result.stderr,
    }


def main():
    protocol = json.loads((OUT / "protocol.json").read_text())
    assert protocol.get("gpu_uuid", GPU) == GPU
    assert protocol["stages"] == ["gate", "feasibility"]
    timeout = int(protocol.get("watchdog_seconds", 600))
    assert 30 <= timeout <= 900
    frozen = json.loads((OUT / "frozen-inputs.json").read_text())
    assert all(
        hashlib.sha256(Path(path).read_bytes()).hexdigest() == digest
        for path, digest in frozen.items()
    )
    report = {
        "status": "PREPARING",
        "gpu_uuid": GPU,
        "watchdog_seconds_per_stage": timeout,
        "stages": [],
        "process_audit_scope": "Sampled every 2 seconds; not continuous exclusivity proof",
    }

    def flush():
        (OUT / "launch-result.json").write_text(json.dumps(report, indent=2) + "\n")

    env = os.environ.copy()
    env.update(
        {str(key): str(value) for key, value in protocol.get("environment", {}).items()}
    )
    env.update(CUDA_VISIBLE_DEVICES=GPU, PYTHONUNBUFFERED="1")
    specifications = [
        (
            "gate",
            [PYTHON, str(OUT / "metadata_gate.py")],
            "M128_METADATA_READY_FULL_AND_EMPTY_EXACT_PASS",
        ),
        (
            "feasibility",
            [PYTHON, str(OUT / "metadata_driver.py"), "feasibility"],
            "FEASIBILITY_PASS",
        ),
    ]
    for name, command, expected in specifications:
        # Refuse to overwrite an executed experiment or a pre-existing GPU owner.
        assert not (OUT / (name + "-result.json")).exists(), name
        before = compute_apps()
        assert before["returncode"] == 0 and not before["pids"], before
        stage = {"name": name, "command": command, "status": "STARTING", "pre": before}
        report["stages"].append(stage)
        report["status"] = "RUNNING_" + name.upper()
        flush()
        with (
            (OUT / (name + ".log")).open("x") as log,
            (OUT / (name + "-process-audit.jsonl")).open("x") as audit,
        ):
            child = subprocess.Popen(
                command,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            stage["pid"] = child.pid
            start = time.monotonic()
            flush()
            try:
                while child.poll() is None:
                    elapsed = time.monotonic() - start
                    sample = compute_apps()
                    audit.write(
                        json.dumps({"elapsed_seconds": elapsed, **sample}) + "\n"
                    )
                    audit.flush()
                    foreign = set(sample["pids"]) - {child.pid}
                    if sample["returncode"] != 0 or foreign:
                        stage["status"] = "PROCESS_AUDIT_FAIL"
                        stage["foreign_pids"] = sorted(foreign)
                        os.killpg(child.pid, signal.SIGKILL)
                        child.wait()
                        break
                    if elapsed > timeout:
                        stage["status"] = "WATCHDOG_TIMEOUT"
                        os.killpg(child.pid, signal.SIGKILL)
                        child.wait()
                        break
                    time.sleep(2)
                if stage["status"] == "STARTING":
                    stage["status"] = "CHILD_EXITED"
                stage["returncode"] = child.returncode
                stage["elapsed_seconds"] = time.monotonic() - start
            finally:
                if child.poll() is None:
                    os.killpg(child.pid, signal.SIGKILL)
                    child.wait()
                stage["post"] = compute_apps()
                cleanup_start = time.monotonic()
                while (
                    stage["post"]["pids"] == [child.pid]
                    and time.monotonic() - cleanup_start < 5
                ):
                    time.sleep(0.25)
                    stage["post"] = compute_apps()
                if stage["post"]["returncode"] != 0 or stage["post"]["pids"]:
                    stage["status"] = "POST_PROCESS_AUDIT_FAIL"
                flush()
        if stage["status"] != "CHILD_EXITED" or stage["returncode"] != 0:
            report["status"] = "STOPPED_" + stage["status"]
            flush()
            raise SystemExit(1)
        result = json.loads((OUT / (name + "-result.json")).read_text())
        stage["result_status"] = result["status"]
        if result["status"] != expected:
            report["status"] = "STOPPED_" + result["status"]
            flush()
            # A failed feasibility is an expected negative scientific result.
            raise SystemExit(
                0
                if name == "feasibility" and result["status"] == "FEASIBILITY_FAIL"
                else 1
            )
        if name == "feasibility":
            report["single_screen_passed"] = result["continuation_gate"]["passed"]
        flush()
    report["status"] = "GATE_AND_SINGLE_FEASIBILITY_COMPLETED"
    report["formal_timing_authorized"] = False
    report["runtime_promoted"] = False
    flush()


if __name__ == "__main__":
    main()
