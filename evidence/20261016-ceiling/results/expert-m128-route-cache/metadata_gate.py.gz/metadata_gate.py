"""Complete parity plus same-graph empty/positive metadata-readiness gate.

The empty probe executes only FC1 and FC2. Its six metadata arrays are copied
from retained, mutable device sources by nodes inside the captured graph. The
same graph therefore validates count transitions without a host-side shortcut.
Native activation and finalizer have no asserted empty no-write contract.
"""

import hashlib
import json
import sys
import traceback


def tensor_hash(value):
    import torch

    return hashlib.sha256(
        value.detach().contiguous().view(torch.uint8).cpu().numpy().tobytes()
    ).hexdigest()


def empty_and_restore_gate(d):
    from flashinfer.fused_moe import core as fi
    from metadata_ready_graph import MetadataReadyGraph, record_eager_metadata

    torch = d.torch
    runtime = fi.get_trtllm_moe_sm100_module()
    dataset = torch.load(
        d.ROOT / "expert-metadata-rebase/oracle-layer0-real.pt",
        map_location="cpu",
        weights_only=False,
    )
    weights = d.c.weights(0, "cuda")
    weight_hashes = [tensor_hash(value) for value in weights]
    x = d.allocate(dataset, weights, "cuda")
    owner = d.native_body(runtime, x)
    fields = ("tile", "mn", "route", "ncta", "padded", "expanded")
    attrs = (
        "cta_idx_xy_to_batch_idx",
        "cta_idx_xy_to_mn_limit",
        "permuted_idx_to_token_idx",
        "num_non_exiting_ctas",
        "total_num_padded_tokens",
        "expanded_idx_to_permuted_idx",
    )
    for key, attr in zip(fields, attrs):
        x["live_" + key] = getattr(owner["slot"], attr)
    stream = d.drv.CUstream(torch.cuda.current_stream().cuda_stream)
    ios = {fc: d.io_for(fc, cfg, x) for fc, cfg in d.configs().items()}
    fns = {fc: d.compile_candidate(fc, io, stream) for fc, io in ios.items()}
    eager_owner = d.candidate_eager(runtime, x, ios, fns, owner)
    torch.cuda.synchronize()
    d.check_metadata("ready/setup/metadata", owner["slot"], x, dataset)
    d.check_outputs("ready/setup", x, dataset["intermediates"])
    d.chk("ready/setup/routed", x["out"], dataset["routed"].cuda())
    rng = torch.cuda.get_rng_state().clone()
    original = {key: x["live_" + key].clone() for key in fields}
    # All six sources have stable storage. Only their contents change for replay.
    sources = {key: value.clone() for key, value in original.items()}
    saved_activation = {key: x[key].clone() for key in ("act", "actscale")}
    readonly = {
        key: value.clone()
        for key, value in x.items()
        if key not in d.OUTPUTS
        and not key.startswith(("guard_", "live_"))
        and key not in ("w1", "s1", "w2", "s2")
    }
    stages = d.candidate_stages(runtime, x, ios, fns)
    owners = [
        runtime,
        x,
        ios,
        fns,
        owner,
        eager_owner,
        sources,
        original,
        saved_activation,
        stages,
    ]

    def metadata_copy():
        for key in fields:
            x["live_" + key].copy_(sources[key])

    def validate():
        d.validate_io(ios["fc2"])

    def body():
        stages["fc1"]()
        stages["fc2"]()

    def eager():
        permit = record_eager_metadata(
            metadata_copy,
            owners=owners,
            fc2_validate=validate,
        )
        permit.wait().launch_once(body)
        # The permit owns every referenced object until its one launch finishes.
        torch.cuda.current_stream().synchronize()
        return permit

    def assert_readonly(label, source_expected):
        for key in fields:
            d.chk(label + "/metadata_" + key, x["live_" + key], source_expected[key])
            d.chk(label + "/source_" + key, sources[key], source_expected[key])
        for key, expected in readonly.items():
            d.chk(label + "/readonly_" + key, x[key], expected)
        for key in d.OUTPUTS:
            raw = x["guard_" + key]
            d.chk(
                label + "/guard_" + key,
                torch.cat((raw[:64], raw[-64:])),
                torch.full_like(raw[:128], 37),
            )
        d.chk(label + "/rng", torch.cuda.get_rng_state(), rng)

    def assert_empty(label, source_expected):
        for key in d.OUTPUTS:
            d.chk(label + "/" + key, x[key], torch.full_like(x[key], d.SENTINELS[key]))
        assert_readonly(label, source_expected)

    sources["ncta"].zero_()
    sources["padded"].zero_()
    empty_expected = {key: value.clone() for key, value in sources.items()}
    d.reset(x)
    eager_empty_owner = eager()
    assert_empty("ready/empty/eager", empty_expected)

    guard = MetadataReadyGraph(
        owners=[*owners, eager_empty_owner],
        fc2_validate=validate,
        mode="gemm_empty_probe",
    )
    with guard.capture():
        guard.record_metadata(metadata_copy)
        guard.record_fc1(stages["fc1"])
        guard.record_fc2(stages["fc2"])
    evidence = guard.seal()
    evidence["label"] = "empty_positive_same_graph"
    d.report.setdefault("metadata_ready_graphs", []).append(evidence)
    d.req("ready/empty/not_full_moe_timing", not evidence["full_moe_timing_allowed"])
    d.req(
        "ready/empty/six_metadata_producers",
        len(evidence["recorded_nodes"]["metadata"]) == 6,
    )
    nodes = {node["identity"]: node for node in evidence["nodes"]}
    for role in ("fc1", "fc2"):
        node = nodes[evidence["recorded_nodes"][role][0]]
        d.req(
            "ready/empty/" + role + "_fixed_nonzero_grid",
            len(node["grid"]) == 3 and all(dim > 0 for dim in node["grid"]),
            node,
        )
    guard.instantiate()
    d.reset(x)
    guard.replay()
    torch.cuda.synchronize()
    assert_empty("ready/empty/same_graph", empty_expected)

    # Positive counts originate inside this SAME graph. Restore activation only:
    # FC1/FC2 must regenerate their own outputs; finalizer output stays sentinel.
    for key in fields:
        sources[key].copy_(original[key])
    d.reset(x)
    for key, value in saved_activation.items():
        x[key].copy_(value)
    guard.replay()
    torch.cuda.synchronize()
    d.check_metadata("ready/restore/metadata", owner["slot"], x, dataset)
    d.check_outputs("ready/restore/same_graph", x, dataset["intermediates"])
    d.chk(
        "ready/restore/no_finalizer",
        x["out"],
        torch.full_like(x["out"], d.SENTINELS["out"]),
    )
    for key, value in saved_activation.items():
        d.chk("ready/restore/retained_" + key, x[key], value)
    assert_readonly("ready/restore/same_graph", original)

    # Re-enter empty on the same executable to expose stale count/metadata use.
    sources["ncta"].zero_()
    sources["padded"].zero_()
    d.reset(x)
    guard.replay()
    torch.cuda.synchronize()
    assert_empty("ready/empty/after_positive", empty_expected)
    for i, (weight, before) in enumerate(zip(weights, weight_hashes)):
        d.req(f"ready/weights_unchanged/{i}", tensor_hash(weight) == before)
    d.report["empty_scope"] = (
        "Fixed nonzero launch grids; live six-field metadata is produced inside "
        "capture by copies from retained device sources. Same sealed executable "
        "runs zero counts, positive native metadata with retained native activation, "
        "then zero counts again. Only FC1/FC2 execute; no empty activation/finalizer "
        "contract and no full-MoE timing claim. Eager uses our completed metadata event."
    )
    d.flush()


def main():
    sys.argv[1:] = ["gate"]
    import metadata_driver as d

    try:
        d.run()
        d.req(
            "all15_full_parity",
            d.report["status"] == "FULL_NATIVE_M128_METADATA_READY_BODY_EXACT_PASS",
        )
        with d.torch.inference_mode():
            empty_and_restore_gate(d)
        d.report.update(
            status="M128_METADATA_READY_FULL_AND_EMPTY_EXACT_PASS",
            runtime_promoted=False,
        )
    except BaseException as exc:
        d.report.update(
            status="M128_METADATA_READY_GATE_FAIL",
            error=repr(exc),
            traceback=traceback.format_exc(),
            timing_allowed=False,
        )
        raise
    finally:
        d.flush()
    print(
        json.dumps({"status": d.report["status"], "checks": len(d.report["checks"])}),
        flush=True,
    )


if __name__ == "__main__":
    main()
