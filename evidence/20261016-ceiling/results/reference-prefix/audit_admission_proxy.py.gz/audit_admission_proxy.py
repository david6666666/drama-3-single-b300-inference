"""CPU-only FIFO proxy from recorded group sizes, not a measured cache hit rate."""
import hashlib,json
from pathlib import Path
R=Path(__file__).resolve().parent
root=R.parent
entries=json.loads((R/'per-request.json').read_text())
ledger=json.loads((root/'current-pipeline-service-ledger.json').read_text())
path=Path(ledger['inputs']['timeline']['path'])
records=json.loads(path.read_text())['records']
start,end=ledger['time']['first_dispatch_s'],ledger['time']['last_completion_s']
groups=[e for e in records if start<=e['cpu_start_s']<=end and e['stage'] in ('prefill','mixed_backbone')]
cache=set();hits=[];misses=[];local_duplicate=[];cursor=0;checks=[]
for e in groups:
 count=e['batch'] if e['stage']=='prefill' else e['prompt_count']
 selected=entries[cursor:cursor+count]
 token_sum=sum(x['prompt_rows'] for x in selected)
 checks.append(dict(stage=e['stage'],count=count,corpus_start=cursor,prompt_token_sum_proxy=token_sum,recorded_prompt_tokens=e.get('prompt_tokens'),prompt_token_sum_matches=token_sum==e['prompt_tokens'] if 'prompt_tokens' in e else None))
 seen_group=set()
 for x in selected:
  k=x['prefix_sha256']
  if k in cache:hits.append(x)
  else:
   misses.append(x)
   if k in seen_group:local_duplicate.append(x)
  seen_group.add(k)
 cache.update(seen_group);cursor+=count
assert cursor==len(entries)
matched=[x for x in checks if x['prompt_token_sum_matches'] is not None]
span=ledger['timeline']['stage']['mixed_backbone']['gpu_event_ms']['sum']/1000
result=dict(status='CPU_PROXY_ONLY',driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),timeline_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),source_sha=ledger['launch']['source_sha'],groups=len(groups),group_sizes=[x['count'] for x in checks],requests=cursor,groups_with_token_count_check=len(matched),token_count_matches=sum(x['prompt_token_sum_matches'] for x in matched),natural_completed_prefix_proxy_hits=len(hits),natural_completed_prefix_proxy_rows=sum(x['prefix_rows'] for x in hits),same_group_duplicate_prefixes=len(local_duplicate),same_group_duplicate_rows=sum(x['prefix_rows'] for x in local_duplicate),full_prefix_upper_rows=sum(x['prefix_rows'] for x in hits+local_duplicate),full_prompt_rows=sum(x['prompt_rows'] for x in entries),mixed_backbone_and_teacher_span_s=span,linear_row_cost_budget_s=span*sum(x['prefix_rows'] for x in hits+local_duplicate)/sum(x['prompt_rows'] for x in entries),checks=checks,limitations=['Assumes FIFO corpus order within recorded arriving groups; service trace contains no request IDs, so matching token sums is consistency evidence rather than proof of exact server admissions.','Cache becomes ready after each group. Same-group duplicates are not already-computed cache hits; deduplicating them requires explicit prefix computation and state fork.','Linear row-cost budget overassigns all mixed backbone/teacher span to cacheable prompt work and ignores old decode, nonlinearity, duplicate weight scans and snapshots. It is neither measured gain nor rigorous roofline.'])
(R/'admission-proxy.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('checks','group_sizes')},indent=2))
