"""CPU-only exact prompt prefix/accounting; no model import or CUDA use."""
import ast
import copy
import hashlib
import json
import re
from collections import Counter, OrderedDict, defaultdict
from pathlib import Path
from types import SimpleNamespace
from typing import Sequence
import torch
from tokenizers import Tokenizer

ROOT=Path(__file__).resolve().parent
FISH=Path('/home/zjy/code/hsliu/drama3-sources/fish-speech/fish_speech/models/text2semantic/fish_omni/generate.py')
CHECK=Path('/home/zjy/.cache/huggingface/hub/models--fishaudio--drama-3/snapshots/e0a9218aa48888270f06ef1ed9ea67622c0e17d2')
CORPUS=Path('/home/zjy/code/hsliu/artifacts/drama3-b300-20261014/seedtts-en1088-codes/requests.jsonl')
source=FISH.read_text(); tree=ast.parse(source)
constants={'DRAMA3_TTS_INSTRUCTION','DRAMA3_REFERENCE_INSTRUCTION','DRAMA3_MESSAGE_END','DRAMA3_GENERATION_START','DRAMA3_STRUCTURAL_TOKENS','SPEAKER_TAG_PATTERN','MAX_SPEAKER_ID','UNICODE_WHITE_SPACE','DRAMA3_MAX_PROMPT_ROWS'}
functions={'validate_drama3_text','with_speaker_tag','build_drama3_prompt'}
nodes=[]
for n in tree.body:
 if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in constants for t in n.targets): nodes.append(n)
 if isinstance(n,ast.FunctionDef) and n.name in functions: nodes.append(n)
ns=dict(torch=torch,re=re,Sequence=Sequence,Tokenizer=Tokenizer,FishOmniConfig=object,InvalidInputError=ValueError,Drama3PromptTooLongError=ValueError)
exec(compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),str(FISH),'exec'),ns)
# Separate AST observer returns the builder's own segments; original stays intact.
observer=copy.deepcopy(next(n for n in nodes if isinstance(n,ast.FunctionDef) and n.name=='build_drama3_prompt'))
observer.name='observe_segments'
cut=next(i for i,n in enumerate(observer.body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='rows' for t in n.targets))
observer.body=observer.body[:cut]+[ast.Return(value=ast.Name(id='segments',ctx=ast.Load()))]
exec(compile(ast.fix_missing_locations(ast.Module(body=[observer],type_ignores=[])),str(FISH),'exec'),ns)
cfg=json.loads((CHECK/'config.json').read_text())
config=SimpleNamespace(audio_decoder=SimpleNamespace(num_codebooks=cfg['audio_decoder_config']['num_codebooks'],vocab_size=cfg['audio_decoder_config']['vocab_size']),**{k:cfg[k] for k in ('semantic_start_token_id','semantic_end_token_id','eos_token_id')})
tokenizer=Tokenizer.from_file(str(CHECK/'tokenizer.json'))
samples=[json.loads(line) for line in CORPUS.read_bytes().splitlines()]
entries=[]; byref=defaultdict(set); unique={}; previous={}; distances=[]
for index,s in enumerate(samples):
 codes=torch.tensor(s['reference_codes'],dtype=torch.int64)
 args=(s['text'],tokenizer,config,[s['reference_text']],[codes])
 prompt=ns['build_drama3_prompt'](*args)
 segments=ns['observe_segments'](*args)
 # Last four segments are user header, tagged target, message end, assistant start.
 assert segments[-4]=='<|im_start|>user\n'
 assert segments[-3]==ns['with_speaker_tag'](s['text'])
 prefix_segments=segments[:-3]
 rows=[]
 for segment in prefix_segments:
  if isinstance(segment,str):
   ids=torch.tensor(tokenizer.encode(segment).ids,dtype=torch.long)
   chunk=torch.zeros((len(ids),11),dtype=torch.long);chunk[:,0]=ids
  else: chunk=torch.cat((segment[:1]+config.semantic_start_token_id,segment)).T
  rows.append(chunk)
 prefix=torch.cat(rows); assert torch.equal(prompt[:len(prefix)],prefix)
 digest=hashlib.sha256(prefix.numpy().tobytes()).hexdigest()
 entry=dict(index=index,id=s['id'],reference_sha256=s['reference_sha256'],prefix_sha256=digest,prompt_rows=len(prompt),prefix_rows=len(prefix),suffix_rows=len(prompt)-len(prefix),audio_reference_rows=codes.shape[-1],first_occurrence=digest not in unique)
 entries.append(entry);byref[s['reference_sha256']].add(digest)
 if digest in previous:distances.append(index-previous[digest])
 previous[digest]=index;unique.setdefault(digest,entry)
assert not torch.cuda.is_initialized()

def stats(values):
 a=sorted(values);n=len(a)
 return dict(n=n,min=a[0],p50=a[n//2],p95=a[min(n-1,int(n*.95))],max=a[-1],mean=sum(a)/n,sum=sum(a))

def simulate(capacity,window=1,warmup=0):
 cache=OrderedDict(); hits=[];misses=[];transfers=0
 def publish(e):
  nonlocal transfers
  key=e['prefix_sha256']
  if key in cache: cache.move_to_end(key);return
  cache[key]=e;transfers+=entry_bytes(e)
  while len(cache)>capacity:cache.popitem(last=False)
 # Optional existing benchmark warmup only; never extra reference-wide prefill.
 for e in entries[:warmup]:publish(e)
 for start in range(0,len(entries),window):
  pending=[]
  for e in entries[start:start+window]:
   key=e['prefix_sha256']
   if key in cache:
    hits.append(e);cache.move_to_end(key);transfers+=entry_bytes(e)
   else:misses.append(e);pending.append(e)
  for e in pending:publish(e)
 return dict(capacity=capacity,publication_window=window,warmup_rows=warmup,hits=len(hits),misses=len(misses),saved_backbone_rows=sum(e['prefix_rows'] for e in hits),saved_tower_rows=sum(e['prefix_rows']-1 for e in hits),saved_backbone_fraction=sum(e['prefix_rows'] for e in hits)/sum(e['prompt_rows'] for e in entries),snapshot_payload_bytes=transfers,resident_payload_bytes=sum(entry_bytes(e) for e in cache.values()))
GDN=30*32*128*128*2
CONV=30*8192*3*2
# BF16 backbone10/tower13 KV, 2(K,V)*2heads*256dim*2bytes.
def entry_bytes(e):return GDN+CONV+10*2048*e['prefix_rows']+13*2048*(e['prefix_rows']-1)+2048*2
result=dict(status='CPU_ONLY_NO_MODEL_OR_CUDA',source=str(FISH),source_sha256=hashlib.sha256(source.encode()).hexdigest(),driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),corpus_sha256=hashlib.sha256(CORPUS.read_bytes()).hexdigest(),tokenizer_sha256=hashlib.sha256((CHECK/'tokenizer.json').read_bytes()).hexdigest(),n=len(entries),unique_reference_audio=len(byref),unique_prefixes=len(unique),reference_with_multiple_prefixes={k:list(v) for k,v in byref.items() if len(v)>1},prefix_histogram=stats([e['prefix_rows'] for e in entries]),prompt_histogram=stats([e['prompt_rows'] for e in entries]),suffix_histogram=stats([e['suffix_rows'] for e in entries]),all_prefix_fraction=sum(e['prefix_rows'] for e in entries)/sum(e['prompt_rows'] for e in entries),repeat_distance=stats(distances),memory=dict(gdn_bytes_per_entry=GDN,conv_bytes_per_entry=CONV,kv_bytes_per_backbone_row=10*2048,kv_bytes_per_tower_row=13*2048,last_hidden_bytes=4096,entry_bytes=stats([entry_bytes(e) for e in unique.values()]),all_unique_bytes=sum(entry_bytes(e) for e in unique.values())),simulations=[simulate(cap,window,warmup) for warmup in (0,64) for cap in (32,64,128,256,512,666,1088) for window in (1,8,64)],limitations=['Window=1 immediate post-prefill availability is a cold-cache upper bound for corpus file order, not a measured runtime hit rate.','Window=8/64 model grouped publication conservatively for that artificial grouping only; actual admission groups/readiness require runtime metadata.','Memory assumes a BF16 recurrent boundary snapshot; native FLA chunk internal FP32 boundary and changed suffix arithmetic need separate correctness/quality proof.','Existing64request warmup shown separately; no reference-wide or future-target prefill permitted.'])
(ROOT/'counts.json').write_text(json.dumps(result,indent=2)+'\n')
(ROOT/'per-request.json').write_text(json.dumps(entries,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('simulations','reference_with_multiple_prefixes')},indent=2))
print('SIMULATIONS',json.dumps([s for s in result['simulations'] if s['capacity'] in (64,256,666) and (s['publication_window'] in (1,8) and s['warmup_rows']==0 or s['publication_window']==1 and s['warmup_rows']==64)],indent=2))
