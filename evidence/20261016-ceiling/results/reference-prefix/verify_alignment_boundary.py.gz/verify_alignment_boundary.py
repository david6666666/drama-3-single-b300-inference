"""Integer-only audit of existing records; no tokenizer, torch, CUDA or cache simulation."""
import hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parent
saved=json.loads((root/'alignment-boundary-proof.json').read_text())
for name,expected in saved['source_hashes'].items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==expected
rows=json.loads((root/'per-request.json').read_text());admit=json.loads((root/'admission-proxy.json').read_text())
group={i:g for g,x in enumerate(admit['checks']) for i in range(x['corpus_start'],x['corpus_start']+x['count'])}
cases=[]
for x in rows:
 if x['first_occurrence']:continue
 i=x['index'];assert i>0 and rows[i-1]['prefix_sha256']==x['prefix_sha256']
 cases.append(dict(index=i,prefix_rows=x['prefix_rows'],boundary=((x['prefix_rows']-1)//128)*128,kind='ready_proxy' if group[i-1]!=group[i] else 'same_group'))
assert cases==saved['cases']
count=0
for P in range(106,241):
 C=((P-1)//128)*128
 for suffix in range(11,38):
  L=P+suffix;assert C<P and C%64==0 and L>C
  if C:
   assert C>=3 and C//64<(L+63)//64
   assert all((C+j)//64==C//64+j//64 for j in range(L-C))
   assert C-1+1<P
   for j in (0,L-C-1):assert (L-(L-C))+j==C+j
  count+=1
assert count==saved['domain_cases']==3645
for name in ('ready_proxy','same_group'):
 sub=[x for x in cases if x['kind']==name]
 assert saved['aligned_proxy'][name]==dict(hits=len(sub),aligned_hits=sum(x['boundary']>0 for x in sub),saved_rows=sum(x['boundary'] for x in sub))
assert sum(x['boundary'] for x in cases)==saved['all_saved_rows']==46208
print(json.dumps(dict(status='CPU_BOUNDARY_VERIFY_PASS',domain_cases=count,derived_repeat_records=len(cases),source_hashes_verified=True,cuda_imported=False)))
