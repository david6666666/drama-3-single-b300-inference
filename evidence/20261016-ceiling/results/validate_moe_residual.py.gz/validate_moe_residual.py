"""Exact native MoE combine/residual fusion gate and diagnostic event timing."""

import argparse
import hashlib
import json
import os
import statistics
import subprocess
import sys
from pathlib import Path
from types import SimpleNamespace

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--source", type=Path, required=True)
parser.add_argument("--checkpoint", required=True)
parser.add_argument("--corpus", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
sys.path.insert(0, str(args.source / "src"))
sys.path.insert(0, str(args.source / "scripts"))

import torch
import torch.nn.functional as F
import triton
from fish_speech.models.text2semantic.fish_omni.generate import build_drama3_prompt
from validate_mixed_layers import Checks, restore, snapshot, state_tensors

import drama3.mixed_model as mixed_module
import drama3.model as model_module
from drama3.engine import BatchedPrefillGraph, DecodeGraph, state_pool_size
from drama3.kernels import add_norm, combine_experts, combine_experts_add_norm
from drama3.mixed_graph import MixedGraph
from drama3.model import DramaModel
from drama3.runtime_state import DeviceRequests


def outputs(graph):
    return graph.output if isinstance(graph.output, tuple) else (graph.output,)


@torch.inference_mode()
def main():
    raw = args.corpus.read_bytes()
    checks = Checks(
        args.output,
        dict(
            source_sha=subprocess.check_output(
                ["git", "rev-parse", "HEAD"], cwd=args.source, text=True
            ).strip(),
            source_status=subprocess.check_output(
                ["git", "status", "--porcelain"], cwd=args.source, text=True
            ),
            driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            corpus_sha256=hashlib.sha256(raw).hexdigest(),
            gpu_uuid=str(torch.cuda.get_device_properties(0).uuid),
            environment={
                k: v for k, v in os.environ.items() if k.startswith("DRAMA3_")
            },
            experiment=json.loads(
                (Path(__file__).parent / "moe-residual-experiment.json").read_text()
            ),
        ),
    )
    try:
        model = DramaModel(args.checkpoint, slots=state_pool_size(64), max_length=2048)
        if model.prefill_moe != "flashinfer" or model.tuned_prefill_moe:
            raise ValueError("Require native untuned FlashInfer MoE")
        if model.state_precision != "bfloat16" or model.moe_shared_stream is not None:
            raise ValueError("Require BF16 state and initial shared overlap disabled")
        device = DeviceRequests(
            model.slots, model.config.eos_token_id, model.max_length
        )
        norms = [layer.input_layernorm for layer in model.backbone.layers[1:]]
        norms.append(model.backbone.norm)
        norm_indices = {id(norm.weight): i for i, norm in enumerate(norms)}
        generator = torch.Generator(device="cuda").manual_seed(93741)
        static_rows = [1, 2, 4, 8, 16, 32, 64, 1344, 1344, 1344]
        for index, norm in enumerate(norms):
            for trial, rows in enumerate(static_rows):
                scale = [0.01, 0.25, 1.0, 4.0, 64.0][trial % 5]
                routed = (
                    torch.randn(rows, 2048, device="cuda", generator=generator) * scale
                ).bfloat16()
                shared = (
                    torch.randn(rows, 2048, device="cuda", generator=generator) * scale
                ).bfloat16()
                gate_storage = torch.randn(
                    rows,
                    1281 if trial % 2 else 1,
                    device="cuda",
                    generator=generator,
                    dtype=torch.bfloat16,
                )
                gate = gate_storage[:, -1:]
                if trial >= 7:
                    gate.copy_(torch.linspace(-90, 90, rows, device="cuda")[:, None])
                residual = torch.randn_like(routed)
                if trial == 8:
                    residual.copy_(-routed)
                if trial == 9:
                    shared.zero_()
                expected_residual = residual.clone()
                expected = add_norm(
                    combine_experts(routed, shared, gate),
                    expected_residual,
                    norm.weight,
                    norm.eps,
                )
                actual = combine_experts_add_norm(
                    routed, shared, gate, residual, norm.weight, norm.eps
                )
                name = f"static/norm{index}/input{trial}/rows{rows}"
                checks.tensor(name + "/normalized", actual, expected, exact=True)
                checks.tensor(
                    name + "/residual", residual, expected_residual, exact=True
                )
        print("STATIC_EXACT_40_NORMS_X_10_INPUTS", flush=True)

        samples = [json.loads(line) for line in raw.splitlines()][:64]
        prompts = [
            build_drama3_prompt(
                s["text"],
                model.weights.tokenizer,
                model.config,
                [s["reference_text"]],
                [torch.tensor(s["reference_codes"])],
            )
            for s in samples
        ]
        model.fused_moe_residual = False
        prefill = BatchedPrefillGraph(
            model, 8, triton.next_power_of_2(max(map(len, prompts)))
        )
        first = DecodeGraph(model, 8, first_frame=True, requests=device)
        control_decode = DecodeGraph(model, 64, requests=device)
        model.fused_moe_residual = True
        candidate_decode = DecodeGraph(model, 64, requests=device)
        model.fused_moe_residual = False
        control_mixed = MixedGraph(model, device, 64, 8, 1280, max_length=256)
        model.fused_moe_residual = True
        candidate_mixed = MixedGraph(model, device, 64, 8, 1280, max_length=256)
        # Additional compatibility gate: retain the existing explicit shared-stream join.
        shared_stream = torch.cuda.Stream()
        model.moe_shared_stream = shared_stream
        model.fused_moe_residual = False
        control_shared = DecodeGraph(model, 64, requests=device)
        model.fused_moe_residual = True
        candidate_shared = DecodeGraph(model, 64, requests=device)
        model.moe_shared_stream = None
        tensors = state_tensors(model, device)

        def initialize(count):
            model.fused_moe_residual = False
            active = [
                SimpleNamespace(slot=i, position=len(prompts[i]) - 1)
                for i in range(count)
            ]
            for i, p in enumerate(prompts[:count]):
                history = F.pad(p[-16:, 0], (max(0, 16 - len(p)), 0), value=-1).cuda()
                device.initialize(i, p[-1].cuda(), history, len(p) - 1, 500)
            for start in range(0, count, 8):
                end = min(start + 8, count)
                hidden = prefill.run(prompts[start:end], list(range(start, end)))
                first.run(active[start:end], hidden)
            return active

        def ownership(label, initial, owned):
            other = torch.tensor(
                [s for s in range(model.slots) if s not in owned], device="cuda"
            )
            for (name, value), saved in zip(tensors.items(), initial, strict=True):
                if name == "sampling_step":
                    continue
                checks.tensor(
                    label + "/untouched/" + name,
                    value.index_select(0, other),
                    saved.index_select(0, other),
                    exact=True,
                )

        def live_layers(graph, label, initial):
            visited = []

            def probe(routed, shared, gate, residual, weight, epsilon):
                expected_residual = residual.clone()
                expected = add_norm(
                    combine_experts(routed, shared, gate),
                    expected_residual,
                    weight,
                    epsilon,
                )
                actual = combine_experts_add_norm(
                    routed, shared, gate, residual, weight, epsilon
                )
                index = norm_indices[id(weight)]
                checks.tensor(
                    f"{label}/live/norm{index}/output", actual, expected, exact=True
                )
                checks.tensor(
                    f"{label}/live/norm{index}/residual",
                    residual,
                    expected_residual,
                    exact=True,
                )
                visited.append(index)
                return actual

            model.fused_moe_residual = True
            model_module.combine_experts_add_norm = probe
            mixed_module.combine_experts_add_norm = probe
            try:
                result = graph.forward()
                eager_output = snapshot(
                    result if isinstance(result, tuple) else (result,)
                )
                eager_state = snapshot(tensors.values())
            finally:
                model_module.combine_experts_add_norm = combine_experts_add_norm
                mixed_module.combine_experts_add_norm = combine_experts_add_norm
                restore(tensors.values(), initial)
            if visited != list(range(40)):
                raise AssertionError(
                    ("Every native MoE boundary must be tested", visited)
                )
            return eager_output, eager_state

        def compare(label, control, candidate, count, shared=False):
            active = initialize(count)
            model.moe_shared_stream = shared_stream if shared else None
            if isinstance(candidate, MixedGraph):
                for graph in (control, candidate):
                    graph.prepare(active, prompts[58:64], list(range(58, 64)))
                owned = set(candidate.layout.sequence_slots.tolist())
                owned.update(candidate.slots[: candidate.decode_size].tolist())
            else:
                for graph in (control, candidate):
                    graph.slots.copy_(torch.arange(64, device="cuda"))
                owned = set(range(64))
            initial = snapshot(tensors.values())
            eager_output, eager_state = live_layers(candidate, label, initial)
            control.graph.replay()
            expected_output, expected_state = (
                snapshot(outputs(control)),
                snapshot(tensors.values()),
            )
            ownership(label + "/control", initial, owned)
            restore(tensors.values(), initial)
            candidate.graph.replay()
            for i, (actual, expected, eager) in enumerate(
                zip(outputs(candidate), expected_output, eager_output, strict=True)
            ):
                checks.tensor(f"{label}/graph_output{i}", actual, expected, exact=True)
                checks.tensor(
                    f"{label}/graph_vs_eager_output{i}", actual, eager, exact=True
                )
            for (name, actual), expected, eager in zip(
                tensors.items(), expected_state, eager_state, strict=True
            ):
                checks.tensor(
                    f"{label}/graph_state/{name}", actual, expected, exact=True
                )
                checks.tensor(
                    f"{label}/graph_vs_eager_state/{name}", actual, eager, exact=True
                )
            ownership(label + "/candidate", initial, owned)
            del eager_state, expected_state, eager_output, expected_output
            timings = {"control_ms": [], "fused_ms": []}
            for iteration in range(6):
                arms = [("control_ms", control), ("fused_ms", candidate)]
                if iteration % 2:
                    arms.reverse()
                for name, graph in arms:
                    restore(tensors.values(), initial)
                    begin, end = (
                        torch.cuda.Event(enable_timing=True) for _ in range(2)
                    )
                    begin.record()
                    graph.graph.replay()
                    end.record()
                    end.synchronize()
                    if iteration:
                        timings[name].append(begin.elapsed_time(end))
            medians = {k: statistics.median(v) for k, v in timings.items()}
            result = dict(
                case=label,
                rows=1344 if isinstance(candidate, MixedGraph) else 64,
                active=count,
                shared_stream=shared,
                timings=timings,
                median_ms=medians,
                latency_decrease_ms=medians["control_ms"] - medians["fused_ms"],
                passed=True,
            )
            checks.report["cases"].append(result)
            checks.flush()
            print(json.dumps(result), flush=True)
            model.moe_shared_stream = None

        compare("b64", control_decode, candidate_decode, 64)
        compare("d58-p6-d64p1280", control_mixed, candidate_mixed, 58)
        compare("b64-shared-stream", control_shared, candidate_shared, 64, shared=True)
        checks.report["status"] = "PASS"
        checks.flush()
    except Exception as error:
        checks.report["status"] = "FAIL"
        checks.report["failure"] = dict(type=type(error).__name__, message=str(error))
        checks.flush()
        raise


if __name__ == "__main__":
    main()
