"""One declared full service pair after all exact production pipeline gates pass."""
import datetime
import hashlib
import json
import os
import re
from pathlib import Path
import socket
import subprocess
import threading

root = Path('/home/zjy/code/hsliu/artifacts/drama3-ceiling-20261016')
source = root / 'source-codec-cache'
venv = Path('/home/zjy/code/hsliu/venvs/codex-drama3-standalone')
checkpoint = '/home/zjy/.cache/huggingface/hub/models--fishaudio--drama-3/snapshots/e0a9218aa48888270f06ef1ed9ea67622c0e17d2'
corpus = '/home/zjy/code/hsliu/artifacts/drama3-b300-20261014/seedtts-en1088-codes/requests.jsonl'
uuid = 'GPU-619f7fdc-5f98-8c37-fe89-0465d6130baf'
sha = subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()
assert sha == 'e7cda1eba083603b88e1f2e89688e1ff2ced7fc2'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True)
assert not subprocess.check_output(['git','diff','--name-only','a7118fb7eb748d08c3b774fa6c9189b6eab0d9cc',sha,'--','src/drama3/model.py','src/drama3/frame_pipeline.py','src/drama3/kernels.py','src/drama3/mixed_model.py'],cwd=source,text=True)
validation = json.loads((root/'frame-pipeline-production-v2-validation.json').read_text())
assert validation['status']=='PASS' and len(validation['checks'])==3689 and all(c['passed'] for c in validation['checks'])
codec_gate=json.loads((root/'codec-cache-dynamic/result.json').read_text())
assert codec_gate['source_sha']==sha and codec_gate['passed'] and codec_gate['normal_matches_archived']
assert len(codec_gate['all_shape_checks'])==46 and all(c['passed'] for c in codec_gate['all_shape_checks'])
assert len(codec_gate['modes'])==4 and all(m['passed'] and m['trace_matches'] and m['trace_length']==414 for m in codec_gate['modes'])
flags = dict(DRAMA3_GDN_STATE_DTYPE='bfloat16', DRAMA3_PREFILL_GDN='fla', DRAMA3_PACKED_MOE_PROJECTION='1', DRAMA3_PREFILL_CONV='triton', DRAMA3_PREFILL_MOE_TUNED='0', DRAMA3_PREFILL_MOE='flashinfer', DRAMA3_ADMISSION_MIN_BATCH='6', DRAMA3_PREFILL_BUCKET_192='1', DRAMA3_PACKED_PREFILL='1', DRAMA3_ASYNC_CODEC='1', DRAMA3_AUDIO_DELIVERY_THREAD='1', DRAMA3_FUSED_MOE_INPUT='1', DRAMA3_MIXED_BACKBONE='1', DRAMA3_MIXED_SPAN256='1', DRAMA3_CODEC_DEDICATED_CAPTURE_STREAM='1', DRAMA3_COMPACT_GDN='1', DRAMA3_FUSED_MIXED_LAYOUT='1', DRAMA3_PACKED_CONV_GUARD='1', DRAMA3_DEFER_CODEC_SUBMIT='0', DRAMA3_CODEC_SPLIT_POLICY='dp', DRAMA3_SHORT_PADDING_CONTEXT='1', DRAMA3_FUSED_MOE_RESIDUAL='1', DRAMA3_CODEC_SMS='0', DRAMA3_RESERVED_PADDING_ROUTER='1', DRAMA3_FRAME_PIPELINE='1', DRAMA3_FRAME_PIPELINE_DEFERRED_WAITING='1', DRAMA3_CODEC_CACHED_LINEAR='0', DRAMA3_CODEC_COALESCE='0')
env = {k:v for k,v in os.environ.items() if not k.startswith('DRAMA3_')}
env.update(flags, PYTHONPATH=str(source/'src'), HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
processes = subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid,pid,process_name,used_gpu_memory','--format=csv,noheader'],text=True)
assert uuid not in processes, 'GPU6 not idle'
with socket.socket() as probe:
    assert probe.connect_ex(('127.0.0.1',18139)) != 0, 'port18139 occupied'
plan = dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    hypothesis='Caching the native FP32 codec Linear weight conversions removes40 repeat BF16-to-FP32 casts per codec invocation and may improve complete C64 service while retaining exact PCM/state.',
    isolated_variable='Only DRAMA3_CODEC_CACHED_LINEAR0->1; both FRAME_PIPELINE1 and DEFERRED_WAITING1, five native flags and RESERVED_PADDING_ROUTER1, privateasync/thread, DP, coalesce0, SMS0 and defer0.',
    source_sha=sha, source=str(source), flags=flags, gpu=6, gpu_uuid=uuid, port=18139,
    cpu_affinity=sorted(os.sched_getaffinity(0)), omp_threads=8, requests=1088, concurrency=64,
    repeats=1, profile_enabled=False, checkpoint=checkpoint, corpus=corpus,
    corpus_sha256=hashlib.sha256(Path(corpus).read_bytes()).hexdigest(),
    prerequisites='Root codec-cache-dynamic/result.json production PASS:46 captured shapes PCM/full state exact; normal_sync/cached_sync/cached_poll/cached_thread each414 trace and80 PCM/full model+codec state exact, distinct BLAS workspaces. Earlier pipeline3689 and selector73 gates retained.',
    gate='All1088 complete and unfiltered1088 WER/SIM per arm. WER<=2.950933601272712%, SIM>=61.88158934120563 versus frozen same-C64 vLLM. Inspect startup, drain, outputs/frames, throughput/TTFA/RTF and eligibility.',
    scheduling='Pair keeps roster and executes second model frame after first EOS, but sticky append mask and CPU first-EOS break prevent extra output. At most one-frame finish/admission delay. Horizon/pending checks retained. Both arms capture identical graphs; initial sampling_step is not instrumented or reset, and later admission/row/step schedules and output lengths can differ. No fixed-seed or fixed-output speedup claim. A deferred waiting deadline crossed during a pair is checked after one additional model step; no hard millisecond delay guarantee.',
    eligibility='Shutdown counts cover entire server lifetime, including max(warmup,C)=64 warmup requests plus1088 measured requests. They are actual decisions, not benchmark-only counters. Mixed/prefill branches are excluded from ordinary-decode selection counts.',
    memory='Cache retains about208MiB. One-second nvidia-smi process memory polling records observed startup/steady peaks, not exact allocator peak or all subsecond transient clones.',
    arm_times={},
    dp_policy='Production DP unchanged. Each startup measures its own codec costs; partitions not frozen. No profiling during service.',
    prepare='Reuse final-path venv/checkpoint/cache. No download/copy/cache flush/clock changes. Process-to-health capture/warmup recorded separately; reference warmup skipped for preencoded corpus, per-concurrency warmup retained.',
    stop='Abort on foreign GPU6 process, server failure, incomplete output or native failure; preserve all artifacts.',
    target_c64_frames_s=6765.407263214912, before_gpu=processes,
    driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
assert plan['corpus_sha256']=='08612ee05ab0dd8a762109978b5f230e5b0311a1dfde87f03a4572434dff2dac'
plan['storage']={p:subprocess.check_output(['findmnt','-T',p,'-o','TARGET,SOURCE,FSTYPE','--noheadings'],text=True).strip() for p in (str(venv),checkpoint,'/home/zjy/.cache/huggingface/hub')}
(root/'codec-cache-service-experiment.json').write_text(json.dumps(plan,indent=2)+'\n')
stop=threading.Event()
def audit():
    with (root/'codec-cache-service-process-audit.jsonl').open('w') as file:
        while not stop.is_set():
            result=subprocess.run(['nvidia-smi','--query-compute-apps=gpu_uuid,pid,process_name,used_gpu_memory','--format=csv,noheader'],capture_output=True,text=True)
            file.write(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),processes=result.stdout.splitlines()))+'\n');file.flush();stop.wait(1)
thread=threading.Thread(target=audit);thread.start()
expected_pids=set()
try:
    for enabled,arm in [('0','control'),('1','candidate')]:
        name=f'codec-cache-{arm}-gpu6'
        cmd=[str(venv/'bin/python'),str(source/'scripts/run_baseline.py'),'--backend','standalone','--source',str(source),'--venv',str(venv),'--bench-python',str(venv/'bin/python'),'--checkpoint',checkpoint,'--fish-source','/home/zjy/code/hsliu/drama3-sources/fish-speech','--corpus',corpus,'--output',str(root/name),'--gpu','6','--port','18139','--capacity','64','--requests','1088','--repeats','1','--concurrency','64','--skip-reference-warmup']
        (root/f'{name}-command.json').write_text(json.dumps(cmd,indent=2)+'\n')
        plan['arm_times'][arm]={'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
        (root/'codec-cache-service-experiment.json').write_text(json.dumps(plan,indent=2)+'\n')
        print('Starting',name,flush=True)
        subprocess.run(cmd,env=dict(env,DRAMA3_CODEC_CACHED_LINEAR=enabled),check=True)
        plan['arm_times'][arm]['end_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        (root/'codec-cache-service-experiment.json').write_text(json.dumps(plan,indent=2)+'\n')
        metrics=json.loads((root/name/'benchmark/summary.json').read_text())[0]
        assert metrics['completed']==1088 and metrics['failed']==0, metrics
        assert 'Application shutdown complete' in (root/name/'server.log').read_text(), 'Server drain not confirmed'
        expected_pids.add(int(re.search(r'Started server process \[(\d+)\]', (root/name/'server.log').read_text()).group(1)))
        audit_rows=[json.loads(line) for line in (root/'codec-cache-service-process-audit.jsonl').read_text().splitlines()]
        observed={int(row.split(',')[1].strip()) for sample in audit_rows for row in sample['processes'] if uuid in row}
        assert not observed-expected_pids, f'Foreign GPU6 processes observed: {observed-expected_pids}'
        print('Finished',name,json.dumps(metrics),flush=True)
finally:
    stop.set();thread.join()
