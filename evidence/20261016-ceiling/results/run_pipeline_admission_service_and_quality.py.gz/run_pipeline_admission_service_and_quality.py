import subprocess
from pathlib import Path
root=Path(__file__).resolve().parent
python='/home/zjy/code/hsliu/venvs/codex-drama3-standalone/bin/python'
for script in ('run_pipeline_admission_pair.py','run_pipeline_admission_quality.py'):
    subprocess.run([python,str(root/script)],check=True)
