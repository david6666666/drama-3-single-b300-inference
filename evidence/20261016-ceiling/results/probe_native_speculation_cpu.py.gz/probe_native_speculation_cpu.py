"""CPU-only causal exact code-pair proposals, with no model or GPU execution."""
import hashlib
import json
from collections import defaultdict
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parent
CORPUS = Path('/home/zjy/code/hsliu/artifacts/drama3-b300-20261014/seedtts-en1088-codes/requests.jsonl')
SOURCE = ROOT / 'source-pipeline-admission-95fcb0e'


def measure(sequences):
    counts = defaultdict(lambda: dict(attempted=0, proposed=0, exact=0))
    details = []
    for name, sequence in sequences:
        maps = [dict() for _ in range(4)]
        choices = [defaultdict(set) for _ in range(4)]
        seen = set()
        local = defaultdict(int)
        for t, target in enumerate(sequence):
            if t:
                proposals = {'last_pair': sequence[t-1]}
                for k in range(1, 5):
                    context = tuple(sequence[max(0,t-k):t])
                    proposal = maps[k-1].get(context) if t >= k else None
                    proposals[f'ngram{k}_last_successor'] = proposal
                    proposals[f'ngram{k}_last_successor_fallback_last'] = proposal or sequence[t-1]
                    oracle = counts[f'ngram{k}_oracle_among_observed_successors']
                    oracle['attempted'] += 1
                    available = choices[k-1].get(context, set()) if t >= k else set()
                    oracle['proposed'] += bool(available)
                    oracle['exact'] += target in available
                for method, proposal in proposals.items():
                    record = counts[method]
                    record['attempted'] += 1
                    record['proposed'] += proposal is not None
                    record['exact'] += target == proposal
                for index, key in enumerate(['last_semantic_alone', 'last_vq1_alone']):
                    record = counts[key]
                    record['attempted'] += 1
                    record['proposed'] += 1
                    record['exact'] += target[index] == sequence[t-1][index]
                record = counts['oracle_any_previously_observed_pair']
                record['attempted'] += 1
                record['proposed'] += bool(seen)
                record['exact'] += target in seen
                local['last_pair_exact'] += target == sequence[t-1]
                local['oracle_previous_pair_exact'] += target in seen
            # Update only AFTER proposal scoring; no future token or corpus lookup.
            for k in range(1, 5):
                if t >= k:
                    context = tuple(sequence[t-k:t])
                    maps[k-1][context] = target
                    choices[k-1][context].add(target)
            seen.add(target)
        details.append(dict(id=name, frames=len(sequence), **local))
    for record in counts.values():
        record['exact_fraction_all_transitions'] = record['exact'] / max(record['attempted'], 1)
        record['exact_fraction_when_proposed'] = record['exact'] / max(record['proposed'], 1)
    return dict(sequences=len(sequences), frames=sum(len(s) for _,s in sequences), methods=counts, per_sequence=details)


paths = sorted((ROOT/'codec-minlaunch/prefix-replay-arrays/codes').glob('request-*.pt'))
generated = []
for path in paths:
    codes = torch.load(path, map_location='cpu', weights_only=True)
    assert codes.ndim == 2 and codes.shape[0] == 10
    generated.append((path.stem, [tuple(row) for row in codes[:2].T.tolist()]))
rows = [json.loads(line) for line in CORPUS.read_text().splitlines()]
reference = [(row['id'], list(zip(*row['reference_codes'][:2], strict=True))) for row in rows]
unique = {}
for row, item in zip(rows, reference, strict=True):
    key = hashlib.sha256(json.dumps(row['reference_codes'], separators=(',',':')).encode()).hexdigest()
    unique.setdefault(key, item)
result = dict(
    hypothesis='Cheap causal last-frame/ngram proposals must exactly match both native next-backbone input codes to permit useful two-position verification.',
    gpu_used=False,
    source_sha='95fcb0ef2662f2caf9bfb7fe6863dc3ad7805b1b',
    driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    input_definition='Frame[:,0]=semantic_begin+codebook0 for emitted acoustic frames; frame[:,2]=codebook1. DeviceRequests stores only 10 codebooks, so saved/reference codes rows0 and1 map exactly to the two backbone inputs. EOS is absent from these acoustic arrays.',
    generated_provenance='codec-minlaunch/prefix-replay.json source8ccefd0 scripted native80-request dynamic trace; reconstructed prefixes reproduced414 archived trace entries/all80 PCM hashes. Partial trajectories, not complete service outputs.',
    generated_files={str(path.relative_to(ROOT)):hashlib.sha256(path.read_bytes()).hexdigest() for path in paths},
    corpus=str(CORPUS), corpus_sha256=hashlib.sha256(CORPUS.read_bytes()).hexdigest(),
    controls='CPU map_location=cpu and CUDA_VISIBLE_DEVICES empty; per-sequence history only, online updates after prediction, no cross-request dictionary or target lookahead.',
    oracle_warning='Oracle methods use actual target to select among previously observed choices and cannot be implemented as one causal proposal. They are loose data-dependent ceilings only, not acceptance measurements.',
    generated=measure(generated), reference_all=measure(reference), reference_unique=measure(list(unique.values())),
    limitation='Exact data matches are necessary but not sufficient for native speculative acceptance: grouped computation, state-rounding, RNG coordinates, repetition history, EOS and rollback must separately match. No GPU timing, model probabilities or service improvement inferred.'
)
(ROOT/'native-speculation-cpu.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({name:{k:v for k,v in result[name].items() if k!='per_sequence'} for name in ('generated','reference_all','reference_unique')},indent=2))
