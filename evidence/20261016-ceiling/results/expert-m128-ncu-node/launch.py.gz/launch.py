"""Run the fixed, bounded NCU node protocol; never modify runtime or old evidence."""
import csv
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

HERE = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def processes(gpu):
    result = subprocess.run(
        ['nvidia-smi', '-i', gpu, '--query-compute-apps=pid,process_name,used_gpu_memory',
         '--format=csv,noheader,nounits'], capture_output=True, text=True, timeout=15,
    )
    if result.returncode:
        raise RuntimeError('GPU process query failed: ' + result.stderr)
    rows = []
    for line in result.stdout.splitlines():
        if not line.strip():
            continue
        cells = next(csv.reader([line], skipinitialspace=True))
        if len(cells) != 3 or not cells[0].strip().isdigit():
            raise RuntimeError('Unrecognized GPU process row: ' + line)
        pid = int(cells[0])
        try:
            pgid = os.getpgid(pid)
        except ProcessLookupError:
            pgid = None
        rows.append({'pid': pid, 'pgid': pgid, 'name': cells[1], 'memory_mib': cells[2]})
    return rows


def parse_metrics(path, wanted):
    with path.open() as handle:
        reader = csv.DictReader(handle)
        records = [row for row in reader if row.get('ID', '').isdigit()]
    if len(records) != 2:
        raise RuntimeError(f'Expected two FC records, got {len(records)}')
    for row in records:
        for metric in wanted:
            if metric not in row or row[metric].strip().lower() in ('', 'n/a', 'nan'):
                raise RuntimeError('Missing metric: ' + metric)
            float(row[metric].replace(',', ''))
        if 'profiler__replayer_passes' not in row:
            raise RuntimeError('Missing actual replay pass count')
    return records


def main():
    result_path = HERE / 'launch-result.json'
    if result_path.exists():
        raise RuntimeError('Refusing to overwrite prior launch evidence')
    protocol = json.loads((HERE / 'protocol.json').read_text())
    frozen = json.loads((HERE / 'frozen-inputs.json').read_text())
    assert all(sha(path) == value for path, value in frozen.items())
    env = os.environ.copy()
    env.update(protocol['environment'])
    env['CUDA_VISIBLE_DEVICES'] = protocol['gpu_uuid']
    env['PYTHONUNBUFFERED'] = '1'
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    report = {'status': 'PREPARING', 'protocol_sha256': sha(HERE / 'protocol.json'),
              'frozen_manifest_sha256': sha(HERE / 'frozen-inputs.json'), 'cases': [],
              'scope': 'serialized per-kernel counter diagnosis, no timing promotion'}
    write(result_path, report)
    try:
        for layer, arm in protocol['cases']:
            label = f'L{layer}-{arm}'
            output = HERE / label
            prefix = HERE / (label + '-ncu')
            if output.exists() or Path(str(prefix) + '.ncu-rep').exists():
                raise RuntimeError('Refusing to overwrite case: ' + label)
            initial = processes(protocol['gpu_uuid'])
            if initial:
                raise RuntimeError('Designated GPU is not idle: ' + repr(initial))
            command = [protocol['ncu'], *protocol['ncu_options'], '--metrics',
                       ','.join(protocol['metrics']), '--kernel-name', protocol['kernel_filters'][arm],
                       '--export', str(prefix), protocol['python'], str(HERE / 'profile_driver.py'),
                       '--layer', str(layer), '--arm', arm, '--output', str(output)]
            case = {'label': label, 'command': command, 'pre_processes': initial,
                    'status': 'RUNNING', 'started_epoch': time.time()}
            report['cases'].append(case)
            report['status'] = 'RUNNING'
            write(result_path, report)
            audits = []
            with (HERE / (label + '.log')).open('w') as log:
                child = subprocess.Popen(command, cwd=HERE, env=env, stdout=log,
                                         stderr=subprocess.STDOUT, start_new_session=True)
                case['pid'] = child.pid
                started = time.monotonic()
                try:
                    while child.poll() is None:
                        rows = processes(protocol['gpu_uuid'])
                        audits.append({'epoch': time.time(), 'processes': rows})
                        write(HERE / (label + '-process-audit.json'), audits)
                        foreign = [row for row in rows if row['pgid'] != child.pid]
                        if foreign:
                            raise RuntimeError('Foreign GPU context detected: ' + repr(foreign))
                        if time.monotonic() - started > protocol['watchdog_seconds']:
                            raise TimeoutError('Per-process watchdog expired')
                        time.sleep(2)
                except BaseException:
                    if child.poll() is None:
                        os.killpg(child.pid, signal.SIGTERM)
                        try:
                            child.wait(timeout=5)
                        except subprocess.TimeoutExpired:
                            os.killpg(child.pid, signal.SIGKILL)
                            child.wait(timeout=5)
                    raise
                case['exit_code'] = child.returncode
                case['elapsed_wall_seconds'] = time.monotonic() - started
            deadline = time.monotonic() + 5
            while True:
                post = processes(protocol['gpu_uuid'])
                if not post or time.monotonic() >= deadline:
                    break
                time.sleep(.5)
            case['post_processes'] = post
            if post:
                raise RuntimeError('POST_PROCESS_AUDIT_FAIL: ' + repr(post))
            if child.returncode != 0:
                raise RuntimeError('Profiler process failed: ' + label)
            exact = json.loads((output / 'result.json').read_text())
            if exact['status'] != 'NCU_SINGLE_GRAPH_REPLAY_EXACT_PASS':
                raise RuntimeError('Driver exact gate failed: ' + label)
            report_file = Path(str(prefix) + '.ncu-rep')
            if not report_file.is_file():
                raise RuntimeError('NCU report missing: ' + str(report_file))
            exported = HERE / (label + '-metrics.csv')
            with exported.open('w') as out:
                subprocess.run([protocol['ncu'], '--config-file', 'off', '--import', str(report_file),
                                '--page', 'raw', '--csv', '--print-units', 'base'],
                               env={**env, 'CUDA_VISIBLE_DEVICES': ''}, stdout=out,
                               stderr=subprocess.PIPE, text=True, check=True, timeout=120)
            records = parse_metrics(exported, protocol['metrics'])
            case['kernel_records'] = [{k: row[k] for k in ['ID', 'Kernel Name', 'profiler__replayer_passes']}
                                      for row in records]
            case['checks'] = len(exact['checks'])
            case['status'] = 'COMPLETE_EXACT_COUNTERS'
            case['report_sha256'] = sha(report_file)
            case['csv_sha256'] = sha(exported)
            if max(float(row['profiler__replayer_passes']) for row in records) > protocol['maximum_replay_passes']:
                raise RuntimeError('Observed replay pass count exceeds bounded plan; preserve this case, stop remaining cases')
            if not all(sha(path) == value for path, value in frozen.items()):
                raise RuntimeError('Frozen source changed during sampling')
            write(result_path, report)
        report['status'] = 'COMPLETE_8_NODE_RECORDS'
    except BaseException as error:
        report['status'] = 'STOPPED_FAILURE'
        report['error'] = repr(error)
        write(result_path, report)
        raise
    write(result_path, report)
    print(json.dumps({'status': report['status'], 'cases': len(report['cases'])}), flush=True)


if __name__ == '__main__':
    main()
