"""One frozen complete-graph replay inside cudaProfilerStart/Stop; no timing.

Profiling selection/replay policy belongs to the external NCU launcher. Every
process owns a fresh output directory. Frozen source directories remain read
only, including Python bytecode; only two necessary source files are copied.
"""

import argparse
import hashlib
import importlib.util
import json
import os
import sys
import traceback
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
FROZEN = ROOT / "expert-m128-pdl-metadata-ready"
SOURCE_SHA = "95fcb0ef2662f2caf9bfb7fe6863dc3ad7805b1b"
GPU = "GPU-bc643dc2-a0d1-5ed6-5ecb-0605ca9f340a"
FIELDS = (
    ("tile", "cta_idx_xy_to_batch_idx"),
    ("mn", "cta_idx_xy_to_mn_limit"),
    ("route", "permuted_idx_to_token_idx"),
    ("ncta", "num_non_exiting_ctas"),
    ("padded", "total_num_padded_tokens"),
    ("expanded", "expanded_idx_to_permuted_idx"),
)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_driver(output):
    """Import unchanged source under a new __file__, redirecting all its writes."""
    sys.dont_write_bytecode = True
    for name in ("metadata_driver.py", "metadata_ready_kernel.py"):
        (output / name).write_bytes((FROZEN / name).read_bytes())
        assert sha(output / name) == sha(FROZEN / name), name
    sys.path.insert(0, str(FROZEN))
    argv = sys.argv[:]
    sys.argv = [str(output / "metadata_driver.py"), "profile"]
    try:
        spec = importlib.util.spec_from_file_location(
            "frozen_metadata_profile_driver", output / "metadata_driver.py"
        )
        module = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = module
        spec.loader.exec_module(module)
    finally:
        sys.argv = argv
    # All exact helper functions resolve these globals at call time. The
    # unchanged import has already created its compile directory under output.
    module.ROOT = ROOT
    module.ORACLES = sorted((ROOT / "expert-metadata-rebase").glob("oracle-layer*.pt"))
    assert module.OUT == output
    assert Path(os.environ["CUTE_DSL_DUMP_DIR"]).parent == output

    def flush():
        (output / "result.json").write_text(json.dumps(module.report, indent=2) + "\n")

    module.flush = flush
    return module


def tensor_bindings(torch, x, owner, ios):
    tensors = dict(x)
    tensors["native_output"] = owner["output"]
    tensors.update({f"native_workspace_{i}": t for i, t in enumerate(owner["ws"])})
    for key, field in FIELDS:
        tensors["owner_metadata_" + key] = getattr(owner["slot"], field)
    for fc, io in ios.items():
        tensors.update(
            {f"{fc}_keepalive_{i}": t for i, t in enumerate(io["_keepalive"])}
        )
    return {
        name: {
            "object_id": id(value),
            "ptr": value.data_ptr(),
            "bytes": value.numel() * value.element_size(),
            "shape": list(value.shape),
            "stride": list(value.stride()),
            "dtype": str(value.dtype),
            "device": str(value.device),
        }
        for name, value in tensors.items()
        if isinstance(value, torch.Tensor)
    }


def snapshot_json(snapshot):
    return {
        "identity": snapshot.identity,
        "nodes": [vars(node) for node in snapshot.nodes],
        "edges": [vars(edge) for edge in snapshot.edges],
    }


def capture_native(d, owner):
    """Native graph stays unmodified; retain raw graph only for provenance."""
    from metadata_ready_graph import _CudaBackend

    graph = d.torch.cuda.CUDAGraph(keep_graph=True)
    with d.torch.cuda.graph(graph):
        info = d.drv.cuStreamGetCaptureInfo(
            d.drv.CUstream(d.torch.cuda.current_stream().cuda_stream)
        )
        d.req("native/capture_info", int(info[0]) == 0)
        owner["call"]()
    backend = _CudaBackend()
    backend._graph = graph
    backend._driver = d.drv
    backend._torch = d.torch
    backend._generation = int(info[2])
    backend._handle = d.drv.CUgraph(graph.raw_cuda_graph())
    snapshot = backend.snapshot()
    graph.instantiate()
    return graph, backend, snapshot


def run(args, output):
    # Verify the coordinator's frozen experiment and the original immutable
    # fixture/source contracts before importing dependencies or initializing CUDA.
    frozen = json.loads((HERE / "frozen-inputs.json").read_text())
    assert all(sha(path) == digest for path, digest in frozen.items())
    original = json.loads((FROZEN / "frozen-inputs.json").read_text())
    fixture = ROOT / f"expert-metadata-rebase/oracle-layer{args.layer}-real.pt"
    required = [
        FROZEN / name
        for name in (
            "metadata_driver.py",
            "metadata_ready_kernel.py",
            "metadata_ready_config.py",
            "metadata_ready_graph.py",
            "body_common.py",
            "gmem_c_resources_m128_body.py",
            "driver-prepare.json",
        )
    ] + [fixture]
    for path in required:
        assert str(path) in original and sha(path) == original[str(path)], str(path)
    assert os.environ["CUDA_VISIBLE_DEVICES"] == GPU
    before_tree = sorted(str(path.relative_to(FROZEN)) for path in FROZEN.rglob("*"))
    d = load_driver(output)
    torch = d.torch
    d.report.update(
        status="PREPARING_NCU_REPLAY",
        layer=args.layer,
        arm=args.arm,
        source_fixture=str(fixture),
        fixture_sha256=sha(fixture),
        profile_replays=1,
        graph_warmup_replays=5,
        timing_claim=False,
        runtime_promoted=False,
        baseline_pdl=True,
        candidate_pdl=True,
        copied_source_hashes={
            name: sha(output / name)
            for name in ("metadata_driver.py", "metadata_ready_kernel.py")
        },
    )
    d.req(
        "source_frozen",
        d.report["source_sha"] == SOURCE_SHA and d.report["source_status"] == "",
    )
    prep = json.loads((FROZEN / "driver-prepare.json").read_text())
    d.req("frozen_CPU_AOT_PASS", prep["status"] == "CPU_AOT_PASS")
    for fc, record in prep["kernels"].items():
        d.req(fc + "/original_cubin_hash", sha(record["cubin"]) == record["sha256"])
    from flashinfer.fused_moe import core as fi

    with torch.inference_mode():
        runtime = fi.get_trtllm_moe_sm100_module()
        dataset = torch.load(fixture, map_location="cpu", weights_only=False)
        weights = d.c.weights(args.layer, "cuda")
        weight_before = [value.clone() for value in weights]
        x = d.allocate(dataset, weights, "cuda")
        owner = d.native_body(runtime, x)
        for key, attr in FIELDS:
            x["live_" + key] = getattr(owner["slot"], attr)
        readonly = {
            key: value.clone()
            for key, value in x.items()
            if key not in d.OUTPUTS
            and not key.startswith(("guard_", "live_"))
            and key not in ("w1", "s1", "w2", "s2")
        }
        rng = torch.cuda.get_rng_state().clone()
        ios, fns, eager_owner = {}, {}, None
        if args.arm == "native":
            owner["call"]()
            torch.cuda.synchronize()
            d.check_native("setup/native", owner, x, dataset)
            graph, backend, captured = capture_native(d, owner)
        else:
            ios, fns, records = d.compile_pair(x)
            for fc, record in records.items():
                d.req(
                    fc + "/CPU_GPU_cubin_identical",
                    record["sha256"] == prep["kernels"][fc]["sha256"],
                )
            d.report["candidate_kernels"] = records
            eager_owner = d.candidate_eager(runtime, x, ios, fns, owner)
            d.check_metadata("setup/candidate_metadata", owner["slot"], x, dataset)
            d.check_outputs("setup/candidate", x, dataset["intermediates"])
            d.chk("setup/candidate_routed", x["out"], dataset["routed"].cuda())
            graph = d.capture_candidate(
                runtime, x, ios, fns, owner, f"L{args.layer}/NCU-exact-graph"
            )
            backend = graph._backend
            captured = backend.snapshot()
        # Keep all original owners and compiled callables alive through profiling
        # and the final correctness/graph checks, not merely through capture.
        retained = [
            runtime,
            weights,
            weight_before,
            x,
            owner,
            ios,
            fns,
            eager_owner,
            graph,
            backend,
            readonly,
            rng,
        ]
        for _ in range(5):
            graph.replay()
        torch.cuda.synchronize()

        def check_state(label):
            if args.arm == "native":
                d.check_native(label + "/native", owner, x, dataset)
            else:
                d.check_metadata(label + "/metadata", owner["slot"], x, dataset)
                d.check_outputs(label + "/candidate", x, dataset["intermediates"])
                d.chk(label + "/routed", x["out"], dataset["routed"].cuda())
            for key, value in readonly.items():
                d.chk(label + "/readonly_" + key, x[key], value)
            for i, (value, expected) in enumerate(zip(weights, weight_before)):
                d.chk(label + f"/weight_{i}", value, expected)
            d.chk(label + "/RNG", torch.cuda.get_rng_state(), rng)

        check_state("pre_profile")
        before = backend.snapshot()
        d.req("graph_unchanged_since_capture", before == captured)
        bindings = tensor_bindings(torch, x, owner, ios)
        pre = {"graph": snapshot_json(before), "owners": bindings}
        (output / "graph.json").write_text(json.dumps({"pre": pre}, indent=2) + "\n")
        # Finish every checker operation before opening the measured range. This
        # range contains exactly one complete original graph replay and its join.
        torch.cuda.synchronize()
        torch.cuda.profiler.start()
        try:
            graph.replay()
            torch.cuda.synchronize()
        finally:
            torch.cuda.profiler.stop()
        check_state("post_profile")
        after = backend.snapshot()
        final_bindings = tensor_bindings(torch, x, owner, ios)
        d.req("graph_nodes_edges_launch_attributes_unchanged", after == before)
        d.req("captured_tensor_bindings_unchanged", final_bindings == bindings)
        d.report["retained_owner_groups"] = len(retained)
        (output / "graph.json").write_text(
            json.dumps(
                {
                    "pre": pre,
                    "post": {"graph": snapshot_json(after), "owners": final_bindings},
                    "note": "Topology/launch attributes and tensor storage identity; kernelParams payload is not fingerprinted.",
                },
                indent=2,
            )
            + "\n"
        )
        torch.cuda.synchronize()
    d.req(
        "frozen_directory_no_new_entries",
        sorted(str(path.relative_to(FROZEN)) for path in FROZEN.rglob("*"))
        == before_tree,
    )
    d.req(
        "reused_source_and_fixture_hashes_unchanged",
        all(sha(path) == original[str(path)] for path in required),
    )
    d.report.update(
        status="NCU_SINGLE_GRAPH_REPLAY_EXACT_PASS",
        graph_json=str(output / "graph.json"),
        counters_are_not_service_benchmark=True,
    )
    d.flush()
    print(
        json.dumps(
            {
                "status": d.report["status"],
                "checks": len(d.report["checks"]),
                "layer": args.layer,
                "arm": args.arm,
            }
        ),
        flush=True,
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--layer", required=True, type=int, choices=(0, 39))
    parser.add_argument("--arm", required=True, choices=("native", "candidate"))
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    output = args.output.resolve()
    assert output.parent == HERE and output.name == f"L{args.layer}-{args.arm}"
    output.mkdir(exist_ok=False)
    try:
        run(args, output)
    except BaseException as exc:
        failure = {
            "status": "NCU_SINGLE_GRAPH_REPLAY_FAIL",
            "error": repr(exc),
            "traceback": traceback.format_exc(),
            "runtime_promoted": False,
        }
        path = output / "result.json"
        if path.exists():
            result = json.loads(path.read_text())
            result.update(failure)
        else:
            result = failure
        path.write_text(json.dumps(result, indent=2) + "\n")
        raise


if __name__ == "__main__":
    main()
