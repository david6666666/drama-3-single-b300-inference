import os,subprocess
from pathlib import Path
root=Path('/home/zjy/code/hsliu/artifacts/drama3-ceiling-20261016');source=root/'source-layout'
env=dict(os.environ,CUDA_VISIBLE_DEVICES='0',OMP_NUM_THREADS='8',PYTHONPATH=str(source/'src')+':/home/zjy/code/hsliu/drama3-sources/fish-speech',DRAMA3_GDN_STATE_DTYPE='bfloat16',DRAMA3_PACKED_MOE_PROJECTION='1',DRAMA3_PREFILL_CONV='triton',DRAMA3_PREFILL_MOE_TUNED='0',DRAMA3_PREFILL_MOE='flashinfer',DRAMA3_FUSED_MOE_INPUT='1')
for variant in ['layout','conv','both']:
 with (root/'mixed-layout'/f'{variant}.log').open('w') as log:
  cmd=['/home/zjy/code/hsliu/venvs/codex-drama3-standalone/bin/python',str(source/'scripts/validate_mixed_span.py'),'--checkpoint','/home/zjy/.cache/huggingface/hub/models--fishaudio--drama-3/snapshots/e0a9218aa48888270f06ef1ed9ea67622c0e17d2','--corpus','/home/zjy/code/hsliu/artifacts/drama3-b300-20261014/seedtts-en1088-codes/requests.jsonl','--output',str(root/'mixed-layout'/f'{variant}.json'),'--variant',variant]
  subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 print(variant,'PASS',flush=True)
