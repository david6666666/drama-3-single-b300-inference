"""Recheck the CPU-only C128 plan with frozen metadata; no Torch or CUDA import."""
import hashlib
import json
import math
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
result = json.loads((OUT / 'result.json').read_text())
rows = json.loads((ROOT / 'reference-prefix/per-request.json').read_text())
prior = json.loads((ROOT / 'prefix-dag-cpu-audit/result.json').read_text())
checks = []


def check(name, condition):
    checks.append({'name': name, 'pass': bool(condition)})
    assert condition, name


for path, digest in result['input_sha256'].items():
    check('source_hash:' + path, hashlib.sha256(Path(path).read_bytes()).hexdigest() == digest)
for group, original in zip(result['groups'], prior['groups'], strict=True):
    requests = rows[original['first_request']:original['first_request'] + original['requests']]
    owner_map = group['owner']
    check(f"group{group['group']}/size", len(owner_map) == len(requests))
    for i, owner in enumerate(owner_map):
        check(f"group{group['group']}/owner{i}", 0 <= owner <= i and owner_map[owner] == owner)
        if owner != i:
            check(f"group{group['group']}/alias{i}", requests[i]['prefix_rows'] > 128 and requests[owner]['prefix_sha256'] == requests[i]['prefix_sha256'])
    total = sum(math.ceil(r['prompt_rows'] / 64) for r in requests)
    compact = sum(math.ceil(min(128, requests[i]['prompt_rows']) / 64) for i in set(owner_map))
    compact += sum(math.ceil(max(0, r['prompt_rows'] - 128) / 64) for r in requests)
    check(f"group{group['group']}/chunks", total == group['native_chunks'] and compact == group['dag_chunks'])
    check(f"group{group['group']}/saved_rows", (total - compact) * 64 == original['c128_reference_rows'])
check('sum_removed_chunks', sum(g['removed_chunks'] for g in result['groups']) == 580)
check('sum_saved_rows', 580 * 64 == 37120)
check('pair190', result['groups'][190]['native_chunks'] == 24 and result['groups'][190]['dag_chunks'] == 16 and result['groups'][190]['prompt_rows'] == 1354)
check('pair192', result['groups'][192]['native_chunks'] == 24 and result['groups'][192]['dag_chunks'] == 18 and result['groups'][192]['prompt_rows'] == 1335)
for prefix in range(106, 241):
    for tail in range(11, 38):
        length = prefix + tail
        if prefix > 128:
            check(f'boundary:{prefix}:{tail}', 127 + 1 < prefix and 2 + math.ceil((length - 128) / 64) == math.ceil(length / 64))
        else:
            check(f'fallback:{prefix}:{tail}', ((prefix - 1) // 128) * 128 == 0)
summary = {
    'status': 'CPU_INTERFACE_AND_METADATA_CHECK_PASS',
    'checks': len(checks),
    'cuda_imported_or_initialized': False,
    'numerical_validation': 'NOT_RUN',
    'runtime_or_kernel_changed': False,
    'check_script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'design_sha256': hashlib.sha256((OUT / 'design.md').read_bytes()).hexdigest(),
    'result_sha256': hashlib.sha256((OUT / 'result.json').read_bytes()).hexdigest(),
    'native_h_source_sha256': hashlib.sha256(Path('/home/zjy/code/hsliu/venvs/codex-drama3-standalone/lib/python3.12/site-packages/sglang/kernels/ops/attention/fla/chunk_delta_h.py').read_bytes()).hexdigest(),
}
(OUT / 'checks.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
