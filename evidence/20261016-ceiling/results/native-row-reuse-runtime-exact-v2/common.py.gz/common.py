"""CPU-only data construction for the frozen production row-reuse gate."""

import ast
import hashlib
import json
import re
import sys
from pathlib import Path
from types import SimpleNamespace
from typing import Sequence

import torch
from tokenizers import Tokenizer

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
SOURCE = ROOT / "source-row-reuse-345c6a1"
SOURCE_SHA = "345c6a18f200853489a9ac8a86bbe0682ebe484d"
CHECKPOINT = Path(
    "/home/zjy/.cache/huggingface/hub/models--fishaudio--drama-3/snapshots/e0a9218aa48888270f06ef1ed9ea67622c0e17d2"
)
CORPUS = Path(
    "/home/zjy/code/hsliu/artifacts/drama3-b300-20261014/seedtts-en1088-codes/requests.jsonl"
)
FISH = Path(
    "/home/zjy/code/hsliu/drama3-sources/fish-speech/fish_speech/models/text2semantic/fish_omni/generate.py"
)
sys.path[:0] = [str(SOURCE / "src"), str(SOURCE / "scripts")]
from drama3.row_reuse import MIXED_ROW_REUSE_BUCKETS, plan_row_reuse


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def exact(a, b):
    return (
        a.shape == b.shape
        and a.dtype == b.dtype
        and torch.equal(
            a.contiguous().reshape(-1).view(torch.uint8),
            b.contiguous().reshape(-1).view(torch.uint8),
        )
    )


def build_prompts():
    constants = {
        "DRAMA3_TTS_INSTRUCTION",
        "DRAMA3_REFERENCE_INSTRUCTION",
        "DRAMA3_MESSAGE_END",
        "DRAMA3_GENERATION_START",
        "DRAMA3_STRUCTURAL_TOKENS",
        "SPEAKER_TAG_PATTERN",
        "MAX_SPEAKER_ID",
        "UNICODE_WHITE_SPACE",
        "DRAMA3_MAX_PROMPT_ROWS",
    }
    functions = {"validate_drama3_text", "with_speaker_tag", "build_drama3_prompt"}
    nodes = [
        n
        for n in ast.parse(FISH.read_text()).body
        if isinstance(n, ast.Assign)
        and any(isinstance(t, ast.Name) and t.id in constants for t in n.targets)
        or isinstance(n, ast.FunctionDef)
        and n.name in functions
    ]
    ns = dict(
        torch=torch,
        re=re,
        Sequence=Sequence,
        Tokenizer=Tokenizer,
        FishOmniConfig=object,
        InvalidInputError=ValueError,
        Drama3PromptTooLongError=ValueError,
    )
    exec(
        compile(
            ast.fix_missing_locations(ast.Module(body=nodes, type_ignores=[])),
            str(FISH),
            "exec",
        ),
        ns,
    )
    cfg = json.loads((CHECKPOINT / "config.json").read_text())
    config = SimpleNamespace(
        audio_decoder=SimpleNamespace(
            num_codebooks=cfg["audio_decoder_config"]["num_codebooks"],
            vocab_size=cfg["audio_decoder_config"]["vocab_size"],
        ),
        **{
            k: cfg[k]
            for k in (
                "semantic_start_token_id",
                "semantic_end_token_id",
                "eos_token_id",
            )
        },
    )
    tokenizer = Tokenizer.from_file(str(CHECKPOINT / "tokenizer.json"))
    samples = [json.loads(x) for x in CORPUS.read_bytes().splitlines()]
    return [
        ns["build_drama3_prompt"](
            s["text"],
            tokenizer,
            config,
            [s["reference_text"]],
            [torch.tensor(s["reference_codes"], dtype=torch.int64)],
        )
        for s in samples
    ]


def cases(prompts):
    groups = {
        x["group"]: x
        for x in json.loads((ROOT / "native-row-reuse-audit/counts.json").read_text())[
            "groups"
        ]
    }
    budget = json.loads(
        (ROOT / "native-row-reuse-runtime-design/finite-bucket-budget.json").read_text()
    )["records"]
    out = []
    for d, p, span, k in MIXED_ROW_REUSE_BUCKETS:
        eligible = [
            r
            for r in budget
            if r["eligible"]
            and r["original_key"][:3] == [d, p, span]
            and r["selected_compact"] == k
        ]
        eligible.sort(key=lambda r: (r["count"] != 6, r["group"]))
        for ordinal, record in enumerate(eligible[:2]):
            group = groups[record["group"]]
            ids = list(
                range(group["corpus_start"], group["corpus_start"] + group["count"])
            )
            if ordinal:
                ids.reverse()
            selected = [prompts[i] for i in ids]
            active = min(58, 64 - len(selected)) if not ordinal else 49
            slots = list(range(64 - len(selected), 64))
            if ordinal:
                slots.reverse()
            out.append(
                dict(
                    name=f"real_P{p}_K{k}_variant{ordinal}",
                    key=(d, p, span, k),
                    prompts=selected,
                    ids=ids,
                    active=active,
                    slots=slots,
                    synthetic=False,
                )
            )
    # Actual integer model tokens, deliberately synthetic lengths: two identical256-row
    # sequences plus a length3 prefix. Causal prefix equality is exact by construction.
    seed = next(p for p in prompts if len(p) >= 128)
    long = seed.repeat((2, 1))[:256].clone()
    short = long[:3].clone()
    out.append(
        dict(
            name="synthetic_min3_max256_partial3",
            key=(64, 768, 256, 576),
            prompts=[long, long.clone(), short],
            ids=[],
            active=49,
            slots=[61, 62, 63],
            synthetic=True,
        )
    )
    # Cancellation occurs before admission: remove one of four identical prompts,
    # then rebuild the plan. This validates fresh roster mapping, not live cancellation.
    out.append(
        dict(
            name="synthetic_cancel_before_admission",
            key=(64, 768, 256, 576),
            prompts=[long[:192].clone() for _ in range(3)],
            ids=[],
            active=58,
            slots=[60, 62, 63],
            synthetic=True,
        )
    )
    noalias = [long[:128].clone() for _ in range(4)]
    for i, prompt in enumerate(noalias):
        prompt[0, 10] = i
    out.append(
        dict(
            name="noalias_original_fallback",
            key=(64, 768, 256, None),
            prompts=noalias,
            ids=[],
            active=58,
            slots=[60, 61, 62, 63],
            synthetic=True,
        )
    )
    capacity_prompts = [long[:192].clone(), long[64:].clone(), long[:192].clone()]
    capacity_prompts[2][0, 10] = 17
    out.append(
        dict(
            name="capacity_original_fallback",
            key=(64, 768, 256, None),
            prompts=capacity_prompts,
            ids=[],
            active=58,
            slots=[60, 62, 63],
            synthetic=True,
        )
    )
    # Only one real row free at B63; this unsupported original P256 graph tests the
    # true disjoint primary-slot contract rather than inventing65+active requests.
    out.append(
        dict(
            name="unsupported_P256_active63",
            key=(64, 256, 256, None),
            prompts=[long],
            ids=[],
            active=63,
            slots=[63],
            synthetic=True,
        )
    )
    return out


def cpu_check():
    prompts = build_prompts()
    report = []
    for case in cases(prompts):
        d, p, span, k = case["key"]
        capacities = [v[3] for v in MIXED_ROW_REUSE_BUCKETS if v[:3] == (d, p, span)]
        plan = plan_row_reuse(case["prompts"], d, p, (k,) if k else capacities)
        assert (plan is not None) == (k is not None), case["name"]
        lengths = list(map(len, case["prompts"]))
        assert (
            min(lengths) >= 3
            and max(lengths + [p - sum(lengths)]) <= span
            and sum(lengths) <= p
        )
        assert len(set(range(case["active"])) | set(case["slots"])) == case[
            "active"
        ] + len(case["slots"])
        if plan:
            keep = plan.packed_indices[:k]
            inverse = plan.packed_indices[k:]
            assert keep[:d].tolist() == list(range(d))
            padding_start = d + sum(lengths)
            assert all(r in keep.tolist() for r in range(padding_start, d + p))
            assert (
                0 <= int(inverse.min()) and int(inverse.max()) < plan.unique_rows <= k
            )
            # Independent causal owner proof, comparing full prefix bytes.
            owner = {}
            offset = d
            for prompt in case["prompts"]:
                for position in range(len(prompt)):
                    prefix = prompt[: position + 1].numpy().tobytes()
                    expected = owner.setdefault(prefix, offset + position)
                    assert int(keep[inverse[offset + position]]) == expected
                offset += len(prompt)
            assert plan.matches_prompts(case["prompts"])
            stale = [x.clone() for x in case["prompts"]]
            stale[0][0, 10] += 1
            assert not plan.matches_prompts(stale)
        report.append(
            dict(
                name=case["name"],
                key=case["key"],
                corpus_ids=case["ids"],
                lengths=lengths,
                active=case["active"],
                slots=case["slots"],
                unique_rows=plan.unique_rows if plan else None,
                synthetic=case["synthetic"],
            )
        )
    assert exact(torch.tensor(7), torch.tensor(7))
    assert not exact(torch.tensor(0.0), torch.tensor(-0.0))
    assert exact(torch.empty(0), torch.empty(0))
    assert not torch.cuda.is_initialized()
    return dict(
        status="CPU_PASS", source_sha=SOURCE_SHA, cuda_initialized=False, cases=report
    )
