import json
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import torch
from drama3.engine import Engine
from drama3.profiling import TimelineProfiler
from validate_async_codec import request

class Event:
    clock=0
    def __init__(self,**kwargs): self.time=0
    def record(self): self.time=Event.clock;Event.clock+=1
    def elapsed_time(self,other): return other.time-self.time

class Codec:
    split_policy='dp'
    batch_buckets={16:[1,2,4,8,12,16]}
    def frame_bucket(self,length): return 16
    def split(self,length,count): return [8]

original_tensor=torch.tensor
reports=[]
for tracing,deferred in [(True,False),(True,True),(False,False),(False,True)]:
    engine=Engine.__new__(Engine)
    engine.profiler=TimelineProfiler('/tmp/drama3-metadata-test.json') if tracing else None
    engine.codec_trace_sequence=0
    engine.codec_trace_submissions={} if tracing else None
    engine.codec_submissions=[]
    engine.codec_graphs=Codec()
    engine.defer_codec_submit=deferred
    engine.device_requests=SimpleNamespace(gather_codes=lambda rows,length: torch.zeros((rows.shape[1],10,length)))
    submitted=[]
    engine.audio_queue=SimpleNamespace(submit=lambda codes,rows,callbacks,**kw: submitted.append((codes,rows,callbacks,kw)))
    requests=[]
    for slot in range(3):
        req=request(slot,lambda _:None)
        req.request_id=f'request-{slot}'
        req.frame_count=6
        requests.append(req)
    with patch('torch.tensor',side_effect=lambda data,**kw:original_tensor(data,dtype=kw.get('dtype'))),patch('torch.cuda.Event',Event):
        engine.emit_audio_batch(requests)
        if deferred: assert not submitted and len(engine.codec_submissions)==1
        engine.flush_codec_submissions()
    assert len(submitted)==1 and not engine.codec_submissions
    kwargs=submitted[0][3]
    if tracing:
        metadata=kwargs['metadata']
        assert metadata['requested_jobs']==3 and metadata['selected_batches']==[8]
        assert metadata['actual_batch']==3 and metadata['planned_batch']==8 and metadata['padded_batch']==4
        assert metadata['valid_frames']==[6,6,6] and metadata['left_frames']==[0,0,0]
        assert metadata['emit_id']==1 and metadata['frame_group_id']==0
        assert engine.codec_trace_submissions=={}
    else:
        assert 'metadata' not in kwargs and engine.codec_trace_sequence==0
    if deferred: assert isinstance(kwargs['ready'],Event)
    reports.append(dict(tracing=tracing,deferred=deferred,passed=True))
profiler=TimelineProfiler('/tmp/drama3-metadata-test.json')
with patch('torch.cuda.Event',Event),patch('torch.cuda.current_stream',return_value=SimpleNamespace(cuda_stream=123)),patch('torch.cuda.synchronize'):
    with profiler.measure('decode',3,steps=4,padded_batch=4): pass
    profiler.save()
row=json.loads(Path('/tmp/drama3-metadata-test.json').read_text())['records'][0]
assert row['batch']==3 and row['steps']==4 and row['padded_batch']==4
assert not torch.cuda.is_initialized()
print(json.dumps(dict(passed=True,cuda_initialized=False,cases=reports,decode_metadata=row),indent=2))
