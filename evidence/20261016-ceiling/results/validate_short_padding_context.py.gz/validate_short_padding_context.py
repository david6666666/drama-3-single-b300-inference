"""Fixed real-input validation for explicitly reserved decode padding positions."""

import argparse
import hashlib
import json
import os
import subprocess
from pathlib import Path
from types import SimpleNamespace

import torch
import torch.nn.functional as F
import triton
from drama3.engine import BatchedPrefillGraph, DecodeGraph, state_pool_size
from drama3.mixed_graph import MixedGraph
from drama3.model import DramaModel
from drama3.runtime_state import DeviceRequests
from fish_speech.models.text2semantic.fish_omni.generate import build_drama3_prompt
from validate_mixed_layers import Checks, restore, snapshot, state_tensors


@torch.inference_mode()
def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--corpus", type=Path, required=True)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    raw = args.corpus.read_bytes()
    checks = Checks(
        args.output,
        dict(
            source_sha=subprocess.check_output(
                ["git", "rev-parse", "HEAD"], cwd=args.source, text=True
            ).strip(),
            source_status=subprocess.check_output(
                ["git", "status", "--porcelain"], cwd=args.source, text=True
            ),
            validator_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            corpus_sha256=hashlib.sha256(raw).hexdigest(),
            gpu_uuid=str(torch.cuda.get_device_properties(0).uuid),
            environment={k: v for k, v in os.environ.items() if k.startswith("DRAMA3_")},
            hypothesis=(
                "Shortening only explicitly reserved decode padding positions removes "
                "unnecessary dummy attention reads without changing live requests."
            ),
            isolated_variable=(
                "DeviceRequests.short_padding_context false/true before capture; same model, "
                "native full top8, state, inputs, slot order, RNG, graph sizes and "
                "max_kv_len2048."
            ),
            gate=(
                "Exact real outputs/codes and all state outside participating reserved decode "
                "dummy slots; mixed prompt outputs exact. Expected dummy changes separately "
                "reported, never exclude a real slot."
            ),
            timing=(
                "One fixed-input feasibility with alternating arms and state restore outside "
                "event; not serving performance or statistical speedup evidence."
            ),
            stop=(
                "First real-output or protected-state mismatch rejects candidate and is persisted."
            ),
        ),
    )
    try:
        model = DramaModel(args.checkpoint, slots=state_pool_size(64), max_length=2048)
        device = DeviceRequests(model.slots, model.config.eos_token_id, model.max_length)
        device.short_padding_context = False
        samples = [json.loads(line) for line in raw.splitlines()][:64]
        prompts = [
            build_drama3_prompt(
                s["text"],
                model.weights.tokenizer,
                model.config,
                [s["reference_text"]],
                [torch.tensor(s["reference_codes"])],
            )
            for s in samples
        ]
        prefill = BatchedPrefillGraph(model, 8, triton.next_power_of_2(max(map(len, prompts))))
        first = DecodeGraph(model, 8, first_frame=True, requests=device)
        active = [SimpleNamespace(slot=i, position=len(p) - 1) for i, p in enumerate(prompts)]
        for i, prompt in enumerate(prompts):
            history = F.pad(prompt[-16:, 0], (max(0, 16 - len(prompt)), 0), value=-1).cuda()
            device.initialize(i, prompt[-1].cuda(), history, len(prompt) - 1, 500)
        hidden_first = None
        for start in range(0, 64, 8):
            hidden = prefill.run(prompts[start : start + 8], list(range(start, start + 8)))
            if start == 0:
                hidden_first = hidden.clone()
            first.run(active[start : start + 8], hidden)
        tensors = state_tensors(model, device)
        base = snapshot(tensors.values())
        rng = torch.cuda.get_rng_state()
        scenarios = [
            ("decode", 64, 64, 1, 0),
            ("decode", 64, 63, 1, 0),
            ("decode", 64, 58, 1, 0),
            ("decode", 48, 40, 1, 0),
            ("decode", 64, 58, 4, 0),
            ("first", 8, 5, 1, 0),
            ("mixed", 64, 58, 1, 6),
            ("mixed", 48, 40, 1, 3),
            ("mixed", 16, 12, 1, 1),
        ]
        for kind, size, count, steps, arriving in scenarios:
            label = f"{kind}-b{size}-n{count}-s{steps}-p{arriving}"
            print(label, flush=True)
            subset = active[:count]
            dummy = list(range(model.slots // 2 + count, model.slots // 2 + size))
            assert not set(dummy).intersection(r.slot for r in subset)
            protected = torch.tensor(
                [i for i in range(model.slots) if i not in dummy],
                device="cuda",
                dtype=torch.int64,
            )
            selected = prompts[count : count + arriving]
            total = sum(map(len, selected))
            capacity = triton.cdiv(total, 256) * 256 if arriving else None
            span = (
                triton.cdiv(max([*map(len, selected), capacity - total]), 64) * 64
                if arriving
                else None
            )
            graphs = []
            for enabled in (False, True):
                device.short_padding_context = enabled
                if kind == "mixed":
                    graph = MixedGraph(model, device, size, 8, capacity, max_length=span)
                    graph.prepare(subset, selected, list(range(count, count + arriving)))
                else:
                    graph = DecodeGraph(
                        model,
                        size,
                        first_frame=kind == "first",
                        steps=steps,
                        requests=device,
                    )
                    graph.run(subset, hidden_first if kind == "first" else None)
                graphs.append(graph)
            control, candidate = graphs

            def outputs(graph, kind=kind, count=count, steps=steps):
                if kind == "mixed":
                    return (graph.output[0][:count].clone(), graph.output[1].clone())
                return ((graph.output[:count] if steps == 1 else graph.output[:, :count]).clone(),)

            restore(tensors.values(), base)
            torch.cuda.set_rng_state(rng)
            control.graph.replay()
            expected_out = outputs(control)
            expected_state = snapshot(tensors.values())
            control_positions = control.positions[:size].clone()
            restore(tensors.values(), base)
            torch.cuda.set_rng_state(rng)
            candidate.graph.replay()
            for i, (actual, expected) in enumerate(
                zip(outputs(candidate), expected_out, strict=True)
            ):
                checks.tensor(f"{label}/output{i}", actual, expected, exact=True)
            differences = []
            for (name, actual), expected in zip(tensors.items(), expected_state, strict=True):
                if actual.ndim and actual.shape[0] == model.slots:
                    checks.tensor(
                        f"{label}/{name}/protected",
                        actual.index_select(0, protected),
                        expected.index_select(0, protected),
                        exact=True,
                    )
                    if dummy:
                        ids = torch.tensor(dummy, device="cuda")
                        differs = (
                            (actual.index_select(0, ids) != expected.index_select(0, ids))
                            .reshape(len(dummy), -1)
                            .any(-1)
                        )
                        if differs.any():
                            differences.append(
                                dict(
                                    name=name,
                                    slots=[
                                        s
                                        for s, d in zip(dummy, differs.cpu().tolist(), strict=True)
                                        if d
                                    ],
                                )
                            )
                else:
                    checks.tensor(f"{label}/{name}", actual, expected, exact=True)
            checks.tensor(
                f"{label}/live_positions",
                candidate.positions[:count],
                control_positions[:count],
                exact=True,
            )
            if dummy:
                expected_position = steps if steps > 1 else 0
                assert (candidate.positions[count:size] == expected_position).all(), (
                    "Candidate dummy context did not shorten"
                )
            if kind == "mixed":
                checks.tensor(
                    f"{label}/prompt_positions",
                    candidate.positions[size:],
                    control.positions[size:],
                    exact=True,
                )
                plan = candidate.attention
            else:
                plan = candidate.batch
            assert plan.pages * plan.page_size == 2048, "Captured max_kv_len changed"
            timings = {"control_ms": [], "candidate_ms": []}
            for iteration in range(6):
                arms = [("control_ms", control), ("candidate_ms", candidate)]
                if iteration % 2:
                    arms.reverse()
                for name, graph in arms:
                    restore(tensors.values(), base)
                    torch.cuda.set_rng_state(rng)
                    begin, end = (torch.cuda.Event(enable_timing=True) for _ in range(2))
                    begin.record()
                    graph.graph.replay()
                    end.record()
                    end.synchronize()
                    if iteration:
                        timings[name].append(begin.elapsed_time(end))
            row = dict(
                case=label,
                active=count,
                batch=size,
                steps=steps,
                arriving=arriving,
                participating_dummy_slots=dummy,
                protected_slots=protected.cpu().tolist(),
                dummy_state_differences=differences,
                captured_max_kv_len=2048,
                prompt_lengths=list(map(len, selected)),
                timings=timings,
                passed=True,
            )
            checks.report["cases"].append(row)
            checks.flush()
            print(
                json.dumps(
                    {
                        k: v
                        for k, v in row.items()
                        if k not in ("protected_slots", "dummy_state_differences")
                    }
                ),
                flush=True,
            )
            del expected_out, expected_state, graphs, control, candidate
        checks.report["status"] = "PASS"
        checks.flush()
    except Exception as error:
        checks.report["status"] = "FAIL"
        checks.report["failure"] = dict(type=type(error).__name__, message=str(error))
        checks.flush()
        raise


if __name__ == "__main__":
    main()
