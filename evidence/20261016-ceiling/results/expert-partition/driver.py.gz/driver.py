"""One fixed native 2x128 expert partition: staged exact gates before timing."""
import hashlib,json,os,subprocess,time,traceback,statistics
from pathlib import Path
from types import SimpleNamespace
from contextlib import ExitStack
import torch,triton
import triton.language as tl
from safetensors import safe_open
from flashinfer.fused_moe import core as fi
from flashinfer.fused_moe.shared.inputs import MoeRunnerInputs
from flashinfer.tllm_enums import DtypeTrtllmGen,Fp8QuantizationType,RoutingInputMode
from drama3.moe_input import prepare_moe_input
ROOT=Path('/home/zjy/code/hsliu/artifacts/drama3-ceiling-20261016')
OUT=Path(__file__).resolve().parent
SOURCE=ROOT/'source-expert-partition-171acc8'
CKPT=Path('/home/zjy/.cache/huggingface/hub/models--fishaudio--drama-3/snapshots/e0a9218aa48888270f06ef1ed9ea67622c0e17d2')
INPUT=ROOT/'padding-router-b63-native-inputs.pt'
report=dict(status='PREPARING',source_sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip(),source_status=subprocess.check_output(['git','status','--porcelain'],cwd=SOURCE,text=True),driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),input_sha256=hashlib.sha256(INPUT.read_bytes()).hexdigest(),pid=os.getpid(),cases=[],checks=[],timings_allowed=False)
def flush():
 (OUT/'result.json').write_text(json.dumps(report,indent=2)+'\n')
def chk(name,a,b):
 av=a.detach().contiguous();bv=b.detach().contiguous()
 equal=av.shape==bv.shape and av.dtype==bv.dtype and torch.equal(av.view(torch.uint8),bv.view(torch.uint8))
 row=dict(name=name,exact=equal,shape=list(av.shape),dtype=str(av.dtype))
 if not equal:
  if av.shape==bv.shape:
   diff=av.float()-bv.float();row.update(maxabs=diff.abs().max().item(),rrms=(diff.square().mean().sqrt()/(bv.float().square().mean().sqrt()+1e-30)).item(),changed=int((av!=bv).sum().item()))
  torch.save({'a':av.cpu(),'b':bv.cpu()},OUT/(name.replace('/','_')+'-mismatch.pt'))
 report['checks'].append(row);flush()
 if not equal:raise AssertionError(row)
def require(name,condition,detail=None):
 report['checks'].append(dict(name=name,exact=bool(condition),detail=detail));flush()
 if not condition:raise AssertionError(name)
def sha_tensor(t):return hashlib.sha256(t.detach().contiguous().view(torch.uint8).cpu().numpy().tobytes()).hexdigest()
@triton.jit
def finalize2(F0,F1,M0,M1,W,O,B:tl.constexpr):
 token=tl.program_id(0);h=tl.program_id(1)*B+tl.arange(0,B)
 acc=tl.full((B,),0,tl.float32)
 for k in tl.static_range(8):
  p0=tl.load(M0+token*8+k);p1=tl.load(M1+token*8+k)
  a=tl.load(F0+p0*2048+h,mask=p0>=0,other=0).to(tl.float32)
  b=tl.load(F1+p1*2048+h,mask=p1>=0,other=0).to(tl.float32)
  v=tl.where(p0>=0,a,b);w=tl.load(W+token*8+k).to(tl.float32)
  acc=tl.fma(w,v,acc)
 tl.store(O+token*2048+h,acc)
def finish(p0,p1,w):
 out=torch.empty((64,2048),device='cuda',dtype=torch.bfloat16)
 finalize2[(64,8)](p0[0],p1[0],p0[2],p1[2],w,out,256)
 return out

def load_weights(layer):
 index=json.loads((CKPT/'model.safetensors.index.json').read_text())['weight_map']
 def key(e,p,s):return f'model.language_model.layers.{layer}.mlp.experts.{e}.{p}.{s}'
 keys=[key(e,p,s) for e in range(256) for p in ('up_proj','gate_proj','down_proj') for s in ('weight','weight_scale_inv')]
 with ExitStack() as stack:
  handles={f:stack.enter_context(safe_open(str(CKPT/f),framework='pt',device='cpu')) for f in sorted({index[k] for k in keys})}
  def tensor(e,p,s):
   k=key(e,p,s);return handles[index[k]].get_tensor(k)
  w1=torch.stack([torch.cat((tensor(e,'up_proj','weight'),tensor(e,'gate_proj','weight')),0) for e in range(256)])
  s1=torch.stack([torch.cat((tensor(e,'up_proj','weight_scale_inv'),tensor(e,'gate_proj','weight_scale_inv')),0) for e in range(256)])
  w2=torch.stack([tensor(e,'down_proj','weight') for e in range(256)])
  s2=torch.stack([tensor(e,'down_proj','weight_scale_inv') for e in range(256)])
 return [t.cuda() for t in (w1,s1,w2,s2)]
def as_torch(t):return t if isinstance(t,torch.Tensor) else torch.from_dlpack(t)

@torch.inference_mode()
def main():
 start=time.monotonic();flush()
 report.update(gpu_uuid=str(torch.cuda.get_device_properties(0).uuid),device_name=torch.cuda.get_device_name(0),torch_version=torch.__version__,cuda_visible_devices=os.environ.get('CUDA_VISIBLE_DEVICES'))
 runtime=fi.get_trtllm_moe_sm100_module()
 data=torch.load(INPUT,map_location='cpu',weights_only=False)
 cases=[]
 for layer in (0,19,39):
  print(json.dumps({'stage':'layer_setup','layer':layer}),flush=True)
  row=dict(layer=layer,real_rows=63,padding_rows=1,checks_pending=True);report['cases'].append(row);flush()
  x=data[layer]['x'].cuda();router=data[layer]['router'].cuda()
  weights=load_weights(layer)
  input_hashes=[sha_tensor(t) for t in (x,router,*weights)]
  rng0=torch.cuda.get_rng_state().clone()
  q,s,logits=prepare_moe_input(x,router)
  common=dict(routing_bias=None,num_experts=256,top_k=8,n_group=None,topk_group=None,intermediate_size=512,routed_scaling_factor=1.0,routing_method_type=4,use_shuffled_weight=False,weight_layout=0,enable_pdl=True)
  publickw={**common,'hidden_states':q,'hidden_states_scale':s,'gemm1_weights':weights[0],'gemm1_weights_scale':weights[1],'gemm2_weights':weights[2],'gemm2_weights_scale':weights[3],'local_expert_offset':0,'local_num_experts':256,'tune_max_num_tokens':4096}
  native=fi.trtllm_fp8_block_scale_moe(routing_logits=logits,**publickw)
  if isinstance(native,list):native=native[0]
  chk(f'L{layer}/native_vs_archived',native,data[layer]['routed'].cuda())
  canonical=fi.allocate_trtllm_moe_canonical_routing(logits,top_k=8,tile_n=8)
  def route_live():
   fi.canonicalize_trtllm_moe_routing_(canonical,logits,None,q,top_k=8,n_group=None,topk_group=None,local_expert_offset=0,local_num_experts=256,routed_scaling_factor=1.0,routing_method_type=4,use_routing_scales_on_input=False,use_deep_seek_fp8=True,norm_topk_prob=True,enable_pdl=True)
  route_live();ids=canonical.routing_replay_ids.to(torch.int32);cw=canonical.expert_weights
  chk(f'L{layer}/native_route_ids',canonical.routing_replay_ids,data[layer]['ids'].cuda())
  cw_original=cw.clone();ids_original=ids.clone()
  bodydata=[]
  for offset,count in ((0,256),(0,128),(128,128)):
   runner=runtime.MoERunner(runtime.moe_op,top_k=8,num_local_experts=count,dtype_act=DtypeTrtllmGen.E4m3,dtype_weights=DtypeTrtllmGen.E4m3,fp8_quantization_type=Fp8QuantizationType.DeepSeekFp8,hidden_size=2048,intermediate_size=512,num_experts=256)
   out=torch.empty_like(native)
   inputs=MoeRunnerInputs(out,None,ids,cw,q,s,None,None).to_list()
   fs=runner.get_factorized_tactic_space(inputs)
   tactic=fs.anchor(8).tactic
   kw={k:v for k,v in common.items() if k not in ('top_k','intermediate_size')}
   kw.update(local_expert_offset=offset,do_finalize=True,routing_input_mode=RoutingInputMode.UnpackedPrecomputed,gemm1_weights=weights[0][offset:offset+count],gemm1_weights_scale=weights[1][offset:offset+count],gemm2_weights=weights[2][offset:offset+count],gemm2_weights_scale=weights[3][offset:offset+count])
   ordinary=runner.forward(inputs,tactic=tactic,**kw)[0].clone()
   if count==256:chk(f'L{layer}/fixed_tactic_native',ordinary,native)
   metadata=fi.trtllm_moe_allocate_routing_metadata_multi_tile(ids,num_experts=256,top_k=8,local_expert_offset=offset,num_local_experts=count,tile_ns=[8],routing_input_mode=RoutingInputMode.UnpackedPrecomputed,topk_weights=cw)
   fi.populate_trtllm_moe_routing_metadata_(metadata,ids,cw)
   slot=metadata.slots[0]
   body=SimpleNamespace(tile_n=8,tactic=tactic[1]);br=runtime.DABodyRunner(runner)
   ws=tuple(as_torch(t) for t in br.prepare_body(inputs,body,slot,**kw))
   br.forward_from_metadata(inputs,body,slot,ws,**kw)
   chk(f'L{layer}/prepared_vs_ordinary_{offset}_{count}',out,ordinary)
   p=int(slot.total_num_padded_tokens.item());mapping=slot.expanded_idx_to_permuted_idx.clone().long().flatten()
   valid=mapping>=0
   require(f'L{layer}/map_range_{offset}_{count}',bool((mapping[valid]<p).all()))
   gathered={}
   for name,wi,channels in (('fc1_bytes',0,1024),('activation_bytes',2,512),('fc2_bf16',4,2048)):
    gathered[name]=ws[wi].reshape(-1,channels)[mapping[valid]].clone()
   for name,wi,blocks in (('fc1_scale',1,8),('activation_scale',3,4)):
    gathered[name]=ws[wi].flatten()[:p*blocks].reshape(blocks,p).T[mapping[valid]].clone()
   nfin_inputs=list(inputs);nfin_inputs[0]=torch.empty((64,0),device='cuda',dtype=torch.bfloat16)
   nk={**kw,'do_finalize':False}
   result=runner.forward(nfin_inputs,tactic=tactic,**nk)
   chk(f'L{layer}/no_finalize_fc2_{offset}_{count}',result[0][result[2].long().flatten()[valid]],gathered['fc2_bf16'])
   bodydata.append(dict(runner=runner,tactic=tactic,kw=kw,nk=nk,inputs=inputs,nfin_inputs=nfin_inputs,meta=metadata,slot=slot,ws=ws,gathered=gathered,valid=valid,mapping=mapping,result=result))
  ref=bodydata[0]
  for i,d in enumerate(bodydata[1:]):
   for name,value in d['gathered'].items():chk(f'L{layer}/partition{i}_{name}',value,ref['gathered'][name][d['valid']])
  require(f'L{layer}/one_owner',bool((bodydata[1]['valid'].int()+bodydata[2]['valid'].int()==1).all()))
  for i,d in enumerate(bodydata[1:]):
   expected=(ids.flatten()>=i*128)&(ids.flatten()<(i+1)*128)
   chk(f'L{layer}/partition{i}_ownership',d['valid'],expected)
  minus=torch.full((512,),-1,device='cuda',dtype=torch.int32)
  empty=[ref['result'][0],cw,minus]
  chk(f'L{layer}/ordered_finalize_single',finish(ref['result'],empty,cw),native)
  chk(f'L{layer}/ordered_finalize_partition',finish(bodydata[1]['result'],bodydata[2]['result'],cw),native)
  row['tactics']=[list(d['tactic']) for d in bodydata]
  row['preparation_seconds']=time.monotonic()-start
  streams=[torch.cuda.Stream(),torch.cuda.Stream()]
  def native_func():
   qq,ss,ll=prepare_moe_input(x,router)
   out=fi.trtllm_fp8_block_scale_moe(routing_logits=ll,**{**publickw,'hidden_states':qq,'hidden_states_scale':ss})
   return out[0] if isinstance(out,list) else out
  # Native q/s/logits references must be refreshed into stable allocated pointers for partitions.
  def partition_func(parallel):
   qq,ss,ll=prepare_moe_input(x,router)
   q.copy_(qq);s.copy_(ss);logits.copy_(ll)
   route_live();ids.copy_(canonical.routing_replay_ids)
   current=torch.cuda.current_stream();parts=[]
   for i,d in enumerate(bodydata[1:]):
    if parallel:
     streams[i].wait_stream(current)
     with torch.cuda.stream(streams[i]):p=d['runner'].forward(d['nfin_inputs'],tactic=d['tactic'],**d['nk'])
    else:p=d['runner'].forward(d['nfin_inputs'],tactic=d['tactic'],**d['nk'])
    parts.append(p)
   if parallel:
    for st in streams:current.wait_stream(st)
   out=finish(parts[0],parts[1],cw)
   return out,parts
  graphs={};holders={}
  for name,fn in [('native',native_func),('serial',lambda:partition_func(False)),('parallel',lambda:partition_func(True))]:
   capture_stream=torch.cuda.Stream();capture_stream.wait_stream(torch.cuda.current_stream())
   with torch.cuda.stream(capture_stream):
    for _ in range(2):fn()
   torch.cuda.current_stream().wait_stream(capture_stream);torch.cuda.synchronize()
   g=torch.cuda.CUDAGraph()
   with torch.cuda.graph(g,pool=torch.cuda.graph_pool_handle(),stream=capture_stream):h=fn()
   holders[name]=h;graphs[name]=g
   g.replay();torch.cuda.synchronize()
   chk(f'L{layer}/graph_{name}',h[0] if name!='native' else h,native)
  for name in ('serial','parallel'):
   parts=holders[name][1]
   require(f'L{layer}/{name}_disjoint_fc2_maps',parts[0][0].data_ptr()!=parts[1][0].data_ptr() and parts[0][2].data_ptr()!=parts[1][2].data_ptr())
  original_x=x.clone();original_router=router.clone()
  for perm in (torch.arange(63,-1,-1,device='cuda'),torch.arange(64,device='cuda').roll(7),torch.arange(64,device='cuda')):
   x.copy_(original_x[perm]);router.copy_(original_router[perm])
   target=native_func().clone()
   for name,g in graphs.items():
    g.replay();torch.cuda.synchronize();chk(f'L{layer}/replay_change_{len(report["checks"])}_{name}',holders[name][0] if name!='native' else holders[name],target)
  x.copy_(original_x);router.copy_(original_router)
  route_live();ids.copy_(canonical.routing_replay_ids)
  chk(f'L{layer}/routing_weights_untouched',cw,cw_original);chk(f'L{layer}/routing_ids_restored',ids,ids_original)
  require(f'L{layer}/input_weight_hashes_untouched',[sha_tensor(t) for t in (x,router,*weights)]==input_hashes)
  chk(f'L{layer}/rng_untouched',torch.cuda.get_rng_state(),rng0)
  row['checks_pending']=False;row['exact_gate']='PASS';flush()
  # Retain all per-layer graph inputs/outputs/workspaces until all three layer gates pass.
  cases.append(dict(layer=layer,row=row,graphs=graphs,holders=holders,bodydata=bodydata,streams=streams,weights=weights,x=x,router=router,q=q,s=s,logits=logits,canonical=canonical,ids=ids))
  print(json.dumps({'stage':'layer_gate_pass','layer':layer,'checks':len(report['checks'])}),flush=True)
 report['timings_allowed']=True;report['status']='TIMING';flush()
 for case in cases:
  raw=[]
  for trial in range(15):
   order=('native','serial','parallel') if trial%2==0 else ('parallel','serial','native')
   values={}
   for name in order:
    g=case['graphs'][name]
    for _ in range(5):g.replay()
    begin=torch.cuda.Event(enable_timing=True);end=torch.cuda.Event(enable_timing=True)
    begin.record()
    for _ in range(20):g.replay()
    end.record();end.synchronize();values[name]=begin.elapsed_time(end)/20
   raw.append(values)
  med={name:statistics.median(v[name] for v in raw) for name in ('native','serial','parallel')}
  case['row'].update(raw_ms=raw,median_ms=med,parallel_gain_vs_native=1-med['parallel']/med['native'],parallel_gain_vs_serial=1-med['parallel']/med['serial'])
  flush();print(json.dumps({'stage':'timed','layer':case['layer'],'median_ms':med}),flush=True)
 report.update(status='COMPLETE',all_exact=True,proposal_gate_pass=all(c['row']['parallel_gain_vs_native']>=.05 for c in cases),duration_seconds=time.monotonic()-start,limits=['Three layers of actual partial B64 (63 real + 1 reserved row), no service/fullmodel claim.','Complete layer includes input quantization, live native canonical routing, IDs cast/copy, partition routing metadata, ordered finalization.','Partition graph retains extra q/scale/logits copies for stable pointer binding; any measured loss includes them.','No model state or sampling instantiated; input/weight hashes, replay ownership and Torch CUDA RNG checked.'])
 flush()
if __name__=='__main__':
 try:main()
 except Exception as exc:
  report.update(status='FAIL',failure={'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()});flush();raise
