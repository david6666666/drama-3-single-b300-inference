from pathlib import Path
import os,json,hashlib,subprocess,sys
out=Path(__file__).resolve().parent
source=out.parent/'source-expert-partition-171acc8'
env=os.environ.copy()
env.update(CUDA_VISIBLE_DEVICES='GPU-bc643dc2-a0d1-5ed6-5ecb-0605ca9f340a',PYTHONPATH=str(source/'src'),PYTHONUNBUFFERED='1',OMP_NUM_THREADS='4',HF_MODULES_CACHE=str(out.parent/'hf_modules'),HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
for key in list(env):
 if key.startswith('DRAMA3_'):del env[key]
argv=['/home/zjy/code/hsliu/venvs/codex-drama3-standalone/bin/python',str(out/'driver.py')]
protocol=dict(hypothesis='Native 2x128 expert pipeline reduces stage waits enough to outweigh duplicated metadata/activation/static-grid work',variable='one fixed contiguous expert split; native / serial partition / parallel partition',fixed=dict(source_sha='171acc82460f479b56372a57d9f7de7a154795aa',layers=[0,19,39],gpu_uuid=env['CUDA_VISIBLE_DEVICES'],native_topk=8,experts=256,FP8='original E4M3/FP32 scales at every native boundary',finalize='ordered top8 FP32 then one BF16 cast',pdl=True,tile=8,cache='warm, no global cache changes',inputs='actual native layer capture:63 real+1 reserved padding',no_sweep=True),success='All staged exact gates before timing; at least 5% complete local MoE time reduction to propose wider validation',stop='Any native semantic mismatch stops timing and promotion; archive failure',commands=dict(argv=argv,environment={k:env[k] for k in ['CUDA_VISIBLE_DEVICES','PYTHONPATH','OMP_NUM_THREADS','HF_MODULES_CACHE','HF_HUB_OFFLINE','TRANSFORMERS_OFFLINE']}),driver_sha256=hashlib.sha256((out/'driver.py').read_bytes()).hexdigest())
(out/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
with (out/'run.log').open('w') as f:
 p=subprocess.Popen(argv,env=env,stdout=f,stderr=subprocess.STDOUT)
 (out/'process.json').write_text(json.dumps({'pid':p.pid,'owner':'/root/vllm_scaling','gpu_uuid':env['CUDA_VISIBLE_DEVICES']},indent=2)+'\n')
 code=p.wait()
print(json.dumps({'exit_code':code,'log':str(out/'run.log')}))
sys.exit(code)
