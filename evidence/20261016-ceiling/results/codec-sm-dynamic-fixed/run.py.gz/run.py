import datetime,hashlib,json,os,subprocess,threading
from pathlib import Path
r=Path(__file__).resolve().parent
source=r.parent/'source-codec-sm-69d636e'
python='/home/zjy/code/hsliu/venvs/codex-drama3-standalone/bin/python'
flags=dict(DRAMA3_PREFILL_MOE='flashinfer',DRAMA3_PACKED_MOE_PROJECTION='1',DRAMA3_GDN_STATE_DTYPE='bfloat16',DRAMA3_FUSED_MOE_INPUT='1',DRAMA3_PREFILL_CONV='triton',DRAMA3_PREFILL_MOE_TUNED='0',DRAMA3_CODEC_DEDICATED_CAPTURE_STREAM='1',DRAMA3_CODEC_SPLIT_POLICY='dp',DRAMA3_CODEC_COALESCE='0',DRAMA3_CODEC_SMS='0',DRAMA3_FUSED_MIXED_LAYOUT='0',DRAMA3_PACKED_CONV_GUARD='0',DRAMA3_DEFER_CODEC_SUBMIT='0')
env={k:v for k,v in os.environ.items() if not k.startswith('DRAMA3_')};env.update(flags,CUDA_VISIBLE_DEVICES='0',OMP_NUM_THREADS='4',PYTHONPATH=f'{source}/src:{source}/scripts:/home/zjy/code/hsliu/drama3-sources/fish-speech',TORCH_EXTENSIONS_DIR='/home/zjy/code/hsliu/cache/drama3-torch-extensions',TORCH_CUDA_ARCH_LIST='10.3')
query=['nvidia-smi','--query-compute-apps=gpu_uuid,pid,process_name,used_gpu_memory','--format=csv,noheader']
before=subprocess.check_output(query,text=True);assert 'GPU-53ed8fd9-9f5a-9c77-430d-095ad4fc860d' not in before
checkpoint='/home/zjy/.cache/huggingface/hub/models--fishaudio--drama-3/snapshots/e0a9218aa48888270f06ef1ed9ea67622c0e17d2'
cmd=[python,str(r/'driver.py'),'--checkpoint',checkpoint,'--fish-source','/home/zjy/code/hsliu/drama3-sources/fish-speech','--corpus','/home/zjy/code/hsliu/artifacts/drama3-b300-20261014/seedtts-en1088-codes/requests.jsonl','--output',str(r/'result.json'),'--capture','dedicated']
plan=dict(source_sha='69d636ef11875add6e4edf7c9bb028b9574143a3',driver_sha256=hashlib.sha256((r/'driver.py').read_bytes()).hexdigest(),hypothesis='All native codec shapes recaptured in48SM greencontext preserve exact outputs and full mutable state under fixed dynamic80request schedule.',isolated_variable='Primary versus48SM captured codec kernel resources; fixed original DP cost table and schedule.',controls='Same physicalGPU0/model/checkpoint/seed/graphs/state/source/nativeprecision; first normal serial then cappedserial/poll/thread; no cacheflush or clockchange.',gate='Same414trace/codes, all80fullPCM and finalfullmodel/codecstate exactly; disjointcaptureworkspace; allslots including scratch compared. No speed or quality claim.',stop='First exact mismatch or initialization failure; preserve failed record separately. No serving promotion.',command=cmd,environment=flags,gpu_uuid='GPU-53ed8fd9-9f5a-9c77-430d-095ad4fc860d',before_gpu=before,storage={p:subprocess.check_output(['findmnt','-T',p,'-o','SOURCE,FSTYPE,TARGET','-n'],text=True).strip() for p in [python,checkpoint,str(r)]})
(r/'experiment.json').write_text(json.dumps(plan,indent=2)+'\n')
stop=threading.Event()
def audit():
 with (r/'process-audit.jsonl').open('w') as f:
  while not stop.is_set():
   x=subprocess.run(query,text=True,capture_output=True);f.write(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),processes=x.stdout.splitlines()))+'\n');f.flush();stop.wait(1)
t=threading.Thread(target=audit);t.start()
try:
 with (r/'stdout.log').open('w') as f:
  p=subprocess.Popen(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
  (r/'pid.json').write_text(json.dumps(dict(pid=p.pid))+'\n')
  rc=p.wait()
 (r/'exit.json').write_text(json.dumps(dict(returncode=rc,after_gpu=subprocess.check_output(query,text=True)))+'\n')
 if rc:raise SystemExit(rc)
finally:stop.set();t.join()
