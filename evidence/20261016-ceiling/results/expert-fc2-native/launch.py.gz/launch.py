from pathlib import Path
import os,json,hashlib,subprocess,sys
out=Path(__file__).resolve().parent;source=out.parent/'source-metadata-rebase-95fcb0e'
prep=json.loads((out/'prepare-result.json').read_text());assert prep['status']=='CPU_AOT_PASS'
gpu='GPU-40e00845-d89c-1393-2c32-a2dca3ee9442'
apps=subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid,pid,process_name,used_memory','--format=csv,noheader'],text=True)
assert not any(gpu in line for line in apps.splitlines()),apps
(out/'gpu-before.txt').write_text(apps+subprocess.check_output(['nvidia-smi','--query-gpu=index,uuid,utilization.gpu,memory.used','--format=csv,noheader'],text=True))
env=os.environ.copy();env.update(CUDA_VISIBLE_DEVICES=gpu,PYTHONPATH=str(source/'src'),PYTHONUNBUFFERED='1',OMP_NUM_THREADS='4',HF_MODULES_CACHE=str(out.parent/'hf_modules'),HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
for key in list(env):
 if key.startswith('DRAMA3_'):del env[key]
argv=['/home/zjy/code/hsliu/venvs/codex-drama3-standalone/bin/python',str(out/'run.py')]
protocol={'hypothesis':'Unmodified Prims TS BF16 FC2 epilogue with native K128 block scale and mma64n8k32 reproduces archived native FC2 exactly. No FC1 candidate is used.',
 'isolated_variable':'FC2 implementation only; six A/B/scale staging depths reduced8→4 for resource fit, native order/dtype/geometry retained; PDL disabled for isolated correctness.',
 'fixed':{'source_sha':prep['source_sha'],'layer':0,'expert':205,'real_routes':8,'original_global_topk':8,'native_tactic':[8,5],'input':'Archived native activation E4M3 bytes[8,512], FP32 scales[4,8], original w2[1,2048,512] and scales[1,16,4]; no re-quantization or rerouting','K_order':'4 K128 blocks, each4 native K32 MMA, native FP32 scaling, BF16 output boundary','candidate_tile':[128,8,128],'candidate_mma':[64,8,32],'cluster_size':1,'shared_limit_bytes':81920,'actual_total_shared_bytes':74664,'cutlass':'4.7.1 process-only overlay; standalone4.6.2 and FI installation unchanged'},
 'gates':['CPU AOT no CUDA initialization; actual shared≤80KiB; LOCAL/STACK0 and no local operations','GPU CUBIN hash matches frozen CPU CUBIN','All16384 BF16 output values bitwise equal native oracle','All input/weight/metadata storage and CUDA RNG unchanged','Only if exact passes: same-input CUDA graph replay exact'],
 'stop':'First mismatch retained with actual/reference tensors; no timing, tolerance changes, fullcluster or runtime promotion',
 'limitations':'One expert/layer/shape arithmetic feasibility only, no end-to-end or performance claim.',
 'commands':{'argv':argv,'environment':{k:env[k] for k in ['CUDA_VISIBLE_DEVICES','PYTHONPATH','OMP_NUM_THREADS','HF_MODULES_CACHE']}},'owner':'/root/engine_audit'}
(out/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
paths=[out/n for n in ['common.py','prepare.py','prepare-result.json','inputs.pt','run.py','launch.py','protocol.json','resource-usage.txt','candidate-fc2.sass']]+list((out/'compile-artifacts').glob('*'))
paths += [Path('/home/zjy/code/hsliu/venvs/codex-drama3-standalone/lib/python3.12/site-packages/flashinfer/prims_ts/batched_gemm/gmem_c_resources.py'),Path('/home/zjy/code/hsliu/venvs/codex-drama3-standalone/lib/python3.12/site-packages/flashinfer/prims_ts/moe/tensor_adapter.py')]
(out/'frozen-inputs.json').write_text(json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths if p.is_file()},indent=2)+'\n')
with (out/'run.log').open('w') as f:
 p=subprocess.Popen(argv,env=env,stdout=f,stderr=subprocess.STDOUT)
 (out/'process.json').write_text(json.dumps({'pid':p.pid,'owner':'/root/engine_audit','gpu_uuid':gpu},indent=2)+'\n');code=p.wait()
(out/'gpu-after.txt').write_text(subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid,pid,process_name,used_memory','--format=csv,noheader'],text=True))
print(json.dumps({'exit_code':code,'log':str(out/'run.log')}));sys.exit(code)
