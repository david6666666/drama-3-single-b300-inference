"""CPU-only post-failure diagnosis; original exact FAIL remains authoritative."""
from pathlib import Path
import hashlib,json,torch
P=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
d=torch.load(P/'actual-reference.pt',map_location='cpu',weights_only=False);x=torch.load(P/'inputs.pt',map_location='cpu',weights_only=False)
a=d['output_bf16'];b=d['expected_bf16'];aligned=a.reshape(8,128,8,2).transpose(-1,-2).reshape(8,2048).contiguous()
r={'status':'POST_FAILURE_LAYOUT_DIAGNOSTIC','original_status':json.loads((P/'result.json').read_text())['status'],'driver_sha256':sha(__file__),'input_sha256':sha(P/'inputs.pt'),'actual_reference_sha256':sha(P/'actual-reference.pt'),'timings_allowed':False,'gpu_used':False,'raw_changed_values':int((a!=b).sum()),'aligned_changed_bytes':int((aligned.view(torch.uint8)!=b.view(torch.uint8)).sum()),'per_row_sorted_values_exact':[bool(torch.equal(torch.sort(u.float()).values,torch.sort(v.float()).values)) for u,v in zip(a,b)]}
v=x['act'].view(torch.float8_e4m3fn).double();w=x['w2'][0].double();s=x['actscale'].double();ws=x['s2'][0].double();y=torch.zeros((8,2048),dtype=torch.float64)
for k in range(4):y+=(v[:,k*128:(k+1)*128]@w[:,k*128:(k+1)*128].T)*s[k,:,None]*ws[:,k].repeat_interleave(128)[None,:]
for name,z in [('raw',a),('aligned',aligned),('native',b)]:
 dd=z.double()-y;r[name+'_vs_fp64']={'maxabs':float(dd.abs().max()),'rrms':float(dd.square().mean().sqrt()/y.square().mean().sqrt()),'bf16_rounded_changed_bytes':int((z.view(torch.uint8)!=y.bfloat16().view(torch.uint8)).sum())}
r['cuda_initialized']=torch.cuda.is_initialized();assert not r['cuda_initialized']
(P/'independent-layout-metrics.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
