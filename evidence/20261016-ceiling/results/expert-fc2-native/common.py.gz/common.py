"""Artifact-only native FC2 contract probe; process-local CUTLASS overlay only."""
import sys
from pathlib import Path
CUTLASS_ROOT=Path('/home/zjy/code/hsliu/venvs/codex-drama3-vllm/lib/python3.12/site-packages/nvidia_cutlass_dsl/dsl_packages')
sys.path.insert(0,str(CUTLASS_ROOT))
import dataclasses,hashlib,json
import torch
from safetensors import safe_open
from contextlib import ExitStack
from flashinfer.prims_ts.moe.config_mapper import map_trtllm_deepseek_fp8_moe_tactic
from flashinfer.prims_ts.batched_gemm.batched_gemm_config import make_config
from flashinfer.prims_ts.batched_gemm.batched_gemm_kernel import build_batched_gemm_task_manager
from flashinfer.prims_ts.moe.tensor_adapter import build_fp8_block_scale_launch_io
from flashinfer.tllm_enums import Fp8QuantizationType,ActivationType
ROOT=Path('/home/zjy/code/hsliu/artifacts/drama3-ceiling-20261016')
OUT=Path(__file__).resolve().parent
SOURCE=ROOT/'source-metadata-rebase-95fcb0e'
ORACLE=ROOT/'expert-metadata-rebase/oracle-layer0-real.pt'
CKPT=Path('/home/zjy/.cache/huggingface/hub/models--fishaudio--drama-3/snapshots/e0a9218aa48888270f06ef1ed9ea67622c0e17d2')
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def config():
 pair=map_trtllm_deepseek_fp8_moe_tactic((8,5),num_tokens=64,top_k=8,num_local_experts=256,enable_pdl=False,weight_layout=0)
 original=dict(pair.fc2.cfg.kwargs)
 candidate={**original,**{k:4 for k in ('num_stages_a','num_stages_b','num_stages_smem_sfa','num_stages_smem_sfb','num_stages_tmem_sfa','num_stages_tmem_sfb')}}
 cfg=make_config(**candidate)
 assert (cfg.mma_m,cfg.mma_n,cfg.mma_k,cfg.tile_k)==(64,8,32,128)
 assert (original['mma_m'],original['mma_n'],original['mma_k'],original['tile_k'])==(64,8,32,128)
 manager=build_batched_gemm_task_manager(num_experts=1,num_tokens=8,top_k=1,verbose=False,**candidate)
 allocator=manager.smem_allocator
 nbytes=int(allocator.total_smem_bytes)+int(allocator.barrier_smem_bytes)
 assert nbytes<=80*1024
 return cfg,dict(original=original,candidate=candidate,resolved=dataclasses.asdict(cfg),task_manager_smem_bytes=nbytes)
def cpu_data():
 d=torch.load(ORACLE,map_location='cpu',weights_only=False)
 expanded=torch.where(d['ids'].long().flatten()==205)[0];tokens=expanded//8
 assert len(expanded)==8 and len(set(tokens.tolist()))==8
 index=json.loads((CKPT/'model.safetensors.index.json').read_text())['weight_map']
 keys=[f'model.language_model.layers.0.mlp.experts.205.{p}.{s}' for p in ('up_proj','gate_proj','down_proj') for s in ('weight','weight_scale_inv')]
 with ExitStack() as stack:
  files={f:stack.enter_context(safe_open(str(CKPT/f),framework='pt',device='cpu')) for f in set(index[k] for k in keys)}
  def tensor(p,s):
   k=f'model.language_model.layers.0.mlp.experts.205.{p}.{s}';return files[index[k]].get_tensor(k)
  w1=torch.cat([tensor(p,'weight') for p in ('up_proj','gate_proj')])[None].contiguous()
  s1=torch.cat([tensor(p,'weight_scale_inv') for p in ('up_proj','gate_proj')])[None].contiguous()
  # Safetensors offsets need not satisfy the adapter's 32-byte pointer contract.
  # Own aligned copies; preserve every original FP8/FP32 byte.
  w2=tensor('down_proj','weight')[None].clone();s2=tensor('down_proj','weight_scale_inv')[None].clone()
 return dict(q=d['q'].view(torch.uint8)[tokens].contiguous().view(torch.float8_e4m3fn),s=d['input_scale'][:,tokens].contiguous(),w1=w1,s1=s1,w2=w2,s2=s2,
             fc1=d['intermediates']['fc1_bytes'][expanded].contiguous(),fc1scale=d['intermediates']['fc1_scale'][expanded].T.contiguous(),
             act=d['intermediates']['activation_bytes'][expanded].contiguous(),actscale=d['intermediates']['activation_scale'][expanded].T.contiguous(),
             expected=d['intermediates']['fc2_bf16'][expanded].contiguous(),expanded=expanded,tokens=tokens)
def io_for(cfg,data,device):
 x={k:v.to(device) for k,v in data.items()}
 x.update(fc2=torch.full((8,2048),-17.0,dtype=torch.bfloat16,device=device),tile=torch.zeros(1,dtype=torch.int32,device=device),mn=torch.full((1,),8,dtype=torch.int32,device=device),route=torch.arange(9,dtype=torch.int32,device=device),ncta=torch.ones(1,dtype=torch.int32,device=device),padded=torch.full((1,),8,dtype=torch.int32,device=device))
 x['route'][-1]=0
 io=build_fp8_block_scale_launch_io(fc='fc2',cfg=cfg,fp8_quantization_type=Fp8QuantizationType.DeepSeekFp8,
  hidden_states=x['q'],hidden_states_scale=x['s'],gemm1_weights=x['w1'],gemm1_weights_scale=x['s1'],gemm2_weights=x['w2'],gemm2_weights_scale=x['s2'],
  gemm1_output=x['fc1'],gemm1_output_scale=x['fc1scale'],activation_output=x['act'],activation_output_scale=x['actscale'],gemm2_output=x['fc2'],
  tile_idx=x['tile'],mn_limit=x['mn'],route_map=x['route'],num_non_exiting_ctas=x['ncta'],total_num_padded_tokens=x['padded'],routed_token_capacity=8,
  activation_type=int(ActivationType.Swiglu),num_experts=1,num_tokens=8,top_k=1,intermediate_size=512,hidden_size=2048)
 return io,x
