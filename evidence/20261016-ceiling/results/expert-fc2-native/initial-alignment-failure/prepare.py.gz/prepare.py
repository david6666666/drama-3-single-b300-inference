import os,time,traceback,subprocess
from pathlib import Path
os.environ['CUTE_DSL_ARCH']='sm_103a'
os.environ['CUTE_DSL_KEEP']='ptx,cubin'
os.environ['CUTE_DSL_DUMP_DIR']=str(Path(__file__).resolve().parent/'compile-artifacts')
os.environ['CUTE_DSL_CACHE_DIR']=str(Path(__file__).resolve().parent/'compile-cache')
os.environ['FLASHINFER_PRIMS_TS_COMPILE_OPTIONS']='--opt-level 2 --gpu-arch sm_103a'
from common import *
from flashinfer.prims_ts.batched_gemm.batched_gemm_run import _compile_for_launch
import cuda.bindings.driver as cuda_drv
(OUT/'compile-artifacts').mkdir(exist_ok=True)
r=dict(status='PREPARING',source_sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip(),source_status=subprocess.check_output(['git','status','--porcelain'],cwd=SOURCE,text=True),oracle_sha256=sha(ORACLE),driver_sha256=sha(__file__),common_sha256=sha(OUT/'common.py'),cutlass_overlay=str(CUTLASS_ROOT),original_standalone_cutlass='4.6.2 unchanged',overlay_version='4.7.1',timings_allowed=False)
def save():(OUT/'prepare-result.json').write_text(json.dumps(r,indent=2)+'\n')
save()
try:
 assert os.environ.get('CUDA_VISIBLE_DEVICES')==''
 assert r['source_sha']=='95fcb0ef2662f2caf9bfb7fe6863dc3ad7805b1b' and not r['source_status']
 cfg,info=config();r['config']=info;save()
 data=cpu_data();torch.save(data,OUT/'inputs.pt');r['inputs_sha256']=sha(OUT/'inputs.pt')
 io,x=io_for(cfg,data,'cpu');r['shape']=io['shape'];assert not torch.cuda.is_initialized()
 t=time.monotonic();fn=_compile_for_launch(io,cuda_drv.CUstream(0));r['compile_seconds']=time.monotonic()-t
 (OUT/'compile-artifacts/host-module.mlir').write_text(str(fn.ir_module))
 r['compiled_artifacts']={str(p.relative_to(OUT)):sha(p) for p in (OUT/'compile-artifacts').iterdir() if p.is_file()}
 r['cuda_initialized']=torch.cuda.is_initialized();assert not r['cuda_initialized'];r['status']='CPU_AOT_PASS_RESOURCE_AUDIT_PENDING'
except BaseException as e:
 r.update(status='CPU_AOT_FAIL',error=repr(e),traceback=traceback.format_exc(),cuda_initialized=torch.cuda.is_initialized());raise
finally:save()
print(json.dumps({k:v for k,v in r.items() if k!='config'},indent=2))
