import datetime
import json
import os
import socket
import subprocess
import threading
from pathlib import Path

root = Path('/home/zjy/code/hsliu/artifacts/drama3-ceiling-20261016')
source = Path('/home/zjy/code/hsliu/artifacts/drama3-ceiling-20261016/source-codec-sm-69d636e')
venv = Path('/home/zjy/code/hsliu/venvs/codex-drama3-standalone')
checkpoint = '/home/zjy/.cache/huggingface/hub/models--fishaudio--drama-3/snapshots/e0a9218aa48888270f06ef1ed9ea67622c0e17d2'
corpus = '/home/zjy/code/hsliu/artifacts/drama3-b300-20261014/seedtts-en1088-codes/requests.jsonl'
flags = dict(DRAMA3_GDN_STATE_DTYPE='bfloat16', DRAMA3_PREFILL_GDN='fla', DRAMA3_PACKED_MOE_PROJECTION='1', DRAMA3_PREFILL_CONV='triton', DRAMA3_PREFILL_MOE_TUNED='0', DRAMA3_PREFILL_MOE='flashinfer', DRAMA3_ADMISSION_MIN_BATCH='6', DRAMA3_PREFILL_BUCKET_192='1', DRAMA3_PACKED_PREFILL='1', DRAMA3_ASYNC_CODEC='1', DRAMA3_AUDIO_DELIVERY_THREAD='1', DRAMA3_FUSED_MOE_INPUT='1', DRAMA3_MIXED_BACKBONE='1', DRAMA3_MIXED_SPAN256='1', DRAMA3_CODEC_DEDICATED_CAPTURE_STREAM='1', DRAMA3_COMPACT_GDN='1', DRAMA3_FUSED_MIXED_LAYOUT='1', DRAMA3_PACKED_CONV_GUARD='1', DRAMA3_DEFER_CODEC_SUBMIT='0', DRAMA3_CODEC_SPLIT_POLICY='dp', DRAMA3_SHORT_PADDING_CONTEXT='1', DRAMA3_FUSED_MOE_RESIDUAL='1', DRAMA3_CODEC_SMS='0', DRAMA3_RESERVED_PADDING_ROUTER='0', DRAMA3_FRAME_PIPELINE='0', DRAMA3_CODEC_COALESCE='0')
env = {k: v for k, v in os.environ.items() if not k.startswith('DRAMA3_')}
env.update(flags)
env['PYTHONPATH']=str(source/'src')
sha = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip()
assert sha == '69d636ef11875add6e4edf7c9bb028b9574143a3'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=source, text=True)
processes = subprocess.check_output(['nvidia-smi', '--query-compute-apps=gpu_uuid,pid,process_name,used_gpu_memory', '--format=csv,noheader'], text=True)
assert 'GPU-53ed8fd9-9f5a-9c77-430d-095ad4fc860d' not in processes
with socket.socket() as probe:
    assert probe.connect_ex(('127.0.0.1', 18138)) != 0, 'port18138 occupied'
dynamic = json.loads((root/'codec-sm-dynamic-fixed/result.json').read_text())
assert dynamic['passed'] is True, 'Full dynamic native cap prerequisite must pass'
plan = dict(hypothesis='Capping only codec graph kernels at48 SM reduces interference with native full-SM model decoding enough to improve complete1088 C64 throughput, without failing quality or completion.', isolated_variable='Only DRAMA3_CODEC_SMS0 vs48. Same frozen runtime and four native flags plus fused MoE residual1; privateasync/thread; DP; coalesce0; reservedrouter0; framepipeline0; defer0.', source_sha=sha, source=str(source), flags=flags, gpu=0, gpu_uuid='GPU-53ed8fd9-9f5a-9c77-430d-095ad4fc860d', port=18138, cpu_affinity=sorted(os.sched_getaffinity(0)), omp_threads=8, requests=1088, concurrency=64, repeats=1, profile_enabled=False, checkpoint=checkpoint, corpus=corpus, gate='All1088 complete and all1088 outputs per arm scored unfiltered. Inspect throughput, TTFA, RTF, makespan, frames and tail. Quality acceptance remains relative frozen vLLM: WER<=2.950933601272712%, SIM>=61.88158934120563. Dynamic full native PCM/model/codec state exact prerequisite passed. One feasibility pair is not a replicated performance claim.', stop='Abort on GPU interference, server failure or incomplete output; preserve every failure.', before_gpu=processes, cpu_probe='Root native codec context CPU validation; codec-sm-dynamic-fixed/result.json', native_validation_references=['codec-sm-dynamic-fixed/result.json','codec-greencap/guarded-summary.json','codec-greencap/capture-isolation/findings.json'], target_c64_frames_s=6765.407263214912, dp_policy_feedback='Production DP unchanged. Each arm builds its own capture-time cost_ms table under its actual SM allocation; changed partitions are an intended feedback consequence. This does not hold codec partitions fixed. Server log exposes endpoint costs; full internal cost table and actual per-emit splits are not instrumented in this unprofiled service pair.', prepare='Reuse existing venv/checkpoint/local caches; no copy/download/cache drop. Capture/warmup included in separately recorded process-to-health readiness. Per-concurrency warmup remains, reference re-encode warmup skipped for preencoded corpus.')
import hashlib
plan['corpus_sha256']=hashlib.sha256(Path(corpus).read_bytes()).hexdigest()
assert plan['corpus_sha256']=='08612ee05ab0dd8a762109978b5f230e5b0311a1dfde87f03a4572434dff2dac'
plan['storage']={p:subprocess.check_output(['findmnt','-T',p,'-o','TARGET,SOURCE,FSTYPE','--noheadings'],text=True).strip() for p in (str(venv),checkpoint,'/home/zjy/.cache/huggingface/hub')}
plan['benchmark_import_path']=env['PYTHONPATH']
(root/'green-sm-service-experiment.json').write_text(json.dumps(plan, indent=2)+'\n')
stop = threading.Event()
def audit():
    with (root/'green-sm-process-audit.jsonl').open('w') as file:
        while not stop.is_set():
            value = subprocess.run(['nvidia-smi', '--query-compute-apps=gpu_uuid,pid,process_name,used_gpu_memory', '--format=csv,noheader'], capture_output=True, text=True)
            file.write(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), processes=value.stdout.splitlines()))+'\n')
            file.flush()
            stop.wait(1)
thread = threading.Thread(target=audit)
thread.start()
try:
    for enabled, name in [('0', 'green-sm-control-gpu0'), ('48', 'green-sm-candidate-gpu0')]:
        cmd = [str(venv/'bin/python'), str(source/'scripts/run_baseline.py'), '--backend', 'standalone', '--source', str(source), '--venv', str(venv), '--bench-python', str(venv/'bin/python'), '--checkpoint', checkpoint, '--fish-source', '/home/zjy/code/hsliu/drama3-sources/fish-speech', '--corpus', corpus, '--output', str(root/name), '--gpu', '0', '--port', '18138', '--capacity', '64', '--requests', '1088', '--repeats', '1', '--concurrency', '64', '--skip-reference-warmup']
        (root/f'{name}-command.json').write_text(json.dumps(cmd, indent=2)+'\n')
        print('Starting', name, flush=True)
        subprocess.run(cmd, env=dict(env, DRAMA3_CODEC_SMS=enabled), check=True)
        print('Finished', name, flush=True)
finally:
    stop.set()
    thread.join()
