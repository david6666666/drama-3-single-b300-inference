import os,sys,json,subprocess,hashlib,time
from pathlib import Path
OUT=Path(__file__).resolve().parent;ROOT=OUT.parent
GPU='GPU-619f7fdc-5f98-8c37-fe89-0465d6130baf'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def processes():
 rows=subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid,pid,process_name,used_memory','--format=csv,noheader,nounits'],text=True)
 return [x for x in rows.splitlines() if x.startswith(GPU)]
assert not processes(), 'GPU6 has active compute process'
prep=json.loads((OUT/'result.json').read_text());assert prep['status']=='CPU_AOT_PASS'
sys.path.insert(0,str(OUT));import common as c
sys.path.insert(0,str(ROOT/'expert-resident-chain'));from resource_audit import audit
p=next((OUT/'aot').glob('*.cubin'));audit(p,p.with_suffix('.ptx'),OUT/'aot/host.mlir',OUT/'resource-audit',cluster_size=1)
c.torch.save(c.cpu_data(),OUT/'inputs.pt');assert not c.torch.cuda.is_initialized()
argv=['/home/zjy/code/hsliu/venvs/codex-drama3-standalone/bin/python',str(OUT/'run.py')]
env=os.environ.copy();env.update(CUDA_VISIBLE_DEVICES=GPU,OMP_NUM_THREADS='4',HF_MODULES_CACHE=str(ROOT/'hf_modules'),HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',PYTHONUNBUFFERED='1')
protocol={'hypothesis':prep['hypothesis'],'isolated_variable':'mma_m64→128 and epi_tile_m64→128; no K32/K128 change, same native BF16 converter; M128 four-slice store coordinates corrected and original checkpoint weights/scales','fixed_controls':prep['fixed_controls'],'source_sha':prep['source_sha'],'gpu_uuid':GPU,'gate':'First eager16384BF16values exact before graph; then same graph mn changes0..8, guards/weights/inputs/RNG exact. CPU/GPU CUBIN must match.','stop':'First failure preserved; no timing/production/quality claims or tolerance relaxation','scope':'Selected layer0 expert205 only, not all experts or whole network','argv':argv,'environment':{k:env[k] for k in ('CUDA_VISIBLE_DEVICES','OMP_NUM_THREADS','HF_MODULES_CACHE')},'cpu_affinity':sorted(os.sched_getaffinity(0)),'storage':[subprocess.check_output(['findmnt','-T',str(p),'--json'],text=True) for p in (Path(sys.executable),c.CKPT,ROOT)],'timing_allowed':False}
(OUT/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
files=[OUT/'probe.py',OUT/'run.py',OUT/'launch.py',OUT/'protocol.json',OUT/'result.json',OUT/'inputs.pt',c.ORACLE,OUT/'common.py',OUT/'gmem_c_resources_m128_fc2.py',OUT/'epilogue.patch',*list((OUT/'aot').glob('*')),*list((OUT/'resource-audit').glob('*'))]
(OUT/'frozen-inputs.json').write_text(json.dumps({str(p):sha(p) for p in files if p.is_file()},indent=2)+'\n')
assert not processes()
with (OUT/'gpu.log').open('w') as f,(OUT/'process-audit.jsonl').open('w') as a:
 p=subprocess.Popen(argv,env=env,stdout=f,stderr=subprocess.STDOUT);(OUT/'pid.json').write_text(json.dumps({'pid':p.pid,'gpu_uuid':GPU})+'\n')
 while p.poll() is None:
  a.write(json.dumps({'time':time.time(),'processes':processes()})+'\n');a.flush()
  if any(int(x.split(',')[1])!=p.pid for x in processes()):
   p.terminate();raise RuntimeError('Competing GPU6 process; no timing claim')
  time.sleep(2)
 code=p.wait();after=processes()
(OUT/'exit.json').write_text(json.dumps({'exit_code':code,'post_processes':after})+'\n');print('exit',code);sys.exit(code)
