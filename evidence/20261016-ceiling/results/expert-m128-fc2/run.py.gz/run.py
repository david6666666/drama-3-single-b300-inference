"""One GPU arithmetic feasibility gate, no timing or deployment."""
import os,sys,json,traceback,subprocess
from pathlib import Path
OUT=Path(__file__).resolve().parent;ROOT=OUT.parent
os.environ.update(CUTE_DSL_ARCH='sm_103a',CUTE_DSL_KEEP='ptx,cubin',CUTE_DSL_DUMP_DIR=str(OUT/'gpu-aot'))
(OUT/'gpu-aot').mkdir(exist_ok=True)
sys.path.insert(0,str(OUT));import common as c
import torch
from flashinfer.prims_ts.batched_gemm.batched_gemm_run import _compile_for_launch,_launch_arg_tuple
from flashinfer.prims_ts.batched_gemm.batched_gemm_config import make_config
import cuda.bindings.driver as drv
r={'status':'PREPARING','checks':[],'timing_allowed':False,'pid':os.getpid()}
def flush():(OUT/'gpu-result.json').write_text(json.dumps(r,indent=2)+'\n')
def chk(name,a,b):
 a=a.contiguous();b=b.contiguous();ok=a.shape==b.shape and a.dtype==b.dtype and torch.equal(a.view(torch.uint8),b.view(torch.uint8));r['checks'].append({'name':name,'exact':ok});flush()
 if not ok:
  torch.save({'actual':a.cpu(),'expected':b.cpu()},OUT/(name.replace('/','_')+'-mismatch.pt'))
  raise AssertionError(name)
@torch.inference_mode()
def run():
 manifest=json.loads((OUT/'frozen-inputs.json').read_text());assert all(c.sha(p)==h for p,h in manifest.items())
 prep=json.loads((OUT/'result.json').read_text());assert prep['status']=='CPU_AOT_PASS'
 assert os.environ['CUDA_VISIBLE_DEVICES']=='GPU-619f7fdc-5f98-8c37-fe89-0465d6130baf'
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=c.SOURCE,text=True).strip()==prep['source_sha']
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=c.SOURCE,text=True).strip()
 data=torch.load(OUT/'inputs.pt',map_location='cpu',weights_only=False)
 cfg=make_config(**prep['candidate']);io,x=c.io_for(cfg,data,'cuda')
 stream=drv.CUstream(torch.cuda.current_stream().cuda_stream);fn=_compile_for_launch(io,stream)
 bins=list((OUT/'gpu-aot').glob('*.cubin'));assert len(bins)==1 and c.sha(bins[0])==prep['cubin_sha256']
 r.update(gpu_uuid=str(torch.cuda.get_device_properties(0).uuid),cubin_sha256=c.sha(bins[0]),cpu_affinity=sorted(os.sched_getaffinity(0)))
 before={k:t.clone() for k,t in x.items() if k not in ('fc2','mn')};rng=torch.cuda.get_rng_state().clone()
 args=_launch_arg_tuple(io,stream);fn(*args);torch.cuda.synchronize()
 chk('initial/bf16',x['fc2'],x['expected'])
 graph=torch.cuda.CUDAGraph()
 with torch.cuda.graph(graph):fn(*_launch_arg_tuple(io,drv.CUstream(torch.cuda.current_stream().cuda_stream)))
 for n in (8,7,1,0,6,2,5,3,4,8):
  x['mn'].fill_(n);expected=x['expected'].clone();expected[n:]=-17
  for mode in ('eager','graph'):
   x['fc2'].fill_(-17)
   fn(*args) if mode=='eager' else graph.replay();torch.cuda.synchronize()
   chk(f'n{n}/{mode}/bf16',x['fc2'],expected)
 for k,t in before.items():chk('untouched/'+k,x[k],t)
 chk('rng',torch.cuda.get_rng_state(),rng);r['status']='ONE_EXPERT_FC2_EXACT_PASS';flush()
try:run()
except BaseException as e:r.update(status='EXACT_OR_EXECUTION_FAIL',error=repr(e),traceback=traceback.format_exc());flush();raise
finally:flush()
print(r['status'],len(r['checks']))
