"""Freeze the single-variable PDL experiment; CPU only, no GPU launch."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
GPU = 'GPU-bc643dc2-a0d1-5ed6-5ecb-0605ca9f340a'
os.environ['CUDA_VISIBLE_DEVICES'] = ''
sys.argv = [str(OUT / 'pdl_driver.py'), 'prepare']
sys.path.insert(0, str(OUT))
import pdl_driver as d


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


prep = json.loads((OUT / 'prepare.json').read_text())
assert prep['status'] == 'CPU_AOT_PASS'
assert not d.torch.cuda.is_initialized()
assert prep['source_sha'] == '95fcb0ef2662f2caf9bfb7fe6863dc3ad7805b1b'
assert prep['source_status'] == ''
audit = {'status': 'CPU_PDL_AOT_PASS', 'gpu_used': False, 'kernels': {}, 'configs': {}}
for fc, config in d.configs().items():
    original = json.loads((ROOT / f'expert-m128-{fc}-expanded/prepare.json').read_text())['config']['candidate']
    candidate = dict(original, use_pdl=1, do_pdl_wait_for_num_non_exiting_ctas=1)
    assert config.use_pdl == 1 and config.do_pdl_wait_for_num_non_exiting_ctas == 1
    assert config.use_early_exit == 1 and config.num_stages_a == 4 and config.num_stages_b == 4
    audit['configs'][fc] = {'changed_fields': {key: [original[key], candidate[key]] for key in candidate if candidate[key] != original[key]}, 'candidate': candidate}
    record = prep['kernels'][fc]
    binary = Path(record['cubin'])
    ptx = binary.with_suffix('.ptx').read_text()
    sass = (OUT / f'resource-{fc}/kernel.sass').read_text()
    old_sass = (ROOT / f'expert-m128-body-v3/resource-{fc}/kernel.sass').read_text()
    host = Path(record['host']).read_text()
    assert ptx.count('griddepcontrol.wait;') == 1
    assert ptx.count('griddepcontrol.launch_dependents;') == 2
    assert len(re.findall(r'\bACQBULK\b', sass)) == 1
    assert len(re.findall(r'\bPREEXIT\b', sass)) == 2
    assert not re.search(r'\b(?:ACQBULK|PREEXIT)\b', old_sass)
    # The generated launch attribute stores literal ID6 and value1.
    assert '%3 = llvm.mlir.constant(6 : i32)' in host
    assert 'llvm.store %3, %216' in host and 'llvm.store %29, %217' in host
    assert '%29 = llvm.mlir.constant(1 : i32)' in host
    resource = prep['resources'][fc]
    assert resource['total_shared_bytes_per_cta'] <= 80 * 1024
    assert resource['stack_bytes'] == resource['local_bytes'] == resource['sass_spill_ops'] == 0
    audit['kernels'][fc] = {'cubin_sha256': sha(binary), 'ptx_sha256': sha(binary.with_suffix('.ptx')), 'host_sha256': sha(record['host']), 'sass_sha256': sha(OUT / f'resource-{fc}/kernel.sass'), 'ptx_wait': 1, 'ptx_launch_dependents': 2, 'sass_acqbulk': 1, 'sass_preexit': 2, 'launch_attribute_id': 6, 'launch_attribute_value': 1, 'shared_bytes': resource['total_shared_bytes_per_cta']}
audit['empty_contract'] = 'Fixed nonzero launch grids and valid storage; candidate FC1 then FC2 only. Set ncta/padded zero; no populate/activation/finalizer. Entry WAIT precedes dynamic metadata read. This M128 path uses CLC persistent scheduling: all invalid work tiles must skip uniformly and drain; it is not the static outer-return path. CTA exit also provides implicit dependency release. Test eager and same captured graph, then restore active data.'
audit['graph_contract'] = 'Keep queried capture alive, inspect edges and kernel attributes, instantiate without modifying graph. Require actual programmatic dependency evidence; attribute query unsupported is recorded explicitly and cannot substitute for edge data.'
(OUT / 'cpu-pdl-audit.json').write_text(json.dumps(audit, indent=2) + '\n')
protocol = {
    'status': 'FROZEN_M128_PDL_SINGLE_VARIABLE',
    'hypothesis': 'Enabling supported programmatic dependent launch in the validated globally staged M128 chain may reduce complete prepared MoE latency; no claim that entry waits permit arbitrary compute overlap.',
    'isolated_variable_from_previous_candidate': 'Both TS GEMM use_pdl/do_pdl_wait_for_num_non_exiting_ctas and original activation/finalizer enable_pdl false to true. M128/K32/K128, four stages, buffers, weights, metadata and epilogues unchanged.',
    'source_sha': prep['source_sha'], 'gpu_uuid': GPU, 'watchdog_seconds': 600,
    'baseline': {'implementation': 'Original vendor prepared complete MoE', 'tactic': [8, 5], 'enable_pdl': True},
    'candidate': {'implementation': 'M128 FC1, original native activation, M128 FC2, original native finalizer', 'enable_pdl': True, 'stages': 4},
    'boundary': {'included': ['live original native routing metadata', 'FC1', 'native activation and FP8 quantizer boundary', 'FC2', 'original ordered top8 finalizer'], 'excluded_common': ['input quantization', 'logits to top8'], 'scope': 'Three real physical B64 fixtures (63 live plus one original padding row) and 12 changed-routing stress cases, full256 experts/top8. No model/service claim.'},
    'exact_before_timing': ['all15 eager and reused graph five boundaries/finalizer exact', 'each arm independent live metadata and logical ownership', 'input/weights/RNG and output guards/padding/tail unchanged', 'CPU/GPU CUBIN identical', 'empty whole-launch ncta0 eager and captured body-only chain does not hang or write', 'captured graph programmatic dependency evidence', 'active graph restored correctly after empty'],
    'feasibility': {'orders': ['AB'], 'warmups': 5, 'replays': 100, 'cases': ['L0/real', 'L19/real', 'L39/real'], 'gate': 'Each complete-call latency reduction >=5% versus native. This one-round screening is not a formal gain claim; stop and archive if any fail.'},
    'formal_timing': {'requires': 'All exact/empty/graph gates and first feasibility pass', 'orders': ['AB', 'BA', 'AB'], 'warmups': 5, 'replays': 100, 'cases': 15, 'gate': 'Each three real medians >=5% lower; every12 stress case <=5% regression; output checks again after timing. No PDLFalse timing arm.'},
    'stop': 'First semantic/hash/ownership mismatch or timeout stops; no relaxed tolerances, source edits during a run, cache flushing, clock controls or runtime promotion. Competing GPU process stops task-owned process only.',
    'storage': [json.loads(subprocess.check_output(['findmnt', '-T', str(p), '--json'], text=True)) for p in (Path(sys.executable), d.c.CKPT, ROOT)],
    'cpu_affinity': sorted(os.sched_getaffinity(0)),
    'environment': {'CUDA_VISIBLE_DEVICES': GPU, 'OMP_NUM_THREADS': '4', 'HF_MODULES_CACHE': str(ROOT / 'hf_modules'), 'HF_HUB_OFFLINE': '1', 'TRANSFORMERS_OFFLINE': '1'},
    'previous_candidate_result': str(ROOT / 'expert-m128-body-timing/result.json'),
    'runtime_modified': False,
}
(OUT / 'protocol.json').write_text(json.dumps(protocol, indent=2) + '\n')
required = ['pdl_driver.py', 'body_common.py', 'gmem_c_resources_m128_body.py', 'pdl_gate.py', 'launch.py', 'prepare_protocol.py', 'prepare.json', 'protocol.json', 'cpu-pdl-audit.json']
assert all((OUT / name).is_file() for name in required), 'gate/launcher source not complete'
files = {Path(k) for k in json.loads((ROOT / 'expert-m128-body-v3/frozen-inputs.json').read_text())}
files.update(OUT / name for name in required)
files.update((ROOT / 'expert-m128-body-timing/result.json', ROOT / 'expert-m128-body-v3/result.json'))
for fc, v in prep['kernels'].items():
    files.update((Path(v['cubin']), Path(v['cubin']).with_suffix('.ptx'), Path(v['host'])))
    files.update((OUT / f'resource-{fc}').glob('*'))
files.update(Path(m.__file__) for name, m in sys.modules.copy().items() if name.startswith(('flashinfer.prims_ts', 'cutlass.experimental.task_scheduling', 'cutlass.pipeline')) and getattr(m, '__file__', None) and str(m.__file__).endswith('.py'))
(OUT / 'frozen-inputs.json').write_text(json.dumps({str(p): sha(p) for p in sorted(files) if p.is_file()}, indent=2) + '\n')
assert not d.torch.cuda.is_initialized()
print('CPU_PDL_PROTOCOL_FROZEN', len(files), flush=True)
