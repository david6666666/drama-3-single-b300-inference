"""Frozen PDL full parity, native graph dependency evidence, and empty GEMM gate.

Empty scope is FC1 -> FC2 only, with native activation storage retained. Native
activation/finalizer do not define a no-write contract for all routes empty.
"""
import hashlib
import json
import sys
import traceback


def tensor_hash(value):
    import torch
    return hashlib.sha256(value.detach().contiguous().view(torch.uint8).cpu().numpy().tobytes()).hexdigest()


def graph_evidence(d, graph, label, expected_kernels):
    drv = d.drv
    handle = drv.CUgraph(graph.raw_cuda_graph())

    def query(name, result):
        d.req(label + '/' + name, int(result[0]) == 0, str(result[0]))
        return result[1:]

    _, count = query('node_count', drv.cuGraphGetNodes(handle, 0))
    nodes, returned = query('nodes', drv.cuGraphGetNodes(handle, count))
    nodes = nodes[:returned]
    index = {int(node): i for i, node in enumerate(nodes)}
    records = []
    for i, node in enumerate(nodes):
        (kind,) = query(f'node{i}_type', drv.cuGraphNodeGetType(node))
        record = {'index': i, 'type': str(kind)}
        if kind == drv.CUgraphNodeType.CU_GRAPH_NODE_TYPE_KERNEL:
            (params,) = query(f'node{i}_params', drv.cuGraphKernelNodeGetParams(node))
            (name,) = query(f'node{i}_name', drv.cuFuncGetName(params.func))
            attr = drv.cuGraphKernelNodeGetAttribute(
                node, drv.CUkernelNodeAttrID.CU_LAUNCH_ATTRIBUTE_PROGRAMMATIC_STREAM_SERIALIZATION)
            record.update(kernel=name.decode() if isinstance(name, bytes) else str(name), grid=[params.gridDimX, params.gridDimY, params.gridDimZ],
                          block=[params.blockDimX, params.blockDimY, params.blockDimZ],
                          shared_bytes=params.sharedMemBytes, attribute_status=str(attr[0]),
                          programmatic_attribute=(int(attr[1].programmaticStreamSerializationAllowed)
                                                  if int(attr[0]) == 0 else None))
        records.append(record)
    _, _, _, count = query('edge_count', drv.cuGraphGetEdges(handle, 0))
    starts, ends, data, returned = query('edges', drv.cuGraphGetEdges(handle, count))
    edges = [{'from': index[int(a)], 'to': index[int(b)], 'type': int(info.type),
              'from_port': int(info.from_port), 'to_port': int(info.to_port)}
             for a, b, info in zip(starts[:returned], ends[:returned], data[:returned])]
    programmatic = int(drv.CUgraphDependencyType.CU_GRAPH_DEPENDENCY_TYPE_PROGRAMMATIC)
    observed = sum(edge['type'] == programmatic for edge in edges)
    evidence = {'scope': label, 'nodes': records, 'edges': edges,
                'programmatic_edges': observed, 'graph_was_modified': False,
                'attribute_note': 'Unsupported node attribute is recorded; typed programmatic edges are authoritative.'}
    d.report.setdefault('graph_pdl_evidence', []).append(evidence)
    d.flush()
    d.req(label + '/expected_kernel_count', sum('kernel' in r for r in records) == expected_kernels)
    d.req(label + '/programmatic_chain', observed >= expected_kernels - 1, evidence)
    return evidence


def captured(d, call):
    graph = d.torch.cuda.CUDAGraph(keep_graph=True)
    with d.torch.cuda.graph(graph):
        call()
    return graph


def empty_and_graph_gate(d):
    torch = d.torch
    from flashinfer.fused_moe import core as fi
    runtime = fi.get_trtllm_moe_sm100_module()
    dataset = torch.load(d.ROOT / 'expert-metadata-rebase/oracle-layer0-real.pt',
                         map_location='cpu', weights_only=False)
    weights = d.c.weights(0, 'cuda')
    weight_hashes = [tensor_hash(value) for value in weights]
    x = d.allocate(dataset, weights, 'cuda')
    owner = d.native_body(runtime, x)
    fields = ('tile', 'mn', 'route', 'ncta', 'padded', 'expanded')
    attrs = ('cta_idx_xy_to_batch_idx', 'cta_idx_xy_to_mn_limit',
             'permuted_idx_to_token_idx', 'num_non_exiting_ctas',
             'total_num_padded_tokens', 'expanded_idx_to_permuted_idx')
    for key, attr in zip(fields, attrs):
        x['live_' + key] = getattr(owner['slot'], attr)
    stream = d.drv.CUstream(torch.cuda.current_stream().cuda_stream)
    ios = {fc: d.io_for(fc, cfg, x) for fc, cfg in d.configs().items()}
    fns = {fc: d._compile_for_launch(io, stream) for fc, io in ios.items()}
    owner['populate']()
    d.candidate_call(runtime, x, ios, fns)
    torch.cuda.synchronize()
    d.check_metadata('PDL/setup/metadata', owner['slot'], x, dataset)
    d.check_outputs('PDL/setup', x, dataset['intermediates'])
    d.chk('PDL/setup/routed', x['out'], dataset['routed'].cuda())
    rng = torch.cuda.get_rng_state().clone()

    # Query an unmodified complete FC1/activation/FC2/finalizer capture.
    full_graph = captured(d, lambda: d.candidate_call(runtime, x, ios, fns))
    graph_evidence(d, full_graph, 'PDL/full_native_body_graph', 4)
    full_graph.instantiate()
    full_graph.replay()
    torch.cuda.synchronize()
    d.check_outputs('PDL/queried_graph', x, dataset['intermediates'])
    d.chk('PDL/queried_graph/routed', x['out'], dataset['routed'].cuda())

    def gemm_body():
        current = d.drv.CUstream(torch.cuda.current_stream().cuda_stream)
        for fc in ('fc1', 'fc2'):
            fns[fc](*d._launch_arg_tuple(ios[fc], current))

    # These descriptors keep a fixed nonzero grid. No host shortcut for ncta0.
    body_graph = captured(d, gemm_body)
    graph_evidence(d, body_graph, 'PDL/empty_gemm_body_graph', 2)
    body_graph.instantiate()
    original = {key: x['live_' + key].clone() for key in fields}
    outputs = {key: x[key].clone() for key in d.OUTPUTS}
    readonly = {key: value.clone() for key, value in x.items()
                if key not in d.OUTPUTS and not key.startswith(('guard_', 'live_'))
                and key not in ('w1', 's1', 'w2', 's2')}
    x['live_ncta'].zero_()
    x['live_padded'].zero_()
    empty_metadata = {key: x['live_' + key].clone() for key in fields}
    for mode, call in (('eager', gemm_body), ('same_graph', body_graph.replay)):
        d.reset(x)
        call()
        torch.cuda.synchronize()
        for key in d.OUTPUTS:
            d.chk('PDL/empty/' + mode + '/' + key, x[key],
                  torch.full_like(x[key], d.SENTINELS[key]))
            raw = x['guard_' + key]
            d.chk('PDL/empty/' + mode + '/guard_' + key,
                  torch.cat((raw[:64], raw[-64:])), torch.full_like(raw[:128], 37))
        for key, expected in empty_metadata.items():
            d.chk('PDL/empty/' + mode + '/metadata_' + key, x['live_' + key], expected)
        for key, expected in readonly.items():
            d.chk('PDL/empty/' + mode + '/readonly_' + key, x[key], expected)
        d.chk('PDL/empty/' + mode + '/rng', torch.cuda.get_rng_state(), rng)
    for key, value in original.items():
        x['live_' + key].copy_(value)
    for key, value in outputs.items():
        x[key].copy_(value)
    body_graph.replay()
    torch.cuda.synchronize()
    d.check_metadata('PDL/restore/metadata', owner['slot'], x, dataset)
    d.check_outputs('PDL/restore_same_body_graph', x, dataset['intermediates'])
    full_graph.replay()
    torch.cuda.synchronize()
    d.check_outputs('PDL/restore_full_graph', x, dataset['intermediates'])
    d.chk('PDL/restore_full_graph/routed', x['out'], dataset['routed'].cuda())
    for i, (weight, before) in enumerate(zip(weights, weight_hashes)):
        d.req(f'PDL/weights_unchanged/{i}', tensor_hash(weight) == before)
    d.chk('PDL/final_rng', torch.cuda.get_rng_state(), rng)
    d.report['empty_scope'] = ('Fixed nonzero-grid FC1 -> FC2 with ncta=padded=0, eager and same graph; '
        'no populate, activation, finalizer. Positive native activation/metadata restored afterward; '
        'same body graph and full PDL graph both reproduce exact native boundaries. '
        'Does not assert empty activation/finalizer semantics.')
    d.flush()


def main():
    sys.argv[1:] = ['gate']
    import pdl_driver as d
    try:
        d.run()
        d.req('all15_full_parity', d.report['status'] == 'FULL_NATIVE_M128_PDL_BODY_EXACT_PASS')
        with d.torch.inference_mode():
            empty_and_graph_gate(d)
        d.report.update(status='M128_PDL_FULL_AND_EMPTY_EXACT_PASS', runtime_promoted=False)
    except BaseException as exc:
        d.report.update(status='M128_PDL_GATE_FAIL', error=repr(exc), traceback=traceback.format_exc(),
                        timing_allowed=False)
        raise
    finally:
        d.flush()
    print(json.dumps({'status': d.report['status'], 'checks': len(d.report['checks'])}), flush=True)


if __name__ == '__main__':
    main()
