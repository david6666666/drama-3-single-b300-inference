import os,sys,json,subprocess,hashlib,time
from pathlib import Path
OUT=Path(__file__).resolve().parent;ROOT=OUT.parent
GPU='GPU-53ed8fd9-9f5a-9c77-430d-095ad4fc860d'
os.environ['CUDA_VISIBLE_DEVICES']=''
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def processes():
 rows=subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid,pid,process_name,used_memory','--format=csv,noheader,nounits'],text=True)
 return [x for x in rows.splitlines() if x.startswith(GPU)]
assert not processes(), 'GPU0 has active compute process'
GATE=ROOT/'expert-m128-body-v3'
gate=json.loads((GATE/'result.json').read_text());assert gate['status']=='FULL_NATIVE_M128_BODY_EXACT_PASS'
prep=json.loads((GATE/'prepare.json').read_text());assert prep['status']=='CPU_AOT_PASS'
sys.path.insert(0,str(OUT));import body_common as c
assert all(json.loads((GATE/('resource-'+fc)/'result.json').read_text())['status']=='CPU_RESOURCE_PASS' for fc in ('fc1','fc2'))
assert not c.torch.cuda.is_initialized()
argv=['/home/zjy/code/hsliu/venvs/codex-drama3-standalone/bin/python',str(OUT/'timing.py'),'timing']
env=os.environ.copy();env.update(CUDA_VISIBLE_DEVICES=GPU,OMP_NUM_THREADS='4',HF_MODULES_CACHE=str(ROOT/'hf_modules'),HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',PYTHONUNBUFFERED='1')
protocol={'hypothesis':'The complete globally staged M128 implementation may reduce complete prepared MoE latency relative to vendor production native tactic(8,5); component speedups are insufficient evidence.', 'baseline':{'implementation':'vendor native prepared full body','tactic':[8,5],'enable_pdl':True},'candidate':{'implementation':'M128 FC1/nativeactivation/M128 FC2/nativefinalizer,4stages','enable_pdl':False},'included_both':'Native live metadata generation from identical precomputed top8 IDs/weights, all body kernels and native finalizer; CUDA graph replay. Each arm has independent metadata.', 'excluded':'Input quantization/routerlogits/topk occurred before oracle fixture; no service throughput or quality claim. No cache flush or clock control.', 'fixed':{'source_sha':prep['source_sha'],'checkpoint':str(c.CKPT),'layers':[0,19,39],'scenarios_per_layer':5,'gpu_uuid':GPU,'graph_shape':'B64/full256/top8,capacity2304'},'measurement':{'orders':['AB','BA','AB'],'warmup_replays_per_arm':5,'measured_replays_per_arm':100,'device_span':'CUDAevents around100 completegraph replays dividedby100','wall_span':'perf_counter startrecord throughend synchronize dividedby100','observer':'Two events around100replays; nvidia-smi ownership monitor2s, no perkernel events or profiler'},'continuation_gate':'Three real cases each median completecall latency at least5%lower, all12 stresscases no >5%regression; all15 raw results retained. This only authorizes later actualmodel experiment, never final1.5xsuccess.','exact_gate':str(GATE/'result.json'),'stop':'Any output/metadata/guard/ownership/hash mismatch or competing GPU process stops; no runtime promotion on failedlocalgate.','argv':argv,'environment':{k:env[k] for k in ('CUDA_VISIBLE_DEVICES','OMP_NUM_THREADS','HF_MODULES_CACHE')},'cpu_affinity':sorted(os.sched_getaffinity(0)),'storage':[subprocess.check_output(['findmnt','-T',str(p),'--json'],text=True) for p in (Path(sys.executable),c.CKPT,ROOT)],'timing_allowed':True}
(OUT/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
files=[Path(k) for k in json.loads((GATE/'frozen-inputs.json').read_text())]
files += [GATE/'result.json',GATE/'exit.json',OUT/'timing.py',OUT/'launch.py',OUT/'protocol.json',OUT/'body_common.py',OUT/'gmem_c_resources_m128_body.py']
files += [Path(m.__file__) for name,m in sys.modules.copy().items() if name.startswith(('flashinfer.prims_ts','cutlass.experimental.task_scheduling','cutlass.pipeline')) and getattr(m,'__file__',None) and str(m.__file__).endswith('.py')]
(OUT/'frozen-inputs.json').write_text(json.dumps({str(p):sha(p) for p in files if p.is_file()},indent=2)+'\n')
assert not processes()
with (OUT/'gpu.log').open('w') as f,(OUT/'process-audit.jsonl').open('w') as a:
 p=subprocess.Popen(argv,env=env,stdout=f,stderr=subprocess.STDOUT);(OUT/'pid.json').write_text(json.dumps({'pid':p.pid,'gpu_uuid':GPU})+'\n')
 while p.poll() is None:
  a.write(json.dumps({'time':time.time(),'processes':processes()})+'\n');a.flush()
  if any(int(x.split(',')[1])!=p.pid for x in processes()):
   p.terminate();raise RuntimeError('Competing GPU0 process; no timing claim')
  time.sleep(2)
 code=p.wait();after=processes()
(OUT/'exit.json').write_text(json.dumps({'exit_code':code,'post_processes':after})+'\n');print('exit',code);sys.exit(code)
