#include <cublasLt.h>
#include <fstream>
#include <iostream>
int main(int argc,char**argv) {
  if(argc!=2)return 2;
  cublasLtMatmulAlgo_t algo{};std::ifstream f(argv[1],std::ios::binary);
  f.read(reinterpret_cast<char*>(&algo),sizeof(algo));if(f.gcount()!=sizeof(algo))return 3;
  uint64_t flags=0;size_t written=0;int id=-1;
  auto status=cublasLtMatmulAlgoCapGetAttribute(&algo,CUBLASLT_ALGO_CAP_NUMERICAL_IMPL_FLAGS,&flags,sizeof(flags),&written);
  cublasLtMatmulAlgoConfigGetAttribute(&algo,CUBLASLT_ALGO_CONFIG_ID,&id,sizeof(id),nullptr);
  std::cout<<"{\"status\":"<<status<<",\"bytes\":"<<written<<",\"flags\":"<<flags<<",\"id\":"<<id<<",\"library_version\":"<<cublasLtGetVersion()<<"}\n";
  return status;
}
