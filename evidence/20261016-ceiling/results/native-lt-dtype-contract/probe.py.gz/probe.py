import ctypes as C
import hashlib,json,sys,subprocess
from pathlib import Path
P=Path(__file__).parent
sys.path.insert(0,str(P.parent/'native-lt-b64'))
from lt_binding import Lt,Plan,Algo
import torch

GPU='GPU-53ed8fd9-9f5a-9c77-430d-095ad4fc860d'
result=dict(status='STARTING',scope='dtype correctness only; no timing or model change',tests=[])
def save():(P/'result.json').write_text(json.dumps(result,indent=2)+'\n')
def get_attr(lib,name,obj,attr,dtype):
    fn=getattr(lib,name);fn.argtypes=[C.c_void_p,C.c_int,C.c_void_p,C.c_size_t,C.POINTER(C.c_size_t)];fn.restype=C.c_int
    value,written=dtype(),C.c_size_t();status=fn(obj,attr,C.byref(value),C.sizeof(value),C.byref(written))
    assert status==0 and written.value==C.sizeof(value),(name,attr,status,written.value)
    return value.value
@torch.inference_mode()
def main():
    lt=Lt();saved=json.loads((P.parent/'native-lt-b64/result.json').read_text())
    result['torch_version']=torch.__version__;result['device']=torch.cuda.get_device_name()
    workspace=torch.empty(32<<20,device='cuda',dtype=torch.uint8)
    plans=[]
    for row in saved['shapes']:
        m,n,k,sx=row['shape'];plan=Plan(lt,m,n,k,sx);plans.append(plan)
        # Exactly first heuristic per shape, matching bounded original selection.
        h=row['heuristics'][0];algo=Algo.from_buffer_copy(bytes.fromhex(h['algo_bytes']))
        attr=dict(compute=get_attr(lt.lib,'cublasLtMatmulDescGetAttribute',plan.desc,0,C.c_int),scale=get_attr(lt.lib,'cublasLtMatmulDescGetAttribute',plan.desc,1,C.c_int),a_dtype=get_attr(lt.lib,'cublasLtMatrixLayoutGetAttribute',plan.layouts[0],0,C.c_int),b_dtype=get_attr(lt.lib,'cublasLtMatrixLayoutGetAttribute',plan.layouts[1],0,C.c_int),d_dtype=get_attr(lt.lib,'cublasLtMatrixLayoutGetAttribute',plan.layouts[2],0,C.c_int))
        assert attr==dict(compute=68,scale=0,a_dtype=14,b_dtype=14,d_dtype=14)
        native_flags=lt.attribute(algo,15,True,C.c_uint64)
        (P/'algo.bin').write_bytes(bytes(algo))
        cxx=subprocess.run([str(P/'capability_probe_gpu'),str(P/'algo.bin')],text=True,capture_output=True)
        assert cxx.returncode==0,(cxx.returncode,cxx.stdout,cxx.stderr)
        cpp=json.loads(cxx.stdout);assert cpp['flags']==native_flags
        for name,exponent,signs in [('large_x',80,False),('tiny_x',-80,False),('alternating_large',80,True),('fp32_accumulation',0,False)]:
            x=torch.full((m,k),2.**exponent,device='cuda',dtype=torch.bfloat16)
            w=torch.full((n,k),2.**(-exponent),device='cuda',dtype=torch.bfloat16)
            if signs:
                w[:,1::2]*=-1;w[:,-1]=2.**(-exponent)
            if name=='fp32_accumulation':
                x[:,1::2]=2.**-7
            out=torch.empty((m,n),device='cuda',dtype=torch.bfloat16)
            expected=(x.double() @ w.double().T).to(torch.bfloat16)
            plan.run(algo,x,w,out,workspace,torch.cuda.current_stream().cuda_stream)
            torch.cuda.synchronize()
            exact=torch.equal(out.view(torch.uint8),expected.view(torch.uint8))
            finite=bool(out.isfinite().all())
            test=dict(shape=row['shape'],name=name,descriptor=attr,flags=native_flags,cxx=cpp,bit_exact_fp64_rounded=exact,finite=finite,first=float(out[0,0]),expected=float(expected[0,0]),algo_id=h['algo_id'],split_k=h['split_k'],reduction=h['reduction'])
            result['tests'].append(test);save()
            assert exact and finite,test
        plan.close()
    lt.close();result['status']='BF16_DESCRIPTOR_AND_RANGE_DIAGNOSTIC_PASS';save()
    print(json.dumps(result),flush=True)
if __name__=='__main__':
    try:main()
    except Exception as e:result['status']='FAIL';result['error']=repr(e);save();raise
