"""Artifact-only FC1 SF prefetch; native stage layout and consumer arithmetic.

576 private shared bytes cache all original FP32 scales for this output tile.
Only the producer uses the cache. Its per-K copies remain guarded by the native
stage acquire/release lifecycle. Pair this resource with pipeline_configs.
"""
# SPDX-License-Identifier: Apache-2.0
from dataclasses import dataclass
from typing import Any, Optional

import cutlass
import cutlass.cute as cute
from cutlass import Float32, Int32, pipeline
from cutlass.experimental.task_scheduling.enums import WorkAttr
from cutlass.experimental.task_scheduling.memory import SmemAllocation
from cutlass.experimental.task_scheduling.resources import (
    PipelineConfig, StageInfo, producer_work,
)
from flashinfer.prims_ts.batched_gemm.smem_deepseek_sf_resources import (
    SmemDeepSeekSfAbResource as NativeSfResource,
)


def validate_config(cfg):
    assert cfg.has_deepseek_fp8 and cfg.is_fp8_mma and cfg.is_swap_ab
    assert cfg.has_routed_act and cfg.cluster_m == 1
    assert (cfg.tile_m, cfg.tile_n, cfg.tile_k) == (128, 8, 128)
    assert cfg.num_dsfp8_act_sfs_per_stage == 32
    assert cfg.num_load_sfab_warps == 1


def pipeline_configs(cfg, original):
    validate_config(cfg)
    result = dict(original)
    result['smem_dsfp8_sfab'] = PipelineConfig.create_async_async_pipeline_cfg(
        num_stages=cfg.num_stages_smem_sfa,
        producer_group=pipeline.CooperativeGroup(pipeline.Agent.Thread, 32),
        consumer_group=pipeline.CooperativeGroup(
            pipeline.Agent.Thread, cfg.num_epilogue_warps * 32),
        cta_layout_vmnk=(1, 1, 1, 1),
        producer_op=pipeline.PipelineOp.AsyncThread,
    )
    return result


@dataclass(kw_only=True)
class TileCachedSfResource(NativeSfResource):
    _alloc_full_sf: cutlass.Constexpr[Optional[SmemAllocation]] = None
    full_sf: Any = None

    def __post_init__(self):
        validate_config(self.cfg)
        super().__post_init__()
        self._alloc_full_sf = SmemAllocation(
            self.name + '_fc1_full_sf', size_bytes=16 * 9 * 4, alignment=16)

    def get_smem_requirements(self):
        return [*super().get_smem_requirements(), self._alloc_full_sf]

    @cute.jit
    def _init_smem(self, context):
        self.smem_buf = cutlass.Array(
            context.smem_base.data_ptr() + self._alloc_dsfp8_sf.offset,
            dtype=cutlass.Uint8, shape=(self._alloc_dsfp8_sf.size_bytes,), addrspace=3)
        self.full_sf = cutlass.Array(
            context.smem_base.data_ptr() + self._alloc_full_sf.offset,
            dtype=Float32, shape=(144,), addrspace=3)

    @producer_work(work_attrs=WorkAttr.AUXILIARY)
    @cute.jit
    def prepare_sfab_tile(self, stage_info: StageInfo):
        NativeSfResource.prepare_sfab_tile(self, stage_info)
        tidx, _, _ = cute.arch.thread_idx()
        lane = tidx - Int32(self.cfg.load_sfab_warp_idx * 32)
        token = lane % Int32(8)
        valid = token < self.dsfp8_token_limit
        physical = Int32(0)
        if valid:
            physical = self.route_map_view.load(
                idx=self.dsfp8_token_base + token, vector_size=1)[0]
        # All 32 producer lanes participate, four K blocks per instruction.
        for iteration in cutlass.range_constexpr(4):
            k = lane // Int32(8) + Int32(iteration * 4)
            value = Float32(0.0)
            if valid:
                value = self.sfb_gmem_base.load(
                    idx=k * self.dsfp8_act_token_stride + physical,
                    vector_size=1)[0]
            self.full_sf.store(value, idx=k * Int32(9) + token)
        if lane < Int32(16):
            offset = (
                self.dsfp8_expert_idx * self.dsfp8_num_weight_tiles
                + self.dsfp8_weight_tile_idx
            ) * self.dsfp8_num_k_blocks + lane
            weight = self.sfa_gmem_base.load(idx=offset, vector_size=1)[0]
            self.full_sf.store(weight, idx=lane * Int32(9) + Int32(8))
        # Cross-lane shared reads below need explicit warp memory ordering.
        # No full-cache consumer lives outside this producer warp.
        cute.arch.sync_warp()

    @producer_work
    @cute.jit
    def load_sfab_tile(self, stage_info: StageInfo):
        tidx, _, _ = cute.arch.thread_idx()
        lane = tidx - Int32(self.cfg.load_sfab_warp_idx * 32)
        k = stage_info.loop_offset
        stage = cutlass.Array(
            self.smem_buf.data_ptr(
                self.cfg.num_bytes_dsfp8_sfab_per_stage * stage_info.stage_idx),
            dtype=Float32, shape=(33,), addrspace=3)
        if (lane < Int32(8)) & (lane < self.dsfp8_token_limit):
            value = self.full_sf.load(idx=k * Int32(9) + lane, vector_size=1)[0]
            stage.store(value, idx=lane)
        if lane == Int32(0):
            weight = self.full_sf.load(
                idx=k * Int32(9) + Int32(8), vector_size=1)[0]
            stage.store(weight, idx=Int32(32))
        # Generic STS is published by AsyncThread release/acquire, never by a
        # cp.async completion group. Keep the explicit shared-proxy fence.
        cute.arch.fence_view_async_shared()
