"""Inspect existing CPU AOT artifacts; no compiler invocation or CUDA import."""
import hashlib
import json
import re
from collections import Counter
from pathlib import Path

OUT = Path(__file__).resolve().parent
OLD = OUT.parent / 'expert-m128-route-cache'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def instructions(text):
    return Counter(re.findall(r'/\*[0-9a-f]+\*/\s+(?:@!?[PU][PT]?\d*\s+)?([A-Z][A-Z0-9_.]+)', text))


def main():
    resources = {fc: json.loads((OUT / f'driver-resource-{fc}/result.json').read_text()) for fc in ['fc1', 'fc2']}
    old_resources = {fc: json.loads((OLD / f'driver-resource-{fc}/result.json').read_text()) for fc in ['fc1', 'fc2']}
    ptx_path = next((OUT / 'driver-cpu-compile').glob('*1024230*.ptx'))
    sass_path = OUT / 'driver-resource-fc1/kernel.sass'
    ptx = ptx_path.read_text()
    sass = sass_path.read_text()
    old_sass = (OLD / 'driver-resource-fc1/kernel.sass').read_text()
    hist = instructions(sass)
    old_hist = instructions(old_sass)
    checks = []

    def check(name, value):
        checks.append({'name': name, 'passed': bool(value)})
        assert value, name

    check('exactly_576_extra_shared', resources['fc1']['total_shared_bytes_per_cta'] - old_resources['fc1']['total_shared_bytes_per_cta'] == 576)
    check('FC1_actual_fit', resources['fc1']['total_shared_bytes_per_cta'] <= 80 * 1024)
    for fc in ['fc1', 'fc2']:
        check(fc + '_no_spill', all(resources[fc][k] == 0 for k in ['stack_bytes', 'local_bytes', 'ptx_local_ops', 'sass_spill_ops']))
    check('FC2_CUBIN_identical', resources['fc2']['cubin_sha256'] == old_resources['fc2']['cubin_sha256'])
    check('FC1_actual_REG32', resources['fc1']['base_registers'] == 32)
    check('no_actual_register_redistribution', not re.search(r'\bU?SETMAXN?REG\b', sass))
    for opcode in ['UTMALDG.3D', 'UTMALDG.2D.GATHER4', 'UTCQMMA', 'ACQBULK', 'PREEXIT']:
        check('same_instruction_count_' + opcode, hist[opcode] == old_hist[opcode] and hist[opcode] > 0)
    check('old_SF_LDGSTS_present', old_hist['LDGSTS.E'] == 14)
    check('no_remaining_LDGSTS', hist['LDGSTS.E'] == 0 and hist['ARRIVES.LDGSTSBAR.64.ARVCNT'] == 0)
    works = re.findall(r'// SmemDeepSeekSfAb_producer_work\n(.*?)// SmemDeepSeekSfAb_producer_commit', ptx, flags=re.DOTALL)
    check('all_seven_unrolled_SF_work_bodies_found', len(works) == 7)
    for index, work in enumerate(works):
        check(f'SF_work_{index}_shared_copies_only', 'ld.shared' in work and 'st.shared' in work and 'ld.global' not in work and 'cp.async' not in work)
        check(f'SF_work_{index}_proxy_fence', 'fence.proxy.async.shared::cta' in work)
    prepare_start = ptx.index('// SmemDeepSeekSfAb_producer_aux_work')
    prepare_end = ptx.index('// SmemDeepSeekSfAb_producer_try_acquire', prepare_start)
    preload = ptx[prepare_start:prepare_end]
    check('warp_sync_after_preload_in_PTX', 'bar.warp.sync' in preload)
    check('full_cache_address_range_emitted', all(f'+{value}' in preload for value in [72256, 72400, 72544, 72688, 72288]))
    check('ordinary_release_arrival_emitted', 'mbarrier.arrive.shared.b64' in ptx and 'cp.async.mbarrier.arrive' not in ptx)
    check('SASS_stage_release_has_generic_store_fence', 'MEMBAR.ALL.CTA' in sass and 'FENCE.VIEW.ASYNC.S' in sass and 'SYNCS.ARRIVE.TRANS64.A1T0' in sass)
    result = {'status': 'CPU_COMPILE_CONTRACT_PASS', 'checks': checks,
              'resources': resources, 'candidate_instruction_histogram': dict(hist),
              'route_cache_control_instruction_histogram': dict(old_hist),
              'scope': 'static compiled evidence; no GPU launch and no throughput result',
              'warp_sync': {'PTX': 'bar.warp.sync -1 after prepare stores',
                            'SASS': 'corresponding PC0x3940 is NOP; stores0x38f0..0x3930 precede a uniform stage loop',
                            'interpretation': 'Compiler eliminated the explicit warp opcode. Do not claim an emitted WARPSYNC here; hardware exact gate remains required.'},
              'limitations': ['Equal static TMA/MMA opcode counts alone do not prove equivalent scheduling or execution counts.',
                             'Actual REG32 and source setmaxnreg hints do not establish occupancy or a register-redistribution speedup.',
                             'Cross-lane publication is specified in PTX; CPU cannot prove absence of a compiler/runtime defect.',
                             'Original metadata-ready and route-cache negative results are unchanged.'],
              'sources': {'audit_compile.py': sha(Path(__file__)), str(ptx_path): sha(ptx_path), str(sass_path): sha(sass_path)},
              'gpu_used': False, 'timing_allowed': False}
    (OUT / 'compile-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'status': result['status'], 'checks': len(checks), 'shared_bytes': resources['fc1']['total_shared_bytes_per_cta']}))


if __name__ == '__main__':
    main()
