"""CPU address/bit-copy proof for the artifact-only full-SF producer.

This does not execute candidate device code or establish a GPU exact result.
"""
import ast
import hashlib
import json
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import torch

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
sys.path.insert(0, str(Path('/home/zjy/code/hsliu/venvs/codex-drama3-vllm/lib/python3.12/site-packages/nvidia_cutlass_dsl/dsl_packages')))
from flashinfer.prims_ts.batched_gemm.batched_gemm_config import make_config

import sf_tile_cached_resources as candidate

checks = 0
transactions = 0


def require(value, name):
    global checks
    checks += 1
    if not value:
        raise AssertionError(name)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def stage_copy(route, tile, valid, expert, output_tile, act_bits, weight_bits):
    """Emulate 32 producer lanes and four-K global preload instructions."""
    global transactions
    full = np.empty((16, 9), dtype=np.uint32)
    writes = np.zeros((16, 9), dtype=np.uint8)
    reads = []
    for lane in range(32):
        token = lane % 8
        physical = 0
        if token < valid:
            address = tile * 8 + token
            require(0 <= address < len(route), 'route read in bounds')
            physical = int(route[address])
            require(0 <= physical < 64, 'live route within input SF')
            reads.append(address)
        for iteration in range(4):
            k = lane // 8 + iteration * 4
            full[k, token] = act_bits[k, physical] if token < valid else 0
            writes[k, token] += 1
        if lane < 16:
            full[lane, 8] = weight_bits[expert, output_tile, lane]
            writes[lane, 8] += 1
    require(bool(np.all(writes == 1)), '144 unique shared writes')
    require(set(reads) == set(range(tile * 8, tile * 8 + valid)), 'only valid routes read')
    # Consumer observes original 33-float stages. Padding is untouched.
    original = np.full((16, 33), 0xA5A5A5A5, dtype=np.uint32)
    staged = original.copy()
    for k in range(16):
        for token in range(valid):
            staged[k, token] = full[k, token]
        staged[k, 32] = full[k, 8]
    expected = original.copy()
    expected[:, :valid] = act_bits[:, route[tile * 8:tile * 8 + valid]]
    expected[:, 32] = weight_bits[expert, output_tile, :]
    require(np.array_equal(staged, expected), 'native SF stage bits and padding')
    transactions += 1
    return staged


def main():
    config_data = json.loads((ROOT / 'expert-m128-fc1-expanded/prepare.json').read_text())['config']['candidate']
    cfg = make_config(**{**config_data, 'use_pdl': 1, 'do_pdl_wait_for_num_non_exiting_ctas': 1})
    candidate.validate_config(cfg)
    require(not torch.cuda.is_initialized(), 'CUDA remains uninitialized after imports')
    # Use unique bit-patterns, not arithmetic approximate comparisons. All 256
    # experts and all eight output SF blocks have distinguishable addresses.
    weight_bits = (np.arange(256 * 8 * 16, dtype=np.uint32).reshape(256, 8, 16)
                   + np.uint32(0x3E800000))
    cases = []
    fixtures = sorted((ROOT / 'expert-metadata-rebase').glob('oracle-layer*.pt'))
    require(len(fixtures) == 15, 'all frozen native fixtures selected')
    for path in fixtures:
        data = torch.load(path, map_location='cpu', weights_only=False)
        mapping = data['global_meta']['expanded'].numpy().astype(np.int64)
        ncta = int(data['global_meta']['ncta'])
        padded = int(data['global_meta']['padded'])
        ids = data['ids'].numpy().reshape(-1)
        experts = data['cta'].numpy()
        limits = data['mn'].numpy()
        act_bits = data['input_scale'].contiguous().view(torch.int32).numpy().view(np.uint32)
        require(act_bits.shape == (16, 64), 'actual native SF stride and K')
        require(padded == ncta * 8 and 0 < ncta <= 288, 'native padded capacity')
        require(len(np.unique(mapping)) == 512, 'native map bijection')
        require(bool(np.all((mapping >= 0) & (mapping < padded))), 'map bounds')
        require(np.array_equal(experts[mapping // 8], ids), 'native expert ownership')
        # Alternate legal physical map per tile: reverse each active prefix.
        alternate = mapping.copy()
        for tile in range(ncta):
            valid = int(limits[tile]) - tile * 8
            require(1 <= valid <= 8, 'absolute mn limit becomes native local count')
            selected = mapping // 8 == tile
            require(np.array_equal(np.sort(mapping[selected]), np.arange(tile * 8, tile * 8 + valid)), 'contiguous live tile prefix')
            alternate[selected] = tile * 8 + valid - 1 - mapping[selected] % 8
        for label, live_map in [('archived', mapping), ('within_tile_reversed', alternate)]:
            route = np.full(2305, -2147483648, dtype=np.int64)
            route[live_map] = np.arange(512) // 8
            require(np.array_equal(route[live_map], np.arange(512) // 8), 'dynamic token ownership')
            require(np.array_equal(experts[live_map // 8], ids), 'dynamic expert ownership')
            for tile in range(ncta):
                valid = int(limits[tile]) - tile * 8
                expert = int(experts[tile])
                for output_tile in range(8):
                    stage_copy(route, tile, valid, expert, output_tile, act_bits, weight_bits)
            cases.append({'fixture': path.name, 'fixture_sha256': sha(path), 'map': label,
                          'ncta': ncta, 'padded': padded,
                          'changed_mapping_entries': int(np.count_nonzero(live_map != mapping))})
    # Independent masks and adversarial FP32 bit patterns, including signed
    # zeros, infinities, subnormals and NaN payloads. No floating operations.
    patterns = np.array([0, 0x80000000, 0x7F800000, 0xFF800000, 1,
                         0x007FFFFF, 0x7FC12345, 0xFFC54321], dtype=np.uint32)
    synthetic = np.resize(patterns, (16, 64))
    for valid in range(9):
        route = np.full(2305, -2147483648, dtype=np.int64)
        route[56:56 + valid] = np.arange(valid)[::-1] + 40
        stage_copy(route, 7, valid, 255, 7, synthetic, weight_bits)
    attrs = {name: getattr(cfg, name) for name in ('has_deepseek_fp8', 'is_fp8_mma', 'is_swap_ab', 'has_routed_act', 'cluster_m', 'tile_m', 'tile_n', 'tile_k', 'num_dsfp8_act_sfs_per_stage', 'num_load_sfab_warps')}
    rejected = []
    for key, bad in [('has_deepseek_fp8', False), ('is_fp8_mma', False),
                     ('is_swap_ab', False), ('has_routed_act', False),
                     ('cluster_m', 2), ('tile_m', 64), ('tile_n', 16),
                     ('tile_k', 64), ('num_dsfp8_act_sfs_per_stage', 16),
                     ('num_load_sfab_warps', 2)]:
        try:
            candidate.validate_config(SimpleNamespace(**{**attrs, key: bad}))
        except AssertionError:
            rejected.append(key)
        else:
            raise AssertionError('unsupported config was accepted: ' + key)
    require(len(rejected) == 10, 'all unsupported configurations rejected')
    # Evaluate the exact precompile shape assertion from the actual driver;
    # never invoke its compiler or CUDA. K must remain exactly 2048.
    module = ast.parse((OUT / 'metadata_driver.py').read_text())
    function = next(n for n in module.body if isinstance(n, ast.FunctionDef) and n.name == 'compile_candidate')
    assertion = next(n for n in ast.walk(function) if isinstance(n, ast.Assert))
    expression = compile(ast.Expression(assertion.test), '<actual compile IO guard>', 'eval')
    io = {'M': 1024, 'N': 2304, 'K': 2048, 'num_tokens': 64}
    require(eval(expression, {}, {'io': io}), 'actual compile IO guard accepts fixed scope')
    for name, value in io.items():
        bad = {**io, name: value + 1}
        require(not eval(expression, {}, {'io': bad}), 'actual compile IO guard rejects ' + name)
    require(not torch.cuda.is_initialized(), 'CUDA uninitialized at completion')
    result = {'status': 'CPU_ADDRESS_AND_BIT_COPY_PASS', 'checks': checks,
              'tile_output_transactions': transactions, 'cases': cases,
              'synthetic_valid_rows': list(range(9)), 'config_negative_cases': rejected,
              'cuda_initialized': torch.cuda.is_initialized(), 'gpu_used': False,
              'limits': ['CPU simulation does not execute candidate machine code.',
                         'Native floating arithmetic and full graph/empty gates remain unrun.',
                         'Alternate physical maps are metadata-defined, never value-sorted.'],
              'sources': {name: sha(OUT / name) for name in ['check_cpu.py', 'sf_tile_cached_resources.py', 'metadata_driver.py']}}
    (OUT / 'cpu-check.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ['status', 'checks', 'tile_output_transactions', 'cuda_initialized']}))


if __name__ == '__main__':
    main()
