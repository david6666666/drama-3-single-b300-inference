"""CPU-only formal freeze for the bounded GPU4 full-SF-cache screen."""
import ast
import difflib
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
OLD = ROOT / 'expert-m128-route-cache'
GPU = 'GPU-4ae7e013-1aac-31d8-8b8e-c27530f1c6ed'
os.environ['CUDA_VISIBLE_DEVICES'] = ''
sys.dont_write_bytecode = True
sys.argv = [str(OUT / 'metadata_driver.py'), 'prepare']
sys.path.insert(0, str(OUT))
import metadata_driver as d
from metadata_ready_graph import run_cpu_tests


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')


checks = []


def require(name, value):
    checks.append({'name': name, 'passed': bool(value)})
    assert value, name


prep = json.loads((OUT / 'driver-prepare.json').read_text())
require('CPU_AOT_PASS', prep['status'] == 'CPU_AOT_PASS')
require('CPU_address_PASS', json.loads((OUT / 'cpu-check.json').read_text())['status'] == 'CPU_ADDRESS_AND_BIT_COPY_PASS')
require('CPU_compile_contract_PASS', json.loads((OUT / 'compile-audit.json').read_text())['status'] == 'CPU_COMPILE_CONTRACT_PASS')
require('native_source_frozen', prep['source_sha'] == '95fcb0ef2662f2caf9bfb7fe6863dc3ad7805b1b' and not prep['source_status'])
snapshot = json.loads((OUT / 'cpu-manifest.json').read_text())['files']
require('CPU_compiled_helper_unchanged', sha(OUT / 'sf_tile_cached_resources.py') == snapshot['sf_tile_cached_resources.py']['sha256'])
require('CPU_driver_snapshot_retained', sha(OUT / 'cpu-original-source/metadata_driver.py') == snapshot['metadata_driver.py']['sha256'])
original = (OUT / 'cpu-original-source/metadata_driver.py').read_text()
current = (OUT / 'metadata_driver.py').read_text()
a = {node.name: ast.dump(node, include_attributes=False) for node in ast.parse(original).body if isinstance(node, ast.FunctionDef)}
b = {node.name: ast.dump(node, include_attributes=False) for node in ast.parse(current).body if isinstance(node, ast.FunctionDef)}
for name in ('configs', 'compile_candidate', 'io_for', 'allocate', 'update', 'reset', 'native_body', 'candidate_stages', 'candidate_eager', 'capture_candidate', 'check_native', 'check_outputs', 'check_metadata'):
    require('unchanged_execution_contract/' + name, a[name] == b[name])
(OUT / 'gpu-host-adaptation.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True), current.splitlines(True), fromfile='CPU driver snapshot', tofile='GPU4 driver with pre-timing audits')))
for fc in ('fc1', 'fc2'):
    resource = prep['resources'][fc]
    require(fc + '/no_spill', all(resource[k] == 0 for k in ('stack_bytes', 'local_bytes', 'ptx_local_ops', 'sass_spill_ops')))
    ptx = Path(prep['kernels'][fc]['cubin']).with_suffix('.ptx').read_text()
    require(fc + '/PDL_preserved', ptx.count('griddepcontrol.wait;') == (1 if fc == 'fc1' else 2) and ptx.count('griddepcontrol.launch_dependents;') == 2)
    require(fc + '/CUBIN_hash', sha(prep['kernels'][fc]['cubin']) == prep['kernels'][fc]['sha256'])
graph = run_cpu_tests()
require('graph_guard_CPU', graph['status'] == 'CPU_TOPOLOGY_AND_READINESS_CONTRACT_PASS')
save('cpu-graph-guard.json', graph)
require('cuda_uninitialized', not d.torch.cuda.is_initialized())
protocol = json.loads((OLD / 'protocol.json').read_text())
protocol.update(
    status='FROZEN_FC1_FULL_FP32_SF_TILE_CACHE_GPU4', gpu_uuid=GPU,
    hypothesis='Move all sixteen original FP32 activation and weight scale groups into 576-byte producer-private shared storage once per active work tile; remove per-K global SF supply without changing native arithmetic. Aggregate stalls do not prove dominance.',
    isolated_change='FC1 SF producer only: full original FP32 cache plus AsyncThread publication. Original activation gather4 and weight TMA, native consumer/MMA/FP8 boundaries, PDL and metadata-ready FC2 remain fixed.',
    candidate={**protocol['candidate'], 'implementation': 'M128 FC1 full original FP32 SF tile cache / native activation / unchanged metadata-ready FC2 / native ordered finalizer'},
    cpu_prerequisites={'address_checks': 1113949, 'compile_contract_checks': 33, 'FC1_shared_bytes': 75192, 'FC2_shared_bytes': 74664, 'actual_base_REG': 32, 'spills': 0, 'GPU_NOT_RUN_before_freeze': True},
)
protocol['environment']['CUDA_VISIBLE_DEVICES'] = GPU
protocol['environment']['PYTHONDONTWRITEBYTECODE'] = '1'
protocol['environment']['PYTHONPATH'] = str(d.c.SOURCE / 'src')
protocol['cpu_affinity'] = sorted(os.sched_getaffinity(0))
protocol['storage'] = {str(path): json.loads(subprocess.check_output(['findmnt', '-J', '-T', str(path)], text=True)) for path in (Path(sys.executable), d.c.CKPT, ROOT / 'hf_modules')}
protocol['native_binary'] = '/home/zjy/.cache/flashinfer/0.7.0.post1/103a/cached_ops/fused_moe_trtllm_sm100/fused_moe_trtllm_sm100.so'
protocol['native_binary_sha256'] = sha(protocol['native_binary'])
protocol['parent_protocol_sha256'] = sha(OLD / 'protocol.json')
protocol['parent_failure_retained'] = str(OLD / 'feasibility-result.json')
protocol['CPU_manifest_snapshot'] = {'path': str(OUT / 'cpu-manifest.json'), 'sha256': sha(OUT / 'cpu-manifest.json'), 'driver_original_copy': 'cpu-original-source/metadata_driver.py', 'host_only_changes': 'gpu-host-adaptation.patch'}
protocol['baseline_comparison'] = 'Complete implementation A/B, not single-variable versus vendor. The isolated SF change is relative to the prior metadata-ready candidate; native baseline retains tactic8,5 and PDL.'
protocol['timing_instrumentation'] = 'No extra debug export kernel or Python checks inside measured replay; normal working intermediates retain their original mathematical role. Only complete native metadata+FC1+activation+FC2+finalizer graphs are timed.'
protocol['feasibility']['gate'] = 'After all exact gates, one three-real-case AB100 screen; every case must reduce complete-call latency by >=5%. Any numerical/hash/ownership failure stops immediately. Failed aggregate screen stops without additional repetitions/service/stress timing.'
protocol['formal_timing'] = {'auto_run': False, 'requires': 'All exact and all three real >=5% first; report screen before additional frozen rounds', 'not_in_this_launcher': True}
save('protocol.json', protocol)
for path in OUT.glob('*.py'):
    ast.parse(path.read_text())
save('cpu-final-source-check.json', {'status': 'CPU_FINAL_SOURCE_PASS', 'checks': checks, 'gpu_used': False, 'cuda_initialized': d.torch.cuda.is_initialized()})
files = {Path(path) for path in json.loads((OLD / 'frozen-inputs.json').read_text())}
files.update(path for path in OUT.rglob('*') if path.is_file() and '__pycache__' not in path.parts and path.name != 'frozen-inputs.json')
files.add(Path(protocol['native_binary']))
for name, module in sys.modules.copy().items():
    path = getattr(module, '__file__', None)
    if path and path.endswith('.py') and name.startswith(('flashinfer.prims_ts', 'cutlass.experimental.task_scheduling', 'cutlass.pipeline')):
        files.add(Path(path))
save('frozen-inputs.json', {str(path): sha(path) for path in sorted(files) if path.is_file()})
print(json.dumps({'status': 'FORMAL_CPU_FREEZE_PASS', 'checks': len(checks), 'files': len(files), 'protocol_sha256': sha(OUT / 'protocol.json'), 'manifest_sha256': sha(OUT / 'frozen-inputs.json'), 'driver_sha256': sha(OUT / 'metadata_driver.py'), 'GPU_NOT_RUN': True}))
