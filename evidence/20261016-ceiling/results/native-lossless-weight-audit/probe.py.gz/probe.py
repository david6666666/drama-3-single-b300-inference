"""CPU-only raw FP8 compressibility and context-free driver capability query."""
import ctypes
import hashlib
import json
import math
import os
from pathlib import Path
import struct
import subprocess
import zlib

import numpy as np

OUT = Path(__file__).resolve().parent
CHECKPOINT = Path('/home/zjy/.cache/huggingface/hub/models--fishaudio--drama-3/snapshots/e0a9218aa48888270f06ef1ed9ea67622c0e17d2')

def entropy(counts):
    counts = np.asarray(counts, dtype=np.float64)
    p = counts[counts > 0] / counts.sum()
    return float(-np.sum(p * np.log2(p)))

def selftest():
    assert entropy([128, 0]) == 0
    assert abs(entropy([64, 64]) - 1) < 1e-12
    assert abs(entropy(np.ones(256)) - 8) < 1e-12
    x = bytes(range(256)) * 8
    assert zlib.decompress(zlib.compress(x, 1)) == x
    return {'status': 'CPU_PASS', 'entropy_cases': 3, 'round_trip_cases': 1}

def query_device():
    cuda = ctypes.CDLL('libcuda.so.1')
    def call(name, *args):
        code = getattr(cuda, name)(*args)
        assert code == 0, (name, code)
    call('cuInit', 0)
    context = ctypes.c_void_p()
    call('cuCtxGetCurrent', ctypes.byref(context))
    assert context.value is None
    count = ctypes.c_int()
    call('cuDeviceGetCount', ctypes.byref(count))
    assert count.value == 1, count.value
    device = ctypes.c_int()
    call('cuDeviceGet', ctypes.byref(device), 0)
    name = ctypes.create_string_buffer(256)
    call('cuDeviceGetName', name, len(name), device)
    uuid = (ctypes.c_ubyte * 16)()
    call('cuDeviceGetUuid_v2', ctypes.byref(uuid), device)
    hx = bytes(uuid).hex()
    formatted = 'GPU-' + '-'.join([hx[:8], hx[8:12], hx[12:16], hx[16:20], hx[20:]])
    assert formatted == 'GPU-4ae7e013-1aac-31d8-8b8e-c27530f1c6ed', formatted
    props = {}
    for label, attribute in [('VIRTUAL_MEMORY_MANAGEMENT_SUPPORTED', 102), ('GENERIC_COMPRESSION_SUPPORTED', 107)]:
        val = ctypes.c_int()
        call('cuDeviceGetAttribute', ctypes.byref(val), attribute, device)
        props[label] = val.value
    call('cuCtxGetCurrent', ctypes.byref(context))
    assert context.value is None
    return {'name': name.value.decode(), 'uuid': formatted, 'attributes': props,
            'context_created': False, 'allocation_performed': False,
            'gpu_kernels_executed': 0, 'visible_devices': os.environ.get('CUDA_VISIBLE_DEVICES')}

def main():
    report = {'scope': 'Predeclared CPU feasibility only; no GPU allocations, kernel timing or runtime change',
              'runtime_sha': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd='/home/zjy/code/hsliu/drama-3-single-b300-inference', text=True).strip(),
              'selftest': selftest(), 'device': query_device(), 'tensors': []}
    index_bytes = (CHECKPOINT / 'model.safetensors.index.json').read_bytes()
    report['weight_index_sha256'] = hashlib.sha256(index_bytes).hexdigest()
    index = json.loads(index_bytes)['weight_map']
    header_cache = {}
    # Three layers, three fixed experts, all original gate/up/down matrices: 27 MiB.
    for layer in [0, 19, 39]:
        for expert in [0, 127, 255]:
            for projection in ['gate_proj', 'up_proj', 'down_proj']:
                key = f'model.language_model.layers.{layer}.mlp.experts.{expert}.{projection}.weight'
                path = CHECKPOINT / index[key]
                if path not in header_cache:
                    with path.open('rb') as f:
                        length = struct.unpack('<Q', f.read(8))[0]
                        raw_header = f.read(length)
                    header_cache[path] = (8 + length, json.loads(raw_header), hashlib.sha256(raw_header).hexdigest())
                start, header, header_sha = header_cache[path]
                meta = header[key]
                assert meta['dtype'] == 'F8_E4M3', meta
                begin, end = meta['data_offsets']
                with path.open('rb') as f:
                    f.seek(start + begin)
                    raw = f.read(end - begin)
                assert len(raw) == math.prod(meta['shape']) == 1048576
                values = np.frombuffer(raw, dtype=np.uint8)
                counts = np.bincount(values, minlength=256)
                exponent = (values >> 3) & 15
                exponents = np.bincount(exponent, minlength=16)
                compressed = zlib.compress(raw, 1)
                assert zlib.decompress(compressed) == raw
                # A 128-byte local format cannot borrow arbitrary remote weight state.
                blocks = exponent.reshape(-1, 128)
                spans = blocks.max(1).astype(np.int16) - blocks.min(1).astype(np.int16)
                report['tensors'].append({
                    'key': key, 'file': str(path), 'shape': meta['shape'], 'dtype': meta['dtype'],
                    'raw_sha256': hashlib.sha256(raw).hexdigest(), 'header_sha256': header_sha,
                    'bytes': len(raw), 'byte_histogram': counts.tolist(),
                    'byte_entropy_bits': entropy(counts), 'exponent_histogram': exponents.tolist(),
                    'sign_mantissa_plus_exponent_entropy_bits': 4 + entropy(exponents),
                    'zlib_level1_bytes': len(compressed), 'zlib_fraction': len(compressed) / len(raw),
                    'zero_byte_fraction': float((values == 0).mean()),
                    'block128_fraction_exponent_span_le3': float((spans <= 3).mean()),
                    'block128_fraction_exponent_span_le7': float((spans <= 7).mean()),
                    'zlib_roundtrip_exact': True,
                })
    report['status'] = 'CPU_DIAGNOSTIC_COMPLETE'
    report['limitations'] = [
        'Fixed 27 tensors are not an all-weight or live-routing-weighted survey.',
        'Marginal entropy is a coding estimate, not a bound for all possible joint/lossless schemes.',
        'CPU zlib ratio and entropy do not establish random-access GPU decoder efficiency.',
        'Original FP8 bytes/scales must be exactly reconstructed before native MMA; no lossy quantization is authorized.',
        'A supported compression attribute would still require actual allocation-property and complete-call measurement; this probe allocates nothing.'
    ]
    (OUT / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'status': report['status'], 'device': report['device'], 'tensors': len(report['tensors']),
                     'mean_byte_entropy': float(np.mean([r['byte_entropy_bits'] for r in report['tensors']])),
                     'mean_zlib_fraction': float(np.mean([r['zlib_fraction'] for r in report['tensors']]))}))

if __name__ == '__main__':
    main()
