"""CPU-only accounting from complete current request delivery traces/counters."""
import hashlib,json,statistics
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
OUT=Path(__file__).resolve().parent
TARGET=6765.407263214912
NAMES=['pipeline-admission-control-gpu6','pipeline-admission-candidate-gpu6','codec-cache-control-gpu6','codec-cache-candidate-gpu6']
def pct(xs,q):
 xs=sorted(xs);p=(len(xs)-1)*q;i=int(p)
 return xs[i]+(xs[min(i+1,len(xs)-1)]-xs[i])*(p-i)
def stats(xs):return dict(n=len(xs),mean=statistics.mean(xs),p50=pct(xs,.5),p95=pct(xs,.95),maximum=max(xs))
report=dict(scope='CPU only. Actual request PCM arrival traces and lifetime selector counters; no current internal GPU stage timeline exists for these4arms.',driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),target_frames_s=TARGET,runs={})
for name in NAMES:
 p=ROOT/name;bench=p/'benchmark'
 raw=bench/'c64-r0.jsonl';rows=[json.loads(l) for l in raw.read_text().splitlines()];rows.sort(key=lambda x:x['dispatch_s'])
 warmup=json.loads((bench/'c64-warmup.json').read_text());summary=json.loads((bench/'summary.json').read_text())[0]
 start=rows[0]['dispatch_s'];fill=rows[63]['dispatch_s'];last=rows[-1]['dispatch_s'];end=max(x['dispatch_s']+x['completion_s'] for x in rows)
 intervals=[(x['dispatch_s'],x['dispatch_s']+x['completion_s']) for x in rows]
 arrivals=[(x['dispatch_s']+t,n/4096) for x in rows for t,n in zip(x['chunk_arrivals_s'],x['chunk_bytes'],strict=True)]
 frames=sum(x['acoustic_frames'] for x in rows);assert frames==sum(n for _,n in arrivals)
 phases={}
 for phase,lo,hi in [('fill',start,fill),('intake',fill,last),('drain',last,end)]:
  duration=hi-lo;delivered=sum(n for t,n in arrivals if lo<t<=hi)
  occupied=sum(max(0,min(e,hi)-max(d,lo)) for d,e in intervals)
  phases[phase]=dict(duration_s=duration,delivered_frames=delivered,delivery_frames_s=delivered/duration,client_inflight_time_weighted=occupied/duration,client_full64_deficit_equivalent_s=duration-occupied/64,algebraic_gap_to_target_s=duration-delivered/TARGET)
 completions=sorted(e for _,e in intervals);refill=[x['dispatch_s']-e for x,e in zip(rows[64:],completions[:-64],strict=True)]
 counts=[json.loads(l) for l in (p/'server.log').read_text().splitlines() if l.startswith('{"frame_pipeline_counts":')][-1]
 r=dict(source_sha=json.loads((p/'launch.json').read_text())['source_sha'],input_sha256=hashlib.sha256(raw.read_bytes()).hexdigest(),summary=summary,frames=frames,warmup_frames=sum(x['acoustic_frames'] for x in warmup),phase=phases,counts=counts,
  all_client_inflight_time_weighted=sum(x['completion_s'] for x in rows)/(end-start),mean_first_audio_client_population=sum(x['ttfa_s'] for x in rows)/(end-start),completion_after_last_audio_s=stats([x['completion_s']-x['last_audio_s'] for x in rows]),client_refill_gap_s=stats(refill),refill_pairing_nonnegative=min(refill)>=0,
  required_gain=TARGET/summary['throughput_frames_s']-1,required_time_reduction_s=summary['makespan_s']-frames/TARGET,required_time_reduction_fraction=1-summary['throughput_frames_s']/TARGET,
  full64_equivalent_delivery_step_ms=64000/summary['throughput_frames_s'],target_full64_equivalent_step_ms=64000/TARGET,
  full64_equivalent_step_gap_ms=64000/summary['throughput_frames_s']-64000/TARGET,
  last_finishes=[dict(request_id=x['request_id'],frames=x['acoustic_frames'],completion_after_last_dispatch_s=x['dispatch_s']+x['completion_s']-last) for x in sorted(rows,key=lambda x:x['dispatch_s']+x['completion_s'],reverse=True)[:5]],
  limits='Client in-flight includes waiting/prefill/decoding/codec/delivery and cannot identify live GPUdecodebatch. Counters include64warmup plus1088measured and exclude mixed/prefill. Algebraic step equivalent and target gap are delivery accounting, not measured model step latency. Raw PCM finish reason unavailable; no inferred count of executed EOS/padded rows.')
 report['runs'][name]=r
(OUT/'current-delivery-ledgers.json').write_text(json.dumps(report,indent=2)+'\n')
for name,r in report['runs'].items():
 print(name,json.dumps({k:r[k] for k in ['frames','required_gain','required_time_reduction_s','full64_equivalent_step_gap_ms','phase','completion_after_last_audio_s','client_refill_gap_s']},indent=2))
