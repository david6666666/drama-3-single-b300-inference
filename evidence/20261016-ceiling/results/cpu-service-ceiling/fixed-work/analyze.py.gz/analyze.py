"""CPU-only accounting of the frozen exact fixed-work diagnostic."""
import collections, hashlib, json
from pathlib import Path
root=Path(__file__).resolve().parent
r=json.loads((root/'result.json').read_text())
f=r['fixed_work']
def mode(name,backend='normal',events=True):
    return next(m for m in f['modes'] if (m['mode'],m['backend'],m['events_enabled'])==(name,backend,events))
model=mode('model_only'); codec=mode('codec_only'); cached=mode('codec_only','cached')
serial=mode('serialized'); serial_cached=mode('serialized','cached')
overlap=mode('overlapped'); overlap_cached=mode('overlapped','cached')
def change(a,b):return dict(before_ms=a,after_ms=b,delta_ms=b-a,relative_change=b/a-1)
paired=[]
for old,new in ((model,overlap),(overlap,overlap_cached)):
    old_events={e['op']:e for e in old['events']}; grouped=collections.defaultdict(list)
    for e in new['events']:
        if e['op'] in old_events:
            b=old_events[e['op']]
            grouped[(e['stage'],e['padded_batch'],e['prefill_capacity'],e['frame_bucket'])].append((b['gpu_ms'],e['gpu_ms']))
    paired.append(dict(before=[old['mode'],old['backend']],after=[new['mode'],new['backend']],groups=[dict(stage=k[0],padded_batch=k[1],prefill_capacity=k[2],frame_bucket=k[3],calls=len(v),**change(sum(a for a,b in v),sum(b for a,b in v))) for k,v in grouped.items()]))
inputs={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [root/'result.json',root/'experiment.json',root/'driver.py',root/'fixed_profile.py',root.parent.parent/'current-pipeline-service-ledger.json']}
summary=dict(source_sha=r['source_sha'],source_status=r['source_status'],gpu_uuid=r['gpu_uuid'],input_sha256=inputs,passed=r['passed'],normal_matches_archived=r['normal_matches_archived'],exact_check_count=sum(len(m['checks']) for m in f['modes']),failed_checks=[c for m in f['modes'] for c in m['checks'] if not c['passed']],operation_counts=f['operation_counts'],modes=[{k:m[k] for k in ('mode','backend','events_enabled','wall_ms','device_span_ms','unions_ms','stage_summary','passed')} for m in f['modes']],codec_only_cache=change(codec['wall_ms'],cached['wall_ms']),serialized_cache=change(serial['wall_ms'],serial_cached['wall_ms']),overlap_cache=change(overlap['wall_ms'],overlap_cached['wall_ms']),normal_serial_to_overlap=change(serial['wall_ms'],overlap['wall_ms']),model_span_with_codec=change(model['unions_ms']['model'],overlap['unions_ms']['model']),codec_span_with_model=change(codec['unions_ms']['codec'],overlap['unions_ms']['codec']),ideal_zero_codec_wall_allowance_ms=overlap['wall_ms']-model['wall_ms'],observer=f['observer_comparison'],paired_event_groups=paired,scope=f['scope'],limitations=['One sequential diagnostic per mode; not a replicated performance estimate or service result.','Fixed packed-prefill/single-step fixture contains no mixed or frame pipeline; current full-service timeline supplies those fractions separately.','Stage events include input copies, graph work and retained validation copies. Codec events retain PCM conversion and pinned D2H.','CPU submit timing can include CUDA queue backpressure/allocator wait. It does not measure Python-only work; no CPU per-step outputs or metadata are read in timed modes.','Model-only and omitted-codec arithmetic are diagnostic counterfactuals, never serving proposals.'])
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:summary[k] for k in ('passed','exact_check_count','codec_only_cache','overlap_cache','normal_serial_to_overlap','model_span_with_codec','ideal_zero_codec_wall_allowance_ms')},indent=2))
