"""Artifact-only observation and fixed native graph-work replay; no server edits."""
import collections,contextlib,hashlib,json,time
from types import SimpleNamespace
import torch

class Recorder:
    def __init__(self,device,prefill,decode,first,codec):
        self.device=device;self.ops=[];self.enabled=True
        self.initialize=device.initialize
        def initialize(slot,frame,history,position,limit):
            if self.enabled:self.ops.append(dict(stage='initialize',slot=slot,frame=frame.clone(),history=history.clone(),metadata=torch.tensor([position,0,limit,0],device='cuda',dtype=torch.int64)))
            return self.initialize(slot,frame,history,position,limit)
        device.initialize=initialize
        self.prefill={k:g.run for k,g in prefill.items()}
        for capacity,graph in prefill.items():
            original=self.prefill[capacity]
            def run(prompts,slots,capacity=capacity,original=original,graph=graph):
                output=original(prompts,slots)
                if self.enabled:self.ops.append(dict(stage='prefill',capacity=capacity,graph=graph,frames=graph.frames.clone(),layout={key:value.clone() for key,value in vars(graph.layout).items() if isinstance(value,torch.Tensor)},actual=len(slots),prompt_tokens=sum(map(len,prompts))))
                return output
            graph.run=run
        self.decode={k:g.run for k,g in decode.items()};self.first=first.run
        for name,graphs in [('decode',decode),('first_frame',{first.size:first})]:
            for size,graph in graphs.items():
                original=graph.run
                def run(requests,hidden=None,name=name,size=size,original=original,graph=graph):
                    output=original(requests,hidden)
                    if self.enabled:
                        self.ops.append(dict(stage=name,size=size,graph=graph,slots=graph.slots.clone(),actual=len(requests),expected=output.clone(),observed=torch.empty_like(output),metadata_expected=device.metadata.clone(),metadata_observed=torch.empty_like(device.metadata)))
                    return output
                graph.run=run
        self.codec=codec
    def record_codec(self,codes,rows,waveform):
        if not self.enabled:return
        expected=(waveform.clamp(-1,1)*32767).to(torch.int16).cpu()
        self.ops.append(dict(stage='codec',codes=codes.clone(),rows=rows.clone(),expected=expected,host=torch.empty_like(expected,pin_memory=True),actual=len(codes),frame_bucket=codes.shape[-1],rows_cpu=rows.cpu().tolist()))

def union(intervals):
    merged=[]
    for a,b in sorted(intervals):
        if merged and a<=merged[-1][1]:merged[-1][1]=max(b,merged[-1][1])
        else:merged.append([a,b])
    return sum(b-a for a,b in merged)

@torch.inference_mode()
def profile(rec,normal,cached,tensors,initial,expected_state,codec_state,rng,result,save):
    rec.enabled=False
    nmodel=len(tensors)-len(codec_state)
    result['fixed_work']=dict(scope='Exact archived80-request/414-entry schedule. Fixed GPU graph work with native model and codec inputs prestaged onGPU. GPU-to-GPU input copies replace native wrapper CPU tensor creation/H2D; this intentionally isolates GPUsequence, not fullEngine host throughput. Packed prefill/single-step decode, no mixed/pipeline/HTTP/Python completion loop. PCM conversion and pinned D2H copy retained; no callback/thread delivery in timed work.',operation_counts=dict(collections.Counter(op['stage'] for op in rec.ops)),codec_rows=[op['rows_cpu'] for op in rec.ops if op['stage']=='codec'],modes=[],passed=False)
    save();report=result['fixed_work']
    auxiliary=torch.cuda.Stream();current=torch.cuda.current_stream()
    configs=[('model_only','normal',True),('codec_only','normal',True),('codec_only','cached',True),('serialized','normal',True),('serialized','cached',True),('overlapped','normal',False),('overlapped','normal',True),('overlapped','cached',True)]
    for mode,backend,observed in configs:
        for dst,src in zip(tensors,initial,strict=True):dst.copy_(src)
        torch.cuda.set_rng_state(rng);torch.cuda.synchronize()
        family=normal if backend=='normal' else cached
        events=[];kept=[];hidden=None
        start,end=(torch.cuda.Event(enable_timing=True) for _ in range(2))
        start.record();wall_start=time.perf_counter()
        for index,op in enumerate(rec.ops):
            stage=op['stage']
            if stage=='codec' and mode=='model_only':continue
            if stage!='codec' and mode=='codec_only':continue
            stream=auxiliary if mode=='overlapped' and stage=='codec' else current
            if stage=='codec':
                codes=op['codes'] if mode=='codec_only' else rec.device.gather_codes(op['rows'],op['frame_bucket'])
                kept.append(codes)
                if mode=='overlapped':stream.wait_stream(current)
            before=time.perf_counter()
            with torch.cuda.stream(stream):
                a,b=(torch.cuda.Event(enable_timing=True) for _ in range(2)) if observed else (None,None)
                if observed:a.record()
                replay_cpu_ms=None
                if stage=='initialize':
                    rec.device.last[op['slot']].copy_(op['frame']);rec.device.history[op['slot']].copy_(op['history']);rec.device.metadata[op['slot']].copy_(op['metadata'])
                elif stage=='prefill':
                    graph=op['graph'];graph.frames.copy_(op['frames'])
                    for key,value in op['layout'].items():getattr(graph.layout,key).copy_(value)
                    launch=time.perf_counter();graph.graph.replay();replay_cpu_ms=(time.perf_counter()-launch)*1000
                    hidden=graph.output.clone()
                elif stage in ('first_frame','decode'):
                    graph=op['graph'];graph.slots.copy_(op['slots'])
                    if stage=='first_frame':graph.hidden.copy_(hidden)
                    launch=time.perf_counter();graph.graph.replay();replay_cpu_ms=(time.perf_counter()-launch)*1000
                    value=graph.output[:op['actual']]
                    op['observed'].copy_(value);op['metadata_observed'].copy_(rec.device.metadata)
                elif stage=='codec':
                    with torch.autocast('cuda',dtype=family.decoder.dtype):wave=family(codes,rows=op['rows'])
                    pcm=(wave.clamp(-1,1)*32767).to(torch.int16)
                    op['host'].copy_(pcm,non_blocking=True);kept.append(pcm)
                if observed:b.record()
            if observed:events.append((index,stage,op.get('actual',1),op.get('size'),op.get('capacity'),op.get('frame_bucket'),before,time.perf_counter()-before,replay_cpu_ms,a,b))
        if mode=='overlapped':current.wait_stream(auxiliary)
        end.record();end.synchronize();wall_ms=(time.perf_counter()-wall_start)*1000
        record=dict(mode=mode,backend=backend,events_enabled=observed,wall_ms=wall_ms,device_span_ms=start.elapsed_time(end),events=[],checks=[],passed=False)
        report['modes'].append(record);save()
        def check(name,actual,expected):
            equal=torch.equal(actual,expected)
            record['checks'].append(dict(name=name,passed=equal,shape=list(actual.shape),dtype=str(actual.dtype)))
            if not equal:save();raise AssertionError(f'{mode}/{backend}/{name}')
        for index,op in enumerate(rec.ops):
            if op['stage'] in ('decode','first_frame') and mode!='codec_only':
                check(f'op{index}/frames',op['observed'],op['expected'])
                check(f'op{index}/metadata',op['metadata_observed'],op['metadata_expected'])
            elif op['stage']=='codec' and mode!='model_only':check(f'op{index}/pcm',op['host'],op['expected'])
        for i,(actual,expected,original) in enumerate(zip(tensors,expected_state,initial,strict=True)):
            omitted=(mode=='model_only' and i>=nmodel) or (mode=='codec_only' and i<nmodel)
            check(f'state{i}',actual,original if omitted else expected)
        check('cuda_rng',torch.cuda.get_rng_state(),rng)
        for index,stage,actual,padded,capacity,bucket,cpu_start,cpu_seconds,replay_cpu_ms,a,b in events:
            record['events'].append(dict(op=index,stage=stage,actual_batch=actual,padded_batch=padded,prefill_capacity=capacity,frame_bucket=bucket,cpu_start_s=cpu_start,cpu_submit_ms=cpu_seconds*1000,graph_replay_cpu_ms=replay_cpu_ms,gpu_start_ms=start.elapsed_time(a),gpu_end_ms=start.elapsed_time(b),gpu_ms=a.elapsed_time(b)))
        model_iv=[(e['gpu_start_ms'],e['gpu_end_ms']) for e in record['events'] if e['stage']!='codec']
        codec_iv=[(e['gpu_start_ms'],e['gpu_end_ms']) for e in record['events'] if e['stage']=='codec']
        grouped=collections.defaultdict(list)
        for event in record['events']:grouped[event['stage']].append(event)
        record['stage_summary']={name:dict(calls=len(es),summed_gpu_ms=sum(e['gpu_ms'] for e in es),summed_cpu_submit_ms=sum(e['cpu_submit_ms'] for e in es),summed_graph_replay_cpu_ms=sum(e['graph_replay_cpu_ms'] or 0 for e in es),actual_rows=sum(e['actual_batch'] for e in es),padded_rows=sum(e['padded_batch'] or e['actual_batch'] for e in es)) for name,es in grouped.items()}
        record['unions_ms']=dict(model=union(model_iv),codec=union(codec_iv),combined=union(model_iv+codec_iv),overlap=union(model_iv)+union(codec_iv)-union(model_iv+codec_iv),outside_recorded=record['device_span_ms']-union(model_iv+codec_iv))
        record['passed']=True;save()
        print(json.dumps(dict(fixed_profile=mode,backend=backend,events=observed,wall_ms=wall_ms,device_ms=record['device_span_ms'],passed=True)),flush=True)
    baseline=next(m for m in report['modes'] if m['mode']=='overlapped' and m['backend']=='normal' and not m['events_enabled'])
    measured=next(m for m in report['modes'] if m['mode']=='overlapped' and m['backend']=='normal' and m['events_enabled'])
    report['observer_comparison']=dict(unobserved_wall_ms=baseline['wall_ms'],event_observed_wall_ms=measured['wall_ms'],wall_change_fraction=measured['wall_ms']/baseline['wall_ms']-1,limitation='One sequential diagnostic pair, not replicated causal overhead. Both retain identical asynchronous frame/metadata verification copies and pinned PCM D2H work; only stage events differ. No per-step CPU outputs/metadata reads in timed replay.')
    report['passed']=all(m['passed'] for m in report['modes']);save()
