import datetime,hashlib,json,os,subprocess,threading
from pathlib import Path
r=Path(__file__).resolve().parent
source=r.parents[1]/'source-codec-cache'
python='/home/zjy/code/hsliu/venvs/codex-drama3-standalone/bin/python'
flags=dict(DRAMA3_PREFILL_MOE='flashinfer',DRAMA3_PACKED_MOE_PROJECTION='1',DRAMA3_GDN_STATE_DTYPE='bfloat16',DRAMA3_FUSED_MOE_INPUT='1',DRAMA3_PREFILL_CONV='triton',DRAMA3_PREFILL_MOE_TUNED='0',DRAMA3_CODEC_DEDICATED_CAPTURE_STREAM='1',DRAMA3_CODEC_SPLIT_POLICY='dp',DRAMA3_CODEC_COALESCE='0',DRAMA3_CODEC_SMS='0',DRAMA3_FUSED_MIXED_LAYOUT='0',DRAMA3_PACKED_CONV_GUARD='0',DRAMA3_DEFER_CODEC_SUBMIT='0')
env={k:v for k,v in os.environ.items() if not k.startswith('DRAMA3_')};env.update(flags,CUDA_VISIBLE_DEVICES='GPU-619f7fdc-5f98-8c37-fe89-0465d6130baf',OMP_NUM_THREADS='4',PYTHONPATH=f'{source}/src:{source}/scripts:/home/zjy/code/hsliu/drama3-sources/fish-speech',TORCH_EXTENSIONS_DIR='/home/zjy/code/hsliu/cache/drama3-torch-extensions',TORCH_CUDA_ARCH_LIST='10.3')
query=['nvidia-smi','--query-compute-apps=gpu_uuid,pid,process_name,used_gpu_memory','--format=csv,noheader']
before=subprocess.check_output(query,text=True);assert 'GPU-619f7fdc-5f98-8c37-fe89-0465d6130baf' not in before
checkpoint='/home/zjy/.cache/huggingface/hub/models--fishaudio--drama-3/snapshots/e0a9218aa48888270f06ef1ed9ea67622c0e17d2'
cmd=[python,str(r/'driver.py'),'--checkpoint',checkpoint,'--fish-source','/home/zjy/code/hsliu/drama3-sources/fish-speech','--corpus','/home/zjy/code/hsliu/artifacts/drama3-b300-20261014/seedtts-en1088-codes/requests.jsonl','--output',str(r/'result.json'),'--capture','dedicated']
plan=dict(source_sha='e7cda1eba083603b88e1f2e89688e1ff2ced7fc2',driver_sha256=hashlib.sha256((r/'driver.py').read_bytes()).hexdigest(),support_sha256=hashlib.sha256((r/'fixed_profile.py').read_bytes()).hexdigest(),hypothesis='Fixed native80request work isolates whether codec overlap slows model spans, and whether native cached Linear weights improve the same work.',isolated_variable='Model-only, codec-only normal/cached, serialized normal/cached, overlapped normal/cached; one extra no-events overlap run. Original DP table, graph inputs and complete generated code trajectory fixed.',controls='Same physicalGPU6/model/checkpoint/seed/graphs/state/source/nativeprecision; same archived80request414trace initialstate; original packedsingle-stepfixture, no current mixed/pipeline; no cacheflush or clockchange.',gate='Prior all46shape/native dynamic gate mustPASS. Untimed normal serial must match archived414trace/all80PCM. Each fixed GPUwork mode compares every model output+request metadata, allcodec PCM calls, fullmodel/codecstate and torchRNG after completion; omitted subsystem stays initial. Input GPUstaging, not Engine host control. No service speed/quality claim.',stop='First exact mismatch or initialization failure; preserve failed record separately. No serving promotion.',command=cmd,environment=flags,gpu_uuid='GPU-619f7fdc-5f98-8c37-fe89-0465d6130baf',before_gpu=before,storage={p:subprocess.check_output(['findmnt','-T',p,'-o','SOURCE,FSTYPE,TARGET','-n'],text=True).strip() for p in [python,checkpoint,str(r)]})
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==plan['source_sha']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True)
prior=json.loads((r.parents[1]/'codec-cache-dynamic/result.json').read_text());assert prior['passed'] and prior['normal_matches_archived']
plan['scope']='Packed prefill and single-step decode; cannot attribute current mixed/pipeline fraction. Prestaged GPUinputs replace CPU input staging; PCM conversion and pinned D2H retained, callbacks/transport omitted. Every source/driver immutable during run. State restores/checks excluded from timers.'
plan['observer']='Event durations resolved once after finaljoin. Per-op frame/metadata verificationGPUcopies retained botharms. One overlap runwithout stage events measuresobserver sensitivity; single diagnostic only, no replicates/winner.'
(r/'experiment.json').write_text(json.dumps(plan,indent=2)+'\n')
stop=threading.Event()
def audit():
 with (r/'process-audit.jsonl').open('w') as f:
  while not stop.is_set():
   x=subprocess.run(query,text=True,capture_output=True);f.write(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),processes=x.stdout.splitlines()))+'\n');f.flush();stop.wait(1)
t=threading.Thread(target=audit);t.start()
try:
 with (r/'stdout.log').open('w') as f:
  p=subprocess.Popen(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
  (r/'pid.json').write_text(json.dumps(dict(pid=p.pid))+'\n')
  rc=p.wait()
 (r/'exit.json').write_text(json.dumps(dict(returncode=rc,after_gpu=subprocess.check_output(query,text=True)))+'\n')
 if rc:raise SystemExit(rc)
finally:stop.set();t.join()
