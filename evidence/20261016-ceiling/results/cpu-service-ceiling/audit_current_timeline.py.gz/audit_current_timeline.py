"""Independent CPU-only interval/step audit; leaves the parent ledger unchanged."""
from pathlib import Path
import collections,hashlib,json
root=Path(__file__).resolve().parent
base=root.parent
ledger_path=base/'current-pipeline-service-ledger.json'
l=json.loads(ledger_path.read_text())
raw_path=Path(l['inputs']['timeline']['path']);raw=json.loads(raw_path.read_text())['records']
start=l['time']['first_dispatch_s'];end=l['time']['last_completion_s']
events=[e for e in raw if start<=e['cpu_start_s']<=end]
def union(es):
    points=sorted([(e['gpu_start_ms'],1) for e in es]+[(e['gpu_end_ms'],-1) for e in es])
    depth=0;last=None;total=0.
    for at,delta in points:
        if last is not None and depth:total+=at-last
        depth+=delta;last=at
    assert depth==0
    return total
stages={'decode','mixed_backbone','first_frame','mixed_decode_tower','prefill'}
model=[e for e in events if e['stage'] in stages]
codec=[e for e in events if e['stage'] in ('codec','codec_gpu_and_copy')]
decode=[e for e in model if e['stage']=='decode']
mixed=[e for e in model if e['stage']=='mixed_backbone']
envelope=max(e['gpu_end_ms'] for e in events)-min(e['gpu_start_ms'] for e in events)
model_ms=union(model);codec_ms=union(codec);combined=union(model+codec)
counts=dict(pure_decode_calls=len(decode),actual_steps=sum(e['steps'] for e in decode),extra_graph_steps=sum(e['steps']-1 for e in decode),call_actual_rows=sum(e['batch'] for e in decode),actual_request_rows=sum(e['batch']*e['steps'] for e in decode),padded_request_rows=sum(e['padded_batch']*e['steps'] for e in decode),mixed_old_rows=sum(e['batch'] for e in mixed),mixed_prompt_count=sum(e['prompt_count'] for e in mixed),initial_prefill_requests=sum(e['batch'] for e in model if e['stage']=='prefill'),codec_valid_frames=sum(sum(e['valid_frames']) for e in codec),steps_histogram=dict(collections.Counter(e['steps'] for e in decode)))
counts['additional_multistep_request_rows']=counts['actual_request_rows']-counts['call_actual_rows']
checks=[]
def check(name,a,b,tol=1e-6):
    checks.append(dict(name=name,independent=a,ledger=b,passed=abs(a-b)<=tol))
u=l['timeline']['union'];c=l['timeline']['conditional_decode_row_accounting']
for key,actual in [('model_event_union_ms',model_ms),('codec_event_union_ms',codec_ms),('model_codec_overlap_ms',model_ms+codec_ms-combined),('codec_only_ms',combined-model_ms),('neither_model_nor_codec_in_envelope_ms',envelope-combined),('all_recorded_union_ms',union(events)),('gpu_event_envelope_ms',envelope)]:check(key,actual,u[key])
check('recorded events',len(events),l['timeline']['selected_events'])
check('actual steps',counts['actual_steps'],c['conditional_pure_decode_actual_steps'])
check('pure request rows',counts['actual_request_rows'],c['pure_decode_request_rows'])
check('mixed old rows',counts['mixed_old_rows'],c['mixed_old_request_rows'])
check('codec valid frames',counts['codec_valid_frames'],l['output']['total_acoustic_frames'])
check('all admitted prompts',counts['mixed_prompt_count']+counts['initial_prefill_requests'],l['completeness']['successful'])
check('model stage union additive',sum(union([e for e in model if e['stage']==s]) for s in stages),model_ms)
check('decomposition closes',l['timeline']['reference_gap_decomposition']['sum_s'],l['timeline']['reference_gap_decomposition']['direct_gap_s'])
phase=[e for e in decode if l['time']['client_fill_end_s']<e['cpu_start_s']<=l['time']['last_dispatch_s']]
weighted=sum(e['batch']*e['gpu_ms'] for e in phase)/sum(e['gpu_ms'] for e in phase)
result=dict(passed=all(c['passed'] for c in checks),input_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (ledger_path,raw_path)},checks=checks,counts=counts,intake_time_weighted_active=weighted,notes=['The 815 field additional_single_request_multistep_rows is a legacy name: its value is extra graph steps across all batch sizes, not request rows. The actual extra request-row count is 39892. Steps/active formulas are correct.','prefill scope calls prefill_many and contains first tower and first-token CPU readback. It is not backbone-only.','Mixed CPU wait included in finish_prefill cannot be added to GPU spans. codec_submit is nested scope and excluded from compute unions.','Cross-stream intervals correctly share the TimelineProfiler origin; pipeline main-stream end follows its captured auxiliary join, covering both steps.','CPU submission-window selection is not exact GPU phase clipping. Event union is stage occupancy, not kernel busy time.','Raw PCM cannot verify EOS reason; 396 executed excess rows remain conditional on normal EOS/max-frame completion.','The 1393.788 ms same-active/steps overlap association is not a counterfactual saving; context and resource history are uncontrolled.'])
(root/'current-timeline-independent-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(passed=result['passed'],checks=len(checks),counts=counts,intake_time_weighted_active=weighted),indent=2))
