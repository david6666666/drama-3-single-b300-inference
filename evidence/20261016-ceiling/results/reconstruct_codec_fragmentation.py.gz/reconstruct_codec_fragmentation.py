"""CPU reconstruction of recorded dynamic codec ready-group boundaries."""
import bisect
from collections import Counter,defaultdict
import hashlib
import json
import math
from pathlib import Path

source=Path('/home/zjy/code/hsliu/artifacts/drama3-mixed-20261016/codec-dynamic/dedicated.json')
a=json.loads(source.read_text())
active={};groups=[];emits=[]
buckets=[6,8,10,12,16,24,32,64];ramp=[6,8,12,16,24,32]
def emit(keys,origin,trace_index):
    by=defaultdict(list)
    for key in keys:
        q=active[key];length=q['count']-q['emitted']
        if length>0:
            by[buckets[bisect.bisect_left(buckets,length)]].append((key,length))
    if by:
        emits.append(dict(trace_index=trace_index,origin=origin,frame_buckets=list(by)))
    for bucket,jobs in by.items():
        groups.append(dict(trace_index=trace_index,origin=origin,bucket=bucket,
                           ready_count=len(jobs),min_calls=math.ceil(len(jobs)/min(16,512//bucket)),jobs=jobs))
        for key,_ in jobs:
            q=active[key];q['emitted']=q['count'];q['chunk']+=1
            q['next']=q['count']+(ramp[q['chunk']] if q['chunk']<len(ramp) else 64)
for index,e in enumerate(a['trace']):
    if 'admit' in e:
        for key in e['admit']:
            assert key not in active
            active[key]=dict(count=0,emitted=0,chunk=0,next=6)
    elif 'operation' in e:
        for key,meta in zip(e['roster'],e['metadata'],strict=True):
            active[key]['count']=meta[0]
        emit([key for key in e['roster'] if active[key]['count']>=active[key]['next']],e['operation'],index)
    elif 'retire' in e:
        emit(e['retire'],'retire',index)
        for key in e['retire']:
            del active[key]
assert not active
minimum=sum(g['min_calls'] for g in groups)
actual={m['mode']:m['codec_calls'] for m in a['modes']}
assert len(set(actual.values()))==1
n=next(iter(actual.values()))
result=dict(diagnostic_only=True,source=str(source),source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
            replay_source_sha=a['source_sha'],trace_entries=len(a['trace']),requests=len(a['modes'][0]['request_frames']),
            nonempty_emit_calls=len(emits),frame_bucket_groups=len(groups),minimum_legal_graph_launches=minimum,
            actual_codec_calls_by_mode=actual,avoidable_DP_launches=n-minimum,
            maximum_launch_count_reduction_fraction=(n-minimum)/n,
            group_histogram=[dict(frame_bucket=b,ready_count=c,groups=n) for (b,c),n in sorted(Counter((g['bucket'],g['ready_count']) for g in groups).items())],
            groups=groups,
            limitations=['This is the historical scripted 80-request dynamic safety replay, not the new 1088-request service trace.',
                         'Per-group actual split choices and the complete startup cost table were not archived; only aggregate99 calls and distinct actual codec shapes are available.',
                         'Reconstructs emitter thresholds exactly from recorded frame counts/retire sequence, ramp6/8/12/16/24/32 then64, with max_batch16 and max_padded_frames512.',
                         'Four avoidable launches are a launch-count bound, not a wall-time gain; larger padded batches may cost more or contend differently.',
                         'No codec precision, audio quality, GPU state or timing was evaluated by this CPU reconstruction.'])
out=Path(__file__).with_name('archived-codec-fragmentation.json')
out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['groups','group_histogram']},indent=2))
