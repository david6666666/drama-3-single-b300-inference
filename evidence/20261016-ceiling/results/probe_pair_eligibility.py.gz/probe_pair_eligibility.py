"""CPU observed chunk-boundary upper bound, not a counterfactual service replay."""
import bisect
from collections import defaultdict
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
path = ROOT / "rich-timeline.json"
ledger_path = ROOT / "rich-timeline-service-ledger.json"
rows = json.loads(path.read_text())["records"]
ledger = json.loads(ledger_path.read_text())
manifest = json.loads((ROOT / "rich-timeline-gpu0/benchmark/manifest.json").read_text())
lo, hi = ledger["time"]["first_dispatch_s"], ledger["time"]["last_completion_s"]
models = sorted((r for r in rows if r["stage"] in
                 ("decode", "mixed_decode_tower", "first_frame", "prefill")),
                key=lambda r: r["cpu_start_s"])
model_times = [r["cpu_start_s"] for r in models]
submits = sorted((r for r in rows if r["stage"] == "codec_submit"),
                 key=lambda r: r["cpu_start_s"])
submit_times = [r["cpu_start_s"] for r in submits]
by_request = defaultdict(list)
for r in rows:
    if r["stage"] != "codec_gpu_and_copy":
        continue
    submit = submits[bisect.bisect_right(submit_times, r["cpu_start_s"]) - 1]
    assert (submit["cpu_start_s"] <= r["cpu_start_s"] <=
            submit["cpu_start_s"] + submit["cpu_submit_ms"] / 1000 + .000001)
    index = bisect.bisect_right(model_times, submit["cpu_start_s"]) - 1
    for request, left, length in zip(r["request_ids"], r["left_frames"],
                                      r["valid_frames"], strict=True):
        by_request[request].append((r["emit_id"], left, length, index))
blocked, max_blocked = set(), set()
full_rows = partial_rows = 0
for request, chunks in by_request.items():
    chunks.sort()
    previous_end = 0
    for chunk_index, (_, left, length, index) in enumerate(chunks):
        expected = (6, 8, 12, 16, 24, 32)[chunk_index] if chunk_index < 6 else 64
        assert left == previous_end and 0 < length <= expected
        previous_end = left + length
        if lo <= models[index]["cpu_start_s"] <= hi:
            if length == expected:
                full_rows += 1
                blocked.add(index)
            else:
                partial_rows += 1
            if previous_end == manifest["max_frames"]:
                max_blocked.add(index)
results = []
for scope in ("all", ">=16", "64"):
    indices = [i for i, r in enumerate(models)
               if r["stage"] == "decode" and lo <= r["cpu_start_s"] <= hi
               and (scope == "all" or
                    (scope == ">=16" and r.get("padded_batch", 0) >= 16) or
                    (scope == "64" and r.get("padded_batch") == 64))]
    blocked_calls = sum(i in blocked for i in indices)
    union_calls = sum(i in blocked or i in max_blocked for i in indices)
    results.append(dict(capacity=scope, ordinary_decode_calls=len(indices),
                        scheduled_audio_blocked=blocked_calls,
                        audio_or_max_frames_blocked=union_calls,
                        not_proven_blocked=len(indices)-union_calls,
                        fraction_upper_bound=1-union_calls/len(indices)))
report = dict(
    diagnostic_only=True,
    source_sha="ab6da532083854670348583d9ec9f2a16d184dfb",
    timeline_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
    ledger_sha256=hashlib.sha256(ledger_path.read_bytes()).hexdigest(),
    driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    benchmark_window=[lo, hi], matching_failures=0, chunk_ramp_failures=0,
    observed_full_scheduled_chunks=full_rows, observed_partial_final_chunks=partial_rows,
    results=results,
    interpretation="This maps actual full audio chunks to the immediately preceding model call. "
                   "For ordinary steps=1 calls a scheduled full chunk proves the current "
                   "one-frame horizon would block a pair. The remainder is ONLY an upper "
                   "bound: pending/waiting, cancellation and the full active roster were not "
                   "logged. Pairing changes future scheduling; this is not actual pair coverage. "
                   "Requests have correlated chunk phases, invalidating independent-row estimates."
)
(ROOT / "pair-eligibility-ledger.json").write_text(json.dumps(report, indent=2)+"\n")
print(json.dumps(report, indent=2))
