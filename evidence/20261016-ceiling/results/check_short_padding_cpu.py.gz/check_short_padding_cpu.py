import json
from types import SimpleNamespace
import torch
import drama3.runtime_state as state

class Kernel:
    def __init__(self): self.calls=[]
    def __getitem__(self, grid):
        def launch(*args, **kw): self.calls.append((grid, kw))
        return launch

kernel=Kernel(); state._load=kernel
requests=object.__new__(state.DeviceRequests)
requests.last=requests.history=None
requests.metadata=SimpleNamespace(shape=(192,4))
requests.max_length=2048
for enabled in [False,True]:
    requests.short_padding_context=enabled
    for boundary in [None,96,192]:
        requests.load([1,2],None,None,None,padding_start=boundary)
        assert kernel.calls[-1][1]['PADDING_START']==(boundary if enabled and boundary is not None else -1)
    for boundary in [0,-1,193]:
        try: requests.load([1],None,None,None,padding_start=boundary)
        except ValueError: pass
        else: raise AssertionError(boundary)
assert not torch.cuda.is_initialized()
print(json.dumps(dict(passed=True, cases=12, cuda_initialized=False, scope='Optional boundary requires explicit caller ownership; missing boundary and flag off retain old constant, invalid boundaries rejected. GPU kernel semantics tested separately.')))
