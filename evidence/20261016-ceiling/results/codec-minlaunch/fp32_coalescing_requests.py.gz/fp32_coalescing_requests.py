"""Independent FP32 reference for the twelve actually changed coalescing requests."""
import hashlib
import json
import subprocess
from pathlib import Path

import numpy as np
import torch
from torch.nn.attention import SDPBackend, sdpa_kernel

from drama3.codec import bake_weight_norm, load_codec
from fp32_reference import CHECKPOINT, FISH, metrics
SOURCE=Path("/home/zjy/code/hsliu/drama3-codec-coalescing-frozen-20261016")

ROOT=Path(__file__).resolve().parent


@torch.inference_mode()
def main():
    replay=json.loads((ROOT/'prefix-replay.json').read_text())
    assert replay['passed'] and replay['replay_matches_original']
    archived=json.loads((ROOT/'coalescing-result.json').read_text())
    assert archived['control_matches_original'] and archived['structural_and_numeric_pass']
    keys=archived['modes'][1]['pcm_mismatches']
    assert keys==['8','9','10','11','12','13','14','15','22','39','49','73']
    prefixes={key:torch.load(ROOT/'prefix-replay-arrays/codes'/f'request-{key}.pt',map_location='cpu',weights_only=True) for key in keys}
    pcm={key:{policy:np.fromfile(ROOT/'coalescing-arrays'/policy/f'pcm-{key}.bin',dtype='<i2') for policy in ('control','coalesced')} for key in keys}
    for key in keys:
        assert prefixes[key].shape[0]==10
        assert all(len(value)==prefixes[key].shape[1]*2048 for value in pcm[key].values())
    assert not torch.cuda.is_initialized()
    before=subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid,pid,process_name,used_gpu_memory','--format=csv,noheader'],text=True)
    assert 'GPU-40e00845-d89c-1393-2c32-a2dca3ee9442' not in before
    output=ROOT/'fp32-coalescing-requests.json'
    report=dict(status='RUNNING',source_sha='a5d8610071fe82bbaa40d5e5ee11f216d0e437dd',source=str(SOURCE),saved_model_trace_source_sha='8ccefd063a90991cc45b31caa6457fae256720d0',coalescing_trace_matches_saved_prefix_control=True,prefix_replay='prefix-replay.json',prefix_replay_matches_original=True,script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),hypothesis='Control and adjacent-frame coalescing BF16 outputs have bounded error relative to native FP32 full-prefix eager decoding for all twelve actual PCM mismatches.',controls='Immutable coalescing/control PCM, full codes recovered by an exact 414-step/80-output DP replay, original FP32 checkpoint, each request decoded in batch1. TF32/autocast off, SDPA math, indices cloned before native in-place clamp.',gate='Diagnostic bound: equal lengths, finite values and full-output RRMS<0.03 for both partitions on every request. Not an exactness or WER/SIM promotion gate.',stop='Retain any mismatch or bound failure; coalescing and original minlaunch exact FAIL unchanged.',gpu=7,before_gpu=before,requests=[])
    output.write_text(json.dumps(report,indent=2)+'\n')
    try:
        torch.backends.cuda.matmul.allow_tf32=False
        torch.backends.cudnn.allow_tf32=False
        torch.set_float32_matmul_precision('highest')
        codec=load_codec(CHECKPOINT,FISH).float();bake_weight_norm(codec)
        for key in keys:
            with torch.autocast('cuda',enabled=False),sdpa_kernel(SDPBackend.MATH):
                full=codec.from_indices(prefixes[key].clone()[None].cuda()).float().cpu().numpy()[0,0]
            assert full.shape==(prefixes[key].shape[1]*2048,)
            np.save(ROOT/f'fp32-coalescing-request{key}.npy',full)
            reference=np.clip(full,-1,1)
            different=np.flatnonzero(pcm[key]['control']!=pcm[key]['coalesced'])
            first_frame=int(different[0]//2048)
            row=dict(request_id=key,frames=prefixes[key].shape[1],first_different_sample=int(different[0]),last_different_sample=int(different[-1]),first_changed_frame=first_frame,policies={})
            for policy in ('control','coalesced'):
                a=pcm[key][policy]/32767
                row['policies'][policy]=dict(full_vs_fp32=metrics(a,reference),changed_suffix_vs_fp32=metrics(a[first_frame*2048:],reference[first_frame*2048:]))
            report['requests'].append(row);output.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n');print(json.dumps(row),flush=True)
        report['diagnostic_bound_pass']=all(r['policies'][policy]['full_vs_fp32']['rrms']<.03 for r in report['requests'] for policy in ('control','coalesced'))
        report['status']='DIAGNOSTIC_PASS' if report['diagnostic_bound_pass'] else 'DIAGNOSTIC_FAIL'
        report['original_exact_gate']='FAIL remains unchanged.'
        output.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    except Exception as error:
        report['status']='FAIL';report['failure']=dict(type=type(error).__name__,message=str(error));output.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n');raise


if __name__=='__main__':main()
