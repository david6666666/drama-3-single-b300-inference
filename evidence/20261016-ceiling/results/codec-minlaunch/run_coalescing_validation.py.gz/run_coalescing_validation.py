import datetime,hashlib,json,os,subprocess,threading
from pathlib import Path
root=Path(__file__).resolve().parent
source=Path('/home/zjy/code/hsliu/drama3-codec-coalescing-frozen-20261016')
assert subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()=='a5d8610071fe82bbaa40d5e5ee11f216d0e437dd'
assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain'],text=True).strip()
script=root/'coalescing_driver.py'
python='/home/zjy/code/hsliu/venvs/codex-drama3-standalone/bin/python'
flags=dict(DRAMA3_PREFILL_MOE='flashinfer',DRAMA3_PACKED_MOE_PROJECTION='1',DRAMA3_GDN_STATE_DTYPE='bfloat16',DRAMA3_FUSED_MOE_INPUT='1',DRAMA3_PREFILL_CONV='triton',DRAMA3_PREFILL_MOE_TUNED='0',DRAMA3_CODEC_DEDICATED_CAPTURE_STREAM='1',DRAMA3_CODEC_SPLIT_POLICY='dp',DRAMA3_FUSED_MIXED_LAYOUT='0',DRAMA3_PACKED_CONV_GUARD='0',DRAMA3_DEFER_CODEC_SUBMIT='0',DRAMA3_SHORT_PADDING_CONTEXT='0',DRAMA3_COMPACT_GDN='0',DRAMA3_CODEC_COALESCE='0')
env={k:v for k,v in os.environ.items() if not k.startswith('DRAMA3_')};env.update(flags,CUDA_VISIBLE_DEVICES='7',OMP_NUM_THREADS='4',PYTHONPATH=f'{source}/src:{source}/scripts:/home/zjy/code/hsliu/drama3-sources/fish-speech',TORCH_EXTENSIONS_DIR='/home/zjy/code/hsliu/cache/drama3-torch-extensions',TORCH_CUDA_ARCH_LIST='10.3')
query=['nvidia-smi','--query-compute-apps=gpu_uuid,pid,process_name,used_gpu_memory','--format=csv,noheader']
before=subprocess.check_output(query,text=True);assert 'GPU-40e00845-d89c-1393-2c32-a2dca3ee9442' not in before
cmd=[python,str(script),'--checkpoint','/home/zjy/.cache/huggingface/hub/models--fishaudio--drama-3/snapshots/e0a9218aa48888270f06ef1ed9ea67622c0e17d2','--fish-source','/home/zjy/code/hsliu/drama3-sources/fish-speech','--corpus','/home/zjy/code/hsliu/artifacts/drama3-b300-20261014/seedtts-en1088-codes/requests.jsonl','--output',str(root/'coalescing-result.json'),'--capture','dedicated']
plan=dict(source_sha='a5d8610071fe82bbaa40d5e5ee11f216d0e437dd',runtime_source=str(source),script_sha256=hashlib.sha256(script.read_bytes()).hexdigest(),flags=flags,command=cmd,gpu=7,before_gpu=before,hypothesis='Same-emit adjacent-frame coalescing preserves exact native model codes, callback boundaries and real state ownership with bounded separately measured codec arithmetic drift.',gate='Control all414 trace and all80 PCM hashes match archived DP. Candidate exact model state/trace, emit schedule, per-chunk callback lengths/EOS and all nonparticipating real codec states; participating-state/PCM RRMS under0.03 are a separate diagnostic gate, not exactness or quality promotion.',stop='Stop on structural ownership/model divergence or nonfinite/>=3% numeric error. Preserve strict exact failures. No service/timing claim; original minlaunch artifacts unchanged.')
plan['artifact_hashes']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (script,root/'coalescing_observer.py',root/'result.json',root/'numeric-result.json')}
plan['storage']={p:subprocess.check_output(['findmnt','-T',p,'-o','TARGET,SOURCE,FSTYPE','--noheadings'],text=True).strip() for p in (python,cmd[3],'/home/zjy/.cache/huggingface/hub','/home/zjy/code/hsliu/cache/drama3-torch-extensions')}
plan['cpu_affinity']=sorted(os.sched_getaffinity(0))
plan['scope']='One serial fixed-input diagnostic; CPU state snapshots deliberately synchronize. Actual codec calls can change, no latency/throughput claim.'
(root/'coalescing-experiment.json').write_text(json.dumps(plan,indent=2)+'\n')
stop=threading.Event()
def audit():
 with (root/'coalescing-process-audit.jsonl').open('w') as f:
  while not stop.is_set():
   r=subprocess.run(query,text=True,capture_output=True);f.write(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),processes=r.stdout.splitlines()))+'\n');f.flush();stop.wait(1)
t=threading.Thread(target=audit);t.start()
try:
 with (root/'coalescing.log').open('w') as f:subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
finally:stop.set();t.join()
