"""Serial diagnostic: per-emit ownership exactness and separate floating drift."""
from pathlib import Path

import torch

from drama3.engine import Engine as NativeEngine


class Engine(NativeEngine):
    def reset_observation(self, enabled):
        self.coalesce_codec=enabled
        self.emit_observations=[]
        self.emit_reference=getattr(self,'emit_reference',[])
        self.observed_emit_index=0
        self.max_state_rrms=0.0
        self.state_ownership_exact=True
        self.first_state_difference_saved=False

    def emit_audio_batch(self, requests):
        jobs=[(r.key,r.slot,r.emitted,r.frame_count) for r in requests if r.frame_count>r.emitted]
        if not jobs:
            return super().emit_audio_batch(requests)
        assert len({j[1] for j in jobs})==len(jobs), 'Same emit contains reused physical slot'
        stream=self.codec_graphs.stream
        touched=sorted(j[1] for j in jobs)
        assert all(0<=slot<stream.num_slots for slot in touched)
        ids=torch.tensor(touched,device='cuda',dtype=torch.long)
        unused=torch.tensor([s for s in range(stream.num_slots) if s not in touched],device='cuda',dtype=torch.long)
        states=[('conv/'+str(k),v,0) for k,v in stream.tensors.items()]
        states += [('kv/'+str(k),v,1 if v.ndim==5 and v.shape[0]==2 else 0) for k,v in stream.kv_tensors.items()]
        before=[value.clone() for _,value,_ in states]
        super().emit_audio_batch(requests)
        assert self.audio_queue is None, 'Per-emit observer is a serial correctness diagnostic'
        for (name,value,axis),saved in zip(states,before,strict=True):
            exact=torch.equal(value.index_select(axis,unused),saved.index_select(axis,unused))
            self.state_ownership_exact &= exact
            assert exact, f'Codec modified nonparticipating real slot: emit{self.observed_emit_index} {name}'
        record=dict(emit=self.observed_emit_index,jobs=jobs,touched_slots=touched,ownership_exact=True,state_differences=[])
        if not self.coalesce_codec:
            self.emit_reference.append((jobs,[value.index_select(axis,ids).cpu() for _,value,axis in states]))
        else:
            expected_jobs,reference=self.emit_reference[self.observed_emit_index]
            assert jobs==expected_jobs, 'Coalescing changed emit schedule, slot generation, left or valid count'
            for (name,value,axis),expected in zip(states,reference,strict=True):
                actual=value.index_select(axis,ids)
                expected=expected.to(actual.device)
                if torch.equal(actual,expected):continue
                a=actual.movedim(axis,0).reshape(len(touched),-1).float()
                b=expected.movedim(axis,0).reshape(len(touched),-1).float()
                assert torch.isfinite(a).all() and torch.isfinite(b).all()
                rrms=((a-b).square().mean(-1)/b.square().mean(-1).clamp_min(1e-12)).sqrt()
                worst=float(rrms.max())
                self.max_state_rrms=max(self.max_state_rrms,worst)
                record['state_differences'].append(dict(name=name,max_abs=float((a-b).abs().max()),slot_rrms=rrms.cpu().tolist(),max_slot_rrms=worst))
                if not self.first_state_difference_saved:
                    torch.save(dict(emit=self.observed_emit_index,jobs=jobs,name=name,slots=touched,actual=actual.cpu(),reference=expected.cpu()),Path(__file__).parent/'coalescing-first-state-difference.pt')
                    self.first_state_difference_saved=True
        self.emit_observations.append(record)
        self.observed_emit_index+=1
