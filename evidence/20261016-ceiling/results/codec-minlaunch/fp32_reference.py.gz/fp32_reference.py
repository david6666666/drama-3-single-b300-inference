"""Independent native FP32 full-prefix codec reference; keeps exact FAIL intact."""
import hashlib
import json
import os
import subprocess
from pathlib import Path

import numpy as np
import torch
from torch.nn.attention import SDPBackend, sdpa_kernel

from drama3.codec import bake_weight_norm, load_codec

ROOT = Path(__file__).resolve().parent
SOURCE = Path('/home/zjy/code/hsliu/drama3-short-padding-frozen-20261016')
CHECKPOINT = Path('/home/zjy/.cache/huggingface/hub/models--fishaudio--drama-3/snapshots/e0a9218aa48888270f06ef1ed9ea67622c0e17d2')
FISH = Path('/home/zjy/code/hsliu/drama3-sources/fish-speech')


def metrics(actual, expected):
    a, b = np.asarray(actual, dtype=np.float64), np.asarray(expected, dtype=np.float64)
    assert a.shape == b.shape and np.isfinite(a).all() and np.isfinite(b).all()
    error = a-b
    rms = float(np.sqrt(np.mean(error**2)))
    signal = float(np.sqrt(np.mean(b**2)))
    return dict(samples=a.size, rms=rms, reference_rms=signal,
                rrms=rms/signal if signal else None,
                snr_db=20*np.log10(signal/rms) if rms and signal else None,
                max_abs=float(np.max(np.abs(error))), different_samples=int(np.count_nonzero(error)))


@torch.inference_mode()
def main():
    output = ROOT/'fp32-reference.json'
    files = [ROOT/'numeric-arrays'/p for p in ('dp/changed-group-call0.pt', 'dp/changed-group-call1.pt', 'min_launches/changed-group-call0.pt')]
    saved = [torch.load(p, map_location='cpu', weights_only=True, mmap=True) for p in files]
    dp, candidate = saved[:2], saved[2]
    for key in ('codes', 'rows'):
        assert torch.equal(torch.cat([x[key] for x in dp], dim=0 if key=='codes' else 1), candidate[key])
    assert all(torch.equal(a,b) for a,b in zip([v for x in dp for v in x['full_codes']], candidate['full_codes'], strict=True))
    for i, (slot, fresh, valid, position) in enumerate(candidate['rows'].T.tolist()):
        assert fresh == 0 and position == 42 and valid == 15
        assert candidate['full_codes'][i].shape == (10, position+valid)
        assert torch.equal(candidate['codes'][i,:,:valid], candidate['full_codes'][i][:,position:])
        original = [np.fromfile(ROOT/'numeric-arrays'/policy/f'pcm-{slot}.bin', dtype='<i2') for policy in ('dp', 'min_launches')]
        assert all(len(x)==(position+valid)*2048 for x in original)
        assert np.array_equal(original[0][:position*2048],original[1][:position*2048])
    assert not torch.cuda.is_initialized()
    before = subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid,pid,process_name,used_gpu_memory','--format=csv,noheader'],text=True)
    assert 'GPU-40e00845-d89c-1393-2c32-a2dca3ee9442' not in before
    report=dict(status='RUNNING', source_sha='a607dff26c3ca5423746f7eebec4f5f5a88cd4c0', saved_trace_source_sha='8ccefd063a90991cc45b31caa6457fae256720d0', source=str(SOURCE), fish_sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=FISH,text=True).strip(), script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), native_loader_sha256=hashlib.sha256((SOURCE/'src/drama3/codec.py').read_bytes()).hexdigest(), hypothesis='Both native BF16 batch partitions should have bounded rounding error against an independent FP32 native full-prefix decoder; this does not erase their original exact comparison failure.', controls='Same saved full code prefixes, original native checkpoint and causal decoder; batch1 full-prefix eager, FP32 weights/activations, autocast/TF32 off and SDPA math. Clone indices because native quantizer clamps in place.', gate='Diagnostic bound only: finite equal-length outputs and both policies tail PCM-vs-FP32 RRMS<0.03; no exact or service-quality promotion. Preserve all five requests.', stop='Any bad code/PCM mapping, missing sample, nonfinite output, or diagnostic bound failure stays explicit.', gpu=7, gpu_uuid='GPU-40e00845-d89c-1393-2c32-a2dca3ee9442', before_gpu=before, storage={str(x):subprocess.check_output(['findmnt','-T',str(x),'-no','SOURCE,FSTYPE,TARGET'],text=True).strip() for x in [CHECKPOINT,Path('/home/zjy/code/hsliu/venvs/codex-drama3-standalone/bin/python')]}, requests=[])
    output.write_text(json.dumps(report,indent=2)+'\n')
    try:
        torch.backends.cuda.matmul.allow_tf32=False
        torch.backends.cudnn.allow_tf32=False
        torch.set_float32_matmul_precision('highest')
        codec=load_codec(CHECKPOINT,FISH).float()
        bake_weight_norm(codec)
        for i,(slot,fresh,valid,position) in enumerate(candidate['rows'].T.tolist()):
            codes=candidate['full_codes'][i].clone().unsqueeze(0).cuda()
            with torch.autocast('cuda',enabled=False),sdpa_kernel(SDPBackend.MATH):
                waveform=codec.from_indices(codes).float().cpu().numpy()[0,0]
            assert waveform.shape == ((position+valid)*2048,)
            np.save(ROOT/f'fp32-reference-request{slot}.npy',waveform)
            reference=np.clip(waveform,-1,1)
            reference_pcm=(reference*32767).astype('<i2')
            row=dict(request_id=str(slot),position=position,valid_frames=valid,full_frames=position+valid,reference_dtype=str(waveform.dtype),policies={})
            for policy in ('dp','min_launches'):
                actual=np.fromfile(ROOT/'numeric-arrays'/policy/f'pcm-{slot}.bin',dtype='<i2')
                row['policies'][policy]=dict(full_vs_fp32=metrics(actual/32767,reference),tail_vs_fp32=metrics(actual[position*2048:]/32767,reference[position*2048:]),tail_vs_fp32_pcm=metrics(actual[position*2048:],reference_pcm[position*2048:]))
            report['requests'].append(row)
            output.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
            print(json.dumps(row),flush=True)
        report['diagnostic_bound_pass']=all(row['policies'][policy]['tail_vs_fp32']['rrms']<.03 for row in report['requests'] for policy in ('dp','min_launches'))
        report['status']='DIAGNOSTIC_PASS' if report['diagnostic_bound_pass'] else 'DIAGNOSTIC_FAIL'
        report['original_exact_gate']='FAIL remains unchanged; this reference is a separate numeric follow-up.'
        output.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    except Exception as error:
        report['status']='FAIL';report['failure']=dict(type=type(error).__name__,message=str(error));output.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n');raise


if __name__=='__main__':main()
