"""CPU batch-readiness sensitivity; no runtime cache or speed claim."""
import collections,hashlib,json,runpy
from pathlib import Path
ns=runpy.run_path('/home/zjy/code/hsliu/artifacts/drama3-ceiling-20261016/prefix_reuse_probe.py')
prompts=ns['prompts']; root=ns['root']
keys=[[(n,hashlib.sha256(p[:n+1].numpy().tobytes()).hexdigest()) for n in range(64,len(p)-1,64)] for p in prompts]
previous={};distances=[]
for i,ks in enumerate(keys):
 best=max((n for n,k in ks if (n,k) in previous),default=0)
 if best: distances.append(i-previous[next(key for key in ks if key[0]==best)])
 for key in ks:previous[key]=i
cases=[]
for group in (1,2,4,6,8,16,64):
 cache=collections.OrderedDict();hits=[];intrabatch=0
 for start in range(0,len(keys),group):
  groupkeys=keys[start:start+group]
  for ks in groupkeys:
   hits.append(max((n for n,k in ks if (n,k) in cache),default=0))
  for ks in groupkeys:
   for key in ks:
    cache[key]=None;cache.move_to_end(key)
    while len(cache)>16:cache.popitem(last=False)
 cases.append(dict(group_size=group,hit_requests=sum(n>0 for n in hits),reused_rows=sum(hits),fraction_prompt_rows=sum(hits)/sum(map(len,prompts))))
x=dict(source_sha=ns['result']['source_sha'],corpus_sha256=ns['result']['corpus_sha256'],match_request_index_distance=dict(collections.Counter(distances)),cache_entries=16,cases=cases,limitations=['Batch grouping is synthetic, not measured admission membership. Prefix states enter cache only after each batch.','This intentionally exposes overestimation from treating adjacent concurrently-prefilled requests as causal ready hits.','Within-batch shared-prefix prefill would require separate computation and may cost more weight traffic than it saves.'])
(root/'prefix-readiness-probe.json').write_text(json.dumps(x,indent=2)+'\n');print(json.dumps(x,indent=2))
