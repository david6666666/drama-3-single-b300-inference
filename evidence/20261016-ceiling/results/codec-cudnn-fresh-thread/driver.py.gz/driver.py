"""Bounded exact codec weight-cast hoisting feasibility, immutable parameters."""
import copy,hashlib,json,os,statistics,subprocess,time,threading,traceback
from pathlib import Path
import torch
from torch.profiler import profile,ProfilerActivity
from drama3.codec import load_codec,bake_weight_norm
from drama3.ops.dac_channels_last import ChannelsLastDACDecoder,DACDecodeGraphs,DACStreamState
R=Path(__file__).resolve().parent
C=Path('/home/zjy/code/hsliu/artifacts/drama3-b300-20261014/seedtts-en1088-codes/requests.jsonl')
CHECK=Path('/home/zjy/.cache/huggingface/hub/models--fishaudio--drama-3/snapshots/e0a9218aa48888270f06ef1ed9ea67622c0e17d2')
FISH=Path('/home/zjy/code/hsliu/drama3-sources/fish-speech')
@torch.inference_mode()
def main():
 result=json.loads((R/'protocol.json').read_text());result.update(status='INITIALIZING',checks=[],cases=[])
 def save():(R/'result.json').write_text(json.dumps(result,indent=2)+'\n')
 save();t=time.perf_counter();codec=load_codec(CHECK,FISH);bake_weight_norm(codec)
 params=[(n,p) for n,p in codec.named_parameters()]
 def parameter_meta():
  return [(n,str(p.dtype),p.data_ptr(),hashlib.sha256(p.detach().cpu().contiguous().view(torch.uint8).numpy().tobytes()).hexdigest()) for n,p in params]
 original_meta=parameter_meta()
 graphs={};state={};prep={}
 @torch.inference_mode()
 def build_arm(arm,tune):
  result.setdefault("capture_thread",{})[arm]=dict(python_id=threading.get_ident(),native_id=threading.get_native_id())
  torch.backends.cudnn.benchmark=tune
  freeze=True
  start=time.perf_counter();decoder=ChannelsLastDACDecoder(codec,dtype=torch.bfloat16)
  if freeze:
   original=decoder.transformer
   decoder.transformer=copy.deepcopy(original)
   cached=[]
   originals=dict(original.named_modules())
   for name,module in decoder.transformer.named_modules():
    if isinstance(module,torch.nn.Linear):
     module.to(dtype=torch.bfloat16)
     assert torch.equal(module.weight,originals[name].weight.to(torch.bfloat16))
     assert module.bias is None or torch.equal(module.bias,originals[name].bias.to(torch.bfloat16))
     cached.append(dict(name=name,elements=module.weight.numel(),bias=module.bias is not None))
   assert len(cached)==40 and all(not x['bias'] for x in cached)
   result['cached_linears']=cached
  decoder.compile_transformer()
  cap=DACDecodeGraphs(decoder,num_codebooks=10,frame_buckets=(8,),max_padded_frames=512,max_batch=8,receptive_frames=0,stream=DACStreamState(64))
  with torch.autocast('cuda',dtype=torch.bfloat16):cap.capture(torch.device('cuda'),capture_stream=torch.cuda.Stream())
  graphs[arm]=cap;state[arm]=dict(conv=cap.stream.tensors,kv=cap.stream.kv_tensors)
  torch.cuda.synchronize();prep[arm]=time.perf_counter()-start
 for arm,tune in [('control',False),('candidate',True)]:
  errors=[]
  def invoke(arm=arm,tune=tune):
   try:build_arm(arm,tune)
   except BaseException as exc:errors.append((exc,traceback.format_exc()))
  worker=threading.Thread(target=invoke,name=f'fresh-cudnn-{arm}')
  worker.start();worker.join()
  if errors:
   result.update(status='PREPARATION_ERROR',error=errors[0][1]);save();raise errors[0][0]
 torch.backends.cudnn.benchmark=False
 result['preparation_s']=prep;result['total_preparation_s']=time.perf_counter()-t;save()
 def flat(arm):return [*state[arm]['conv'].values(),*state[arm]['kv'].values()]
 def record(name,passed,**details):
  result['checks'].append(dict(name=name,passed=bool(passed),**details));save()
  if not passed:result['status']='EXACT_FAIL';save();raise AssertionError(name)
 record('parameter_identity_dtype_sha256_unchanged',original_meta==parameter_meta())
 for k in ['conv','kv']:record(f'{k}_state_key_order',list(state['control'][k])==list(state['candidate'][k]))
 corpus=[json.loads(x) for x in C.read_bytes().splitlines()]
 tensors=[torch.tensor(x['reference_codes'],device='cuda',dtype=torch.int64) for x in corpus[:8]]
 snapshots={}
 for b in (1,4,8):
  for arm in graphs:
   for x in flat(arm):x.zero_()
  codes=torch.stack([x[:,:24] for x in tensors[:b]])
  for pos in (0,8,16):
   rows=torch.tensor([list(range(b)),[int(pos==0)]*b,[8]*b,[pos]*b],device='cuda')
   if pos==16:snapshots[b]={arm:[x.clone() for x in flat(arm)] for arm in graphs}
   outputs={}
   for arm,cap in graphs.items():
    with torch.autocast('cuda',dtype=torch.bfloat16):outputs[arm]=cap(codes[:,:,pos:pos+8],rows=rows)
   torch.cuda.synchronize()
   record(f'b{b}_p{pos}_audio',torch.equal(outputs['control'],outputs['candidate']),max_abs=float((outputs['control']-outputs['candidate']).abs().max()))
   for i,(a,c) in enumerate(zip(flat('control'),flat('candidate'),strict=True)):
    record(f'b{b}_p{pos}_state{i}',torch.equal(a,c),finite=bool(torch.isfinite(c).all()))
   record(f'b{b}_p{pos}_finite_audio',torch.isfinite(outputs['candidate']).all())
 # All output/full-state exact gates must pass before timing any arm.
 result['status']='EXACT_PASS';save()
 for b in (1,4,8):
  row={'batch':b,'frames':8,'timing_ms':{arm:[] for arm in graphs}}
  for repeat in range(3):
   for arm in (['control','candidate'] if repeat%2==0 else ['candidate','control']):
    for d,s in zip(flat(arm),snapshots[b][arm],strict=True):d.copy_(s)
    graph=graphs[arm].graphs[(b,8,0)][0]
    # Timing repeats the same graph once from restored state; preparation excluded.
    start,end=torch.cuda.Event(enable_timing=True),torch.cuda.Event(enable_timing=True)
    start.record();graph.replay();end.record();end.synchronize();row['timing_ms'][arm].append(start.elapsed_time(end))
  row['relative_reduction']=1-statistics.median(row['timing_ms']['candidate'])/statistics.median(row['timing_ms']['control'])
  for arm in graphs:
   for d,s in zip(flat(arm),snapshots[b][arm],strict=True):d.copy_(s)
   torch.cuda.synchronize()
   with profile(activities=[ProfilerActivity.CPU,ProfilerActivity.CUDA]) as prof:
    graphs[arm].graphs[(b,8,0)][0].replay();torch.cuda.synchronize()
   prof.export_chrome_trace(str(R/f'{arm}-b{b}-trace.json'))
  result['cases'].append(row);save()
 result['status']='LOCAL_GAIN_PASS' if all(x['relative_reduction']>=.05 for x in result['cases'] if x['batch']in(4,8)) else 'LOCAL_GAIN_FAIL'
 torch.backends.cudnn.benchmark=False
 result['parameters_unchanged_after_replay']=original_meta==parameter_meta()
 save()
if __name__=='__main__':main()
