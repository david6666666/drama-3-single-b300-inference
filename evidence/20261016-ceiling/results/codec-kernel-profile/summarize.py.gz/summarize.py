import json,collections,hashlib
from pathlib import Path
r=Path(__file__).resolve().parent;result={}
for b in (1,4,8):
 ev=json.loads((r/f'b{b}-trace.json').read_text())['traceEvents'];kernels=[e for e in ev if e.get('cat')=='kernel']
 groups=collections.defaultdict(lambda:dict(us=0,count=0));names=collections.defaultdict(lambda:dict(us=0,count=0))
 for e in kernels:
  n=e['name'];category='other'
  if n=='_snake_kernel':category='snake'
  elif n.startswith('_history'):category='history'
  elif n in ('triton_poi_fused__to_copy_1','triton_poi_fused__to_copy_3'):category='parameter_cast'
  elif 'implicit_gemm' in n or 'convFwd' in n or 'conv1d_' in n:category='convolution'
  elif n.startswith('nvjet') or 'splitKreduce' in n:category='dense'
  elif n=='_write_attend':category='attention'
  groups[category]['us']+=e['dur'];groups[category]['count']+=1
  names[n]['us']+=e['dur'];names[n]['count']+=1
 total=sum(e['dur'] for e in kernels)
 for v in groups.values():v['fraction_of_kernel_sum']=v['us']/total
 result[str(b)]=dict(kernel_count=len(kernels),kernel_sum_us=total,groups=dict(groups),top_kernels=sorted([dict(name=k,**v) for k,v in names.items()],key=lambda x:-x['us'])[:15])
result['scope']='One native graph profile per batchF8, valid corpus reference codes, not simultaneous model interference or fullservice; kernel names classified manually. Castkernel40launches correspond32large+8outputprojection casts, five weights per8layers; no gain claim.'
(r/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v['groups'] for k,v in result.items() if isinstance(v,dict)},indent=2))
