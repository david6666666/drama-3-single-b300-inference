"""One fixed native codec graph profile; no algorithm/precision or service claim."""
import hashlib,json,os,subprocess,time
from pathlib import Path
import torch
from torch.profiler import profile,ProfilerActivity
from drama3.codec import load_codec,bake_weight_norm
from drama3.ops.dac_channels_last import ChannelsLastDACDecoder,DACDecodeGraphs,DACStreamState
R=Path(__file__).resolve().parent
C=Path('/home/zjy/code/hsliu/artifacts/drama3-b300-20261014/seedtts-en1088-codes/requests.jsonl')
CHECK=Path('/home/zjy/.cache/huggingface/hub/models--fishaudio--drama-3/snapshots/e0a9218aa48888270f06ef1ed9ea67622c0e17d2')
FISH=Path('/home/zjy/code/hsliu/drama3-sources/fish-speech')
SRC=Path('/home/zjy/code/hsliu/artifacts/drama3-ceiling-20261016/source-codec-sm-69d636e')
@torch.inference_mode()
def main():
 data=C.read_bytes(); samples=[json.loads(x) for x in data.splitlines()]
 codes_cpu=[torch.tensor(x['reference_codes'],dtype=torch.int64) for x in samples[:8]]
 assert all(x.shape[0]==10 and x.shape[1]>=24 for x in codes_cpu)
 sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=SRC,text=True).strip()
 result=dict(status='INITIALIZING',source_sha=sha,driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),corpus_sha256=hashlib.sha256(data).hexdigest(),input='First8 corpus reference code streams, windows0:8,8:16,16:24; valid native codes but not generated service output codes.',hypothesis='Locate native BF16 codec graph cost beyond scheduling/capping; no optimization hypothesis or service speed claim.',isolated_variable='Diagnostic batch size1/4/8 at F8; no candidate.',controls='Same fixed source, original codec checkpoint, native BF16 autocast and defaults, primary context/private capture stream; no cache flush or clock change.',success='All graph replay outputs/states finite and deterministic after fixed-state restoration; collect kernel costs once per representative batch.',stop='Any nonfinite or replay nondeterminism; no changes or threshold relaxation.',gpu_uuid=str(torch.cuda.get_device_properties(0).uuid),storage={str(p):subprocess.check_output(['findmnt','-T',str(p),'-o','SOURCE,FSTYPE,TARGET','-n'],text=True).strip() for p in [CHECK,R,Path(os.sys.executable)]},cases=[])
 def save(): (R/'result.json').write_text(json.dumps(result,indent=2)+'\n')
 save();t=time.perf_counter()
 codec=load_codec(CHECK,FISH);bake_weight_norm(codec)
 dec=ChannelsLastDACDecoder(codec,dtype=torch.bfloat16);dec.compile_transformer()
 graphs=DACDecodeGraphs(dec,num_codebooks=10,frame_buckets=(8,),max_padded_frames=512,max_batch=8,receptive_frames=0,stream=DACStreamState(64))
 with torch.autocast('cuda',dtype=torch.bfloat16):graphs.capture(torch.device('cuda'),capture_stream=torch.cuda.Stream())
 torch.cuda.synchronize();result['preparation_s']=time.perf_counter()-t;save()
 states=[*graphs.stream.tensors.values(),*graphs.stream.kv_tensors.values()]
 for b in (1,4,8):
  for x in states:x.zero_()
  codes=torch.stack([x[:,:24] for x in codes_cpu[:b]]).cuda()
  with torch.autocast('cuda',dtype=torch.bfloat16):
   for pos in (0,8):
    rows=torch.tensor([list(range(b)),[int(pos==0)]*b,[8]*b,[pos]*b],device='cuda')
    graphs(codes[:,:,pos:pos+8],rows=rows)
  graph,static,out=graphs.graphs[(b,8,0)]
  static.copy_(codes[:,:,16:24]);rowbuf,idle=graphs.stream_rows[(b,8,0)]
  rowbuf.copy_(torch.tensor([list(range(b)),[0]*b,[8]*b,[16]*b],device='cuda'))
  initial=[x.clone() for x in states];torch.cuda.synchronize()
  graph.replay();torch.cuda.synchronize();expected=out.clone();after=[x.clone() for x in states]
  def restore():
   for dst,src in zip(states,initial,strict=True):dst.copy_(src)
  restore();graph.replay();torch.cuda.synchronize()
  assert torch.equal(out,expected)
  assert all(torch.equal(x,y) for x,y in zip(states,after,strict=True))
  assert torch.isfinite(out).all() and all(torch.isfinite(x).all() for x in states)
  elapsed=[]
  for _ in range(3):
   restore();start,end=torch.cuda.Event(enable_timing=True),torch.cuda.Event(enable_timing=True)
   start.record();graph.replay();end.record();end.synchronize();elapsed.append(start.elapsed_time(end))
  restore();torch.cuda.synchronize()
  with profile(activities=[ProfilerActivity.CPU,ProfilerActivity.CUDA]) as prof:
   graph.replay();torch.cuda.synchronize()
  prof.export_chrome_trace(str(R/f'b{b}-trace.json'))
  (R/f'b{b}-table.txt').write_text(prof.key_averages().table(sort_by='self_cuda_time_total',row_limit=100))
  result['cases'].append(dict(batch=b,frames=8,graph_ms_samples=elapsed,exact_fixed_state_replay=True,finite=True,state_tensors=len(states),profile=f'b{b}-trace.json'))
  save()
 result['status']='PROFILE_COMPLETE';save()
if __name__=='__main__':main()
