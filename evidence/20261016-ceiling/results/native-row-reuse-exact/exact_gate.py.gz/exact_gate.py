"""Exact-only native MoE compact/expand gate on real captured mixed inputs."""
import hashlib
import json
import os
from pathlib import Path
import sys

import torch
import capture_inputs as capture
from check_mapping import build_mapping, COMPACT, FULL

OUT=Path(__file__).resolve().parent
ROOT=OUT.parent
sys.path[:0]=[str(capture.SOURCE/'src'),str(capture.SOURCE/'scripts')]


def byte_equal(a,b):
    return a.shape==b.shape and a.dtype==b.dtype and torch.equal(a.contiguous().view(torch.uint8),b.contiguous().view(torch.uint8))


def readonly_weights(layer):
    e=layer.experts
    return dict(packed_projection=layer.packed_input_projection,
        shared_down=layer.shared_expert.down_proj.weight,
        w13=e.flashinfer_w13,w13_scale=e.flashinfer_w13_scale,
        w2=e.flashinfer_w2,w2_scale=e.w2_scale_inv)


def cpu_check():
    assert not torch.cuda.is_initialized()
    assert byte_equal(torch.tensor([0.,1.],dtype=torch.bfloat16),torch.tensor([0.,1.],dtype=torch.bfloat16))
    assert not byte_equal(torch.tensor([0.],dtype=torch.bfloat16),torch.tensor([-0.],dtype=torch.bfloat16))
    return dict(status='CPU_IMPORT_PASS',cuda_initialized=False,byte_comparator_distinguishes_signed_zero=True)


@torch.inference_mode()
def main():
    report=dict(status='RUNNING',checks=[],layers=[],pid=os.getpid(),timing_allowed=False,
        source_sha=capture.SOURCE_SHA,driver_sha256=capture.sha(__file__),
        contract='Original model.moe_parts fulltop8; all original rows compared after compact/expand; no tolerance',
        routing_scope='Native canonical routing diagnostic runs on actual captured prepare outputs; it does not replace or intercept the opaque internal routing of original moe_parts.')
    def flush(): (OUT/'result.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    def check(name,a,b,stop=True):
        ok=byte_equal(a,b)
        row=dict(name=name,byte_exact=ok,shape=list(a.shape),dtype=str(a.dtype))
        if not ok:
            if a.shape==b.shape:
                delta=a.float()-b.float()
                row.update(changed_elements=int((a!=b).sum()),max_abs=float(delta.abs().max()),
                    rrms=float((delta.square().mean()/b.float().square().mean().clamp_min(1e-30)).sqrt()))
            path=OUT/(name.replace('/','_')+'-failure.pt')
            torch.save(dict(actual=a.cpu(),expected=b.cpu()),path)
            row['failure_tensors']=path.name
        report['checks'].append(row);flush()
        if not ok and stop: raise AssertionError(row)
        return ok
    flush()
    from drama3 import moe_input
    from flashinfer.fused_moe import core as fi
    from validate_mixed_layers import state_tensors
    original_prepare=moe_input.prepare_moe_input
    state_before=None
    states=None
    weight_before=None
    weights=None
    rng_before=None
    cpu_rng_before=None
    failed_buffers=None
    try:
        protocol=json.loads((OUT/'protocol.json').read_text())
        for path,expected in protocol['frozen_files'].items(): assert capture.sha(path)==expected,path
        model,device=capture.main()
        assert model.packed_moe_projection and model.moe_shared_stream is None
        captured_report=json.loads((OUT/'capture-result.json').read_text())
        assert captured_report['status']=='PASS'
        report['capture_cases']=[dict(case=c['case'],aliases=c['alias_count']) for c in captured_report['cases']]
        inputs=[]
        for case in captured_report['cases']:
            name=case['case']
            xs=torch.load(OUT/f'{name}-moe-inputs.pt',map_location='cpu',weights_only=True)
            md=torch.load(OUT/f'{name}-inputs.pt',map_location='cpu',weights_only=True)
            keep,inverse,unique=build_mapping(case)
            inputs.append(dict(case=name,xs=xs,slots=md['row_slots'].cuda(),keep=keep.cuda(),inverse=inverse.cuda(),unique=unique))
        states=state_tensors(model,device)
        state_before={name:x.clone() for name,x in states.items()}
        rng_before=torch.cuda.get_rng_state().clone()
        cpu_rng_before=torch.get_rng_state().clone()
        report['read_only_state_bytes']=sum(x.numel()*x.element_size() for x in state_before.values())
        report['gpu_uuid']=str(torch.cuda.get_device_properties(0).uuid)
        for layer_index,layer_obj in enumerate(model.backbone.layers):
            print(json.dumps(dict(stage='exact_layer',layer=layer_index)),flush=True)
            layer=layer_obj.mlp
            weights=readonly_weights(layer)
            weight_before={name:x.clone() for name,x in weights.items()}
            x_storage=torch.full((FULL+2,2048),-73.,dtype=torch.bfloat16,device='cuda')
            x=x_storage[1:-1]
            slots=torch.zeros(FULL,dtype=torch.int64,device='cuda')
            keep_storage=torch.full((COMPACT+2,),-1,dtype=torch.int64,device='cuda')
            inverse_storage=torch.full((FULL+2,),-1,dtype=torch.int64,device='cuda')
            keep,inverse=keep_storage[1:-1],inverse_storage[1:-1]
            compact_storage=torch.full((COMPACT+2,2048),-71.,dtype=torch.bfloat16,device='cuda')
            compact=compact_storage[1:-1]
            compact_slots=torch.empty(COMPACT,dtype=torch.int64,device='cuda')
            expanded_storages=[torch.full((FULL+2,width),-79.,dtype=torch.bfloat16,device='cuda') for width in (2048,2048,1)]
            expanded=tuple(t[1:-1] for t in expanded_storages)
            failed_buffers=[('source',x_storage,-73.),('compact',compact_storage,-71.),*[(f'expanded{i}',t,-79.) for i,t in enumerate(expanded_storages)],('keep',keep_storage,-1),('inverse',inverse_storage,-1)]
            native_prepared={}
            arm='control'
            def observe_prepare(*args,**kwargs):
                values=original_prepare(*args,**kwargs)
                native_prepared[arm]=values
                return values
            moe_input.prepare_moe_input=observe_prepare
            def control_call():
                return model.moe_parts(x,layer,decode=True,row_slots=slots)
            def candidate_call():
                torch.index_select(x,0,keep,out=compact)
                torch.index_select(slots,0,keep,out=compact_slots)
                parts=model.moe_parts(compact,layer,decode=True,row_slots=compact_slots)
                for value,out in zip(parts,expanded,strict=True):
                    torch.index_select(value,0,inverse,out=out)
                return expanded
            canonical={}
            def routing(which):
                q,scales,logits=native_prepared[which]
                if which not in canonical:
                    canonical[which]=fi.allocate_trtllm_moe_canonical_routing(logits,top_k=8,tile_n=8)
                destination=canonical[which]
                fi.canonicalize_trtllm_moe_routing_(destination,logits,None,q,top_k=8,n_group=None,topk_group=None,
                    local_expert_offset=0,local_num_experts=256,routed_scaling_factor=1.0,routing_method_type=4,
                    use_routing_scales_on_input=False,use_deep_seek_fp8=True,norm_topk_prob=True,enable_pdl=True)
                return destination.routing_replay_ids,destination.expert_weights
            def load(case):
                x.copy_(case['xs'][layer_index]);slots.copy_(case['slots'])
                keep.copy_(case['keep']);inverse.copy_(case['inverse'])
            def verify(name,actual,expected,case):
                # Compare the real native prepare outputs before checking downstream arithmetic.
                nq,ns,nl=native_prepared['control'];cq,cs,cl=native_prepared['candidate']
                check(name+'/FP8_bytes',cq.view(torch.uint8).index_select(0,inverse),nq.view(torch.uint8))
                check(name+'/input_scales',cs.index_select(1,inverse),ns)
                check(name+'/routing_logits',cl.index_select(0,inverse),nl)
                ni,nw=routing('control');ci,cw=routing('candidate')
                check(name+'/native_canonical_top8_ids',ci.index_select(0,inverse),ni)
                check(name+'/native_canonical_top8_weights',cw.index_select(0,inverse),nw)
                for key,a,b in zip(('routed','shared','shared_gate'),actual,expected,strict=True):
                    check(name+'/'+key,a,b)
                check(name+'/original_input',x,case['xs'][layer_index].cuda())
                check(name+'/original_slots',slots,case['slots'])
                check(name+'/keep_map',keep,case['keep']);check(name+'/inverse_map',inverse,case['inverse'])
                check(name+'/compact_input',compact,x.index_select(0,keep))
                check(name+'/compact_slots',compact_slots,slots.index_select(0,keep))
                for key,storage,value in [('source',x_storage,-73.),('compact',compact_storage,-71.),*[(f'expanded{i}',t,-79.) for i,t in enumerate(expanded_storages)]]:
                    ends=storage[[0,-1]]
                    check(name+'/guard/'+key,ends,torch.full_like(ends,value))
                for key,storage in [('keep',keep_storage),('inverse',inverse_storage)]:
                    ends=storage[[0,-1]];check(name+'/guard/'+key,ends,torch.full_like(ends,-1))
            # Eager comparisons use all original rows, including decode and padding.
            for case in inputs:
                load(case)
                arm='control';expected=tuple(t.clone() for t in control_call())
                arm='candidate';actual=candidate_call()
                verify(f'L{layer_index}/eager/{case["case"]}',actual,expected,case)
            # Dedicated graphs retain their returned tensors and prepared buffers.
            load(inputs[0])
            control_graph=torch.cuda.CUDAGraph();candidate_graph=torch.cuda.CUDAGraph()
            stream=torch.cuda.Stream();stream.wait_stream(torch.cuda.current_stream())
            with torch.cuda.stream(stream):
                for _ in range(2):
                    arm='control';control_call()
                    arm='candidate';candidate_call()
            torch.cuda.current_stream().wait_stream(stream)
            arm='control'
            with torch.cuda.graph(control_graph): control_output=control_call()
            control_prepared=native_prepared['control']
            arm='candidate'
            with torch.cuda.graph(candidate_graph): candidate_output=candidate_call()
            candidate_prepared=native_prepared['candidate']
            moe_input.prepare_moe_input=original_prepare
            for case in inputs:
                load(case)
                control_graph.replay();expected=tuple(t.clone() for t in control_output)
                candidate_graph.replay()
                native_prepared['control']=control_prepared;native_prepared['candidate']=candidate_prepared
                verify(f'L{layer_index}/graph/{case["case"]}',candidate_output,expected,case)
            for name,tensor in weights.items(): check(f'L{layer_index}/readonly_weight/{name}',tensor,weight_before[name])
            weight_before=None;weights=None
            report['layers'].append(dict(layer=layer_index,all_three_cases_eager_and_same_graph=True,
                full_rows=FULL,compact_rows=COMPACT,original_native_function=True,passed=True));flush()
            del control_graph,candidate_graph,control_output,candidate_output,control_prepared,candidate_prepared
        for name,tensor in states.items():check('readonly_state/'+name,tensor,state_before[name])
        check('readonly_cuda_RNG',torch.cuda.get_rng_state(),rng_before)
        check('readonly_cpu_RNG',torch.get_rng_state(),cpu_rng_before)
        report['status']='PASS'
    except Exception as error:
        report['status']='FAIL';report['failure']=dict(type=type(error).__name__,message=str(error));flush()
        # Preserve the primary failure, then audit read-only ownership; no further candidate calls.
        if weights is not None and weight_before is not None:
            for name,tensor in weights.items():check('failure_readonly_weight/'+name,tensor,weight_before[name],stop=False)
        if states is not None and state_before is not None:
            for name,tensor in states.items():check('failure_readonly_state/'+name,tensor,state_before[name],stop=False)
        if rng_before is not None:check('failure_readonly_cuda_RNG',torch.cuda.get_rng_state(),rng_before,stop=False)
        if cpu_rng_before is not None:check('failure_readonly_cpu_RNG',torch.get_rng_state(),cpu_rng_before,stop=False)
        if failed_buffers is not None:
            for name,storage,value in failed_buffers:
                ends=storage[[0,-1]]
                check('failure_guard/'+name,ends,torch.full_like(ends,value),stop=False)
            check('failure_original_input',x,case['xs'][layer_index].cuda(),stop=False)
            check('failure_original_slots',slots,case['slots'],stop=False)
        flush();raise
    finally:
        moe_input.prepare_moe_input=original_prepare
    flush()


if __name__=='__main__':
    if '--cpu-check' in sys.argv:print(json.dumps(cpu_check(),indent=2))
    else:main()
