"""Launch exactly one frozen exact-only compact/expand gate on idle GPU6."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

OUT=Path(__file__).resolve().parent
ROOT=OUT.parent
PYTHON='/home/zjy/code/hsliu/venvs/codex-drama3-standalone/bin/python'
protocol=json.loads((OUT/'protocol.json').read_text())
for name,expected in protocol['frozen_files'].items():
    assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==expected,name
assert not (OUT/'result.json').exists(), 'Do not overwrite an earlier result'
state=subprocess.check_output(['nvidia-smi','-i','6','--query-gpu=uuid,memory.used,utilization.gpu','--format=csv,noheader,nounits'],text=True).strip()
uuid,memory,util=[v.strip() for v in state.split(',')]
processes=subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid,pid,used_memory','--format=csv,noheader,nounits'],text=True)
assert int(memory)<20 and int(util)==0 and uuid not in processes, (state,processes)
env=os.environ.copy()
for name in list(env):
    if name.startswith('DRAMA3_'): del env[name]
env.update(protocol['environment'])
command=[PYTHON,str(OUT/'exact_gate.py')]
with (OUT/'gate.log').open('x') as log:
    child=subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
record=dict(argv=command,pid=child.pid,gpu_before=state,compute_processes_before=processes,
    protocol_sha256=hashlib.sha256((OUT/'protocol.json').read_bytes()).hexdigest(),
    environment=protocol['environment'],scope=protocol['scope'])
(OUT/'command.json').write_text(json.dumps(record,indent=2)+'\n')
(OUT/'gate.pid').write_text(str(child.pid)+'\n')
print(json.dumps(record,indent=2))
