"""Read-only CPU interpretation of archived FC1 failure; preserves original FAIL."""
import hashlib,json
from pathlib import Path
from collections import Counter
import torch
R=Path(__file__).resolve().parent
torch.set_num_threads(8)
x=torch.load(R/'actual-reference.pt',map_location='cpu',weights_only=True)
z=torch.load(R/'inputs.pt',map_location='cpu',weights_only=True)
a=x['output_bytes'];b=x['expected_bytes'];scale=x['output_scales'];refscale=x['expected_scales']
# Candidate = [b0,b8,b1,b9,...] inside every16bytes; inverse is fixed2x8 transpose.
aligned=a.reshape(8,64,8,2).transpose(-1,-2).reshape(8,1024).contiguous()
af=a.view(torch.float8_e4m3fn).float();bf=b.view(torch.float8_e4m3fn).float();cf=aligned.view(torch.float8_e4m3fn).float()

def metric(actual,ref):
 d=actual.double()-ref.double();return dict(max_abs=d.abs().max().item(),relative_rms=(d.square().mean()/ref.double().square().mean()).sqrt().item(),different_values=int((actual!=ref).sum()))
actual_dq=cf.reshape(8,8,128)*scale.T[:,:,None]
expected_dq=bf.reshape(8,8,128)*refscale.T[:,:,None]
ulps=(scale.view(torch.int32).long()-refscale.view(torch.int32).long())
# Independent real-number block-scaled GEMM; diagnostic, NOT a native FP32 reduction oracle.
y=torch.zeros(8,1024,dtype=torch.float64)
for k in range(16):
 dot=z['q'][:,k*128:(k+1)*128].double()@z['w1'][0,:,k*128:(k+1)*128].double().T
 y+=dot*z['s'][k,:,None].double()*z['s1'][0,:,k].repeat_interleave(128)[None,:].double()
quant_reference=(y.reshape(8,8,128)/refscale.T.double()[:,:,None]).clamp(-448,448).float().to(torch.float8_e4m3fn).view(torch.uint8).reshape(8,1024)
quant_candidate=(y.reshape(8,8,128)/scale.T.double()[:,:,None]).clamp(-448,448).float().to(torch.float8_e4m3fn).view(torch.uint8).reshape(8,1024)
refnorm=expected_dq.reshape(8,1024).double();candnorm=actual_dq.reshape(8,1024).double()
result=dict(status='CPU_LAYOUT_ATTRIBUTION_ONLY_ORIGINAL_EXACT_FAIL_RETAINED',driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),inputs={name:hashlib.sha256((R/name).read_bytes()).hexdigest() for name in ('actual-reference.pt','inputs.pt','result.json')},original_byte_mismatches=int((a!=b).sum()),fixed_16byte_inverse_permutation='a.reshape(8,64,8,2).transpose(-1,-2).reshape(8,1024)',aligned_byte_mismatches=int((aligned!=b).sum()),aligned_uint8_exact=torch.equal(aligned,b),signed_zero_mismatches=int(((a!=b)&(af==0)&(bf==0)).sum()),nan_count_actual=int(torch.isnan(af).sum()),nan_count_reference=int(torch.isnan(bf).sum()),zero_count_actual=int((af==0).sum()),zero_count_reference=int((bf==0).sum()),each_row_byte_multiset_exact=[torch.equal(torch.sort(a[i])[0],torch.sort(b[i])[0]) for i in range(8)],scale_changed=int((scale!=refscale).sum()),scale_signed_ulp_histogram={str(k):v for k,v in sorted(Counter(ulps.flatten().tolist()).items())},scale_difference=metric(scale,refscale),aligned_dequantized_difference=metric(actual_dq,expected_dq),independent_float64_block_gemm=dict(purpose='Distinguish logical row layout/gate order. Does not reproduce native FP32 rounding or justify threshold changes.',native_bytes_vs_fp64_quant=int((b!=quant_reference).sum()),candidate_raw_bytes_vs_fp64_quant=int((a!=quant_candidate).sum()),candidate_aligned_bytes_vs_fp64_quant=int((aligned!=quant_candidate).sum()),reference_dequant_error=metric(refnorm,y),candidate_aligned_dequant_error=metric(candnorm,y),gate_up_swap_error=metric(torch.cat((refnorm[:,512:],refnorm[:,:512]),1),y)),cuda_initialized=torch.cuda.is_initialized())
assert not result['cuda_initialized']
(R/'independent-layout-metrics.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
