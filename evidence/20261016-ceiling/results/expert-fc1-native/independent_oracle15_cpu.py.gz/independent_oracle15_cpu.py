"""Independent CPU math-layout spot check of all15 archived native scenarios."""
import hashlib,json
from pathlib import Path
from contextlib import ExitStack
import torch
from safetensors import safe_open
R=Path(__file__).resolve().parent
O=R.parent/'expert-metadata-rebase'
C=Path('/home/zjy/.cache/huggingface/hub/models--fishaudio--drama-3/snapshots/e0a9218aa48888270f06ef1ed9ea67622c0e17d2')
torch.set_num_threads(8)
index=json.loads((C/'model.safetensors.index.json').read_text())['weight_map']; cache={}
def weights(layer,expert):
 if (layer,expert) in cache:return cache[layer,expert]
 keys=[f'model.language_model.layers.{layer}.mlp.experts.{expert}.{p}.{s}' for p in ('up_proj','gate_proj') for s in ('weight','weight_scale_inv')]
 with ExitStack() as stack:
  files={f:stack.enter_context(safe_open(str(C/f),framework='pt',device='cpu')) for f in set(index[k] for k in keys)}
  def read(p,s):
   key=f'model.language_model.layers.{layer}.mlp.experts.{expert}.{p}.{s}';return files[index[key]].get_tensor(key)
  value=(torch.cat([read(p,'weight') for p in ('up_proj','gate_proj')]).double(),torch.cat([read(p,'weight_scale_inv') for p in ('up_proj','gate_proj')]).double())
 cache[layer,expert]=value;return value
cases=[]
for path in sorted(O.glob('oracle-layer*-*.pt')):
 d=torch.load(path,map_location='cpu',weights_only=False);ids=d['ids'].long().flatten(); expert=205 if bool((ids==205).any()) else int(ids[0]);expanded=torch.where(ids==expert)[0];tokens=expanded//8
 w,s=weights(d['layer'],expert);q=d['q'][tokens].double();ss=d['input_scale'][:,tokens].double();y=torch.zeros(len(tokens),1024,dtype=torch.float64)
 for k in range(16):y+=(q[:,k*128:(k+1)*128]@w[:,k*128:(k+1)*128].T)*ss[k,:,None]*s[:,k].repeat_interleave(128)[None,:]
 raw=d['intermediates']['fc1_bytes'][expanded].contiguous();scale=d['intermediates']['fc1_scale'][expanded].double()
 reference=(y.reshape(-1,8,128)/scale[:,:,None]).clamp(-448,448).float().to(torch.float8_e4m3fn).view(torch.uint8).reshape(-1,1024)
 candidate_order=raw.reshape(-1,64,2,8).transpose(-1,-2).reshape(-1,1024).contiguous()
 cases.append(dict(file=path.name,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),layer=d['layer'],scenario=d['scenario'],selected_expert=expert,selected_rows=len(tokens),total_scenario_rows=int(d['ids'].numel()),native_logical_byte_mismatches_vs_fp64=int((raw!=reference).sum()),native_as_interleaved_byte_mismatches_vs_fp64=int((candidate_order!=reference).sum()),selected_byte_count=raw.numel()))
assert len(cases)==15 and not torch.cuda.is_initialized()
result=dict(status='CPU_LOGICAL_LAYOUT_DIAGNOSTIC',driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),cases=cases,selected_bytes=sum(c['selected_byte_count'] for c in cases),logical_mismatch_total=sum(c['native_logical_byte_mismatches_vs_fp64'] for c in cases),interleaved_mismatch_total=sum(c['native_as_interleaved_byte_mismatches_vs_fp64'] for c in cases),cuda_initialized=False,scope='One explicit available expert per15native scenario, not all experts or a native-FP32 arithmetic reproduction; FP64 checks logical ordering only.')
(R/'independent-oracle15-metrics.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
