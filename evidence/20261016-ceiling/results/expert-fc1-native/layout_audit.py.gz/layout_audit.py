import json,torch
from pathlib import Path
p=Path(__file__).resolve().parent
d=torch.load(p/'actual-reference.pt',map_location='cpu',weights_only=False)
a=d['output_bytes'];b=d['expected_bytes'];s=d['output_scales'];t=d['expected_scales']
# Sole hypothesis from the actual TMEM16x256b/packed-pair store: interleaved8+8.
a_reordered=a.reshape(8,64,8,2).transpose(-1,-2).reshape(8,1024)
def metrics(x,y):
 z=x.float()-y.float();return {'maxabs':float(z.abs().max()),'rrms':float(z.square().mean().sqrt()/(y.float().square().mean().sqrt()+1e-30)),'changed_values':int((x!=y).sum()),'rms':float(z.square().mean().sqrt())}
af=a.view(torch.float8_e4m3fn).float();bf=b.view(torch.float8_e4m3fn).float();rf=a_reordered.view(torch.float8_e4m3fn).float()
ulps=s.view(torch.int32)-t.view(torch.int32)
r={'status':'CPU_LAYOUT_LOCALIZATION_ONLY_ORIGINAL_GPU_EXACT_FAIL_UNCHANGED',
 'permutation':'within each16-byte block: candidate [b0,b8,b1,b9,...,b7,b15]; deinterleave to original b0..b15',
 'raw_byte_mismatches':int((a!=b).sum()),'raw_fp8':metrics(af,bf),
 'raw_signed_zero_mismatches':int((((a==0)&(b==128))|((a==128)&(b==0))).sum()),
 'raw_zero_vs_nonzero_mismatches':int(((af==0)!=(bf==0)).sum()),
 'raw_nonzero_sign_mismatches':int(((af!=0)&(bf!=0)&(torch.signbit(af)!=torch.signbit(bf))).sum()),
 'corrected_layout_byte_mismatches':int((a_reordered!=b).sum()),'corrected_layout_fp8':metrics(rf,bf),
 'scale':metrics(s,t),'scale_ulp_histogram':{str(int(k)):int((ulps==k).sum()) for k in torch.unique(ulps)},
 'raw_dequantized':metrics(af.reshape(8,8,128)*s.T[:,:,None],bf.reshape(8,8,128)*t.T[:,:,None]),
 'layout_corrected_dequantized':metrics(rf.reshape(8,8,128)*s.T[:,:,None],bf.reshape(8,8,128)*t.T[:,:,None]),
 'cuda_initialized':torch.cuda.is_initialized(),'not_proven':'Source-level native packing/scale contract and corrected GPU execution have not been validated.'}
assert not r['cuda_initialized']
(p/'layout-audit.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
