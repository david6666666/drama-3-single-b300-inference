import datetime
import json
import os
import socket
import subprocess
import threading
from pathlib import Path

root = Path('/home/zjy/code/hsliu/artifacts/drama3-ceiling-20261016')
source = Path('/home/zjy/code/hsliu/drama3-short-padding-frozen-20261016')
venv = Path('/home/zjy/code/hsliu/venvs/codex-drama3-standalone')
checkpoint = '/home/zjy/.cache/huggingface/hub/models--fishaudio--drama-3/snapshots/e0a9218aa48888270f06ef1ed9ea67622c0e17d2'
corpus = '/home/zjy/code/hsliu/artifacts/drama3-b300-20261014/seedtts-en1088-codes/requests.jsonl'
flags = dict(DRAMA3_GDN_STATE_DTYPE='bfloat16', DRAMA3_PACKED_MOE_PROJECTION='1', DRAMA3_PREFILL_CONV='triton', DRAMA3_PREFILL_MOE_TUNED='0', DRAMA3_PREFILL_MOE='flashinfer', DRAMA3_ADMISSION_MIN_BATCH='6', DRAMA3_PREFILL_BUCKET_192='1', DRAMA3_PACKED_PREFILL='1', DRAMA3_ASYNC_CODEC='1', DRAMA3_AUDIO_DELIVERY_THREAD='1', DRAMA3_FUSED_MOE_INPUT='1', DRAMA3_MIXED_BACKBONE='1', DRAMA3_MIXED_SPAN256='1', DRAMA3_CODEC_DEDICATED_CAPTURE_STREAM='1', DRAMA3_COMPACT_GDN='0', DRAMA3_FUSED_MIXED_LAYOUT='0', DRAMA3_PACKED_CONV_GUARD='0', DRAMA3_DEFER_CODEC_SUBMIT='0', DRAMA3_CODEC_SPLIT_POLICY='dp')
env = {k: v for k, v in os.environ.items() if not k.startswith('DRAMA3_')}
env.update(flags)
sha = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip()
assert sha == 'a607dff26c3ca5423746f7eebec4f5f5a88cd4c0'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=source, text=True)
processes = subprocess.check_output(['nvidia-smi', '--query-compute-apps=gpu_uuid,pid,process_name,used_gpu_memory', '--format=csv,noheader'], text=True)
assert 'GPU-40e00845-d89c-1393-2c32-a2dca3ee9442' not in processes
with socket.socket() as probe:
    assert probe.connect_ex(('127.0.0.1', 18137)) != 0, 'port18137 occupied'
plan = dict(hypothesis='Short runtime attention context for explicitly reserved decode padding slots may reduce service GPU time while preserving every real request calculation. Only padding-context toggles; all other native flags and codec schedule remain fixed.', isolated_variable='DRAMA3_SHORT_PADDING_CONTEXT: control0 vs candidate1', source_sha=sha, source=str(source), flags=flags, gpu=7, gpu_uuid='GPU-40e00845-d89c-1393-2c32-a2dca3ee9442', port=18137, cpu_affinity=sorted(os.sched_getaffinity(0)), omp_threads=8, requests=1088, concurrency=64, repeats=1, profile_enabled=False, checkpoint=checkpoint, corpus=corpus, gate='All1088 complete; inspect throughput/TTFA/RTF and total output frames; score all1088 outputs of each arm against unchanged WER/SIM limits before any promotion. The 7.23ms fixed-input B64 diagnostic used different input state from the old8.275ms reference and is not a new universal ceiling.', stop='Abort on GPU interference, server failures or incomplete output. One feasibility run each is not a statistical speedup claim.', before_gpu=processes)
(root/'short-padding-service-experiment.json').write_text(json.dumps(plan, indent=2)+'\n')
stop = threading.Event()
def audit():
    with (root/'short-padding-process-audit.jsonl').open('w') as file:
        while not stop.is_set():
            value = subprocess.run(['nvidia-smi', '--query-compute-apps=gpu_uuid,pid,process_name,used_gpu_memory', '--format=csv,noheader'], capture_output=True, text=True)
            file.write(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), processes=value.stdout.splitlines()))+'\n')
            file.flush()
            stop.wait(1)
thread = threading.Thread(target=audit)
thread.start()
try:
    for enabled, name in [('0', 'short-padding-control-gpu7'), ('1', 'short-padding-candidate-gpu7')]:
        cmd = [str(venv/'bin/python'), str(source/'scripts/run_baseline.py'), '--backend', 'standalone', '--source', str(source), '--venv', str(venv), '--bench-python', str(venv/'bin/python'), '--checkpoint', checkpoint, '--fish-source', '/home/zjy/code/hsliu/drama3-sources/fish-speech', '--corpus', corpus, '--output', str(root/name), '--gpu', '7', '--port', '18137', '--capacity', '64', '--requests', '1088', '--repeats', '1', '--concurrency', '64', '--skip-reference-warmup']
        (root/f'{name}-command.json').write_text(json.dumps(cmd, indent=2)+'\n')
        print('Starting', name, flush=True)
        subprocess.run(cmd, env=dict(env, DRAMA3_SHORT_PADDING_CONTEXT=enabled), check=True)
        print('Finished', name, flush=True)
finally:
    stop.set()
    thread.join()
