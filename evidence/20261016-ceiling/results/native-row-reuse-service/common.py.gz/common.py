"""Shared CPU contracts and monitored subprocess execution for one service pair."""

import csv
import hashlib
import json
import math
import os
import signal
import subprocess
import time
from datetime import UTC, datetime
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
SOURCE_SHA = "345c6a18f200853489a9ac8a86bbe0682ebe484d"
CORPUS_SHA = "08612ee05ab0dd8a762109978b5f230e5b0311a1dfde87f03a4572434dff2dac"
BUCKETS = [
    [64, 768, 256, 576],
    [64, 1024, 256, 832],
    [64, 1280, 256, 1088],
    [64, 1536, 256, 1088],
    [64, 1536, 256, 1344],
]
FLAGS = {
    "DRAMA3_GDN_STATE_DTYPE": "bfloat16",
    "DRAMA3_PREFILL_GDN": "fla",
    "DRAMA3_PACKED_MOE_PROJECTION": "1",
    "DRAMA3_PREFILL_CONV": "triton",
    "DRAMA3_PREFILL_MOE_TUNED": "0",
    "DRAMA3_PREFILL_MOE": "flashinfer",
    "DRAMA3_ADMISSION_MIN_BATCH": "6",
    "DRAMA3_PREFILL_BUCKET_192": "1",
    "DRAMA3_PACKED_PREFILL": "1",
    "DRAMA3_ASYNC_CODEC": "1",
    "DRAMA3_AUDIO_DELIVERY_THREAD": "1",
    "DRAMA3_FUSED_MOE_INPUT": "1",
    "DRAMA3_MIXED_BACKBONE": "1",
    "DRAMA3_MIXED_SPAN256": "1",
    "DRAMA3_CODEC_DEDICATED_CAPTURE_STREAM": "1",
    "DRAMA3_COMPACT_GDN": "1",
    "DRAMA3_FUSED_MIXED_LAYOUT": "1",
    "DRAMA3_PACKED_CONV_GUARD": "1",
    "DRAMA3_DEFER_CODEC_SUBMIT": "0",
    "DRAMA3_CODEC_SPLIT_POLICY": "dp",
    "DRAMA3_SHORT_PADDING_CONTEXT": "1",
    "DRAMA3_FUSED_MOE_RESIDUAL": "1",
    "DRAMA3_CODEC_SMS": "0",
    "DRAMA3_RESERVED_PADDING_ROUTER": "1",
    "DRAMA3_FRAME_PIPELINE": "1",
    "DRAMA3_FRAME_PIPELINE_DEFERRED_WAITING": "1",
    "DRAMA3_CODEC_CACHED_LINEAR": "0",
    "DRAMA3_CODEC_COALESCE": "0",
}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def utc():
    return datetime.now(UTC).isoformat()


def git(source, *args):
    return subprocess.check_output(["git", "-C", str(source), *args], text=True).strip()


def require(value, message):
    if not value:
        raise RuntimeError(message)


def verify_exact(gate):
    require(
        gate["original_AA_passed"] is True, "original A/A padding-binding gate missing"
    )
    require(
        gate["status"] == "PASS" and gate["exact_passed"] is True,
        "expanded exact gate has not passed",
    )
    require(gate["source_sha"] == SOURCE_SHA, "exact gate source mismatch")
    require(
        gate["pool_interleaving_passed"] is True
        and gate["retained_outputs_passed"] is True,
        "pool/output lifetime gate missing",
    )
    require(gate["all111_states"] is True, "full 111-state gate missing")
    require(
        sorted(gate["five_bucket_coverage"]) == sorted(BUCKETS),
        "five production buckets not covered",
    )
    require(
        set(gate["capture_orders"]) == {"ascending", "descending"},
        "both capture orders required",
    )
    require(
        gate["checks"] and all(x["passed"] is True for x in gate["checks"]),
        "nonempty all-pass exact checks required",
    )
    require(
        gate["cases"] and all(x["passed"] is True for x in gate["cases"]),
        "nonempty all-pass exact cases required",
    )


def verify_protocol(protocol, *, frozen=True):
    require(
        sorted(os.sched_getaffinity(0)) == protocol["cpu_affinity"],
        "CPU affinity changed",
    )
    require(protocol["source_sha"] == SOURCE_SHA, "unreviewed production SHA")
    require(protocol["common_flags"] == FLAGS, "common controls changed")
    require(
        protocol["arm_flags"]
        == {
            "control": {"DRAMA3_MIXED_ROW_REUSE": "0"},
            "candidate": {"DRAMA3_MIXED_ROW_REUSE": "1"},
        },
        "not a row-reuse-only pair",
    )
    require(
        protocol["concurrency"] == 64
        and protocol["requests"] == 1088
        and protocol["repeats"] == 1,
        "incorrect workload",
    )
    require(
        protocol["corpus_sha256"] == CORPUS_SHA
        and sha(protocol["corpus"]) == CORPUS_SHA,
        "corpus mismatch",
    )
    require(
        protocol["continuation"]["minimum_fps_ratio"] == 1.01,
        "continuation threshold changed",
    )
    require(
        protocol["quality_limits"]
        == {"wer_corpus_max": 0.02950933601272712, "sim_min": 61.88158934120563},
        "quality limits changed",
    )
    require(
        git(protocol["source"], "rev-parse", "HEAD") == SOURCE_SHA,
        "source HEAD changed",
    )
    require(
        not git(protocol["source"], "status", "--porcelain"), "source tree not clean"
    )
    if frozen:
        require(
            protocol["status"] == "FROZEN_AFTER_EXPANDED_EXACT", "draft cannot launch"
        )
        require(
            sha(protocol["exact_gate"]) == protocol["exact_gate_sha256"],
            "exact result changed",
        )
        verify_exact(json.loads(Path(protocol["exact_gate"]).read_text()))
        manifest = json.loads((OUT / "frozen-inputs.json").read_text())
        require(str(OUT / "protocol.json") in manifest, "protocol not frozen")
        for path, digest in manifest.items():
            require(sha(path) == digest, "frozen file changed: " + path)
        for name in ("fish_source", "quality_upstream"):
            require(
                git(protocol[name], "rev-parse", "HEAD") == protocol[name + "_sha"],
                name + " HEAD changed",
            )
            require(
                git(protocol[name], "status", "--porcelain")
                == protocol[name + "_status"],
                name + " status changed",
            )


def load_protocol():
    protocol = json.loads((OUT / "protocol.json").read_text())
    verify_protocol(protocol)
    return protocol


def environment(protocol, arm):
    result = {k: v for k, v in os.environ.items() if not k.startswith("DRAMA3_")}
    result.update(protocol["common_flags"], **protocol["arm_flags"][arm])
    result.update(
        PYTHONPATH=str(Path(protocol["source"]) / "src"),
        PYTHONDONTWRITEBYTECODE="1",
        OMP_NUM_THREADS="8",
        CUDA_VISIBLE_DEVICES=str(protocol["gpu"]),
        HF_HUB_OFFLINE="1",
        TRANSFORMERS_OFFLINE="1",
    )
    return result


def gpu_processes(protocol):
    output = subprocess.check_output(
        [
            "nvidia-smi",
            "--query-compute-apps=gpu_uuid,pid,process_name,used_gpu_memory",
            "--format=csv,noheader,nounits",
        ],
        text=True,
    )
    return [
        {
            "uuid": row[0].strip(),
            "pid": int(row[1]),
            "name": row[2].strip(),
            "memory_mib": int(row[3]),
        }
        for row in csv.reader(output.splitlines())
        if row and row[0].strip() == protocol["gpu_uuid"]
    ]


def process_identity(pid):
    try:
        # comm may contain spaces; fields start after the last closing parenthesis.
        fields = Path(f"/proc/{pid}/stat").read_text().rsplit(")", 1)[1].split()
        return int(fields[1]), int(fields[19])  # ppid, starttime
    except FileNotFoundError:
        return None


def descendant(pid, parent):
    seen = set()
    while pid > 1 and pid not in seen:
        if pid == parent:
            return True
        seen.add(pid)
        identity = process_identity(pid)
        if identity is None:
            return False
        pid = identity[0]
    return False


def run_monitored(command, env, directory, protocol, timeout):
    """Terminate only our runner; run_baseline owns its separate server-group cleanup."""
    directory.mkdir(exist_ok=False)
    require(not gpu_processes(protocol), "selected GPU already occupied")
    info = subprocess.check_output(
        [
            "nvidia-smi",
            "-i",
            str(protocol["gpu"]),
            "--query-gpu=uuid",
            "--format=csv,noheader",
        ],
        text=True,
    ).strip()
    require(info == protocol["gpu_uuid"], "GPU index/UUID mismatch")
    save(directory / "command.json", command)
    report = {
        "status": "RUNNING",
        "start_utc": utc(),
        "command": command,
        "known_owned_gpu_pids": {},
        "sampling_interval_s": 1,
        "sampling_limitation": "One-second polling cannot exclude shorter unobserved interference or capture true transient allocator peak.",
    }
    save(directory / "result.json", report)
    started = time.monotonic()
    proc = None
    known = {}
    error = None
    try:
        with (
            (directory / "stdout.log").open("x") as log,
            (directory / "process-audit.jsonl").open("x") as audit,
        ):
            proc = subprocess.Popen(
                command,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            report["runner_pid"] = proc.pid
            while True:
                rows = gpu_processes(protocol)
                readiness = False
                if "--backend" in command:
                    launch = (
                        Path(command[command.index("--output") + 1]) / "launch.json"
                    )
                    if launch.exists():
                        try:
                            readiness = "startup_to_readiness_s" in json.loads(
                                launch.read_text()
                            )
                        except json.JSONDecodeError:
                            pass  # launch.json can be concurrently rewritten at readiness.
                audit.write(
                    json.dumps(
                        {
                            "utc": utc(),
                            "elapsed_s": time.monotonic() - started,
                            "processes": rows,
                            "readiness_observed": readiness,
                        }
                    )
                    + "\n"
                )
                audit.flush()
                for row in rows:
                    pid = row["pid"]
                    identity = process_identity(pid)
                    if identity and descendant(pid, proc.pid):
                        known[pid] = identity[1]
                    require(
                        pid in known
                        and (identity is None or known[pid] == identity[1]),
                        f"foreign or unattributable selected-GPU process {pid}",
                    )
                if proc.poll() is not None:
                    require(
                        proc.returncode == 0, f"command failed with {proc.returncode}"
                    )
                    break
                require(time.monotonic() - started < timeout, "watchdog expired")
                time.sleep(1)
    except BaseException as exc:  # noqa: BLE001 - preserve failure and clean owned processes.
        error = f"{type(exc).__name__}: {exc}"
    finally:
        if proc and proc.poll() is None:
            os.killpg(proc.pid, signal.SIGTERM)
            try:
                proc.wait(
                    timeout=40
                )  # run_baseline finally allows its server 30 seconds.
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGKILL)
                proc.wait(timeout=5)
        # A runner crash can leave its separately-sessioned server. Never signal an
        # unobserved or reused PID. Normal run_baseline cleanup handles the common path.
        for pid, starttime in known.items():
            identity = process_identity(pid)
            if identity and identity[1] == starttime:
                try:
                    os.kill(pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
        deadline = time.monotonic() + 5
        while time.monotonic() < deadline:
            alive = [
                pid
                for pid, stamp in known.items()
                if (identity := process_identity(pid)) and identity[1] == stamp
            ]
            if not alive:
                break
            time.sleep(0.2)
        for pid in alive:
            identity = process_identity(pid)
            if identity and identity[1] == known[pid]:
                try:
                    os.kill(pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
        try:
            post = gpu_processes(protocol)
            if post:
                error = (
                    error + "; " if error else ""
                ) + "post-run selected GPU not empty"
        except Exception as exc:  # noqa: BLE001 - a failed post-audit must fail the experiment.
            post = None
            error = (error + "; " if error else "") + f"post-run audit error: {exc}"
        report.update(
            status="FAIL" if error else "PASS",
            error=error,
            end_utc=utc(),
            elapsed_s=time.monotonic() - started,
            known_owned_gpu_pids=known,
            post_gpu=post,
            exit_code=proc.returncode if proc else None,
        )
        save(directory / "result.json", report)
    require(error is None, error)
    return report


def finite(value):
    return isinstance(value, (float, int)) and math.isfinite(value)
