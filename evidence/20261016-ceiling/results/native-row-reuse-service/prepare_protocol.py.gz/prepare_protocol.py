"""Write a non-launchable CPU draft, or freeze after expanded production exact PASS."""

import argparse
import json
import os
from pathlib import Path

from common import (
    BUCKETS,
    CORPUS_SHA,
    FLAGS,
    OUT,
    ROOT,
    SOURCE_SHA,
    git,
    require,
    save,
    sha,
    utc,
    verify_exact,
    verify_protocol,
)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--freeze",
        action="store_true",
        help="Requires complete expanded exact result; does not launch GPU work",
    )
    args = parser.parse_args()
    source = ROOT / "source-row-reuse-345c6a1"
    exact = ROOT / "native-row-reuse-runtime-exact-v2" / "result.json"
    protocol = {
        "status": "CPU_DRAFT_NOT_LAUNCHABLE",
        "created_utc": utc(),
        "source": str(source),
        "source_sha": SOURCE_SHA,
        "hypothesis": "Reuse exactly equal conditioning-prefix rows for native MoE and its shared/router projections only; attention, GDN, backbone dense projections and teacher computation keep full rows.",
        "isolated_variable": "Only DRAMA3_MIXED_ROW_REUSE 0 to 1 on the same frozen production commit.",
        "common_flags": FLAGS,
        "arm_flags": {
            "control": {"DRAMA3_MIXED_ROW_REUSE": "0"},
            "candidate": {"DRAMA3_MIXED_ROW_REUSE": "1"},
        },
        "gpu": 6,
        "gpu_uuid": "GPU-619f7fdc-5f98-8c37-fe89-0465d6130baf",
        "port": 18139,
        "requests": 1088,
        "concurrency": 64,
        "repeats": 1,
        "order": ["control", "candidate"],
        "venv": "/home/zjy/code/hsliu/venvs/codex-drama3-standalone",
        "checkpoint": "/home/zjy/.cache/huggingface/hub/models--fishaudio--drama-3/snapshots/e0a9218aa48888270f06ef1ed9ea67622c0e17d2",
        "corpus": "/home/zjy/code/hsliu/artifacts/drama3-b300-20261014/seedtts-en1088-codes/requests.jsonl",
        "corpus_sha256": CORPUS_SHA,
        "fish_source": "/home/zjy/code/hsliu/drama3-sources/fish-speech",
        "quality_upstream": "/home/zjy/code/hsliu/drama3-sources/sglang-omni",
        "quality_assets": "/home/zjy/code/hsliu/artifacts/drama3-b300-20261014/quality-models.json",
        "quality_hf_modules": "/home/zjy/code/hsliu/artifacts/drama3-b300-20261014/quality-hf-modules",
        "quality_limits": {
            "wer_corpus_max": 0.02950933601272712,
            "sim_min": 61.88158934120563,
        },
        "quality_scope": "Both complete unfiltered 1088 scores against same-C64 vLLM bounds: WER +1 percentage point, SIM -2. No outlier clipping or drain exclusion.",
        "continuation": {
            "minimum_fps_ratio": 1.01,
            "requires": "Both complete quality gates plus candidate frames/s >= 1.01 * control frames/s and actual candidate activation coverage > 0.",
            "after_pass": "Report to root before separately frozen 3 paired rounds; never automatically repeat.",
            "after_fail": "Stop promotion and additional rounds; preserve full results.",
        },
        "target_frames_s": 6765.407263214912,
        "vllm_baseline_frames_s": 4510.271508809941,
        "exact_gate": str(exact),
        "exact_gate_sha256": None,
        "five_buckets": BUCKETS,
        "cpu_affinity": sorted(os.sched_getaffinity(0)),
        "omp_threads": 8,
        "service_watchdog_seconds_per_arm": 2400,
        "quality_watchdog_seconds_per_arm": 3600,
        "benchmark": {
            "max_frames": 500,
            "temperature": 1.0,
            "top_p": 0.9,
            "top_k": 30,
            "warmup_requests_per_arm": 64,
            "skip_reference_warmup": True,
            "profile_enabled": False,
        },
        "sampling": "Candidate prebuilds five extra graphs. Sampling step is neither instrumented nor reset; initialization and subsequent admission schedules may change generated frames/audio. This is an end-to-end service feasibility pair, not a fixed-output or replicated speedup claim.",
        "codec_policy": "Both arms use native DP. Each startup measures its own codec cost table; partitions are not frozen. Async private capture/thread remains identical.",
        "startup_memory": "Process-to-readiness includes load/capture/warmup. One-second GPU process polling reports observed startup and steady peaks, not exact allocator peaks or transient capture allocations. No downloads, cache flushes, clock changes, or profiler.",
        "coverage": "Shutdown row_reuse_counts include all server lifetime work: 64 concurrency-warmup requests plus 1088 measured requests. They are not benchmark-only. Report opportunities/used/unsupported/no-fit/removed rows; reject zero activation as inconclusive.",
        "mapping_cpu": "mapping_cpu_ms and maximum cover planning and prompt snapshots only. Prepare byte-binding validation and map H2D upload are excluded from this counter but included in measured end-to-end service latency.",
        "tail": "Metrics include all requests and full drain. Report last dispatch to last completion, frames/chunks emitted after last dispatch, and active-request time integral separately; these client timestamps do not imply GPU causal spans.",
        "ownership": "Selected GPU must be empty before each arm. Poll once/sec; abort on any observed unowned process/query error. SIGTERM the owned run_baseline runner and let its finally clean the server; only recorded PID+starttime identities may receive cleanup signals. Never signal foreign jobs.",
        "stop": "Any source/hash/exact/ownership/server/incomplete-result failure stops, preserving artifacts. Complete quality is still required after a numerically valid throughput-negative pair.",
    }
    verify_protocol(protocol, frozen=False)
    rows = [
        json.loads(line) for line in Path(protocol["corpus"]).read_text().splitlines()
    ]
    require(
        len(rows) == 1088 and len({r["id"] for r in rows}) == 1088,
        "corpus IDs incomplete",
    )
    for name in ("fish_source", "quality_upstream"):
        protocol[name + "_sha"] = git(protocol[name], "rev-parse", "HEAD")
        protocol[name + "_status"] = git(protocol[name], "status", "--porcelain")
    protocol["quality_assets_sha256"] = sha(protocol["quality_assets"])
    if not args.freeze:
        require(not (OUT / "protocol.json").exists(), "frozen protocol already exists")
        save(OUT / "protocol-draft.json", protocol)
        print("CPU_DRAFT_READY; no GPU query, import, capture or service launch")
        return
    require(
        not (OUT / "protocol.json").exists()
        and not (OUT / "frozen-inputs.json").exists(),
        "refuse to overwrite freeze",
    )
    verify_exact(json.loads(exact.read_text()))
    protocol["exact_gate_sha256"] = sha(exact)
    protocol["status"] = "FROZEN_AFTER_EXPANDED_EXACT"
    save(OUT / "protocol.json", protocol)
    files = set(OUT.glob("*.py")) | {
        OUT / "protocol.json",
        exact,
        Path(protocol["corpus"]),
        Path(protocol["quality_assets"]),
    }
    # Pin all Python implementation imports in the frozen runtime and the two source adapters.
    for directory in (
        source / "src",
        source / "scripts",
        Path(protocol["fish_source"]),
        Path(protocol["quality_upstream"]),
    ):
        files.update(
            p
            for p in directory.rglob("*.py")
            if ".git" not in p.parts and "__pycache__" not in p.parts
        )
    for name in ("protocol.json", "frozen-manifest.json"):
        path = exact.parent / name
        require(path.is_file(), "expanded gate freeze evidence missing: " + str(path))
        files.add(path)
    save(OUT / "frozen-inputs.json", {str(p): sha(p) for p in sorted(files)})
    verify_protocol(protocol)
    print(
        json.dumps(
            {
                "status": "FROZEN_NO_GPU_LAUNCH",
                "source_sha": SOURCE_SHA,
                "files": len(files),
                "protocol_sha256": sha(OUT / "protocol.json"),
                "manifest_sha256": sha(OUT / "frozen-inputs.json"),
            }
        )
    )


if __name__ == "__main__":
    main()
