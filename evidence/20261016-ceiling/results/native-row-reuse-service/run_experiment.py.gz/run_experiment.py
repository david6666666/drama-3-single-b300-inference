"""Explicit one-pair service/quality phases; no automatic additional trials."""

import argparse
import json
import socket
from pathlib import Path

from common import (
    OUT,
    environment,
    load_protocol,
    require,
    run_monitored,
    save,
    sha,
    verify_protocol,
)
from summarize import service_arm, summarize


def pair(p):
    report = {
        "status": "RUNNING",
        "source_sha": p["source_sha"],
        "protocol_sha256": sha(OUT / "protocol.json"),
        "arms": {},
    }
    require(
        not (OUT / "pair-result.json").exists(), "pair already attempted; preserve it"
    )
    save(OUT / "pair-result.json", report)
    try:
        for arm in p["order"]:
            verify_protocol(p)
            with socket.socket() as probe:
                require(
                    probe.connect_ex(("127.0.0.1", p["port"])) != 0,
                    "service port occupied",
                )
            output = OUT / (arm + "-gpu6")
            require(not output.exists(), "refuse to overwrite service arm")
            python = str(Path(p["venv"]) / "bin/python")
            command = [
                python,
                str(Path(p["source"]) / "scripts/run_baseline.py"),
                "--backend",
                "standalone",
                "--source",
                p["source"],
                "--venv",
                p["venv"],
                "--bench-python",
                python,
                "--checkpoint",
                p["checkpoint"],
                "--fish-source",
                p["fish_source"],
                "--corpus",
                p["corpus"],
                "--output",
                str(output),
                "--gpu",
                "6",
                "--port",
                str(p["port"]),
                "--capacity",
                "64",
                "--requests",
                "1088",
                "--repeats",
                "1",
                "--concurrency",
                "64",
                "--skip-reference-warmup",
            ]
            run_monitored(
                command,
                environment(p, arm),
                OUT / (arm + "-service-runner"),
                p,
                p["service_watchdog_seconds_per_arm"],
            )
            report["arms"][arm] = service_arm(p, arm)
            save(OUT / "pair-result.json", report)
        verify_protocol(p)
        report["status"] = "SERVICE_COMPLETE_QUALITY_REQUIRED"
    except BaseException as exc:
        report.update(status="FAIL", error=f"{type(exc).__name__}: {exc}")
        raise
    finally:
        save(OUT / "pair-result.json", report)


def quality(p):
    pair_report = json.loads((OUT / "pair-result.json").read_text())
    require(
        pair_report["status"] == "SERVICE_COMPLETE_QUALITY_REQUIRED",
        "complete successful service pair required",
    )
    require(
        not (OUT / "quality-result.json").exists(),
        "quality already attempted; preserve it",
    )
    report = {"status": "RUNNING", "source_sha": p["source_sha"], "arms": {}}
    save(OUT / "quality-result.json", report)
    try:
        for arm in p["order"]:
            verify_protocol(p)
            service_arm(p, arm)
            output = OUT / (arm + "-quality.json")
            require(not output.exists(), "refuse to overwrite scores")
            command = [
                str(Path(p["venv"]) / "bin/python"),
                str(Path(p["source"]) / "scripts/evaluate_audio.py"),
                "--upstream",
                p["quality_upstream"],
                "--assets",
                p["quality_assets"],
                "--corpus",
                p["corpus"],
                "--benchmark",
                str(OUT / (arm + "-gpu6") / "benchmark"),
                "--labels",
                "c64-r0",
                "--output",
                str(output),
                "--batch-size",
                "8",
            ]
            env = environment(p, arm)
            env["HF_MODULES_CACHE"] = p["quality_hf_modules"]
            report["arms"][arm] = run_monitored(
                command,
                env,
                OUT / (arm + "-quality-runner"),
                p,
                p["quality_watchdog_seconds_per_arm"],
            )
            save(OUT / "quality-result.json", report)
        verify_protocol(p)
        report["status"] = "SCORING_COMPLETE"
    except BaseException as exc:
        report.update(status="FAIL", error=f"{type(exc).__name__}: {exc}")
        raise
    finally:
        save(OUT / "quality-result.json", report)
    summarize(p)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("phase", choices=("pair", "quality", "summarize"))
    args = parser.parse_args()
    p = load_protocol()
    {"pair": pair, "quality": quality, "summarize": summarize}[args.phase](p)


if __name__ == "__main__":
    main()
