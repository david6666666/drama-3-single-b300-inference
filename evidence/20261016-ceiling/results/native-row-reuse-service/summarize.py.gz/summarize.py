"""CPU-only full-workload accounting. Never trim drain or reject quality outliers."""

import collections
import json
import math
import re
from pathlib import Path

from common import OUT, finite, require, save


def read_records(path):
    return [json.loads(line) for line in Path(path).read_text().splitlines()]


def service_arm(p, arm):
    directory = OUT / (arm + "-gpu6")
    bench = directory / "benchmark"
    metrics_list = json.loads((bench / "summary.json").read_text())
    require(len(metrics_list) == 1, "exactly one C64 repeat required")
    metrics = metrics_list[0]
    require(
        metrics["requests"] == metrics["completed"] == 1088
        and metrics["failed"] == 0
        and metrics["valid"],
        "incomplete service results",
    )
    require(
        metrics["concurrency"] == 64 and metrics["repeat"] == 0, "wrong measured run"
    )
    require(
        all(
            finite(metrics[k]) and metrics[k] > 0
            for k in (
                "makespan_s",
                "throughput_frames_s",
                "ttfa_p50_ms",
                "ttfa_p95_ms",
                "rtf_mean",
            )
        ),
        "invalid service metrics",
    )
    rows = read_records(bench / "c64-r0.jsonl")
    samples = read_records(p["corpus"])
    expected = {f"c64-r0-{i:05d}": sample["id"] for i, sample in enumerate(samples)}
    require(
        len(rows) == 1088 and len({r["request_id"] for r in rows}) == 1088,
        "missing or duplicate request",
    )
    require(
        {r["request_id"]: r["sample_id"] for r in rows} == expected,
        "request/corpus identity changed",
    )
    require(
        all(
            r["success"]
            and r["audio_samples"] > 0
            and math.isclose(r["acoustic_frames"], r["audio_samples"] / 2048)
            for r in rows
        ),
        "invalid raw request outputs",
    )
    frames = sum(r["audio_samples"] for r in rows) / 2048
    require(
        math.isclose(
            frames / metrics["makespan_s"],
            metrics["throughput_frames_s"],
            rel_tol=1e-12,
        ),
        "throughput/makespan accounting mismatch",
    )
    warmup = json.loads((bench / "c64-warmup.json").read_text())
    require(
        len(warmup) == 64 and all(r["success"] for r in warmup), "64 warmups must pass"
    )
    launch = json.loads((directory / "launch.json").read_text())
    require(
        launch["source_sha"] == p["source_sha"] and not launch["source_status"],
        "arm source mismatch",
    )
    expected_env = dict(p["common_flags"], **p["arm_flags"][arm])
    require(
        launch["runtime_environment"] == expected_env,
        "arm runtime flags differ from protocol",
    )
    require(
        finite(launch["startup_to_readiness_s"])
        and launch["startup_to_readiness_s"] > 0,
        "readiness missing",
    )
    log = (directory / "server.log").read_text()
    require(
        "Application shutdown complete" in log, "server did not drain and shut down"
    )
    process = re.search(r"Started server process \[(\d+)\]", log)
    require(process is not None, "server PID missing")
    counts = []
    for line in log.splitlines():
        try:
            value = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(value, dict) and "row_reuse_counts" in value:
            counts.append(value["row_reuse_counts"])
    if arm == "candidate":
        require(
            len(counts) == 1, "candidate row-reuse coverage counter missing or repeated"
        )
        c = counts[0]
        require(
            c["opportunities"]
            == c["used"] + c["unsupported_shape"] + c["no_fitting_bucket"],
            "coverage counts inconsistent",
        )
        require(
            c["used"] >= 0
            and c["removed_rows"] >= 0
            and c["mapping_cpu_ms"] >= c["mapping_cpu_ms_max"] >= 0,
            "invalid row-reuse counters",
        )
    else:
        require(not counts, "default-off control unexpectedly reported row reuse")
    start = min(r["dispatch_s"] for r in rows)
    last_dispatch = max(r["dispatch_s"] for r in rows)
    finish = max(r["dispatch_s"] + r["completion_s"] for r in rows)
    duration = finish - start
    intake = last_dispatch - start
    chunks_after = sum(
        size
        for r in rows
        for delay, size in zip(r["chunk_arrivals_s"], r["chunk_bytes"], strict=True)
        if r["dispatch_s"] + delay >= last_dispatch
    )
    audits = read_records(OUT / (arm + "-service-runner") / "process-audit.jsonl")
    memory = {
        "overall_observed_peak_mib": max(
            (sum(x["memory_mib"] for x in a["processes"]) for a in audits), default=0
        )
    }
    for ready, name in (
        (False, "before_readiness_observed_peak_mib"),
        (True, "after_readiness_observed_peak_mib"),
    ):
        memory[name] = max(
            (
                sum(x["memory_mib"] for x in a["processes"])
                for a in audits
                if a.get("readiness_observed") is ready
            ),
            default=None,
        )
    memory["qualification"] = (
        "One-second observed process-memory peaks; phase boundary is controller first observation of launch.json readiness, not exact GPU capture boundary."
    )
    return {
        "metrics": metrics,
        "server_pid": int(process.group(1)),
        "startup_to_readiness_s": launch["startup_to_readiness_s"],
        "warmup_requests": len(warmup),
        "row_reuse_counts": counts[0] if counts else None,
        "memory": memory,
        "output": {
            "frames": frames,
            "audio_samples": sum(r["audio_samples"] for r in rows),
            "audio_duration_s": sum(r["audio_duration_s"] for r in rows),
            "frames_at_least_500": sum(r["acoustic_frames"] >= 500 for r in rows),
            "finish_reasons": dict(
                collections.Counter(r["finish_reason"] for r in rows)
            ),
        },
        "client_schedule": {
            "first_dispatch_to_final_completion_s": duration,
            "intake_duration_s": intake,
            "last_dispatch_to_final_completion_s": finish - last_dispatch,
            "requests_finishing_after_last_dispatch": sum(
                r["dispatch_s"] + r["completion_s"] > last_dispatch for r in rows
            ),
            "transport_frames_received_after_last_dispatch": chunks_after / 4096,
            "mean_active_requests_all": sum(r["completion_s"] for r in rows) / duration,
            "mean_active_requests_intake": sum(
                max(
                    0,
                    min(r["dispatch_s"] + r["completion_s"], last_dispatch)
                    - r["dispatch_s"],
                )
                for r in rows
            )
            / intake,
            "qualification": "Client lifecycle/PCM arrival accounting; includes initial ramp and tail. Does not identify GPU compute, model frames at generation time, or codec causality.",
        },
    }


def quality_arm(p, arm):
    quality = json.loads((OUT / (arm + "-quality.json")).read_text())["groups"][
        "c64-r0"
    ]
    require(
        quality["complete"]
        and quality["wer"]["evaluated"] == 1088
        and quality["similarity"]["evaluated"] == 1088,
        "quality incomplete",
    )
    require(
        quality["wer"]["skipped"] == 0 and quality["similarity"]["skipped"] == 0,
        "quality filtering forbidden",
    )
    records = quality["records"]
    expected = {
        r["request_id"]: r["sample_id"]
        for r in read_records(OUT / (arm + "-gpu6") / "benchmark/c64-r0.jsonl")
    }
    require(
        len(records) == 1088 and len({r["request_id"] for r in records}) == 1088,
        "quality missing/duplicate records",
    )
    require(
        {r["request_id"]: r["sample_id"] for r in records} == expected,
        "quality identity mismatch",
    )
    require(
        all(
            r["is_success"]
            and not r.get("error")
            and finite(r["wer"])
            and finite(r["speaker_similarity"])
            for r in records
        ),
        "missing or failed individual quality score",
    )
    wer, sim = quality["wer"]["wer_corpus"], quality["similarity"]["mean"]
    require(finite(wer) and finite(sim), "invalid aggregate quality")
    return {
        "wer": quality["wer"],
        "similarity": quality["similarity"],
        "complete": True,
        "gate_passed": wer <= p["quality_limits"]["wer_corpus_max"]
        and sim >= p["quality_limits"]["sim_min"],
    }


def summarize(p):
    result = {
        "source_sha": p["source_sha"],
        "concurrency": 64,
        "requests_per_arm": 1088,
        "repeats": 1,
        "arms": {},
        "target_status": "INCONCLUSIVE",
        "qualification": "One feasibility AB pair with potentially different outputs; not a replicated or fixed-output speedup claim. The all-concurrency 1.5x target remains unproven.",
    }
    raw = {}
    for arm in p["order"]:
        result["arms"][arm] = dict(service_arm(p, arm), quality=quality_arm(p, arm))
        raw[arm] = {
            r["request_id"]: r
            for r in read_records(OUT / (arm + "-gpu6") / "benchmark/c64-r0.jsonl")
        }
    a, b = result["arms"]["control"], result["arms"]["candidate"]
    ratio = b["metrics"]["throughput_frames_s"] / a["metrics"]["throughput_frames_s"]
    activated = (
        b["row_reuse_counts"]["used"] > 0 and b["row_reuse_counts"]["removed_rows"] > 0
    )
    passed = (
        ratio >= p["continuation"]["minimum_fps_ratio"]
        and a["quality"]["gate_passed"]
        and b["quality"]["gate_passed"]
        and activated
    )
    result.update(
        status="SINGLE_FEASIBILITY_PASS_REQUIRES_REVIEW"
        if passed
        else "SINGLE_FEASIBILITY_FAIL_STOP",
        continuation_passed=passed,
        actual_candidate_activation=activated,
    )
    result["comparison"] = {
        "fps_ratio": ratio,
        "makespan_ratio": b["metrics"]["makespan_s"] / a["metrics"]["makespan_s"],
        "output_frames_ratio": b["output"]["frames"] / a["output"]["frames"],
        "ttfa_p50_delta_ms": b["metrics"]["ttfa_p50_ms"] - a["metrics"]["ttfa_p50_ms"],
        "ttfa_p95_delta_ms": b["metrics"]["ttfa_p95_ms"] - a["metrics"]["ttfa_p95_ms"],
        "rtf_mean_delta": b["metrics"]["rtf_mean"] - a["metrics"]["rtf_mean"],
        "wer_delta_percentage_points": 100
        * (b["quality"]["wer"]["wer_corpus"] - a["quality"]["wer"]["wer_corpus"]),
        "sim_delta": b["quality"]["similarity"]["mean"]
        - a["quality"]["similarity"]["mean"],
        "same_audio_hash_requests": sum(
            raw["control"][k]["audio_sha256"] == raw["candidate"][k]["audio_sha256"]
            for k in raw["control"]
        ),
        "same_frame_count_requests": sum(
            raw["control"][k]["acoustic_frames"]
            == raw["candidate"][k]["acoustic_frames"]
            for k in raw["control"]
        ),
    }
    result["c64_target"] = {
        "frames_s": p["target_frames_s"],
        "candidate_to_vllm_ratio": b["metrics"]["throughput_frames_s"]
        / p["vllm_baseline_frames_s"],
        "observed_fps_threshold_met": b["metrics"]["throughput_frames_s"]
        >= p["target_frames_s"],
        "formal_success": False,
    }
    save(OUT / "summary.json", result)
    print(json.dumps(result, indent=2, allow_nan=False))
    return result
