"""CPU-only guard negatives and complete archived-workload parser checks."""

import ast
import copy
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

import common as c
import run_experiment  # noqa: F401 - import guard: must not launch any work.
import summarize as s

checks = []


def check(name, value):
    checks.append({"name": name, "passed": bool(value)})
    c.require(value, name)


def reject(name, callback):
    try:
        callback()
    except (RuntimeError, KeyError, FileNotFoundError):
        check(name, True)
    else:
        check(name, False)


p = json.loads((c.OUT / "protocol-draft.json").read_text())
c.verify_protocol(p, frozen=False)
check("draft_source_and_flags_CPU_pass", True)
reject("draft_launch_rejected", lambda: c.verify_protocol(p))
gate = {
    "original_AA_passed": True,
    "status": "PASS",
    "exact_passed": True,
    "source_sha": c.SOURCE_SHA,
    "pool_interleaving_passed": True,
    "retained_outputs_passed": True,
    "all111_states": True,
    "five_bucket_coverage": c.BUCKETS,
    "capture_orders": ["ascending", "descending"],
    "checks": [{"passed": True}],
    "cases": [{"passed": True}],
}
c.verify_exact(gate)
check("synthetic_complete_gate_contract_accepted_not_a_real_GPU_gate", True)
for key, bad in [
    ("original_AA_passed", False),
    ("status", "FAIL"),
    ("exact_passed", False),
    ("source_sha", "wrong"),
    ("pool_interleaving_passed", False),
    ("retained_outputs_passed", False),
    ("all111_states", False),
    ("five_bucket_coverage", c.BUCKETS[:-1]),
    ("capture_orders", ["ascending"]),
    ("checks", []),
    ("checks", [{"passed": False}]),
    ("cases", []),
    ("cases", [{"passed": False}]),
]:
    broken = copy.deepcopy(gate)
    broken[key] = bad
    reject(
        "reject_gate/" + key + "/" + str(bad),
        lambda broken=broken: c.verify_exact(broken),
    )
for key, value in [("requests", 64), ("source_sha", "wrong"), ("repeats", 3)]:
    broken = copy.deepcopy(p)
    broken[key] = value
    reject(
        "reject_protocol/" + key,
        lambda broken=broken: c.verify_protocol(broken, frozen=False),
    )
broken = copy.deepcopy(p)
broken["common_flags"]["DRAMA3_FRAME_PIPELINE"] = "0"
reject("reject_other_flag_change", lambda: c.verify_protocol(broken, frozen=False))
old = os.environ.get("DRAMA3_UNREVIEWED_TEST")
os.environ["DRAMA3_UNREVIEWED_TEST"] = "1"
try:
    a, b = c.environment(p, "control"), c.environment(p, "candidate")
    check("inherited_DRAMA3_removed", "DRAMA3_UNREVIEWED_TEST" not in a)
    check(
        "only_one_arm_env_difference",
        {k for k in a if a[k] != b[k]} == {"DRAMA3_MIXED_ROW_REUSE"},
    )
    check(
        "benchmark_client_pinned_source",
        a["PYTHONPATH"] == str(Path(p["source"]) / "src"),
    )
finally:
    if old is None:
        del os.environ["DRAMA3_UNREVIEWED_TEST"]
    else:
        os.environ["DRAMA3_UNREVIEWED_TEST"] = old
check("current_process_identity", c.process_identity(os.getpid())[1] > 0)
child = subprocess.Popen(["sleep", "1"])
try:
    check("child_ownership", c.descendant(child.pid, os.getpid()))
    check("ancestor_not_child", not c.descendant(os.getppid(), child.pid))
finally:
    child.terminate()
    child.wait()
# Replay the parser against preserved full service data; no model execution and no
# mutation of original logs. This is a parser fixture, not evidence for row reuse.
with tempfile.TemporaryDirectory(prefix="row-reuse-controller-cpu-") as temp:
    t = Path(temp)
    original = s.OUT
    try:
        s.OUT = t
        (t / "control-gpu6").symlink_to(
            c.ROOT / "codec-cache-control-gpu6", target_is_directory=True
        )
        (t / "control-quality.json").symlink_to(
            c.ROOT / "codec-cache-control-quality.json"
        )
        (t / "control-service-runner").mkdir()
        (t / "control-service-runner/process-audit.jsonl").write_text(
            json.dumps({"processes": [], "readiness_observed": False}) + "\n"
        )
        archived = copy.deepcopy(p)
        archived["source_sha"] = "e7cda1eba083603b88e1f2e89688e1ff2ced7fc2"
        archived["arm_flags"]["control"] = {}
        arm = s.service_arm(archived, "control")
        quality = s.quality_arm(archived, "control")
        check(
            "archived_all1088_service_parser",
            arm["metrics"]["completed"] == 1088 and arm["output"]["frames"] == 101529,
        )
        check(
            "archived_full_quality_parser",
            quality["complete"]
            and quality["wer"]["evaluated"] == 1088
            and quality["similarity"]["evaluated"] == 1088,
        )
        check(
            "client_tail_retained",
            arm["client_schedule"]["last_dispatch_to_final_completion_s"] > 0,
        )
        check(
            "throughput_unchanged_by_tail_accounting",
            arm["metrics"]["throughput_frames_s"] == 4726.77149517109,
        )
    finally:
        s.OUT = original
for path in c.OUT.glob("*.py"):
    ast.parse(path.read_text())
check(
    "no_torch_or_cuda_import", "torch" not in sys.modules and "cuda" not in sys.modules
)
c.save(
    c.OUT / "cpu-check.json",
    {
        "status": "CPU_CONTROLS_AND_ARCHIVED_PARSER_PASS",
        "checks": checks,
        "gpu_used": False,
        "files": {p.name: c.sha(p) for p in c.OUT.glob("*.py")},
    },
)
print(json.dumps({"status": "PASS", "checks": len(checks), "gpu_used": False}))
