"""Frozen production graph exact gate; synthetic EOS is a separate diagnostic."""

import gc
import hashlib
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "source-pipeline-a7118fb"
sys.path.insert(0, str(SOURCE / "src"))
sys.path.insert(0, str(SOURCE / "scripts"))
import torch
import torch.nn.functional as F
import triton
from fish_speech.models.text2semantic.fish_omni.generate import build_drama3_prompt
from validate_mixed_layers import Checks, restore, snapshot, state_tensors
from drama3.engine import BatchedPrefillGraph, DecodeGraph, state_pool_size
from drama3.frame_pipeline import FramePipelineGraph
from drama3.model import DramaModel
import drama3.model as model_module
from drama3.runtime_state import DeviceRequests

CHECKPOINT = "/home/zjy/.cache/huggingface/hub/models--fishaudio--drama-3/snapshots/e0a9218aa48888270f06ef1ed9ea67622c0e17d2"
CORPUS = Path(
    "/home/zjy/code/hsliu/artifacts/drama3-b300-20261014/seedtts-en1088-codes/requests.jsonl"
)


@torch.inference_mode()
def main():
    checks = Checks(
        ROOT / "frame-pipeline-production-fixed-validation.json",
        dict(
            source_sha=subprocess.check_output(
                ["git", "rev-parse", "HEAD"], cwd=SOURCE, text=True
            ).strip(),
            source_status=subprocess.check_output(
                ["git", "status", "--porcelain"], cwd=SOURCE, text=True
            ),
            driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            corpus_sha256=hashlib.sha256(CORPUS.read_bytes()).hexdigest(),
            gpu_uuid=str(torch.cuda.get_device_properties(0).uuid),
            environment={
                k: v for k, v in os.environ.items() if k.startswith("DRAMA3_")
            },
            experiment=json.loads(
                (ROOT / "frame-pipeline-production-fixed-experiment.json").read_text()
            ),
        ),
    )
    try:
        assert (
            checks.report["metadata"]["source_sha"]
            == "a7118fb7eb748d08c3b774fa6c9189b6eab0d9cc"
        )
        assert checks.report["metadata"]["source_status"] == ""
        model = DramaModel(CHECKPOINT, slots=state_pool_size(64), max_length=2048)
        assert model.reserved_padding_router and model.fused_moe_residual
        assert model.moe_shared_stream is None
        device = DeviceRequests(
            model.slots, model.config.eos_token_id, model.max_length
        )
        samples = [json.loads(line) for line in CORPUS.read_bytes().splitlines()][:64]
        prompts = [
            build_drama3_prompt(
                s["text"],
                model.weights.tokenizer,
                model.config,
                [s["reference_text"]],
                [torch.tensor(s["reference_codes"])],
            )
            for s in samples
        ]
        prefill = BatchedPrefillGraph(
            model, 8, triton.next_power_of_2(max(map(len, prompts)))
        )
        first = DecodeGraph(model, 8, first_frame=True, requests=device)
        tensors = state_tensors(model, device)

        def initialize(count, *, reuse=False):
            slots = list(reversed(range(64)))[:count] if reuse else list(range(count))
            active = [
                SimpleNamespace(slot=slot, position=len(prompts[i]) - 1)
                for i, slot in enumerate(slots)
            ]
            for i, slot in enumerate(slots):
                p = prompts[i]
                history = F.pad(p[-16:, 0], (max(0, 16 - len(p)), 0), value=-1).cuda()
                device.initialize(slot, p[-1].cuda(), history, len(p) - 1, 500)
            for start in range(0, count, 8):
                end = min(start + 8, count)
                hidden = prefill.run(prompts[start:end], slots[start:end])
                first.run(active[start:end], hidden)
            return active

        def compare(
            label,
            size,
            count,
            serial,
            pipeline,
            *,
            max_boundary=False,
            reuse=False,
            force_step=None,
        ):
            active = initialize(count, reuse=reuse)
            first_slot = active[0].slot
            if max_boundary:
                device.metadata[first_slot, 2].copy_(device.metadata[first_slot, 1] + 1)
            if force_step is not None:
                force_step.copy_(model.sampling_step + 1)
            slots = [r.slot for r in active] + list(
                range(model.slots // 2 + count, model.slots // 2 + size)
            )
            other = torch.tensor(
                [s for s in range(model.slots) if s not in slots], device="cuda"
            )
            initial = snapshot(tensors.values())
            serial_output = serial.run(active).clone()
            expected_state = snapshot(tensors.values())
            restore(tensors.values(), initial)
            output = pipeline.run(active).clone()
            checks.tensor(label + "/frames", output, serial_output, exact=True)
            for (name, value), saved, before in zip(
                tensors.items(), expected_state, initial, strict=True
            ):
                checks.tensor(label + "/state/" + name, value, saved, exact=True)
                if name != "sampling_step":
                    checks.tensor(
                        label + "/untouched/" + name,
                        value.index_select(0, other),
                        before.index_select(0, other),
                        exact=True,
                    )
            if max_boundary:
                assert int(device.metadata[first_slot, 3]) == 1
            if force_step is not None:
                assert int(output[0, 0, 0]) == model.config.eos_token_id
                assert int(device.metadata[first_slot, 3]) == 1
                for (name, value), before in zip(tensors.items(), initial, strict=True):
                    if name in ("request_last", "request_history", "request_codes"):
                        checks.tensor(
                            label + "/eos_append_mask/" + name,
                            value[first_slot],
                            before[first_slot],
                            exact=True,
                        )
                    if name == "request_metadata":
                        expected = before[first_slot].clone()
                        expected[3] = 1
                        checks.tensor(
                            label + "/eos_append_mask/metadata",
                            value[first_slot],
                            expected,
                            exact=True,
                        )
            expected_hidden = pipeline.next_hidden.clone()
            del expected_state, output
            restore(tensors.values(), initial)
            eager = pipeline.forward()
            checks.tensor(
                label + "/eager_frames", eager[:, :count], serial_output, exact=True
            )
            checks.tensor(
                label + "/eager_hidden2",
                pipeline.next_hidden,
                expected_hidden,
                exact=True,
            )
            eager_state = snapshot(tensors.values())
            restore(tensors.values(), initial)
            pipeline.graph.replay()
            for (name, value), saved in zip(tensors.items(), eager_state, strict=True):
                checks.tensor(
                    label + "/capture_eager_state/" + name, value, saved, exact=True
                )
            result = dict(
                case=label,
                batch_size=size,
                actual_requests=count,
                max_frames_boundary=max_boundary,
                reversed_reused_slots=reuse,
                synthetic_first_eos=force_step is not None,
                passed=True,
            )
            checks.report["cases"].append(result)
            checks.flush()
            print(json.dumps(result), flush=True)
            del initial, serial_output, eager_state, expected_hidden

        # Each pair is captured before its real prompt initialization.
        serial64 = DecodeGraph(model, 64, steps=2, requests=device)
        pipeline64 = FramePipelineGraph(model, 64, device)
        compare("real-b64", 64, 64, serial64, pipeline64)
        compare("real-partial58", 64, 58, serial64, pipeline64)
        compare("real-partial58-reused-slots", 64, 58, serial64, pipeline64, reuse=True)
        compare("real-b64-maxframes", 64, 64, serial64, pipeline64, max_boundary=True)
        serial32 = DecodeGraph(model, 32, steps=2, requests=device)
        pipeline32 = FramePipelineGraph(model, 32, device)
        compare("real-b32", 32, 32, serial32, pipeline32)
        for size in (16, 24, 40, 48, 56):
            serial = DecodeGraph(model, size, steps=2, requests=device)
            pipeline = FramePipelineGraph(model, size, device)
            compare(f"real-capacity{size}", size, size, serial, pipeline)
            del serial, pipeline
            gc.collect()

        # Synthetic scheduling boundary ONLY: run the native sampler, then inject
        # EOS for row0/stream0 at a single declared sampling_step. No timed graph
        # or real-input gate above uses this wrapper. All codebook samples run.
        native_sample = model_module.sample
        force_step = torch.full((), -1, dtype=torch.int64, device="cuda")
        eos_index = int((model.candidates == model.config.eos_token_id).nonzero()[0, 0])

        def inject_first_eos(logits, step, stream, **kwargs):
            result = native_sample(logits, step, stream, **kwargs)
            if stream == 0:
                row0 = torch.arange(len(result), device=result.device) == 0
                result = torch.where(row0 & (step == force_step), eos_index, result)
            return result

        model_module.sample = inject_first_eos
        try:
            serial_eos = DecodeGraph(model, 64, steps=2, requests=device)
            pipeline_eos = FramePipelineGraph(model, 64, device)
            compare(
                "synthetic-first-eos-b64",
                64,
                64,
                serial_eos,
                pipeline_eos,
                force_step=force_step,
            )
        finally:
            model_module.sample = native_sample
        del serial_eos, pipeline_eos
        gc.collect()

        # Timing starts only after EVERY declared exact case has passed. These
        # normal graphs were captured before the synthetic sampler wrapper.
        checks.report["timing"] = []
        for label, count, serial, pipeline in (
            ("real-b64", 64, serial64, pipeline64),
            ("real-partial58", 58, serial64, pipeline64),
            ("real-b32", 32, serial32, pipeline32),
        ):
            active = initialize(count)
            # run() refreshes the selected slots. Restore before every timed replay.
            serial.run(active)
            pipeline.run(active)
            active = initialize(count)
            initial = snapshot(tensors.values())
            timings = {"serial_ms": [], "pipeline_ms": []}
            for iteration in range(6):
                arms = [("serial_ms", serial), ("pipeline_ms", pipeline)]
                if iteration % 2:
                    arms.reverse()
                for name, graph in arms:
                    restore(tensors.values(), initial)
                    begin, end = (
                        torch.cuda.Event(enable_timing=True) for _ in range(2)
                    )
                    begin.record()
                    graph.graph.replay()
                    end.record()
                    end.synchronize()
                    if iteration:
                        timings[name].append(begin.elapsed_time(end))
            medians = {k: statistics.median(v) for k, v in timings.items()}
            result = dict(
                case=label,
                two_frames=True,
                timings=timings,
                median_ms=medians,
                latency_decrease_ms=medians["serial_ms"] - medians["pipeline_ms"],
            )
            checks.report["timing"].append(result)
            checks.flush()
            print(json.dumps(result), flush=True)
            del initial
        checks.report["source_status_after"] = subprocess.check_output(
            ["git", "status", "--porcelain"], cwd=SOURCE, text=True
        )
        assert checks.report["source_status_after"] == ""
        checks.report["status"] = "PASS"
        checks.flush()
    except Exception as error:
        checks.report["status"] = "FAIL"
        checks.report["failure"] = dict(type=type(error).__name__, message=str(error))
        checks.flush()
        raise


if __name__ == "__main__":
    main()
