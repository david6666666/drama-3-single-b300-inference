"""Read-only upstream stage1 CPU schedule/graph-launch accounting, no inferred graph shapes."""
import gzip,hashlib,json,re,statistics
from pathlib import Path
from collections import Counter,defaultdict
p=Path('/home/zjy/code/hsliu/artifacts/drama3-mixed-20261016/vllm-continuous-profile/traces/20261015-164759_stage1_rank0_1792082879/trace_rank0.json.gz')
x=json.load(gzip.open(p,'rt'));events=x['traceEvents'];steps=[]
for r in events:
 if r.get('cat')=='user_annotation' and r.get('ph')=='X':
  m=re.fullmatch(r'execute_context_(\d+)\((\d+)\)_generation_(\d+)\((\d+)\)',r.get('name',''))
  if m:steps.append((r,int(m[1])))
nonempty=[(r,n) for r,n in steps if n]
gcalls=[r for r in events if r.get('name')=='cudaGraphLaunch' and r.get('ph')=='X']
bycorr=defaultdict(list)
for r in events:
 if r.get('cat')=='kernel':bycorr[r['args'].get('correlation')].append(r)
per=[]
for r,n in nonempty:
 calls=[g for g in gcalls if g['tid']==r['tid'] and r['ts']<=g['ts']<=r['ts']+r['dur']]
 spans=[]
 for call in calls:
  kernels=bycorr[call['args'].get('correlation')]
  if kernels:spans.append((max(k['ts']+k['dur'] for k in kernels)-min(k['ts'] for k in kernels))/1000)
 per.append(dict(jobs=n,graph_calls=len(calls),cpu_ms=r['dur']/1000,graph_gpu_spans_ms=spans))
assert sum(r['graph_calls'] for r in per)==len(gcalls)
spans=[s for row in per for s in row['graph_gpu_spans_ms']]
result=dict(source=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),context_steps=len(steps),empty_context_steps=len(steps)-len(nonempty),
 nonempty_context_steps=len(nonempty),scheduled_jobs=sum(n for r,n in nonempty),scheduled_jobs_per_nonempty_context=statistics.mean(n for r,n in nonempty),
 actual_cuda_graph_launches=len(gcalls),scheduled_jobs_per_graph_launch=sum(n for r,n in nonempty)/len(gcalls),
 jobs_histogram=dict(sorted(Counter(n for r,n in nonempty).items())),graph_calls_per_nonempty_context=dict(sorted(Counter(r['graph_calls'] for r in per).items())),
 correlated_graph_gpu_spans=dict(n=len(spans),mean_ms=statistics.mean(spans),sum_ms=sum(spans)),
 diagnostic_trace_cpu_span_s=(max(r['ts']+r['dur'] for r,n in steps)-min(r['ts'] for r,n in steps))/1e6,
 caveats=['Archived256request C64 profile, not matched1088 work or noninstrumentedperformance.',
 'Context annotation counts scheduled codec jobs; actual graph input batches/frame buckets are not exposed by the trace and are NOT inferred.',
 'GraphGPUspan from all kernels sharing runtime launch correlation; includes intervening waits/contention and is not the sum of kernel durations.',
 'Do not count empty polling contexts or graph/kernel events as extra scheduler steps.',
 'Simple average scheduled jobs/graphlaunch assumes normal valid nonempty streamed jobs; do not interpret it as capacity, padding, or same-workcomparison.'])
(Path(__file__).parent/'upstream-codec-trace-accounting.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
