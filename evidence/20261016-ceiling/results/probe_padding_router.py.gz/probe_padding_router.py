"""Actual native FI padding-only expert footprint, no routing modification."""
import hashlib,json,os,sys,subprocess
from pathlib import Path
from types import SimpleNamespace
ROOT=Path('/home/zjy/code/hsliu/artifacts/drama3-ceiling-20261016')
SOURCE=ROOT/'source-moe-residual-6ff8d80'
sys.path.insert(0,str(SOURCE/'src'))
import torch,triton
import torch.nn.functional as F
from fish_speech.models.text2semantic.fish_omni.generate import build_drama3_prompt
import drama3.model as model_module
from drama3.engine import BatchedPrefillGraph,DecodeGraph,state_pool_size
from drama3.model import DramaModel
from drama3.runtime_state import DeviceRequests
CHECKPOINT='/home/zjy/.cache/huggingface/hub/models--fishaudio--drama-3/snapshots/e0a9218aa48888270f06ef1ed9ea67622c0e17d2'
CORPUS=Path('/home/zjy/code/hsliu/artifacts/drama3-b300-20261014/seedtts-en1088-codes/requests.jsonl')
report=dict(source_sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip(),source_status=subprocess.check_output(['git','status','--porcelain'],cwd=SOURCE,text=True),driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),corpus_sha256=hashlib.sha256(CORPUS.read_bytes()).hexdigest(),gpu_uuid=str(torch.cuda.get_device_properties(0).uuid),environment={k:v for k,v in os.environ.items() if k.startswith('DRAMA3_')},status='RUNNING',cases=[])
def flush():
 (ROOT/'padding-router-probe.json').write_text(json.dumps(report,indent=2)+'\n')

@torch.inference_mode()
def main():
 flush()
 try:
  model=DramaModel(CHECKPOINT,slots=state_pool_size(64),max_length=2048)
  assert model.fused_moe_input and model.prefill_moe=='flashinfer' and model.moe_shared_stream is None
  device=DeviceRequests(model.slots,model.config.eos_token_id,model.max_length)
  samples=[json.loads(line) for line in CORPUS.read_bytes().splitlines()][:64]
  prompts=[build_drama3_prompt(s['text'],model.weights.tokenizer,model.config,[s['reference_text']],[torch.tensor(s['reference_codes'])]) for s in samples]
  prefill=BatchedPrefillGraph(model,8,triton.next_power_of_2(max(map(len,prompts))))
  first=DecodeGraph(model,8,first_frame=True,requests=device)
  decode=DecodeGraph(model,64,requests=device)
  original=model.routed_moe
  fi=model_module.trtllm_fp8_block_scale_moe
  indices={id(layer.mlp.experts):i for i,layer in enumerate(model.backbone.layers)}
  for count in (58,63):
   active=[SimpleNamespace(slot=i,position=len(prompts[i])-1) for i in range(count)]
   for i,p in enumerate(prompts[:count]):
    history=F.pad(p[-16:,0],(max(0,16-len(p)),0),value=-1).cuda()
    device.initialize(i,p[-1].cuda(),history,len(p)-1,500)
   for start in range(0,count,8):
    end=min(start+8,count)
    hidden=prefill.run(prompts[start:end],list(range(start,end)))
    first.run(active[start:end],hidden)
   for _ in range(8):
    decode.run(active)
   row=dict(real_rows=count,batch_rows=64,padding_slots=decode.slots[count:].tolist(),decode_positions=decode.positions[:count].tolist(),completed_real_slots=device.metadata[:count,3].nonzero().flatten().tolist(),layers=[])
   report['cases'].append(row)
   saved={}
   def record(x,router,experts,decode_flag):
    index=indices[id(experts)]
    reference=original(x,router,experts,decode_flag)
    ids=torch.full((len(x),8),-1,dtype=torch.int16,device='cuda')
    def routing(*args,**kwargs):
     return fi(*args,**kwargs,routing_replay_out=ids)
    model_module.trtllm_fp8_block_scale_moe=routing
    try:
     candidate=original(x,router,experts,decode_flag)
    finally:
     model_module.trtllm_fp8_block_scale_moe=fi
    exact=torch.equal(reference,candidate)
    valid=bool(((ids>=0)&(ids<256)).all())
    all_ids=set(ids.flatten().tolist())
    real_ids=set(ids[:count].flatten().tolist())
    exclusive=sorted(all_ids-real_ids)
    result=dict(layer=index,route_capture_exact=exact,route_ids_valid=valid,all_experts=len(all_ids),real_experts=len(real_ids),padding_only_experts=exclusive,padding_only_weight_bytes=len(exclusive)*3145728,all_weight_bytes=len(all_ids)*3145728,all_expert_counts=torch.bincount(ids.long().flatten(),minlength=256).tolist(),real_expert_counts=torch.bincount(ids[:count].long().flatten(),minlength=256).tolist())
    row['layers'].append(result)
    flush()
    if not exact or not valid:
     raise AssertionError(result)
    saved[index]=dict(x=x.cpu(),router=router.cpu(),ids=ids.cpu(),routed=reference.cpu())
    return reference
   model.routed_moe=record
   try:
    decode.forward()
   finally:
    model.routed_moe=original
   assert [x['layer'] for x in row['layers']]==list(range(40))
   exclusive=sum(len(x['padding_only_experts']) for x in row['layers'])
   total=sum(x['all_experts'] for x in row['layers'])
   row['sum_padding_only_experts']=exclusive
   row['sum_all_experts']=total
   row['fraction_logical_weight_bytes_from_padding']=exclusive/total
   row['padding_only_weight_bytes']=exclusive*3145728
   torch.save(saved,ROOT/f'padding-router-b{count}-native-inputs.pt')
   flush()
   print(json.dumps({k:v for k,v in row.items() if k!='layers'}),flush=True)
  report['status']='COMPLETE'
  report['limitations']=['Two partial B64 inputs after first frames and eight native decode steps; not a service distribution.','Per-layer actual FI routing IDs, and exact routed output checked against calls without capture.','Unique logical expert weight bytes approximate a bandwidth budget, not measured DRAM or a guaranteed latency saving.','No dummy routes, logits, activation quantization, real outputs or states were changed.']
  flush()
 except Exception as e:
  report['status']='FAIL';report['failure']=dict(type=type(e).__name__,message=str(e));flush();raise
if __name__=='__main__':main()
