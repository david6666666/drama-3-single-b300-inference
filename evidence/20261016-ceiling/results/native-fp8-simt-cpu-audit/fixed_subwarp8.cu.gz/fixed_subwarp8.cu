// Artifact-only fixed mapping. No launch/registration or production integration.
#include <cuda_fp8.h>
#include <cuda_bf16.h>
#include <cuda_runtime.h>
#include <stdint.h>
__device__ __forceinline__ float2 decode_pair(uint16_t bits) {
    // E4M3 -> half -> float is exact value decoding, not dequantization.
    const __half2_raw h = __nv_cvt_fp8x2_to_halfraw2(bits, __NV_E4M3);
    return __half22float2(static_cast<__half2>(h));
}
__device__ __forceinline__ float native_scaled_fma(float group, float scale, float prior) {
    // Native SF epilogue uses FMUL without FTZ followed by FFMA2.FTZ.
    float out;
    asm("fma.rn.ftz.f32 %0, %1, %2, %3;" : "=f"(out) : "f"(group), "f"(scale), "f"(prior));
    return out;
}
template<int K, bool BF16>
__device__ __forceinline__ void grouped2_core(
    const uint8_t* __restrict__ q, const float* __restrict__ qs,
    const uint8_t* __restrict__ w, const float* __restrict__ ws,
    void* __restrict__ output, int rows, int outputs) {
    const int lane = threadIdx.x & 7;
    const int column = blockIdx.x * 16 + threadIdx.x / 8;
    if (rows == 0 || column >= outputs) return;
    float total0 = 0.0f, total1 = 0.0f;
    #pragma unroll 1
    for (int group = 0; group < K / 128; ++group) {
        float acc0 = 0.0f, acc1 = 0.0f;
        #pragma unroll
        for (int chunk = 0; chunk < 4; ++chunk) {
            const int k = group * 128 + chunk * 32 + lane * 4;
            const uint32_t pw = *reinterpret_cast<const uint32_t*>(w + column * K + k);
            const float2 w01 = decode_pair(uint16_t(pw));
            const float2 w23 = decode_pair(uint16_t(pw >> 16));
            const uint32_t p0 = *reinterpret_cast<const uint32_t*>(q + k);
            const float2 a01 = decode_pair(uint16_t(p0));
            const float2 a23 = decode_pair(uint16_t(p0 >> 16));
            acc0 = __fmaf_rn(w01.x, a01.x, acc0);
            acc0 = __fmaf_rn(w01.y, a01.y, acc0);
            acc0 = __fmaf_rn(w23.x, a23.x, acc0);
            acc0 = __fmaf_rn(w23.y, a23.y, acc0);
            if (rows == 2) {
                const uint32_t p1 = *reinterpret_cast<const uint32_t*>(q + K + k);
                const float2 b01 = decode_pair(uint16_t(p1));
                const float2 b23 = decode_pair(uint16_t(p1 >> 16));
                acc1 = __fmaf_rn(w01.x, b01.x, acc1);
                acc1 = __fmaf_rn(w01.y, b01.y, acc1);
                acc1 = __fmaf_rn(w23.x, b23.x, acc1);
                acc1 = __fmaf_rn(w23.y, b23.y, acc1);
            }
        }
        #pragma unroll
        for (int shift = 4; shift; shift /= 2) {
            acc0 = __fadd_rn(acc0, __shfl_down_sync(0xffffffff, acc0, shift, 8));
            acc1 = __fadd_rn(acc1, __shfl_down_sync(0xffffffff, acc1, shift, 8));
        }
        if (lane == 0) {
            const float weight_scale = ws[(column / 128) * (K / 128) + group];
            total0 = native_scaled_fma(acc0, __fmul_rn(qs[group * rows], weight_scale), total0);
            if (rows == 2) total1 = native_scaled_fma(acc1, __fmul_rn(qs[group * rows + 1], weight_scale), total1);
        }
    }
    if (lane == 0) {
        if constexpr (BF16) {
            static_cast<__nv_bfloat16*>(output)[column] = __float2bfloat16_rn(total0);
            if (rows == 2) static_cast<__nv_bfloat16*>(output)[outputs + column] = __float2bfloat16_rn(total1);
        } else {
            // Prequant FC1 diagnostic only, never substitutes the native FP8
            // epilogue/activation/finalizer. Those remain required boundaries.
            static_cast<float*>(output)[column] = total0;
            if (rows == 2) static_cast<float*>(output)[outputs + column] = total1;
        }
    }
}
extern "C" __global__ __launch_bounds__(128)
void fc1_grouped2_subwarp8_raw(const uint8_t* q, const float* qs,
    const uint8_t* w, const float* ws, float* output, int rows) {
    grouped2_core<2048, false>(q, qs, w, ws, output, rows, 1024);
}
extern "C" __global__ __launch_bounds__(128)
void fc2_grouped2_subwarp8_bf16(const uint8_t* q, const float* qs,
    const uint8_t* w, const float* ws, __nv_bfloat16* output, int rows) {
    grouped2_core<512, true>(q, qs, w, ws, output, rows, 2048);
}
