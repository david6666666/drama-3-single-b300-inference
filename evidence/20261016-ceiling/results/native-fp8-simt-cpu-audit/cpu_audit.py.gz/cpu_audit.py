"""CPU-only fixed 8-lane arithmetic, ownership and actual SASS issue audit."""
import collections
import ctypes
import hashlib
import json
import math
import os
import re
from contextlib import ExitStack
from pathlib import Path

os.environ['CUDA_VISIBLE_DEVICES'] = ''
os.environ['OMP_NUM_THREADS'] = '4'
import numpy as np
import torch
from safetensors import safe_open

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
CKPT = Path('/home/zjy/.cache/huggingface/hub/models--fishaudio--drama-3/snapshots/e0a9218aa48888270f06ef1ed9ea67622c0e17d2')
ORACLES = ROOT / 'expert-metadata-rebase'
libm = ctypes.CDLL('libm.so.6')
libm.fmaf.argtypes = [ctypes.c_float] * 3
libm.fmaf.restype = ctypes.c_float
F = np.float32
TINY = np.finfo(np.float32).tiny


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def bits(x):
    return int(np.asarray(x, dtype=np.float32).view(np.uint32))


def fma(a, b, c):
    return F(libm.fmaf(float(a), float(b), float(c)))


def ftz(x):
    return F(math.copysign(0.0, float(x))) if 0 < abs(float(x)) < TINY else F(x)


def native_outer(a, b, c):
    return ftz(fma(ftz(a), ftz(b), ftz(c)))


def bf16(x):
    return int(torch.tensor(float(x), dtype=torch.float32).to(torch.bfloat16).view(torch.uint16))


def subwarp8(a, w):
    acc = [F(0.0) for _ in range(8)]
    for lane in range(8):
        for chunk in range(4):
            for byte in range(4):
                k = chunk * 32 + lane * 4 + byte
                acc[lane] = fma(w[k], a[k], acc[lane])
    for shift in (4, 2, 1):
        old = list(acc)
        # CUDA shfl returns own value for a source outside its width. Only lane0
        # is stored; model every lane so the simulation matches the instruction.
        acc = [F(old[i] + old[i + shift if i + shift < 8 else i]) for i in range(8)]
    return acc[0]


def serial128(a, w):
    value = F(0.0)
    for x, y in zip(a, w, strict=True):
        value = fma(y, x, value)
    return value


def chunks32(a, w):
    # A separate CPU comparison tree, NOT a claim about hidden UMMA ordering.
    parts = [serial128(a[i:i+32], w[i:i+32]) for i in range(0, 128, 32)]
    return F(F(parts[0] + parts[1]) + F(parts[2] + parts[3]))


def dot(a, w, act_scales, weight_scales):
    trees = {'subwarp8': F(0.0), 'serial128': F(0.0), 'chunks32': F(0.0)}
    partials = []
    fp64_rounded_scale = 0.0
    fp64_original_scale = 0.0
    for group in range(len(a) // 128):
        aa, ww = a[group*128:(group+1)*128], w[group*128:(group+1)*128]
        scale = F(F(act_scales[group]) * F(weight_scales[group]))
        group64 = math.fsum(float(x) * float(y) for x, y in zip(aa, ww, strict=True))
        values = {'subwarp8': subwarp8(aa, ww), 'serial128': serial128(aa, ww), 'chunks32': chunks32(aa, ww)}
        for name, value in values.items():
            trees[name] = native_outer(value, scale, trees[name])
        partials.append({name: bits(value) for name, value in values.items()})
        fp64_rounded_scale += group64 * float(scale)
        fp64_original_scale += group64 * float(act_scales[group]) * float(weight_scales[group])
    return trees, partials, fp64_rounded_scale, fp64_original_scale


def weight(layer, expert, projection, handles, index):
    prefix = f'model.language_model.layers.{layer}.mlp.experts.{expert}.{projection}'
    return [handles[index[prefix + '.' + suffix]].get_tensor(prefix + '.' + suffix) for suffix in ('weight', 'weight_scale_inv')]


def simulate():
    index = json.loads((CKPT / 'model.safetensors.index.json').read_text())['weight_map']
    records, matrix_records = [], []
    for layer in (0, 19, 39):
        path = ORACLES / f'oracle-layer{layer}-real.pt'
        data = torch.load(path, map_location='cpu', weights_only=False)
        counts = torch.bincount(data['ids'].flatten().long(), minlength=256)
        expert = 205 if counts[205] >= 2 else int(torch.where(counts >= 2)[0][0])
        expanded = torch.where(data['ids'].flatten() == expert)[0][:2]
        tokens = expanded // 8
        keys = [f'model.language_model.layers.{layer}.mlp.experts.{expert}.{p}.{s}' for p in ('up_proj', 'gate_proj', 'down_proj') for s in ('weight', 'weight_scale_inv')]
        with ExitStack() as stack:
            handles = {f: stack.enter_context(safe_open(str(CKPT / f), framework='pt', device='cpu')) for f in set(index[k] for k in keys)}
            pairs = {p: weight(layer, expert, p, handles, index) for p in ('up_proj', 'gate_proj', 'down_proj')}
            for p, tensors in pairs.items():
                for suffix, tensor in zip(('weight', 'weight_scale_inv'), tensors, strict=True):
                    raw = tensor.contiguous().view(torch.uint8).numpy().tobytes()
                    matrix_records.append({'key': f'model.language_model.layers.{layer}.mlp.experts.{expert}.{p}.{suffix}', 'shape': list(tensor.shape), 'dtype': str(tensor.dtype), 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)})
            down, down_scale = pairs['down_proj']
            fc1 = torch.cat([pairs[p][0] for p in ('up_proj', 'gate_proj')])
            fc1_scale = torch.cat([pairs[p][1] for p in ('up_proj', 'gate_proj')])
            cases = [
                ('fc2', data['intermediates']['activation_bytes'][expanded].contiguous().view(torch.float8_e4m3fn).float().numpy(), data['intermediates']['activation_scale'][expanded].numpy(), down.float().numpy(), down_scale.numpy(), sorted(set(np.linspace(0, 2047, 64, dtype=int).tolist()))),
                ('fc1_raw_diagnostic', data['q'][tokens].float().numpy(), data['input_scale'][:, tokens].T.numpy(), fc1.float().numpy(), fc1_scale.numpy(), [0, 31, 127, 255, 384, 511, 512, 543, 639, 767, 896, 1023]),
            ]
            for name, act, act_scale, wt, wt_scale, columns in cases:
                for row in range(2):
                    for column in columns:
                        trees, parts, ref64, original64 = dot(act[row], wt[column], act_scale[row], wt_scale[column // 128])
                        expected = None
                        if name == 'fc2':
                            expected = int(data['intermediates']['fc2_bf16'][expanded[row], column].view(torch.uint16))
                        records.append({'layer': layer, 'oracle': str(path), 'oracle_sha256': sha(path), 'expert': expert, 'expanded': int(expanded[row]), 'token': int(tokens[row]), 'projection': name, 'column': int(column), 'values': {k: float(v) for k, v in trees.items()}, 'bits': {k: bits(v) for k, v in trees.items()}, 'bf16_bits': {k: bf16(v) for k, v in trees.items()}, 'native_fc2_bf16_bits': expected, 'fp64_same_rounded_scale': ref64, 'fp64_original_scales': original64, 'partials_bits': parts})
    return records, matrix_records


def ownership():
    checks = 0
    for rows in (0, 1, 2):
        for k, columns in ((2048, 1024), (512, 2048)):
            writes = collections.Counter()
            for block in range(columns // 16):
                for thread in range(128):
                    col, lane = block * 16 + thread // 8, thread % 8
                    if rows == 0:
                        continue
                    indices = [group*128 + chunk*32 + lane*4 + byte for group in range(k//128) for chunk in range(4) for byte in range(4)]
                    assert all(0 <= i < k for i in indices)
                    assert len(indices) == len(set(indices)) == k // 8
                    assert all((col*k + group*128 + chunk*32 + lane*4) % 4 == 0 for group in range(k//128) for chunk in range(4))
                    checks += 3
                    if lane == 0:
                        for row in range(rows):
                            writes[row*columns + col] += 1
            assert writes == collections.Counter({i: 1 for i in range(rows*columns)})
            checks += 1
    for group in range(16):
        gathered = [group*128 + chunk*32 + lane*4 + byte for lane in range(8) for chunk in range(4) for byte in range(4)]
        assert sorted(gathered) == list(range(group*128, (group+1)*128))
        checks += 1
    workloads = []
    for path in sorted(ORACLES.glob('oracle-layer*.pt')):
        data = torch.load(path, map_location='cpu', weights_only=False)
        if 'ids' not in data:
            continue
        ids = data['ids'].flatten().tolist()
        by_expert = collections.defaultdict(list)
        for expanded, expert in enumerate(ids):
            by_expert[expert].append(expanded)
        groups = [(expert, rows[i:i+2]) for expert, rows in by_expert.items() for i in range(0, len(rows), 2)]
        covered = [x for _, rows in groups for x in rows]
        assert sorted(covered) == list(range(len(ids))) and len(set(covered)) == len(ids)
        assert all(len(rows) in (1, 2) and all(ids[i] == expert for i in rows) for expert, rows in groups)
        assert all(len(set(data['ids'][token].tolist())) == 8 for token in range(64))
        checks += 3
        counts = collections.Counter(len(rows) for _, rows in groups)
        workloads.append({'oracle': path.name, 'active_experts': len(by_expert), 'route_pairs': counts[2], 'single_routes': counts[1], 'groups': len(groups), 'native_tiles8': sum((len(x)+7)//8 for x in by_expert.values()), 'logical_weight_load_bytes_grouped2': len(groups)*3*1024*1024, 'logical_weight_load_bytes_one_per_active_expert': len(by_expert)*3*1024*1024, 'caveat': 'Logical requested weight bytes; repeated pairs may share L2, not a prediction of DRAM bytes.'})
    return {'checks': checks, 'workloads': workloads, 'warps_per_CTA': 4, 'outputs_per_warp': 4, 'subwarp_width': 8, 'uint32_weight_load_sector_bytes_per_subwarp_per_chunk': 32, 'four_nonadjacent_output_columns_per_warp': 4, 'full_dispatch_implemented': False}


def issue_audit():
    text = (OUT / 'kernel.sass').read_text()
    functions = {}
    for name, body in re.findall(r'Function : (\S+)\n(.*?)(?=\n\s*Function :|\Z)', text, re.S):
        insns = []
        for pc, instruction in re.findall(r'/\*([0-9a-f]+)\*/\s+(.*?)\s*;\s*/\*', body):
            inst = re.sub(r'^@!?P\d+\s+', '', instruction)
            insns.append((int(pc, 16), inst))
        # Both templates emit the same fixed loops. Record PCs and every opcode;
        # do not count the nonexecuted exit safety loop or assume unknown branches.
        loops = {}
        for label, start, end in [('one_route_k128', 0x220, 0x820), ('two_route_steady_k128', 0x1280, 0x1bf0)]:
            selected = [(pc, x) for pc, x in insns if start <= pc <= end]
            assert selected[-1][1].startswith('BRA.U') and f'0x{start:x}' in selected[-1][1]
            counts = collections.Counter(x.split()[0] for _, x in selected)
            core = sum(counts[x] for x in ('F2FP.F16.E4M3.UNPACK_B', 'HADD2.F32'))
            # In both loops two_route has 32 unscaled FFMA + 2 outer FTZ FFMA.
            core += counts['FFMA']
            loops[label] = {'first_pc': hex(start), 'last_pc': hex(end), 'instructions': len(selected), 'opcodes': dict(counts), 'decode_plus_unscaled_fma_instructions': core, 'warp_MACs': 1024 if label.startswith('two') else 512}
        functions[name] = loops
    assert len(functions) == 2
    chosen = functions['fc1_grouped2_subwarp8_raw']['two_route_steady_k128']
    assert chosen['opcodes']['F2FP.F16.E4M3.UNPACK_B'] == 24
    assert chosen['opcodes']['HADD2.F32'] == 48
    assert chosen['opcodes']['FFMA'] == 32
    assert chosen['opcodes']['FFMA.FTZ'] == 2
    mac = 40*64*8*(2048*1024 + 512*2048)
    capacity = 148*4*2.032e9
    instr = mac / 1024 * chosen['decode_plus_unscaled_fma_instructions']
    return {'functions': functions, 'total_MAC_per_B64_step': mac, 'recorded_device': {'SMs': 148, 'schedulers_per_SM': 4, 'clock_hz': 2.032e9}, 'all_pairs_ideal_decode_plus_FMA_warp_instructions': instr, 'optimistic_issue_ms_at_recorded_clock': instr/capacity*1000, 'all_pairs_total_steady_loop_issue_ms_at_recorded_clock': mac/1024*chosen['instructions']/capacity*1000, 'FP32_only_ideal_ms_at_recorded_clock': 2*mac/(148*128*2*2.032e9)*1000, 'claim_scope': 'Optimistic issue budget for this compiled fixed mapping at recorded clock, not measured latency or a universal hardware/model lower bound. Uniform/control issue overlap and memory are excluded from the 104-vector-instruction budget. One-route tails only increase cost per MAC. FC1 epilogue, native activation, metadata, finalizer, memory stalls, and prologue/epilogue omitted.'}


def main():
    assert not torch.cuda.is_initialized()
    assert not (OUT / 'cpu-result.json').exists()
    records, matrices = simulate()
    fc2 = [r for r in records if r['projection'] == 'fc2']
    metrics = {}
    for name in ('subwarp8', 'serial128', 'chunks32'):
        metrics[name] = {'native_fc2_bf16_mismatches': sum(r['bf16_bits'][name] != r['native_fc2_bf16_bits'] for r in fc2), 'native_fc2_compared': len(fc2), 'raw32_mismatch_vs_subwarp8': sum(r['bits'][name] != r['bits']['subwarp8'] for r in records), 'group_partial_mismatch_vs_subwarp8': sum(p[name] != p['subwarp8'] for r in records for p in r['partials_bits']), 'max_abs_error_vs_fp64_same_rounded_scale': max(abs(r['values'][name] - r['fp64_same_rounded_scale']) for r in records)}
    report = {'status': 'CPU_AOT_FEASIBILITY_ONLY', 'gpu_executed': False, 'cuda_initialized': torch.cuda.is_initialized(), 'source_sha256': sha(OUT/'fixed_subwarp8.cu'), 'CUBIN_sha256': sha(OUT/'fixed_subwarp8.cubin'), 'cpu_driver_sha256': sha(__file__), 'resources': {'registers_per_thread': 32, 'shared_bytes': 0, 'local_bytes': 0, 'stack_bytes': 0, 'spill_loads': 0, 'spill_stores': 0}, 'selected_output_counts': dict(collections.Counter(r['projection'] for r in records)), 'selected_raw32_tree_metrics': metrics, 'arithmetic_limitation': 'Native unscaled K128 partials and FC1 prequant FP32 are not archived. Different CPU trees isolate sum-order differences among those simulations; native mismatch cannot alone prove only hidden UMMA summation differs. No exact native FC1 epilogue or full MoE implemented.', 'ownership': ownership(), 'issue': issue_audit(), 'matrix_inputs': matrices, 'records': records}
    assert not report['cuda_initialized']
    (OUT/'cpu-result.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps({k:report[k] for k in ('status','gpu_executed','selected_output_counts','selected_raw32_tree_metrics')}, indent=2))
    print(json.dumps(report['issue'], indent=2))


if __name__ == '__main__':
    main()
