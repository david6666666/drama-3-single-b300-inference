"""CPU-owned native resident-chain contracts; importing never initializes CUDA.

Metadata derives from the independently validated expert-fc1/2-expanded harness.
No candidate arithmetic, quantization, hidden permutation, or finalizer lives here.
"""
import hashlib
import json
from contextlib import ExitStack
from pathlib import Path

import torch
from safetensors import safe_open

ROOT = Path(__file__).resolve().parent.parent
ORACLE_DIR = ROOT / 'expert-metadata-rebase'
SOURCE = ROOT / 'source-metadata-rebase-95fcb0e'
SOURCE_SHA = '95fcb0ef2662f2caf9bfb7fe6863dc3ad7805b1b'
CKPT = Path('/home/zjy/.cache/huggingface/hub/models--fishaudio--drama-3/snapshots/e0a9218aa48888270f06ef1ed9ea67622c0e17d2')
CAP, CTA, TOKENS, TOPK, HIDDEN, INTERMEDIATE = 2304, 288, 64, 8, 2048, 512
# The checker observes these logical addresses directly. No inverse permutations.
BOUNDARIES = {
    'fc1_bytes': ((8, 1024), torch.uint8, 173),
    'fc1_sf': ((8, 8), torch.float32, -17.0),  # K128 output block, token
    'act_bytes': ((8, 512), torch.uint8, 91),
    'act_sf': ((4, 8), torch.float32, -19.0),  # K128 input block, token
    'fc2': ((8, 2048), torch.bfloat16, 7.0),
}
ORACLE_KEYS = {
    'fc1_bytes': 'fc1_bytes', 'fc1_sf': 'fc1_scale',
    'act_bytes': 'activation_bytes', 'act_sf': 'activation_scale',
    'fc2': 'fc2_bf16',
}

def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def load_oracle(path):
    d = torch.load(path, map_location='cpu', weights_only=False)
    specs = {'q': ((64, 2048), torch.float8_e4m3fn),
             'input_scale': ((16, 64), torch.float32),
             'ids': ((64, 8), torch.int32), 'weights': ((64, 8), torch.bfloat16),
             'routed': ((64, 2048), torch.bfloat16)}
    for name, (shape, dtype) in specs.items():
        assert tuple(d[name].shape) == shape and d[name].dtype == dtype, name
    for name, (shape, dtype, _) in BOUNDARIES.items():
        item = d['intermediates'][ORACLE_KEYS[name]]
        expected = (512, shape[0]) if name.endswith('_sf') else (512, shape[1])
        assert tuple(item.shape) == expected and item.dtype == dtype, name
    metadata(d)
    return d


def metadata(d):
    n = int(d['global_meta']['ncta'])
    padded = int(d['global_meta']['padded'])
    mapping = d['global_meta']['expanded'].long()
    ids = d['ids'].long().flatten()
    assert 0 < n <= CTA and padded == n * 8
    assert mapping.shape == (512,) and mapping.unique().numel() == 512
    assert int(mapping.min()) >= 0 and int(mapping.max()) < padded <= CAP
    assert torch.equal(d['cta'][mapping // 8].long(), ids)
    tile = torch.zeros(CTA, dtype=torch.int32)
    limits = torch.zeros(CTA, dtype=torch.int32)
    tile[:n], limits[:n] = d['cta'], d['mn']
    route = torch.zeros(CAP + 1, dtype=torch.int32)
    route[mapping] = torch.arange(512, dtype=torch.int32) // 8
    valid = torch.zeros(CAP, dtype=torch.bool)
    valid[mapping] = True
    for i in range(n):
        rows = torch.where(valid[i * 8:(i + 1) * 8])[0] + i * 8
        assert rows.numel() and torch.equal(rows, torch.arange(i * 8, int(limits[i])))
    return {'tile': tile, 'mn': limits, 'route': route,
            'ncta': torch.tensor([n], dtype=torch.int32),
            'padded': torch.tensor([padded], dtype=torch.int32),
            'mapping': mapping, 'valid': valid}


def single_weights(layer, expert):
    index = json.loads((CKPT / 'model.safetensors.index.json').read_text())['weight_map']
    prefix = f'model.language_model.layers.{layer}.mlp.experts.{expert}'
    keys = [f'{prefix}.{proj}.{suffix}' for proj in ('up_proj', 'gate_proj', 'down_proj')
            for suffix in ('weight', 'weight_scale_inv')]
    with ExitStack() as stack:
        readers = {name: stack.enter_context(safe_open(str(CKPT / name), framework='pt', device='cpu'))
                   for name in sorted({index[key] for key in keys})}
        def tensor(proj, suffix):
            key = f'{prefix}.{proj}.{suffix}'
            return readers[index[key]].get_tensor(key)
        return {
            'w1': torch.cat([tensor(p, 'weight') for p in ('up_proj', 'gate_proj')]),
            'sf1': torch.cat([tensor(p, 'weight_scale_inv') for p in ('up_proj', 'gate_proj')]),
            # Own aligned storage, including safetensors scales with unaligned offsets.
            'w2': tensor('down_proj', 'weight').clone(),
            'sf2': tensor('down_proj', 'weight_scale_inv').clone(),
        }


def single_fixture(d, expert=205, tile_index=0, valid_rows=None, weights=None):
    expanded = torch.where(d['ids'].long().flatten() == expert)[0]
    selected = expanded[tile_index * 8:(tile_index + 1) * 8]
    count = len(selected) if valid_rows is None else int(valid_rows)
    assert 0 <= count <= len(selected) <= 8
    selected = selected[:count]
    q = torch.zeros((8, 2048), dtype=torch.float8_e4m3fn)
    input_sf = torch.zeros((16, 8), dtype=torch.float32)
    if count:
        q[:count] = d['q'][selected // 8]
        input_sf[:, :count] = d['input_scale'][:, selected // 8]
    data = {'q': q, 'input_sf': input_sf, 'valid_rows': count}
    data.update(single_weights(d['layer'], expert) if weights is None else weights)
    expected = {}
    for name, (shape, dtype, sentinel) in BOUNDARIES.items():
        out = torch.full(shape, sentinel, dtype=dtype)
        src = d['intermediates'][ORACLE_KEYS[name]][selected]
        if name.endswith('_sf'):
            out[:, :count] = src.T
        else:
            out[:count] = src
        expected[name] = out
    return data, expected, selected


def ordered_top8_cpu(d):
    """Diagnostic FP32 FMA emulation on native BF16 operands, not a candidate finalizer.

    BF16 product is exact in FP64. Each addition is rounded explicitly to FP32.
    Real-data agreement is checked against the archived native result; no general
    claim about synthetic extreme-exponent IEEE FMA behavior is inferred.
    """
    branches = d['intermediates']['fc2_bf16'].reshape(64, 8, 2048)
    acc = torch.zeros((64, 2048), dtype=torch.float32)
    for rank in range(8):
        acc = (d['weights'][:, rank, None].double() * branches[:, rank].double()
               + acc.double()).float()
    return acc.bfloat16()


def tensor_bytes_equal(a, b):
    return (a.shape == b.shape and a.dtype == b.dtype
            and torch.equal(a.contiguous().view(torch.uint8), b.contiguous().view(torch.uint8)))


def initialize_outputs(outputs):
    assert set(outputs) == set(BOUNDARIES)
    for name, (shape, dtype, sentinel) in BOUNDARIES.items():
        assert tuple(outputs[name].shape) == shape and outputs[name].dtype == dtype, name
        assert outputs[name].is_contiguous(), name
        outputs[name].fill_(sentinel)


def require_disjoint_outputs(outputs, immutable):
    """Logical debug boundaries must survive to the checker, so cannot alias."""
    def span(tensor):
        assert tensor.is_contiguous()
        return tensor.data_ptr(), tensor.data_ptr() + tensor.numel() * tensor.element_size()
    names = list(outputs)
    for i, name in enumerate(names):
        lo, hi = span(outputs[name])
        for other, tensor in list(outputs.items())[i + 1:] + list(immutable.items()):
            lo2, hi2 = span(tensor)
            assert hi <= lo2 or hi2 <= lo, (name, other, 'overlap')


def cpu_contract():
    assert not torch.cuda.is_initialized()
    cases = []
    paths = sorted(ORACLE_DIR.glob('oracle-layer*.pt'))
    assert len(paths) == 15
    for path in paths:
        d = load_oracle(path)
        md = metadata(d)
        hist = torch.bincount(d['ids'].long().flatten(), minlength=256)
        assert tensor_bytes_equal(ordered_top8_cpu(d), d['routed']), path.name
        cases.append({'name': path.name, 'sha256': sha(path),
                      'ncta': int(md['ncta']), 'padded': int(md['padded']),
                      'active_experts': int((hist > 0).sum()), 'max_routes': int(hist.max()),
                      'ordered_top8_cpu_matches_archived_native': True})
    d = load_oracle(ORACLE_DIR / 'oracle-layer0-real.pt')
    weights = single_weights(0, 205)
    fixtures = []
    for count in range(9):
        data, expected, selected = single_fixture(d, valid_rows=count, weights=weights)
        assert int(data['q'][count:].view(torch.uint8).sum()) == 0
        assert torch.count_nonzero(data['input_sf'][:, count:]) == 0
        assert all(tensor_bytes_equal(expected[key][:, count:] if key.endswith('_sf') else expected[key][count:],
                                    torch.full_like(expected[key][:, count:] if key.endswith('_sf') else expected[key][count:], spec[2]))
                   for key, spec in BOUNDARIES.items())
        fixtures.append({'valid_rows': count, 'expanded': selected.tolist()})
    assert not torch.cuda.is_initialized()
    return {'status': 'CPU_CONTRACT_PASS', 'cuda_initialized': False,
            'source_sha': SOURCE_SHA, 'timing_allowed': False,
            'cases': cases, 'single_expert_fixtures': fixtures,
            'finalizer': 'Installed native trtllm_moe_run_finalize; original BF16 weights, top8 order, one BF16 output boundary',
            'one_expert_finalizer_scope': 'Oracle-assisted: substitute only tested selected branches into otherwise native FC2, never claim full MoE candidate.'}
