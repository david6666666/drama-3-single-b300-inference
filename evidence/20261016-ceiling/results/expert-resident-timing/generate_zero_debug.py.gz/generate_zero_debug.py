"""Remove only global debug boundary exports from the exact full chain."""
from pathlib import Path
import ast,difflib,json,hashlib
OUT=Path(__file__).resolve().parent
source=OUT.parent/'expert-resident-full/resident_chain_kernel.py'
s=source.read_text();original=s
start=s.index('        # Debug boundary export is explicit;')
end=s.index('        prims.barrier_cta_sync()\n',start)
region=s[start:end]
valid=next(line for line in region.splitlines(True) if line.lstrip().startswith('valid_rows ='))
s=s[:start]+'        # Zero-debug path keeps every native shared arithmetic boundary.\n'+valid+s[end:]
start=s.index('        # Debug activation output is never the FC2 input.')
end=s.index('        prims.barrier_cta_sync()\n',start)
s=s[:start]+'        # No global activation debug export; FC2 consumes shared full_act/full_sf.\n'+s[end:]
ast.parse(s)
(OUT/'resident_chain_kernel.py').write_text(s)
(OUT/'zero-debug.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),s.splitlines(True),fromfile='exact-full/resident_chain_kernel.py',tofile='zero-debug/resident_chain_kernel.py')))
(OUT/'zero-debug-source.json').write_text(json.dumps({'source_sha256':hashlib.sha256(original.encode()).hexdigest(),'candidate_sha256':hashlib.sha256(s.encode()).hexdigest(),'changes':['Remove globalFC1 bytes/scales debug exports','Remove globalactivation bytes/scales debug exports'],'unchanged':['Native sharedFC1/activation arithmetic and quantization boundaries','All CTA/clusterbarriers','All sixstage calls andTMEM lifecycle','FC2 globaloutput andoriginalorderedfinalizer'],'status':'CPU_PARSE_PASS_NOT_GPU_VALIDATED'},indent=2)+'\n')
print('ZERO_DEBUG_CPU_PARSE_PASS')
