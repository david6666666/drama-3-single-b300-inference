"""CPU AOT of the actual four-CTA resident full chain; no GPU initialization."""
import os,json,traceback,subprocess,hashlib
from pathlib import Path
OUT=Path(__file__).resolve().parent
os.environ.update(CUTE_DSL_ARCH='sm_103a',CUTE_DSL_KEEP='ptx,cubin',CUTE_DSL_DUMP_DIR=str(OUT/'chain-cpu-compile'))
(OUT/'chain-cpu-compile').mkdir(exist_ok=True)
import chain_common as c
import torch
report={'status':'PREPARING','gpu_launched':False,'timing_allowed':False,'source_sha':'95fcb0ef2662f2caf9bfb7fe6863dc3ad7805b1b','scope':'One original expert205, native FC1/activation/FC2, four CTA cluster with original group1 MMA; debug boundary exports retained.'}
def flush():(OUT/'chain-aot-result.json').write_text(json.dumps(report,indent=2)+'\n')
try:
 assert os.environ.get('CUDA_VISIBLE_DEVICES')=='' and not torch.cuda.is_initialized()
 candidate=c.build_chain(c.cpu_data())
 (OUT/'chain-cpu-compile/host-module.mlir').write_text(str(candidate.fn.ir_module))
 bins=list((OUT/'chain-cpu-compile').glob('*.cubin'));assert len(bins)==1
 usage=subprocess.check_output(['/usr/local/cuda/bin/cuobjdump','--dump-resource-usage',str(bins[0])],text=True)
 (OUT/'chain-resource-usage.txt').write_text(usage)
 report.update(status='CPU_AOT_PASS',cuda_initialized=torch.cuda.is_initialized(),cubin_sha256=hashlib.sha256(bins[0].read_bytes()).hexdigest(),resource_usage=usage,configs=[x[1] for x in candidate.configs])
 assert not torch.cuda.is_initialized()
except BaseException as e:report.update(status='CPU_AOT_FAIL',error=repr(e),traceback=traceback.format_exc());raise
finally:flush()
