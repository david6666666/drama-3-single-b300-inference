"""CPU AOT/resource qualification of full-routing artifact; never GPU launch."""
import hashlib
import json
import os
import subprocess
import traceback
from pathlib import Path

OUT = Path(__file__).resolve().parent
os.environ.update(CUTE_DSL_ARCH='sm_103a', CUTE_DSL_KEEP='ptx,cubin',
                  CUTE_DSL_DUMP_DIR=str(OUT / 'full-cpu-compile'))
(OUT / 'full-cpu-compile').mkdir(exist_ok=True)
import chain_common as c
import torch
from resource_audit import audit

report = {'status': 'PREPARING', 'gpu_launched': False, 'timing_allowed': False,
          'source_sha': c.contract.SOURCE_SHA, 'scope': 'full256 experts, CAP2304, grid4x288, all15 native oracle metadata'}
def flush():
    (OUT / 'full-aot-result.json').write_text(json.dumps(report, indent=2) + '\n')

try:
    assert os.environ.get('CUDA_VISIBLE_DEVICES') == '' and not torch.cuda.is_initialized()
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=c.contract.SOURCE, text=True).strip() == c.contract.SOURCE_SHA
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=c.contract.SOURCE, text=True)
    paths = sorted(c.contract.ORACLE_DIR.glob('oracle-layer*.pt'))
    assert len(paths) == 15
    report['metadata_coverage'] = []
    for path in paths:
        d = c.contract.load_oracle(path)
        md = c.contract.metadata(d)
        report['metadata_coverage'].append({'oracle': str(path), 'sha256': c.contract.sha(path),
            'ncta': int(md['ncta']), 'padded': int(md['padded']),
            'valid_expanded_rows': int(md['valid'].sum())})
    data = c.cpu_data()
    candidate = c.build_full_chain(data)
    host_ir = OUT / 'full-cpu-compile/host-module.mlir'
    host_ir.write_text(str(candidate.fn.ir_module))
    bins = list((OUT / 'full-cpu-compile').glob('*.cubin'))
    ptxs = list((OUT / 'full-cpu-compile').glob('*.ptx'))
    assert len(bins) == len(ptxs) == 1
    host = OUT / 'resident_chain_host.py'
    literal = 'cluster=[4,1,1]'
    assert literal in host.read_text()
    resource = audit(bins[0], ptxs[0], host_ir, OUT / 'full-resource-audit',
        cluster_size=4, cluster_evidence={'path': str(host), 'sha256': c.contract.sha(host), 'literal': literal})
    assert not torch.cuda.is_initialized()
    report.update(status='CPU_AOT_PASS', cuda_initialized=False,
        cubin_sha256=hashlib.sha256(bins[0].read_bytes()).hexdigest(),
        resource=resource, configs=[item[1] for item in candidate.configs])
except BaseException as exc:
    report.update(status='CPU_AOT_FAIL', error=repr(exc), traceback=traceback.format_exc())
    raise
finally:
    flush()
