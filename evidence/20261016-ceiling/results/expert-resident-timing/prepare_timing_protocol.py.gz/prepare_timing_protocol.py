"""Freeze CPU-qualified zero-debug matched-boundary gate; no GPU launch."""
import argparse
import hashlib
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
SOURCE = ROOT / 'source-metadata-rebase-95fcb0e'
SOURCE_SHA = '95fcb0ef2662f2caf9bfb7fe6863dc3ad7805b1b'


def sha(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b''):
            value.update(chunk)
    return value.hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--gpu-uuid', required=True)
    parser.add_argument('--watchdog-seconds', type=int, default=600)
    args = parser.parse_args()
    assert args.gpu_uuid.startswith('GPU-') and 30 <= args.watchdog_seconds <= 900
    prepared = json.loads((OUT / 'timing-aot-result.json').read_text())
    assert prepared['status'] == 'CPU_AOT_PASS'
    full = ROOT / 'expert-resident-full/full-gate/result.json'
    exact = json.loads(full.read_text())
    assert exact['status'] == 'FULL_CHAIN_EXACT_PASS' and exact['passed']
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SOURCE, text=True).strip() == SOURCE_SHA
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=SOURCE, text=True)
    protocol = {
        'status': 'FROZEN_ZERO_DEBUG_PARITY_AND_MATCHED_BOUNDARY_LOCAL_TIMING',
        'source_sha': SOURCE_SHA, 'gpu_uuid': args.gpu_uuid,
        'watchdog_seconds': args.watchdog_seconds,
        'hypothesis': 'Removing FC1/activation global roundtrips may reduce complete prepared-MoE latency; exact debug chain alone established no speed gain.',
        'boundary': {'input': 'same original q E4M3 bytes/input scale FP32 + top8 ids + route weights BF16',
            'included_per_call': ['live original native routing metadata population', 'FC1', 'original native activation/FP8 scale boundary', 'FC2', 'original ordered-top8 native finalizer'],
            'excluded_common': ['input quantization', 'logits-to-top8 routing'],
            'real_fixture_limit': 'Three archived physical B64 layers from63 live +1 original padding row, not a whole-model or service benchmark'},
        'pdl': {'native': True, 'resident': False,
            'interpretation': 'Complete implementation A/B. Preserve optimized native baseline; candidate PDL=False is its current limitation, not a single-variable MMA comparison.'},
        'exact_gate_before_timing': ['all15 eager and reused-graph FC2/native-finalized outputs exact',
            'four removed global debug buffers remain full sentinels', 'FC2 inactive/padding/tail sentinel',
            'inputs/weights/RNG unchanged', 'independent arm metadata/workspaces',
            'candidate-only whole-launch ncta0 eager+same-body-graph, no finalizer, no hang',
            'CPU/GPU candidate CUBIN identity'],
        'timing_order': [['native', 'resident'], ['resident', 'native'], ['native', 'resident']],
        'replays': 100, 'warmups': 5,
        'continuation': {'primary': 'L0/real, L19/real, L39/real; each median complete-call latency reduction >=5%',
            'secondary': 'all12 stress cases reported separately; each regression <=5%; near-zero changes are not gains',
            'all_exact_required': True, 'whole_model_and_service': 'Allowed only after this local continuation passes; no promotion from averages'},
        'resource': prepared['resource'], 'cpu_cubin_sha256': prepared['cubin_sha256'],
        'full_debug_exact_evidence': {'path': str(full), 'sha256': sha(full), 'checks': len(exact['checks'])},
        'runtime_modified': False, 'timing_is_service_performance': False}
    protocol_path = OUT / 'timing-protocol.json'
    protocol_path.write_text(json.dumps(protocol, indent=2) + '\n')
    paths = list(OUT.glob('*.py')) + list(OUT.glob('*.patch'))
    paths += [protocol_path, OUT / 'timing-aot-result.json', full]
    paths += list((OUT / 'timing-cpu-compile').glob('*'))
    paths += list((ROOT / 'expert-metadata-rebase').glob('oracle-layer*.pt'))
    fi = Path('/home/zjy/code/hsliu/venvs/codex-drama3-standalone/lib/python3.12/site-packages/flashinfer')
    paths += [fi / name for name in ('fused_moe/core.py', 'prims_ts/moe/tensor_adapter.py',
                                    'prims_ts/batched_gemm/batched_gemm_run.py')]
    frozen = {str(path): sha(path) for path in sorted(set(paths)) if path.is_file()}
    (OUT / 'timing-frozen-inputs.json').write_text(json.dumps(frozen, indent=2) + '\n')
    print(json.dumps({'status': protocol['status'], 'frozen_files': len(frozen), 'gpu_launched': False}))


if __name__ == '__main__':
    main()
