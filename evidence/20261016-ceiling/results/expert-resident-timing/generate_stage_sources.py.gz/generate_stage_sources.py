"""Artifact-local native stage extraction; no installed-source mutation."""
from pathlib import Path
import ast,json,hashlib,difflib
OUT=Path(__file__).resolve().parent;ROOT=OUT.parent
FI=Path('/home/zjy/code/hsliu/venvs/codex-drama3-standalone/lib/python3.12/site-packages/flashinfer/prims_ts/batched_gemm')
def segment(source,name):
 tree=ast.parse(source)
 node=next(n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==name)
 start=min([node.lineno]+[x.lineno for x in node.decorator_list]);return ''.join(source.splitlines(True)[start-1:node.end_lineno])
base=(ROOT/'expert-fc1-native-v3/gmem_c_resources_native_v3.py').read_text();s=base
# Include independently exact-validated BF16 TMEM -> shared logical mapping.
fc2=(ROOT/'expert-fc2-native-v2/gmem_c_resources_native_v2.py').read_text()
def method(text,name):
 tree=ast.parse(text);cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='GmemCResource');n=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name==name);start=min([n.lineno]+[d.lineno for d in n.decorator_list]);return ''.join(text.splitlines(True)[start-1:n.end_lineno])
name='_stage_swap_ab_bf16_dsfp8_tma_pair';old=method(s,name);s=s.replace(old,method(fc2,name),1)
# This resource is used in the artifact resident stage only. Global C remains
# available for eventual BF16 output; native FC1 bytes/scales go to pinned SMEM.
needle='''        context = stage_info.context
        if cutlass.const_expr(
            self.cfg.uses_fp4_output_quant'''
replacement='''        context = stage_info.context
        if cutlass.const_expr(self.cfg.has_deepseek_fp8_c_scale):
            # Outer owns this region through both FC1 stages and activation.
            self.gCBytes = cutlass.Array(context.smem_base.data_ptr() + 72704,
                dtype=cutlass.Int8, shape=(2048,), addrspace=3)
            self.gSfC = cutlass.Array(context.smem_base.data_ptr() + 74752,
                dtype=cutlass.Float32, shape=(16,), addrspace=3)
        if cutlass.const_expr(
            self.cfg.uses_fp4_output_quant'''
assert s.count(needle)==1;s=s.replace(needle,replacement)
needle='return (m_row // Int32(128)) * self.dsfp8_c_scale_stride + n_col'
assert s.count(needle)==1;s=s.replace(needle,'return (m_row // Int32(512)) * Int32(8) + n_col')
start=s.index('        elif cutlass.const_expr(self.cfg.has_deepseek_fp8_c_scale):',s.index('def _store_swap_ab_16x256b'))
end=s.index('            else:\n                val0_vals = []',start)
a=s[start:end];needle='flat_idx0 = n_col * output_m + m_row0';assert a.count(needle)==1
a=a.replace(needle,'flat_idx0 = n_col * Int32(256) + (m_row0 // Int32(512)) * Int32(128) + m_row0 % Int32(128)')
s=s[:start]+a+s[end:]
(OUT/'resident_gmem_c.py').write_text(s)
(OUT/'resident-gmem-c.patch').write_text(''.join(difflib.unified_diff(base.splitlines(True),s.splitlines(True),fromfile='FC1v3/gmem_c_resources_native_v3.py',tofile='resident_gmem_c.py')))
source=(FI/'batched_gemm_kernel.py').read_text();body=segment(source,'_batched_gemm_kernel_bf16_body');originalbody=body
body=body.replace('def _batched_gemm_kernel_bf16_body(', 'def resident_stage_body(')
body=body.replace('    early_exit_max_token_ctas: cutlass.Int32,\n) -> None:', '    early_exit_max_token_ctas: cutlass.Int32,\n    resident_base,\n    resident_phase: cutlass.Constexpr[int],\n    resident_tmem_base: cutlass.Int32,\n) -> None:')
body=body.replace('smem_allocator = SmemAllocator()', 'smem_allocator = BorrowedSmemAllocator(resident_base, reserved_bytes=72704)')
body=body.replace('    tmem_allocator.compute_layout()','    tmem_allocator.compute_layout()\n    if cutlass.const_expr(max(tmem_allocator.total_tmem_columns, cfg.tmem_total_cols) > 32):\n        raise ValueError(\"resident outer TMEM allocation exceeds32 columns\")')
# One outer-owned TMEM allocation survives every sequential stage. Native
# relinquish is terminal for a CTA, so no stage may allocate again afterward.
a=body.index('        # TMEM allocation\n')
b=body.index('        # Run\n',a)
body=body[:a]+"""        if warp_idx == 0:
            if prims.elect_sync():
                tmem_ptr_i32.store(resident_tmem_base)
        prims.barrier_cta_sync()

"""+body[b:]
a=body.index('        # TMEM deallocation.')
body=body[:a]+"""        # All producer/MMA/epilogue tasks must return before scratch/TMEM reuse.
        prims.tcgen05_fence(prims.Tcgen05Fence.BEFORE_THREAD_SYNC)
        prims.barrier_cta_sync()
"""

needle='''    task_manager = task_manager_cls(
        tasks=task_list,'''
replace='''    for resident_task in task_list:
        resident_task.resident_tile_offset = resident_phase * 4
    task_manager = task_manager_cls(
        tasks=task_list,'''
assert body.count(needle)==1;body=body.replace(needle,replace)
header='''# SPDX-License-Identifier: Apache-2.0
# Native stage extracted from FlashInfer; original and changes in stage-source-manifest.json.
import importlib.util,sys
from pathlib import Path
import flashinfer.prims_ts.batched_gemm.batched_gemm_kernel as _native
# Keep all original helpers/types available to the extracted function.
globals().update({k:v for k,v in vars(_native).items() if not k.startswith('__')})
from resident_resources import BorrowedSmemAllocator
_OUT=Path(__file__).resolve().parent

def _load_artifact(name,filename):
    key='flashinfer.prims_ts.batched_gemm.'+name
    spec=importlib.util.spec_from_file_location(key,_OUT/filename)
    module=importlib.util.module_from_spec(spec);sys.modules[key]=module
    spec.loader.exec_module(module);return module

_resident_tasks=_load_artifact('resident_native_tasks','resident_native_tasks.py')
for _key,_value in vars(_resident_tasks).items():
    if _key.startswith('create_'):globals()[_key]=_value
_resident_gmem=_load_artifact('resident_gmem_c','resident_gmem_c.py')
GmemCResource=_resident_gmem.GmemCResource

'''
(OUT/'resident_stage.py').write_text(header+body+'\n')
(OUT/'resident-stage.patch').write_text(''.join(difflib.unified_diff(originalbody.splitlines(True),body.splitlines(True),fromfile='FI/_batched_gemm_kernel_bf16_body',tofile='resident_stage_body')))
# Reuse the original host-side TensorMap/shape descriptor builder. For the first
# AOT integration gate it launches the two-phase FC1 pair outer kernel.
host=segment(source,'gemm');host=host.replace('def gemm(', 'def resident_fc1_pair_host(')
needle='    batched_gemm_kernel_bf16(\n';assert host.count(needle)==1;host=host.replace(needle,'    resident_fc1_pair_kernel(\n')
host=host.replace('        grid=grid,\n        block=[block, 1, 1],\n        cluster=list(cluster_shape),','        grid=[4, 1, 1],\n        block=[512, 1, 1],\n        cluster=[4, 1, 1],')
(OUT/'resident_fc1_host.py').write_text('# SPDX-License-Identifier: Apache-2.0\nimport flashinfer.prims_ts.batched_gemm.batched_gemm_kernel as _native\nglobals().update({k:v for k,v in vars(_native).items() if not k.startswith("__")})\nfrom resident_fc1_pair import resident_fc1_pair_kernel\n\n'+host+'\n')
manifest={'source_kernel':str(FI/'batched_gemm_kernel.py'),'source_kernel_sha256':hashlib.sha256(source.encode()).hexdigest(),'fc1_arithmetic_sha256':hashlib.sha256(base.encode()).hexdigest(),'fc2_arithmetic_sha256':hashlib.sha256(fc2.encode()).hexdigest(),'status':'CPU_IMPLEMENTATION_NOT_YET_AOT','changes':['Static Task tile offset is explicit phase*4','Borrow one outer stage SMEM allocation for sequential phases','FC1 output bytes/scales stored in pinned shared logical fragment','Native BF16 TMEM store mapping from independently exact FC2v2','Same host TensorMap construction; outercluster4 does not change native cfg.cluster_m1/MMAgroup1'],'no_timing':True}
(OUT/'stage-source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
