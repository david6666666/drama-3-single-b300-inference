"""Artifact-only CuTe translation of the exact-validated CUDA shared activation.

Unvalidated numerical translation until its own GPU gate. No hidden allocation,
CTA synchronization, global access, or bypass of either native FP8 boundary.
Caller supplies shared tensors with logical layouts x[8,256], sf[2,8], y[8,128],
ysf[8]. x is up128 followed by gate128; sf is up/gate then token. All thread IDs
are CTA-local; only warps0..7 participate, with one complete warp per valid row.
"""
# SPDX-License-Identifier: Apache-2.0
# Arithmetic/converters adapted from FlashInfer activationDeepSeekKernel and
# CUTLASS float_e4m3_t; native code and SASS provenance are in ../expert-activation-native.
import cutlass
import cutlass.cute as cute
from cutlass import Float32, Int32, Uint8, Uint32
from cutlass.cutlass_dsl import dsl_user_op
from cutlass._mlir.dialects import llvm


def _asm(result_type, operands, code, constraints, loc=None, ip=None):
    return llvm.inline_asm(result_type, operands, code, constraints,
        has_side_effects=False, is_align_stack=False,
        asm_dialect=llvm.AsmDialect.AD_ATT, loc=loc, ip=ip)


@dsl_user_op
def fp8_bits_to_float(value, *, loc=None, ip=None):
    # Exact scalar CUTLASS route: E4M3 byte -> low FP16 -> FP32.
    return Float32(_asm(Float32.mlir_type, [Uint32(value).ir_value(loc=loc, ip=ip)],
        """{ .reg .b16 q, h, unused; .reg .b32 packed;
          cvt.u16.u32 q, $1;
          cvt.rn.f16x2.e4m3x2 packed, q;
          mov.b32 {h, unused}, packed;
          cvt.f32.f16 $0, h;
        }""", "=f,r", loc, ip))


@dsl_user_op
def native_silu_product(up, gate, up_scale, gate_scale, *, loc=None, ip=None):
    # Native nvcc -use_fast_math SASS order: separate FTZ products, EX2 of
    # gate*(-log2(e)), +1, approximate reciprocal, gate*reciprocal, then *up.
    args=[Float32(v).ir_value(loc=loc, ip=ip) for v in (up,gate,up_scale,gate_scale)]
    return Float32(_asm(Float32.mlir_type,args,
        """{ .reg .f32 x1, x2, t;
          mul.rn.ftz.f32 x1, $1, $3;
          mul.rn.ftz.f32 x2, $2, $4;
          mul.rn.ftz.f32 t, x2, 0fbfb8aa3b;
          ex2.approx.ftz.f32 t, t;
          add.rn.ftz.f32 t, t, 0f3f800000;
          rcp.approx.ftz.f32 t, t;
          mul.rn.ftz.f32 t, x2, t;
          mul.rn.ftz.f32 $0, t, x1;
        }""", "=f,f,f,f,f",loc,ip))


@dsl_user_op
def abs_ftz(value, *, loc=None, ip=None):
    return Float32(_asm(Float32.mlir_type,[Float32(value).ir_value(loc=loc,ip=ip)],
        'abs.ftz.f32 $0, $1;', '=f,f',loc,ip))


@dsl_user_op
def max_ftz(lhs,rhs, *, loc=None, ip=None):
    return Float32(_asm(Float32.mlir_type,[Float32(v).ir_value(loc=loc,ip=ip) for v in (lhs,rhs)],
        'max.ftz.f32 $0, $1, $2;', '=f,f,f',loc,ip))


@dsl_user_op
def native_activation_scale(amax, *, loc=None, ip=None):
    # Native activation uses max(amax * RN(1/448), FLT_MIN), not FC1's
    # reciprocal-of-quantizer scale and not a generic per-token quantizer.
    return Float32(_asm(Float32.mlir_type,[Float32(amax).ir_value(loc=loc,ip=ip)],
        """{ .reg .f32 s;
          mul.rn.ftz.f32 s, $1, 0f3b124925;
          max.ftz.f32 $0, s, 0f00800000;
        }""",'=f,f',loc,ip))


@dsl_user_op
def native_quantize(value, scale, *, loc=None, ip=None):
    args=[Float32(v).ir_value(loc=loc,ip=ip) for v in (value,scale)]
    result=Uint32(_asm(Uint32.mlir_type,args,
        """{ .reg .f32 r, q; .reg .b16 bits;
          rcp.approx.ftz.f32 r, $2;
          mul.rn.ftz.f32 q, $1, r;
          cvt.rn.satfinite.e4m3x2.f32 bits, 0f00000000, q;
          cvt.u32.u16 $0, bits;
        }""",'=r,f,f',loc,ip))
    return Uint8(result)


@cute.jit
def activation_shared_8x128(x: cute.Tensor, sf: cute.Tensor,
                            y: cute.Tensor, ysf: cute.Tensor,
                            valid_rows: Int32, thread_idx: Int32):
    """No CTA barrier: caller owns producer/publication/consumer lifetime."""
    warp=thread_idx//Int32(32)
    lane=thread_idx%Int32(32)
    if warp<Int32(8):
        if warp<valid_rows:
            values=cute.make_rmem_tensor((4,),Float32)
            amax=Float32(0.0)
            for i in cutlass.range_constexpr(4):
                channel=lane*Int32(4)+Int32(i)
                up=fp8_bits_to_float(x[warp,channel])
                gate=fp8_bits_to_float(x[warp,Int32(128)+channel])
                values[i]=native_silu_product(up,gate,sf[0,warp],sf[1,warp])
                amax=max_ftz(amax,abs_ftz(values[i]))
            for i in cutlass.range_constexpr(5):
                amax=max_ftz(amax,cute.arch.shuffle_sync_down(amax,Int32(16>>i)))
            amax=cute.arch.shuffle_sync(amax,Int32(0))
            scale=native_activation_scale(amax)
            if lane==Int32(0):
                ysf[warp]=scale
            for i in cutlass.range_constexpr(4):
                y[warp,lane*Int32(4)+Int32(i)]=native_quantize(values[i],scale)
