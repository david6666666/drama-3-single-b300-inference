"""Replay identical real autoregressive requests with synchronous/queued codec.

Request order and sampling counters are fixed. Compare all generated codes,
model state, codec state and delivered PCM across two generations reusing slots.
This isolates stream safety from service admission and stochastic batch changes.
"""

import argparse
import ctypes
import os
import subprocess
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace

import torch
import torch.nn.functional as F
import triton
from fish_speech.models.text2semantic.fish_omni.generate import build_drama3_prompt
from validate_async_codec import request

from drama3.audio_queue import AudioQueue
from drama3.codec import load_codec, streaming_codec
from drama3.engine import BatchedPrefillGraph, DecodeGraph, Engine, state_pool_size
from drama3.model import DramaModel
from drama3.runtime_state import DeviceRequests


@torch.inference_mode()
def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", required=True, type=Path)
    parser.add_argument("--fish-source", required=True, type=Path)
    parser.add_argument("--corpus", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    data = args.corpus.read_bytes()
    samples = [json.loads(s) for s in data.splitlines()][:64]
    model = DramaModel(str(args.checkpoint), slots=state_pool_size(64), max_length=2048)
    device = DeviceRequests(model.slots, model.config.eos_token_id, model.max_length)
    graph = DecodeGraph(model, 64, requests=device)
    first = DecodeGraph(model, 8, first_frame=True, requests=device)
    codec = streaming_codec(load_codec(args.checkpoint, args.fish_source), 64)
    engine = Engine.__new__(Engine)
    engine.device_requests = device
    engine.codec_graphs = codec
    prompts = [
        build_drama3_prompt(
            s["text"],
            model.weights.tokenizer,
            model.config,
            [s["reference_text"]],
            [torch.tensor(s["reference_codes"])],
        )
        for s in samples
    ]
    requests = [SimpleNamespace(slot=i, position=len(p) - 1) for i, p in enumerate(prompts)]
    prefill = BatchedPrefillGraph(model, 8, triton.next_power_of_2(max(map(len, prompts))))
    for i, prompt in enumerate(prompts):
        history = F.pad(prompt[-16:, 0], (max(0, 16 - len(prompt)), 0), value=-1).cuda()
        device.initialize(i, prompt[-1].cuda(), history, len(prompt) - 1, 500)
    for start in range(0, 64, 8):
        hidden = prefill.run(prompts[start : start + 8], list(range(start, start + 8)))
        first.run(requests[start : start + 8], hidden)
    graph.run(requests)
    model_tensors = [v for pair in (*model.states.values(), *model.kv.values()) for v in pair]
    model_tensors += [
        device.last,
        device.history,
        device.metadata,
        device.codes,
        model.sampling_step,
    ]
    codec_tensors = [*codec.stream.tensors.values(), *codec.stream.kv_tensors.values()]
    initial = [value.clone() for value in model_tensors]
    initial_codec = [value.clone() for value in codec_tensors]
    # Eight genuine AR steps supply fixed codec inputs before every timing arm.
    for _ in range(7):
        graph.graph.replay()
    torch.cuda.synchronize()
    counts = device.metadata[:64,1].cpu().tolist()
    valid = [i for i,n in enumerate(counts) if n >= 8]
    assert len(valid) >= 24, counts
    initial = [value.clone() for value in model_tensors]
    initial_codec = [value.clone() for value in codec_tensors]
    cudart = ctypes.CDLL('/home/zjy/code/hsliu/venvs/codex-drama3-standalone/lib/python3.12/site-packages/nvidia/cu13/lib/libcudart.so.13')
    getflags=cudart.cudaGraphExecGetFlags
    getflags.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_ulonglong)]
    getflags.restype=ctypes.c_int
    flags=ctypes.c_ulonglong()
    assert getflags(ctypes.c_void_p(graph.graph.raw_cuda_graph_exec()),ctypes.byref(flags))==0
    assert not flags.value & 8, 'Graph instantiated with node priorities; launch priority is not the tested variable'
    normal = torch.cuda.Stream(priority=0)
    high = torch.cuda.Stream(priority=-1)
    audio = torch.cuda.Stream(priority=0)
    assert high.priority < normal.priority, 'Device provides no distinct high priority'
    result=dict(source_sha='ab6da532083854670348583d9ec9f2a16d184dfb',driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),gpu_uuid=str(torch.cuda.get_device_properties(0).uuid),corpus_sha256=hashlib.sha256(data).hexdigest(),graph_instantiate_flags=flags.value,stream_priorities=dict(normal=normal.priority,high=high.priority,codec=audio.priority),actual_frame_counts=counts,initial_done=int(device.metadata[:64,3].sum()),model_steps_per_arm=4,codec_jobs_per_arm=3,codec_frames_per_job=8,trials=[],status='RUNNING',limitations=['Fixed input/state causal interference probe, not a service or quality benchmark.','Launches use an existing captured graph and its original private workspace; priority cannot preempt already-running kernels.','Codec inputs are three distinct actual request groups and do not depend on the four timed future decode steps.'])
    def save(): args.output.write_text(json.dumps(result,indent=2)+'\n')
    save()
    for size in (1,4,8):
        jobs=[]
        for j in range(3):
            slots=valid[j*size:(j+1)*size]
            rows=torch.tensor([slots,[1]*size,[8]*size,[0]*size],device='cuda',dtype=torch.int64)
            jobs.append((device.gather_codes(rows,8),rows))
        torch.cuda.synchronize()
        expected_model=expected_codec=expected_pcm=None
        for iteration in range(4):
            arms=['serial','model_only','codec_only','concurrent','model_priority']
            if iteration % 2: arms=arms[::-1]
            for arm in arms:
                if expected_model is None and arm!='serial': raise AssertionError('Serial reference must run first')
                for dst,src in zip(model_tensors,initial,strict=True): dst.copy_(src)
                for dst,src in zip(codec_tensors,initial_codec,strict=True): dst.copy_(src)
                torch.cuda.synchronize()
                origin=torch.cuda.Event(enable_timing=True);mb=torch.cuda.Event(enable_timing=True);me=torch.cuda.Event(enable_timing=True);cb=torch.cuda.Event(enable_timing=True);ce=torch.cuda.Event(enable_timing=True)
                origin.record()
                stream=high if arm=='model_priority' else normal
                stream.wait_event(origin);audio.wait_event(origin)
                if arm!='codec_only':
                    with torch.cuda.stream(stream):
                        mb.record()
                        for _ in range(4): graph.graph.replay()
                        me.record()
                outputs=[]
                if arm!='model_only':
                    if arm=='serial': audio.wait_event(me)
                    with torch.cuda.stream(audio),torch.autocast('cuda',dtype=codec.decoder.dtype):
                        cb.record()
                        for codes,rows in jobs:
                            waveform=codec(codes,rows=rows)
                            outputs.append((waveform.clamp(-1,1)*32767).to(torch.int16))
                        ce.record()
                torch.cuda.synchronize()
                if expected_model is None:
                    expected_model=[x.clone() for x in model_tensors]
                    expected_codec=[x.clone() for x in codec_tensors]
                    expected_pcm=[x.clone() for x in outputs]
                model_ref=initial if arm=='codec_only' else expected_model
                codec_ref=initial_codec if arm=='model_only' else expected_codec
                model_bad=[i for i,(x,y) in enumerate(zip(model_tensors,model_ref,strict=True)) if not torch.equal(x,y)]
                codec_bad=[i for i,(x,y) in enumerate(zip(codec_tensors,codec_ref,strict=True)) if not torch.equal(x,y)]
                pcm_bad=[] if arm=='model_only' else [i for i,(x,y) in enumerate(zip(outputs,expected_pcm,strict=True)) if not torch.equal(x,y)]
                row=dict(batch=size,iteration=iteration,arm=arm,model_ms=None if arm=='codec_only' else mb.elapsed_time(me),codec_ms=None if arm=='model_only' else cb.elapsed_time(ce),pair_ms=max([origin.elapsed_time(e) for e in ([ce] if arm=='codec_only' else [me] if arm=='model_only' else [me,ce])]),model_differences=model_bad,codec_differences=codec_bad,pcm_differences=pcm_bad)
                result['trials'].append(row);save()
                assert not(model_bad or codec_bad or pcm_bad), row
            print(json.dumps(dict(batch=size,iteration=iteration)),flush=True)
    result['status']='PASS';save()


if __name__ == '__main__':
    main()
