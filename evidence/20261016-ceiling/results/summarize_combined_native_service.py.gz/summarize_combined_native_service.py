import collections
import json
import re
from pathlib import Path

p=Path(__file__).resolve().parent
experiment=json.loads((p/'combined-native-service-experiment.json').read_text())
result=dict(source_sha=experiment['source_sha'],concurrency=64,requests_per_arm=1088,repeats_per_arm=1,profile_enabled=False,limits=dict(wer_corpus_max=.02950933601272712,sim_min=61.88158934120563),arms={},qualification='One feasibility pair only, no statistical speedup claim. Generated output lengths and quality must be considered. The7.23ms local fixed-inputB64 diagnostic used different input state from old8.275ms and is not a new universal ceiling.')
rows={}
for arm in ['control','candidate']:
 b=p/f'combined-native-{arm}-gpu0/benchmark'
 raw=[json.loads(x) for x in (b/'c64-r0.jsonl').read_text().splitlines()]
 rows[arm]={x['sample_id']:x for x in raw}
 q=json.loads((p/f'combined-native-{arm}-quality.json').read_text())['groups']['c64-r0']
 m=json.loads((b/'summary.json').read_text())[0]
 assert len(raw)==1088 and len(rows[arm])==1088 and all(x['success'] for x in raw)
 assert q['complete'] and q['wer']['evaluated']==q['similarity']['evaluated']==1088
 result['arms'][arm]=dict(metrics=m,output=dict(acoustic_frames=sum(x['acoustic_frames'] for x in raw),audio_samples=sum(x['audio_samples'] for x in raw),audio_duration_s=sum(x['audio_duration_s'] for x in raw),at_or_above_500_frames=sum(x['acoustic_frames']>=500 for x in raw),rms_below_1e_3=sum(x['rms']<1e-3 for x in raw),finish_reasons=dict(collections.Counter(x['finish_reason'] for x in raw))),quality={k:v for k,v in q.items() if k!='records'},quality_gate_pass=q['wer']['wer_corpus']<=result['limits']['wer_corpus_max'] and q['similarity']['mean']>=result['limits']['sim_min'],server_pid=int(re.search(r'Started server process \[(\d+)\]',(p/f'combined-native-{arm}-gpu0/server.log').read_text()).group(1)))
c,a=result['arms']['control'],result['arms']['candidate']
result['comparison']=dict(throughput_relative_change=a['metrics']['throughput_frames_s']/c['metrics']['throughput_frames_s']-1,makespan_relative_change=a['metrics']['makespan_s']/c['metrics']['makespan_s']-1,output_frames_relative_change=a['output']['acoustic_frames']/c['output']['acoustic_frames']-1,ttfa_p50_delta_ms=a['metrics']['ttfa_p50_ms']-c['metrics']['ttfa_p50_ms'],ttfa_p95_delta_ms=a['metrics']['ttfa_p95_ms']-c['metrics']['ttfa_p95_ms'],wer_delta_percentage_points=100*(a['quality']['wer']['wer_corpus']-c['quality']['wer']['wer_corpus']),sim_delta=a['quality']['similarity']['mean']-c['quality']['similarity']['mean'],same_audio_sha256=sum(rows['control'][k]['audio_sha256']==rows['candidate'][k]['audio_sha256'] for k in rows['control']),same_output_frame_count=sum(rows['control'][k]['acoustic_frames']==rows['candidate'][k]['acoustic_frames'] for k in rows['control']))
audit=[json.loads(x) for x in (p/'combined-native-process-audit.jsonl').read_text().splitlines()]
selected=[[x for x in a['processes'] if 'GPU-53ed8fd9-9f5a-9c77-430d-095ad4fc860d' in x] for a in audit]
pids=sorted({int(x.split(',')[1]) for s in selected for x in s})
result['process_audit']=dict(path='combined-native-process-audit.jsonl',samples=len(audit),sampling_interval_s=1,observed_gpu0_pids=pids,expected_server_pids=[c['server_pid'],a['server_pid']],maximum_simultaneous_gpu0_processes=max(map(len,selected)),foreign_process_observed=set(pids)!={c['server_pid'],a['server_pid']},sampling_limitation='One-second polling cannot exclude shorter unobserved interference.')
(p/'combined-native-service-summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(arms={k:dict(metrics=v['metrics'],output=v['output'],wer=v['quality']['wer']['wer_corpus'],sim=v['quality']['similarity']['mean'],quality_gate_pass=v['quality_gate_pass']) for k,v in result['arms'].items()},comparison=result['comparison'],process_audit=result['process_audit']),indent=2))
