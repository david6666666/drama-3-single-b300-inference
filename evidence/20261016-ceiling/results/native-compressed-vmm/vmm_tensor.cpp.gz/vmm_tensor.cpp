// Isolated diagnostic allocator. All owners must outlive captured graphs.
#include <Python.h>
#include <cuda.h>
#include <ATen/dlpack.h>
#include <atomic>
#include <cstdint>
#include <limits>
#include <new>

static std::atomic<long> live{0}, destroyed{0}, cleanup_errors{0};
struct Allocation {
    DLManagedTensor tensor{};
    int64_t shape[1]{};
    CUdevice device{};
    CUcontext context{};
    CUmemGenericAllocationHandle handle{};
    CUdeviceptr pointer{};
    size_t size{};
    bool retained{}, reserved{}, mapped{}, counted{};
};
static void note(CUresult result) { if (result != CUDA_SUCCESS) ++cleanup_errors; }
static void dispose(Allocation* a) {
    if (!a) return;
    bool pushed = false;
    if (a->context) {
        CUresult code = cuCtxPushCurrent(a->context);
        note(code); pushed = code == CUDA_SUCCESS;
    }
    if (pushed) {
        // Cleanup is outside every measured interval and protects foreign storage.
        note(cuCtxSynchronize());
        if (a->mapped) note(cuMemUnmap(a->pointer, a->size));
        if (a->reserved) note(cuMemAddressFree(a->pointer, a->size));
        if (a->handle) note(cuMemRelease(a->handle));
        CUcontext ignored{}; note(cuCtxPopCurrent(&ignored));
    }
    if (a->retained) note(cuDevicePrimaryCtxRelease(a->device));
    if (a->counted) { --live; ++destroyed; }
    delete a;
}
static void tensor_delete(DLManagedTensor* tensor) {
    dispose(static_cast<Allocation*>(tensor->manager_ctx));
}
static void capsule_delete(PyObject* capsule) {
    if (PyCapsule_IsValid(capsule, "dltensor")) {
        auto* tensor = static_cast<DLManagedTensor*>(PyCapsule_GetPointer(capsule, "dltensor"));
        tensor->deleter(tensor);
    }
}
static PyObject* fail(const char* operation, CUresult code, Allocation* a) {
    const char* message = nullptr; cuGetErrorString(code, &message);
    dispose(a);
    PyErr_Format(PyExc_RuntimeError, "%s: CUDA %d (%s)", operation, int(code), message ? message : "unknown");
    return nullptr;
}
static PyObject* allocate(PyObject*, PyObject* args) {
    unsigned long long bytes{}; int device_id{}, compress{};
    if (!PyArg_ParseTuple(args, "Kii", &bytes, &device_id, &compress)) return nullptr;
    if (!bytes || bytes > static_cast<unsigned long long>(std::numeric_limits<int64_t>::max()) ||
        device_id < 0 || (compress != 0 && compress != 1)) {
        PyErr_SetString(PyExc_ValueError, "Require positive int64 byte size, nonnegative device, compression 0 or 1");
        return nullptr;
    }
    CUcontext current{}; CUresult code = cuCtxGetCurrent(&current);
    if (code != CUDA_SUCCESS) return fail("cuCtxGetCurrent", code, nullptr);
    if (!current) { PyErr_SetString(PyExc_RuntimeError, "Initialize the target Torch CUDA context first"); return nullptr; }
    CUdevice current_device{}; code = cuCtxGetDevice(&current_device);
    if (code != CUDA_SUCCESS) return fail("cuCtxGetDevice", code, nullptr);
    if (current_device != device_id) { PyErr_SetString(PyExc_ValueError, "Current CUDA context device mismatch"); return nullptr; }
    auto* a = new (std::nothrow) Allocation();
    if (!a) return PyErr_NoMemory();
    a->device = current_device;
    code = cuDevicePrimaryCtxRetain(&a->context, a->device);
    if (code != CUDA_SUCCESS) return fail("cuDevicePrimaryCtxRetain", code, a);
    a->retained = true;
    if (a->context != current) { dispose(a); PyErr_SetString(PyExc_ValueError, "Only the current primary context is supported"); return nullptr; }
    CUmemAllocationProp prop{};
    prop.type = CU_MEM_ALLOCATION_TYPE_PINNED;
    prop.location.type = CU_MEM_LOCATION_TYPE_DEVICE;
    prop.location.id = device_id;
    prop.allocFlags.compressionType = compress ? CU_MEM_ALLOCATION_COMP_GENERIC : CU_MEM_ALLOCATION_COMP_NONE;
    size_t granularity{};
    code = cuMemGetAllocationGranularity(&granularity, &prop, CU_MEM_ALLOC_GRANULARITY_MINIMUM);
    if (code != CUDA_SUCCESS) return fail("cuMemGetAllocationGranularity", code, a);
    if (!granularity || bytes > std::numeric_limits<size_t>::max() - (granularity - 1)) {
        dispose(a); PyErr_SetString(PyExc_OverflowError, "Invalid allocation granularity or rounded size overflow"); return nullptr;
    }
    a->size = ((bytes + granularity - 1) / granularity) * granularity;
    code = cuMemCreate(&a->handle, a->size, &prop, 0);
    if (code != CUDA_SUCCESS) return fail("cuMemCreate", code, a);
    CUmemAllocationProp actual{};
    code = cuMemGetAllocationPropertiesFromHandle(&actual, a->handle);
    if (code != CUDA_SUCCESS) return fail("cuMemGetAllocationPropertiesFromHandle", code, a);
    code = cuMemAddressReserve(&a->pointer, a->size, 0, 0, 0);
    if (code != CUDA_SUCCESS) return fail("cuMemAddressReserve", code, a);
    a->reserved = true;
    code = cuMemMap(a->pointer, a->size, 0, a->handle, 0);
    if (code != CUDA_SUCCESS) return fail("cuMemMap", code, a);
    a->mapped = true;
    CUmemAccessDesc access{}; access.location = prop.location; access.flags = CU_MEM_ACCESS_FLAGS_PROT_READWRITE;
    code = cuMemSetAccess(a->pointer, a->size, &access, 1);
    if (code != CUDA_SUCCESS) return fail("cuMemSetAccess", code, a);
    a->shape[0] = static_cast<int64_t>(bytes);
    a->tensor.dl_tensor.data = reinterpret_cast<void*>(a->pointer);
    a->tensor.dl_tensor.device = DLDevice{kDLCUDA, device_id};
    a->tensor.dl_tensor.ndim = 1;
    a->tensor.dl_tensor.dtype = DLDataType{kDLUInt, 8, 1};
    a->tensor.dl_tensor.shape = a->shape;
    a->tensor.dl_tensor.strides = nullptr;
    a->tensor.dl_tensor.byte_offset = 0;
    a->tensor.manager_ctx = a;
    a->tensor.deleter = tensor_delete;
    a->counted = true; ++live;
    PyObject* capsule = PyCapsule_New(&a->tensor, "dltensor", capsule_delete);
    if (!capsule) { dispose(a); return nullptr; }
    PyObject* metadata = Py_BuildValue("{s:K,s:K,s:K,s:i,s:i,s:i}",
        "pointer", static_cast<unsigned long long>(a->pointer),
        "requested_bytes", bytes, "mapped_bytes", static_cast<unsigned long long>(a->size),
        "compression_requested", compress, "compression_actual", int(actual.allocFlags.compressionType),
        "device", device_id);
    if (!metadata) { Py_DECREF(capsule); return nullptr; }
    PyObject* result = PyTuple_Pack(2, capsule, metadata);
    Py_DECREF(capsule); Py_DECREF(metadata);
    return result;
}
static PyObject* stats(PyObject*, PyObject*) {
    return Py_BuildValue("{s:l,s:l,s:l}", "live", live.load(), "destroyed", destroyed.load(), "cleanup_errors", cleanup_errors.load());
}
static PyMethodDef methods[] = {
    {"allocate", allocate, METH_VARARGS, "Return DLPack uint8 owner and actual VMM metadata."},
    {"stats", stats, METH_NOARGS, "Diagnostic allocation lifecycle counts."},
    {nullptr, nullptr, 0, nullptr}
};
static PyModuleDef module = {PyModuleDef_HEAD_INIT, "_vmm_tensor", nullptr, -1, methods};
PyMODINIT_FUNC PyInit__vmm_tensor() { return PyModule_Create(&module); }
