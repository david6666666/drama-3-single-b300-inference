"""One allocation/byte/graph/lifetime gate. No performance measurement."""
import gc
import hashlib
import json
import os
from pathlib import Path
import struct
import subprocess

import numpy as np
import torch

import vmm_weights as vmm

OUT = Path(__file__).parent
AUDIT = OUT.parent / 'native-lossless-weight-audit/result.json'
UUID = 'GPU-4ae7e013-1aac-31d8-8b8e-c27530f1c6ed'

def audit_processes():
    raw = subprocess.check_output(['nvidia-smi', '--query-compute-apps=gpu_uuid,pid', '--format=csv,noheader,nounits'],text=True)
    rows = []
    for line in raw.splitlines():
        fields = [s.strip() for s in line.split(',')]
        if len(fields) == 2 and fields[0] == UUID:
            rows.append({'uuid': fields[0], 'pid': int(fields[1])})
    return rows

@torch.inference_mode()
def main():
    protocol = json.loads((OUT / 'micro-protocol.json').read_text())
    for path,digest in protocol['files'].items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == digest, path
    report={'status':'RUNNING','pid':os.getpid(),'scope':'Allocation/bytes/graph/lifetime gate only; no timing','checks':[], 'allocations':[], 'process_audits':[]}
    def flush(): (OUT/'micro-result.json').write_text(json.dumps(report,indent=2)+'\n')
    def check(name, condition):
        report['checks'].append({'name':name,'pass':bool(condition)});flush()
        assert condition,name
    def process_check():
        rows=audit_processes();report['process_audits'].append(rows);flush()
        check('sampled process owner',all(r['pid']==os.getpid() for r in rows))
    flush()
    try:
        check('preflight device empty',not audit_processes())
        torch.cuda.init();torch.cuda.set_device(0)
        observed=str(torch.cuda.get_device_properties(0).uuid)
        check('device UUID',observed.removeprefix('GPU-')==UUID.removeprefix('GPU-'))
        check('initial no VMM owners',vmm.stats()=={'live':0,'destroyed':0,'cleanup_errors':0})
        samples=json.loads(AUDIT.read_text())['tensors']
        selected=[samples[0],next(s for s in samples if '.layers.39.' in s['key'] and '.experts.0.down_' in s['key'])]
        for item in selected:
            process_check()
            with Path(item['file']).open('rb') as f:
                size=struct.unpack('<Q',f.read(8))[0];header=json.loads(f.read(size));begin,end=header[item['key']]['data_offsets'];f.seek(8+size+begin);raw=f.read(end-begin)
            check('actual input hash '+item['key'],hashlib.sha256(raw).hexdigest()==item['raw_sha256'])
            original=torch.from_numpy(np.frombuffer(raw,dtype=np.uint8).copy()).cuda().view(torch.float8_e4m3fn).reshape(item['shape'])
            control,cm=vmm.clone_weight(original,compression=False)
            candidate,bm=vmm.clone_weight(original,compression=True)
            report['allocations'].append({'tensor':item['key'],'control':cm,'candidate':bm});flush()
            check('actual uncompressed flag',cm['compression_actual']==0)
            check('actual compressed flag',bm['compression_actual']==1)
            check('different live storage',len({original.data_ptr(),control.data_ptr(),candidate.data_ptr()})==3)
            check('same tensor contracts',control.dtype==candidate.dtype==original.dtype and control.shape==candidate.shape==original.shape and control.stride()==candidate.stride()==original.stride())
            check('control original bytes',torch.equal(control.view(torch.uint8),original.view(torch.uint8)))
            check('candidate original bytes',torch.equal(candidate.view(torch.uint8),original.view(torch.uint8)))
            original_before=original.view(torch.uint8).clone()
            mask=torch.zeros((),dtype=torch.uint8,device='cuda')
            outputs=[torch.empty_like(original,dtype=torch.uint8) for _ in range(2)]
            stream=torch.cuda.Stream();stream.wait_stream(torch.cuda.current_stream())
            with torch.cuda.stream(stream):
                for _ in range(2):
                    torch.bitwise_xor(control.view(torch.uint8),mask,out=outputs[0]);torch.bitwise_xor(candidate.view(torch.uint8),mask,out=outputs[1])
            torch.cuda.current_stream().wait_stream(stream)
            graph=torch.cuda.CUDAGraph()
            with torch.cuda.graph(graph):
                torch.bitwise_xor(control.view(torch.uint8),mask,out=outputs[0]);torch.bitwise_xor(candidate.view(torch.uint8),mask,out=outputs[1])
            for value in [0,63,255,0]:
                mask.fill_(value);graph.replay()
                expected=torch.bitwise_xor(original_before,value)
                for i,out in enumerate(outputs):check(f'graph changing mask {value} arm{i}',torch.equal(out,expected))
            check('both readonly weights',torch.equal(control.view(torch.uint8),original_before) and torch.equal(candidate.view(torch.uint8),original_before))
            # A view keeps the DLPack manager alive after the original Tensor reference is dropped.
            view=candidate.view(torch.uint8).reshape(-1);del candidate
            gc.collect();check('view retains allocation',vmm.stats()['live']==2)
            check('retained view byte exact',torch.equal(view,original_before.reshape(-1)))
            torch.cuda.synchronize();del graph,view,control,outputs,original,original_before,mask,expected,out
            gc.collect();check('full owners released',vmm.stats()['live']==0 and vmm.stats()['cleanup_errors']==0)
        # Unconsumed DLPack capsule is a distinct cleanup route.
        capsule,metadata=vmm._impl.allocate(17,0,1)
        check('unused capsule actual flag',metadata['compression_actual']==1)
        check('unused capsule live',vmm.stats()['live']==1)
        del capsule;gc.collect()
        check('unused capsule released',vmm.stats()['live']==0 and vmm.stats()['cleanup_errors']==0)
        process_check();report['stats']=vmm.stats();report['status']='PASS';flush()
    except Exception as error:
        report['status']='FAIL';report['error']={'type':type(error).__name__,'message':str(error)};report['stats']=vmm.stats();flush();raise

if __name__=='__main__': main()
