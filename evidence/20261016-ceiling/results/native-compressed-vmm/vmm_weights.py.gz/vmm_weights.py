"""Diagnostic-only byte-preserving CUDA VMM storage; retain owners with graphs."""
import importlib.util
from pathlib import Path
import sysconfig

import torch

_path = Path(__file__).parent / ('_vmm_tensor' + sysconfig.get_config_var('EXT_SUFFIX'))
_spec = importlib.util.spec_from_file_location('_vmm_tensor', _path)
_impl = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_impl)


def clone_weight(source, *, compression):
    if not source.is_cuda or not source.is_contiguous() or source.numel() == 0:
        raise ValueError('Require a nonempty contiguous CUDA tensor')
    if source.device.index != torch.cuda.current_device():
        raise ValueError('Source must be on the current CUDA device')
    capsule, metadata = _impl.allocate(source.numel() * source.element_size(), source.device.index, int(compression))
    # DLPack uint8 avoids float8 interchange enum ambiguity. View changes no bytes.
    owner = torch.from_dlpack(capsule)
    result = owner.view(source.dtype).reshape(source.shape)
    result.view(torch.uint8).copy_(source.view(torch.uint8))
    return result, metadata


def stats():
    return _impl.stats()
