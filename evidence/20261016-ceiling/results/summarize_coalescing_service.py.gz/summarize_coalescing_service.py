import collections,json,re,subprocess
from pathlib import Path
root=Path(__file__).resolve().parent
uuid='GPU-40e00845-d89c-1393-2c32-a2dca3ee9442'
limits=dict(wer_corpus_max=.02950933601272712,sim_min=61.88158934120563)
summary=dict(source_sha='69d636ef11875add6e4edf7c9bb028b9574143a3',concurrency=64,requests_per_arm=1088,repeats_per_arm=1,profile_enabled=False,limits=limits,arms={},qualification='One feasibility pair, no replicated or fixed-output speedup claim. Native codec floating effects remain separate from exact ownership/model gates. Both arms require complete unfiltered1088 WER/SIM.',artifacts=dict(service_protocol='coalescing-native-service-experiment.json',quality_protocol='coalescing-native-quality-experiment.json',dynamic='codec-minlaunch/coalescing-summary.json',fp32='codec-minlaunch/fp32-coalescing-requests.json'))
raw={}
for arm in ('control','candidate'):
 path=root/f'coalescing-native-{arm}-gpu7';bench=path/'benchmark'
 metrics=json.loads((bench/'summary.json').read_text())[0]
 rows=[json.loads(x) for x in (bench/'c64-r0.jsonl').read_text().splitlines()]
 raw[arm]={r['request_id']:r for r in rows}
 assert len(rows)==1088 and len(raw[arm])==1088 and metrics['completed']==1088 and metrics['failed']==0
 quality=json.loads((root/f'coalescing-native-{arm}-quality.json').read_text())['groups']['c64-r0']
 assert quality['complete'] and quality['wer']['evaluated']==1088 and quality['similarity']['evaluated']==1088 and len(quality['records'])==1088
 assert {r['request_id'] for r in quality['records']}==set(raw[arm])
 warmup=json.loads((bench/'c64-warmup.json').read_text());assert warmup and all(r['success'] for r in warmup)
 launch=json.loads((path/'launch.json').read_text());assert launch['source_sha']==summary['source_sha'] and not launch['source_status']
 pid=int(re.search(r'Started server process \[(\d+)\]',(path/'server.log').read_text()).group(1))
 summary['arms'][arm]=dict(metrics=metrics,output=dict(acoustic_frames=sum(r['acoustic_frames'] for r in rows),audio_samples=sum(r['audio_samples'] for r in rows),audio_duration_s=sum(r['audio_duration_s'] for r in rows),at_or_above_500_frames=sum(r['acoustic_frames']>=500 for r in rows),rms_below_1e_3=sum(r['rms']<1e-3 for r in rows),finish_reasons=dict(collections.Counter(r['finish_reason'] for r in rows))),quality={k:v for k,v in quality.items() if k!='records'},quality_gate_pass=quality['wer']['wer_corpus']<=limits['wer_corpus_max'] and quality['similarity']['mean']>=limits['sim_min'],server_pid=pid,startup_to_readiness_s=launch['startup_to_readiness_s'],warmup_requests=len(warmup),warmup_success=True)
a,b=summary['arms']['control'],summary['arms']['candidate']
summary['comparison']=dict(throughput_relative_change=b['metrics']['throughput_frames_s']/a['metrics']['throughput_frames_s']-1,makespan_relative_change=b['metrics']['makespan_s']/a['metrics']['makespan_s']-1,output_frames_relative_change=b['output']['acoustic_frames']/a['output']['acoustic_frames']-1,ttfa_p50_delta_ms=b['metrics']['ttfa_p50_ms']-a['metrics']['ttfa_p50_ms'],ttfa_p95_delta_ms=b['metrics']['ttfa_p95_ms']-a['metrics']['ttfa_p95_ms'],wer_delta_percentage_points=100*(b['quality']['wer']['wer_corpus']-a['quality']['wer']['wer_corpus']),sim_delta=b['quality']['similarity']['mean']-a['quality']['similarity']['mean'],same_audio_sha256=sum(raw['control'][k]['audio_sha256']==raw['candidate'][k]['audio_sha256'] for k in raw['control']),same_output_frame_count=sum(raw['control'][k]['acoustic_frames']==raw['candidate'][k]['acoustic_frames'] for k in raw['control']))
expected={a['server_pid'],b['server_pid']}
for kind,filename in [('service','coalescing-native-process-audit.jsonl'),('quality','coalescing-native-quality-process-audit.jsonl')]:
 samples=[json.loads(x) for x in (root/filename).read_text().splitlines()]
 per=[[int(p.split(',')[1].strip()) for p in s['processes'] if uuid in p] for s in samples]
 observed=set(p for s in per for p in s)
 report=dict(path=filename,samples=len(samples),sampling_interval_s=1,observed_gpu7_pids=sorted(observed),maximum_simultaneous_gpu7_processes=max(map(len,per)),sampling_limitation='One-second polling cannot exclude shorter unobserved interference.')
 if kind=='service':report.update(expected_server_pids=sorted(expected),foreign_process_observed=bool(observed-expected))
 summary[f'{kind}_process_audit']=report
baseline=4510.271508809941
summary['target']=dict(vllm_c64_baseline_frames_s=baseline,required_ratio=1.5,target_frames_s=6765.407263214912,observed_candidate_vs_vllm=b['metrics']['throughput_frames_s']/baseline,achieved=b['metrics']['throughput_frames_s']>=baseline*1.5 and b['quality_gate_pass'])
processes=subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid,pid,process_name,used_gpu_memory','--format=csv,noheader'],text=True)
summary['post_run_gpu7_empty']=uuid not in processes
summary['interpretation']='Same-source coalescing-only feasibility observed lower throughput and slightly longer makespan; output lengths differ. Keep default off; no service speedup or1.5x target claim. Numeric diagnostics did not imply a throughput improvement. Full quality outcomes retained for both arms without exclusions.'
(root/'coalescing-native-service-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ('arms',)},indent=2))
for arm,x in summary['arms'].items():print(arm,x['metrics'],x['quality']['wer']['wer_corpus'],x['quality']['similarity']['mean'],x['quality_gate_pass'])
