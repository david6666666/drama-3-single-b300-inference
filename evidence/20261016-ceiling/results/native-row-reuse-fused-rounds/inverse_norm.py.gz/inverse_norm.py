"""Frozen native BF16 combine/RMS arithmetic; only MoE read row is indirect.

Generated from e7cda1e kernels.py. Residual/output row and normalization axes are
unchanged. No new quantization, arithmetic reassociation or dtype boundary.
Caller owns INVERSE, per-call output storage and all input lifetimes.
"""
import triton
import triton.language as tl

@triton.jit
def inverse_combine_experts_add_norm_kernel(ROUTED, SHARED, GATE, INVERSE, RESIDUAL, W, OUT, STRIDE: tl.constexpr, EPS: tl.constexpr, WIDTH: tl.constexpr):
    row = tl.program_id(0)
    source_row = tl.load(INVERSE + row)
    col = tl.arange(0, WIDTH)
    routed = tl.load(ROUTED + source_row * WIDTH + col)
    shared = tl.load(SHARED + source_row * WIDTH + col)
    gate = tl.sigmoid(tl.load(GATE + source_row * STRIDE).to(tl.float32)).to(SHARED.dtype.element_ty)
    combined = tl.inline_asm_elementwise('fma.rn.bf16 $0, $1, $2, $3;', constraints='=h,h,h,h', args=[shared, gate, routed], dtype=tl.bfloat16, is_pure=True, pack=1).to(tl.float32)
    value = combined + tl.load(RESIDUAL + row * WIDTH + col).to(tl.float32)
    value = value.to(ROUTED.dtype.element_ty).to(tl.float32)
    tl.store(RESIDUAL + row * WIDTH + col, value)
    value *= tl.rsqrt(tl.sum(value * value, 0) / WIDTH + EPS)
    value *= 1.0 + tl.load(W + col).to(tl.float32)
    tl.store(OUT + row * WIDTH + col, value)

def inverse_combine(routed, shared, gate, inverse, residual, weight, epsilon, output):
    assert routed.shape == shared.shape and routed.shape[1] == residual.shape[1] == 2048
    assert gate.shape == (len(routed), 1) and output.shape == residual.shape
    assert inverse.shape == (len(residual),) and inverse.stride(0) == 1
    inverse_combine_experts_add_norm_kernel[(len(residual),)](
        routed, shared, gate, inverse, residual, weight, output,
        gate.stride(0), epsilon, residual.shape[-1], num_warps=4,
        enable_fp_fusion=False)
    return output
