"""Production row-reuse five-bucket/shared-pool byte-exact gate; no timing."""

import json
import os
import subprocess
import sys
import time
from types import SimpleNamespace

import torch

from common import (
    CHECKPOINT,
    MIXED_ROW_REUSE_BUCKETS,
    OUT,
    SOURCE,
    SOURCE_SHA,
    build_prompts,
    cases,
    cpu_check,
    exact,
    plan_row_reuse,
    sha,
)


def state_tensors(model, device):
    result = {}
    for index, pair in model.states.items():
        result[f"conv/{index}"], result[f"gdn/{index}"] = pair
    for index, pair in model.kv.items():
        result[f"key/{index}"], result[f"value/{index}"] = pair
    result.update(
        request_last=device.last,
        request_history=device.history,
        request_metadata=device.metadata,
        request_codes=device.codes,
        sampling_step=model.sampling_step,
    )
    return result


@torch.inference_mode()
def main():
    import torch.nn.functional as F
    import triton
    from drama3.engine import BatchedPrefillGraph, DecodeGraph, state_pool_size
    from drama3.frame_pipeline import FramePipelineGraph
    from drama3.mixed_graph import MixedGraph
    from drama3.model import DramaModel
    from drama3.runtime_state import DeviceRequests

    report = dict(
        status="RUNNING",
        exact_passed=False,
        source_sha=SOURCE_SHA,
        pid=os.getpid(),
        checks=[],
        cases=[],
        capture_orders=["ascending", "descending"],
        five_bucket_coverage=[],
        preparation={},
        scope="Production MixedGraph full outputs/all111state byte equality; no kernel patch, performance or service claim",
    )

    def flush():
        (OUT / "result.json").write_text(
            json.dumps(report, indent=2, allow_nan=False) + "\n"
        )

    def check(name, a, b):
        ok = exact(a, b)
        entry = dict(
            name=name, passed=ok, byte_exact=ok, shape=list(a.shape), dtype=str(a.dtype)
        )
        report["checks"].append(entry)
        if not ok:
            if a.shape == b.shape and a.numel():
                delta = a.float() - b.float()
                entry.update(
                    changed=int((a != b).sum()),
                    max_abs=float(delta.abs().max()),
                    rrms=float(
                        (
                            delta.square().mean()
                            / b.float().square().mean().clamp_min(1e-30)
                        ).sqrt()
                    ),
                )
            path = OUT / (name.replace("/", "_") + "-failure.pt")
            torch.save(dict(actual=a.cpu(), expected=b.cpu()), path)
            entry["tensors"] = path.name
            flush()
            raise AssertionError(entry)

    flush()
    try:
        protocol = json.loads((OUT / "protocol.json").read_text())
        for path, expected in protocol["frozen_files"].items():
            assert sha(path) == expected, path
        assert (
            subprocess.check_output(
                ["git", "rev-parse", "HEAD"], cwd=SOURCE, text=True
            ).strip()
            == SOURCE_SHA
        )
        assert (
            subprocess.check_output(
                ["git", "status", "--porcelain"], cwd=SOURCE, text=True
            )
            == ""
        )
        for key, value in protocol["environment"].items():
            assert os.environ.get(key) == value, (key, os.environ.get(key), value)
        prompts = build_prompts()
        case_list = cases(prompts)
        assert [c["name"] for c in case_list] == [
            c["name"] for c in json.loads((OUT / "cpu-check.json").read_text())["cases"]
        ]
        start = time.perf_counter()
        model = DramaModel(CHECKPOINT, slots=state_pool_size(64), max_length=2048)
        device = DeviceRequests(
            model.slots, model.config.eos_token_id, model.max_length
        )
        assert model.fused_moe_residual and model.moe_shared_stream is None
        torch.cuda.synchronize()
        report["preparation"]["model_load_wall_seconds"] = time.perf_counter() - start
        report["device"] = dict(
            name=torch.cuda.get_device_name(0),
            uuid=str(torch.cuda.get_device_properties(0).uuid),
        )
        start = time.perf_counter()
        prefill = BatchedPrefillGraph(
            model, 8, triton.next_power_of_2(max(map(len, prompts[:64])))
        )
        first = DecodeGraph(model, 8, first_frame=True, requests=device)
        decode = DecodeGraph(model, 64, requests=device)
        pair = FramePipelineGraph(model, 64, device)
        torch.cuda.synchronize()
        report["preparation"]["other_graphs_capture_wall_seconds"] = (
            time.perf_counter() - start
        )
        specs = [(64, p, 256, None) for p in (256, 768, 1024, 1280, 1536)] + list(
            MIXED_ROW_REUSE_BUCKETS
        )
        sets = {}
        for order, sequence in [
            ("ascending", specs),
            ("descending", list(reversed(specs))),
        ]:
            graphs = {}
            pool = torch.cuda.graph_pool_handle()
            start = time.perf_counter()
            for d, p, span, k in sequence:
                graph = MixedGraph(
                    model, device, d, 8, p, pool=pool, max_length=span, compact_rows=k
                )
                graphs[(d, p, span, k)] = graph
                print(
                    json.dumps(
                        dict(stage="captured", order=order, key=(d, p, span, k))
                    ),
                    flush=True,
                )
            torch.cuda.synchronize()
            report["preparation"][order + "_capture_wall_seconds"] = (
                time.perf_counter() - start
            )
            report["preparation"][order + "_pool"] = list(pool)
            assert all(g.graph.pool() == pool for g in graphs.values())
            sets[order] = graphs
        assert (
            sets["ascending"][specs[0]].graph.pool()
            != sets["descending"][specs[0]].graph.pool()
        )
        assert decode.graph.pool() != pair.graph.pool()
        assert all(
            decode.graph.pool() != g.graph.pool()
            and pair.graph.pool() != g.graph.pool()
            for graphs in sets.values()
            for g in graphs.values()
        )
        # All graph captures precede real initialization. Fill every primary service
        # slot with a real trajectory, so new arrivals genuinely reuse nonzero state.
        start = time.perf_counter()
        for values in model.states.values():
            for value in values:
                value.zero_()
        for values in model.kv.values():
            for value in values:
                value.zero_()
        device.last.zero_()
        device.last[:, 0] = model.config.eos_token_id
        device.history.fill_(-1)
        device.metadata.zero_()
        device.metadata[:, 0] = model.max_length - 1
        device.metadata[:, 2] = 500
        device.codes.zero_()
        model.sampling_step.zero_()
        all_active = [
            SimpleNamespace(slot=i, position=len(prompts[i]) - 1) for i in range(64)
        ]
        for i in range(64):
            prompt = prompts[i]
            history = F.pad(
                prompt[-16:, 0], (max(0, 16 - len(prompt)), 0), value=-1
            ).cuda()
            device.initialize(i, prompt[-1].cuda(), history, len(prompt) - 1, 500)
        for begin in range(0, 64, 8):
            hidden = prefill.run(
                prompts[begin : begin + 8], list(range(begin, begin + 8))
            )
            first.run(all_active[begin : begin + 8], hidden)
        tensors = state_tensors(model, device)
        assert len(tensors) == 111
        initial = [value.clone() for value in tensors.values()]
        torch.cuda.synchronize()
        report["preparation"]["real_initialize_and_snapshot_wall_seconds"] = (
            time.perf_counter() - start
        )
        report["sampling_step_after_real_initialization"] = int(model.sampling_step)

        def restore():
            for value, saved in zip(tensors.values(), initial, strict=True):
                value.copy_(saved)

        retained = []
        covered = set()
        for order, graphs in sets.items():
            for case in case_list:
                name = order + "/" + case["name"]
                d, p, span, k = case["key"]
                active = all_active[: case["active"]]
                selected = case["prompts"]
                slots = case["slots"]
                capacities = [
                    v[3] for v in MIXED_ROW_REUSE_BUCKETS if v[:3] == (d, p, span)
                ]
                plan = plan_row_reuse(selected, d, p, (k,) if k else capacities)
                assert (plan is not None) == (k is not None)
                control = graphs[(d, p, span, None)]
                candidate = graphs[tuple(case["key"])]
                prompt_bytes = [value.numpy().tobytes() for value in selected]
                rng = torch.cuda.get_rng_state().clone()
                cpu_rng = torch.get_rng_state().clone()
                restore()
                expected = control.run(active, selected, slots)
                expected_states = [value.clone() for value in tensors.values()]
                restore()
                actual = candidate.run(active, selected, slots, row_reuse_plan=plan)
                for i, (value, reference) in enumerate(
                    zip(actual, expected, strict=True)
                ):
                    check(name + f"/output{i}", value, reference)
                for (key, value), reference in zip(
                    tensors.items(), expected_states, strict=True
                ):
                    check(name + "/state/" + key, value, reference)
                check(name + "/cuda_RNG", torch.cuda.get_rng_state(), rng)
                check(name + "/cpu_RNG", torch.get_rng_state(), cpu_rng)
                assert [value.numpy().tobytes() for value in selected] == prompt_bytes
                # Nonparticipating state ownership uses the original graph's legal
                # full slot union, including explicit decode/prompt padding slots.
                owned = set(candidate.slots[:d].cpu().tolist()) | set(
                    candidate.layout.sequence_slots.cpu().tolist()
                )
                untouched = torch.tensor(
                    [i for i in range(model.slots) if i not in owned],
                    device="cuda",
                    dtype=torch.int64,
                )
                for (key, value), saved in zip(tensors.items(), initial, strict=True):
                    if key.startswith(("conv/", "gdn/", "key/", "value/")):
                        check(
                            name + "/untouched/" + key,
                            value.index_select(0, untouched),
                            saved.index_select(0, untouched),
                        )
                if k is not None:
                    covered.add(tuple(case["key"]))
                    keep, inverse, compact_slots = candidate.moe_row_reuse
                    check(
                        name + "/row_indices",
                        candidate.row_indices,
                        plan.packed_indices.cuda(),
                    )
                    check(
                        name + "/compact_slots",
                        compact_slots,
                        candidate.slots.index_select(0, keep),
                    )
                    assert int(inverse.max()) < plan.unique_rows <= k
                    # Runtime captures normal buffers, not artifact guard wrappers.
                    # Check their complete contents and source identities instead of
                    # claiming nonexistent red zones around graph-pool allocations.
                    check(
                        name + "/decode_slots", candidate.slots[:d], control.slots[:d]
                    )
                    check(
                        name + "/boundaries",
                        candidate.layout.boundaries,
                        control.layout.boundaries,
                    )
                    check(
                        name + "/sequence_slots",
                        candidate.layout.sequence_slots,
                        control.layout.sequence_slots,
                    )
                # Public run clones survive same-pool original/compact/other-bucket
                # replays. Retain all earlier returns; compare after every new pair.
                for old_name, outputs, references in retained:
                    for i, (value, reference) in enumerate(
                        zip(outputs, references, strict=True)
                    ):
                        check(name + "/retained/" + old_name + str(i), value, reference)
                retained.append(
                    (name, actual, tuple(value.clone() for value in actual))
                )
                retained.append(
                    (
                        name + "_control",
                        expected,
                        tuple(value.clone() for value in expected),
                    )
                )
                report["cases"].append(
                    dict(
                        name=name,
                        key=case["key"],
                        corpus_ids=case["ids"],
                        lengths=list(map(len, selected)),
                        active=case["active"],
                        slots=slots,
                        synthetic=case["synthetic"],
                        fallback=k is None,
                        unique_rows=plan.unique_rows if plan else None,
                        all111_states=True,
                        untouched_state_tensors=106,
                        passed=True,
                    )
                )
                del expected_states
                flush()
                print(
                    json.dumps(
                        dict(stage="case_pass", name=name, checks=len(report["checks"]))
                    ),
                    flush=True,
                )
            # Real graph negative check: stale same-length conditioning must reject
            # before frames, slots, layout, indices or recurrent/model state writes.
            case = case_list[0]
            d, p, span, k = case["key"]
            graph = graphs[tuple(case["key"])]
            plan = plan_row_reuse(case["prompts"], d, p, (k,))
            buffers = dict(
                frames=graph.frames,
                positions=graph.positions,
                slots=graph.slots,
                labels=graph.labels,
                boundaries=graph.layout.boundaries,
                sequence_slots=graph.layout.sequence_slots,
                row_indices=graph.row_indices,
                compact_slots=graph.moe_row_reuse[2],
            )
            saved = {key: value.clone() for key, value in buffers.items()}
            changed = [p.clone() for p in case["prompts"]]
            changed[0][0, 10] += 1
            try:
                graph.prepare(
                    all_active[: case["active"]],
                    changed,
                    case["slots"],
                    row_reuse_plan=plan,
                )
            except ValueError:
                report["checks"].append(
                    dict(name=order + "/stale_plan_rejected", passed=True)
                )
            else:
                raise AssertionError("stale plan accepted")
            for key, value in buffers.items():
                check(order + "/stale_no_write/" + key, value, saved[key])
            # Existing independent decode/pipeline graph pools interleaved with the
            # shared mixed pool. Each graph is its own deterministic reference.
            for label, other in [("decode", decode), ("frame_pipeline", pair)]:
                restore()
                before = other.run(all_active[:58]).clone()
                other_states = [value.clone() for value in tensors.values()]
                restore()
                graph.run(
                    all_active[: case["active"]],
                    case["prompts"],
                    case["slots"],
                    row_reuse_plan=plan,
                )
                restore()
                after = other.run(all_active[:58]).clone()
                check(order + "/" + label + "/output", after, before)
                for (key, value), reference in zip(
                    tensors.items(), other_states, strict=True
                ):
                    check(order + "/" + label + "/state/" + key, value, reference)
                for old_name, outputs, references in retained:
                    for i, (value, reference) in enumerate(
                        zip(outputs, references, strict=True)
                    ):
                        check(
                            order + "/" + label + "/retained/" + old_name + str(i),
                            value,
                            reference,
                        )
                del other_states
            flush()
        assert covered == set(MIXED_ROW_REUSE_BUCKETS)
        report.update(
            status="PASS",
            exact_passed=True,
            five_bucket_coverage=[list(x) for x in sorted(covered)],
            pool_interleaving_passed=True,
            retained_outputs_passed=True,
            all111_states=True,
            nonparticipating_state_ownership_passed=True,
            stale_plan_rejected_before_writes=True,
            peak_allocated_bytes=torch.cuda.max_memory_allocated(),
            peak_reserved_bytes=torch.cuda.max_memory_reserved(),
        )
        for path, expected in protocol["frozen_files"].items():
            assert sha(path) == expected, path
        flush()
    except Exception as error:
        report.update(
            status="FAIL",
            exact_passed=False,
            failure=dict(type=type(error).__name__, message=str(error)),
        )
        flush()
        raise


if __name__ == "__main__":
    if "--cpu-check" in sys.argv:
        print(json.dumps(cpu_check(), indent=2))
    else:
        main()
