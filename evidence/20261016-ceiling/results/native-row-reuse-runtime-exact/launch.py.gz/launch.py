"""Frozen correctness-only launcher; GPU6 must be idle at preflight."""
import json
import os
import subprocess
import sys
from pathlib import Path

from common import OUT, sha


def main():
    protocol = json.loads((OUT / 'protocol.json').read_text())
    manifest = json.loads((OUT / 'frozen-manifest.json').read_text())
    for path, digest in manifest.items():
        assert sha(path) == digest, path
    for path, digest in protocol['frozen_files'].items():
        assert sha(path) == digest, path
    query = ['nvidia-smi', '-i', '6', '--query-gpu=uuid,memory.used,utilization.gpu', '--format=csv,noheader,nounits']
    gpu = subprocess.check_output(query, text=True).strip()
    uuid, memory, utilization = [x.strip() for x in gpu.split(',')]
    apps = subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid,gpu_uuid,used_gpu_memory', '--format=csv,noheader,nounits'], text=True)
    assert not any(uuid in line for line in apps.splitlines()), apps
    assert int(memory) < 512 and int(utilization) == 0, gpu
    env = os.environ.copy(); env.update(protocol['environment'])
    command = [sys.executable, str(OUT / 'driver.py')]
    preflight = dict(command=command, environment=protocol['environment'], gpu=gpu, compute_apps=apps, scope='Point-in-time ownership check, not continuous exclusivity')
    (OUT / 'preflight.json').write_text(json.dumps(preflight, indent=2) + '\n')
    with (OUT / 'gpu.log').open('w') as log:
        process = subprocess.Popen(command, cwd=OUT, env=env, stdout=log, stderr=subprocess.STDOUT)
        (OUT / 'pid.json').write_text(json.dumps(dict(pid=process.pid, gpu=6), indent=2) + '\n')
        print(json.dumps(dict(pid=process.pid, gpu=6)), flush=True)
        code = process.wait()
    post = subprocess.check_output(query, text=True).strip()
    apps_post = subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid,gpu_uuid,used_gpu_memory', '--format=csv,noheader,nounits'], text=True)
    result = dict(returncode=code, gpu_after=post, compute_apps_after=apps_post, owned_pid_absent=not Path(f'/proc/{process.pid}').exists())
    (OUT / 'postflight.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result), flush=True)
    raise SystemExit(code)


if __name__ == '__main__':
    main()
