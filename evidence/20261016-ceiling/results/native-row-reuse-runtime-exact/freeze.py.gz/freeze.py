"""Freeze CPU-passed source and correctness-only protocol before the first GPU run."""
import json
from pathlib import Path

from common import CHECKPOINT, CORPUS, FISH, MIXED_ROW_REUSE_BUCKETS, OUT, ROOT, SOURCE, SOURCE_SHA, sha

prior = json.loads((ROOT/'native-row-reuse-fused-rounds/protocol.json').read_text())
environment = prior['environment'].copy()
environment['PYTHONPATH'] = str(SOURCE/'src') + ':/home/zjy/code/hsliu/drama3-sources/fish-speech'
environment['DRAMA3_MIXED_ROW_REUSE'] = '1'
files = list((SOURCE/'src/drama3').glob('*.py'))
files += [OUT/name for name in ('common.py','driver.py','launch.py','freeze.py','cpu-check.json')]
files += [FISH,CORPUS,CHECKPOINT/'config.json',CHECKPOINT/'tokenizer.json',ROOT/'native-row-reuse-audit/counts.json',ROOT/'native-row-reuse-runtime-design/finite-bucket-budget.json']
files += [Path(p) for p in prior['frozen_files'] if '/site-packages/' in p]
protocol = dict(source_sha=SOURCE_SHA, source=str(SOURCE), scope='Production native row reuse expanded exact only; no performance/service run', environment=environment, frozen_files={str(p):sha(p) for p in sorted(set(files))}, capture_orders=['ascending','descending'], cases=json.loads((OUT/'cpu-check.json').read_text())['cases'], required_buckets=MIXED_ROW_REUSE_BUCKETS, gates=['No runtime monkeypatch: full production MixedGraph, compact buffers allocated by graph pool.', 'All15cases in both capture orders: unchanged original versus compact or explicit original fallback.', 'Each arm starts from the same full111state snapshot, all64 primary slots initialized with actual real prefills and first sampled frames after allcaptures.', 'All output rows,111states, CPU/CUDA RNG byteexact; all106model state tensors outside union of real/reserved decode and prefill slots untouched.', 'Every earlier publicrun output clone retained and compared after each later samepool replay and separate decode/framepipeline graph replay.', 'Five finite variants, actual batch6, reverse order/different references, active49/56/58 and original active63, synthetic min3/max256, reused slots, noalias/insufficientK/unsupported original fallback.', 'Stale same-length conditioning rejects before graphmetadata writes; source ordering proves no model writes, negative test snapshots graphbuffers.', 'No external sentinel allocations attached to production graphpool buffers; complete maps/slots and fullstate checked instead.', 'On first genuine byte mismatch save tensors and stop. No tolerance relaxation, timing or automatic service continuation.'], limitations=['Corpus grouping uses historical FIFO proxy for case selection, not measured actual current admissions.', 'Synthetic prompts only test native graph mechanics, not speech quality.', 'Two capture orders share one process/model; they are distinct graph pools, not independent process repeats.', 'Point-in-time GPU preflight does not prove continuous exclusivity.', 'No timings or quality measurements in this gate.'])
(OUT/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
manifest={str(p):sha(p) for p in files+[OUT/'protocol.json']}
(OUT/'frozen-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(source_sha=SOURCE_SHA,protocol_sha256=sha(OUT/'protocol.json'),manifest_sha256=sha(OUT/'frozen-manifest.json'),driver_sha256=sha(OUT/'driver.py'),cpu_sha256=sha(OUT/'cpu-check.json'),frozen_files=len(manifest)),indent=2))
