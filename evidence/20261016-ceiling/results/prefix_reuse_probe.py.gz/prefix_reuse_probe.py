"""CPU-only potential of causal runtime prompt reuse; no benchmark preprocessing."""
import hashlib,json,collections,os
from pathlib import Path
import torch
from tokenizers import Tokenizer
from fish_speech.models.text2semantic.fish_omni.config import FishOmniConfig
from fish_speech.models.text2semantic.fish_omni.generate import build_drama3_prompt
root=Path('/home/zjy/code/hsliu/artifacts/drama3-ceiling-20261016')
checkpoint=Path('/home/zjy/.cache/huggingface/hub/models--fishaudio--drama-3/snapshots/e0a9218aa48888270f06ef1ed9ea67622c0e17d2')
corpus=Path('/home/zjy/code/hsliu/artifacts/drama3-b300-20261014/seedtts-en1088-codes/requests.jsonl')
config=FishOmniConfig.from_dict(json.loads((checkpoint/'config.json').read_text()))
tokenizer=Tokenizer.from_file(str(checkpoint/'tokenizer.json'))
samples=[json.loads(line) for line in corpus.read_bytes().splitlines()]
prompts=[build_drama3_prompt(s['text'],tokenizer,config,[s['reference_text']],[torch.tensor(s['reference_codes'])]) for s in samples]
common=0
for i in range(min(map(len,prompts))):
 if all(torch.equal(p[i],prompts[0][i]) for p in prompts[1:]):common+=1
 else:break
results=[]
for capacity in (16,64,128,256,512,1024,4096):
 cache=collections.OrderedDict();hits=[]
 for p in prompts:
  keys=[(n,hashlib.sha256(p[:n+1].numpy().tobytes()).hexdigest()) for n in range(64,len(p)-1,64)]
  matches=[n for n,k in keys if (n,k) in cache]
  hits.append(max(matches,default=0))
  for key in keys:
   cache[key]=None;cache.move_to_end(key)
   while len(cache)>capacity:cache.popitem(last=False)
 results.append(dict(cache_entries=capacity,hit_requests=sum(n>0 for n in hits),reused_rows=sum(hits),fraction_prompt_rows=sum(hits)/sum(map(len,prompts))))
result=dict(source_sha=os.environ.get('SOURCE_SHA'),corpus_sha256=hashlib.sha256(corpus.read_bytes()).hexdigest(),requests=len(prompts),prompt_rows=sum(map(len,prompts)),common_prefix_rows=common,simulation=results,limitations=['CPU-only request-order upper approximation: a later request may arrive before the earlier prefix state is ready at C64.','Cache starts empty; no corpus-derived prefix is loaded into the runtime. Warmup duplicates excluded.','A teacher-tower prefix of n rows requires matching n+1 input rows because labels are shifted.','Actual continuation requires GDN and convolution state plus prefix KV for every backbone/tower attention layer; the current packed prefill starts from zero and attends only current tokens.','Reusing reference audio codes alone cannot skip model prefill.','GEMM shapes and recurrent chunk boundaries may affect rounding; complete native-state and quality comparisons are required before service.'])
(root/'prefix-reuse-probe.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
