"""CPU-only structural probe: M128 can halve epilogue warp groups.
No GPU or performance claim; no dependency edits. Original FP8 format, K32 MMA,
K128 scale boundaries, weights and input tensors remain fixed. M128 arithmetic
parity is not presumed. Stop if configuration/compiler/resource audit fails.
"""
import os,sys,json,traceback,dataclasses,hashlib,subprocess
from pathlib import Path
OUT=Path(__file__).resolve().parent
ROOT=OUT.parent
os.environ.update(CUDA_VISIBLE_DEVICES='', CUTE_DSL_ARCH='sm_103a', CUTE_DSL_KEEP='ptx,cubin', CUTE_DSL_DUMP_DIR=str(OUT/'aot'))
(OUT/'aot').mkdir(exist_ok=True)
sys.path.insert(0,str(ROOT/'expert-fc1-native-v3'))
import common as c
import torch
from flashinfer.prims_ts.batched_gemm.batched_gemm_config import make_config
from flashinfer.prims_ts.batched_gemm.batched_gemm_kernel import build_batched_gemm_task_manager
from flashinfer.prims_ts.batched_gemm.batched_gemm_run import _compile_for_launch
import cuda.bindings.driver as drv
r={'status':'CPU_PROBE','cuda_allowed':False,'timing_allowed':False,'source_sha':'95fcb0ef2662f2caf9bfb7fe6863dc3ad7805b1b','hypothesis':'Replacing two M64 epilogue warp groups by one M128 group may reduce resident dynamic register capacity; this is not an assumed arithmetic-equivalent implementation.','fixed_controls':'Original FP8 weights/scales, K32 MMA, K128 dequant order, tile128x8x128 and four A/B stages. No source/venv changes.','gate':'Successful AOT with bounded complete resources only; independent native bit-exact gate required before timing.'}
try:
 assert not torch.cuda.is_initialized()
 _,base=c.config();kw={**base['candidate'],'mma_m':128,'epi_tile_m':128}
 cfg=make_config(**kw)
 manager=build_batched_gemm_task_manager(num_experts=1,num_tokens=8,top_k=1,verbose=False,**kw)
 r.update(original=base['candidate'],candidate=kw,resolved=dataclasses.asdict(cfg),manager_threads=manager.cfg.threads_per_cta if hasattr(manager,'cfg') else None,allocator_bytes=int(manager.smem_allocator.total_smem_bytes)+int(manager.smem_allocator.barrier_smem_bytes))
 io,x=c.io_for(cfg,c.cpu_data(),'cpu')
 fn=_compile_for_launch(io,drv.CUstream(0))
 (OUT/'aot/host.mlir').write_text(str(fn.ir_module))
 bins=list((OUT/'aot').glob('*.cubin'));assert len(bins)==1
 usage=subprocess.check_output(['/usr/local/cuda/bin/cuobjdump','--dump-resource-usage',str(bins[0])],text=True)
 (OUT/'aot/resources.txt').write_text(usage)
 r.update(status='CPU_AOT_PASS',cubin_sha256=c.sha(bins[0]),resource_usage=usage)
except BaseException as e:
 r.update(status='CPU_PROBE_STOP',error=repr(e),traceback=traceback.format_exc())
finally:
 r['cuda_initialized']=torch.cuda.is_initialized();assert not r['cuda_initialized']
 (OUT/'result.json').write_text(json.dumps(r,indent=2)+'\n')
 print(json.dumps({k:r[k] for k in ('status','cuda_initialized','error','allocator_bytes') if k in r}))
