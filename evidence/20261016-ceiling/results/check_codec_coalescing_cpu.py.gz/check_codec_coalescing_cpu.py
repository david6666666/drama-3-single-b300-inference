"""GPU-free real-planner and engine callback ownership checks."""
import ast
import collections
import itertools
import json
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import torch
from validate_async_codec import request

from drama3.codec_grouping import _execution_cost, coalesce_codec_groups
from drama3.engine import Engine
from drama3.ops.dac_channels_last import DACDecodeGraphs

ROOT=Path(__file__).resolve().parent
original=json.loads((ROOT/'codec-minlaunch/result.json').read_text())
graphs=DACDecodeGraphs(SimpleNamespace(receptive_frames=0),10,(6,8,10,12,16,24,32,64),512,16)
graphs.cost_ms={ast.literal_eval(k):v for k,v in original['codec_cost_ms'].items()}
graphs.split_policy='dp'


def verify(groups):
    actual=coalesce_codec_groups(groups,graphs)
    before=[job for jobs in groups.values() for job in jobs]
    after=[job for _,jobs in actual for job in jobs]
    assert collections.Counter(before)==collections.Counter(after)
    assert len(before)==len(set(before))
    initial={job:frame for frame,jobs in groups.items() for job in jobs}
    rank={f:i for i,f in enumerate(graphs.frame_buckets)}
    for frame,jobs in actual:
        source={initial[j] for j in jobs}
        assert max(source)==frame and len(source)<=2
        assert max(rank[f] for f in source)-min(rank[f] for f in source)<=1
    old=[_execution_cost(graphs,f,len(jobs)) for f,jobs in groups.items()]
    new=[_execution_cost(graphs,f,len(jobs)) for f,jobs in actual]
    assert sum(x[0] for x in new)<=sum(x[0] for x in old)
    assert sum(x[1] for x in new)<=sum(x[1] for x in old)+1e-12
    return sum(x[0] for x in old),sum(x[0] for x in new),len(groups)-len(actual)


# Exhaust all adjacent pairs with realistic queue counts and reversed arrival order.
count=0
for low,high in zip(graphs.frame_buckets,graphs.frame_buckets[1:]):
    for left,right in itertools.product(range(1,33),repeat=2):
        for order in [(low,high),(high,low)]:
            groups={f:[(f,i) for i in range(left if f==low else right)] for f in order}
            verify(groups);count+=1
# Exact batch-rounding edge: planned8 for actual3 executes B4, not B8.
fake=SimpleNamespace(split=lambda f,n:[8],batch_buckets={16:[1,2,4,8]},cost_ms={(4,16,0):4.,(8,16,0):.1})
assert _execution_cost(fake,16,3)==(1,4.)
# Missing/invalid timing evidence cannot introduce merges.
missing=SimpleNamespace(frame_buckets=[6,8],split=lambda f,n:[n],batch_buckets={6:[1,2],8:[1,2]},cost_ms={})
assert coalesce_codec_groups({6:['a'],8:['b']},missing)==[(6,['a']),(8,['b'])]
ledger=json.loads((ROOT/'rich-timeline-service-ledger.json').read_text())
start,end=ledger['time']['first_dispatch_s'],ledger['time']['last_completion_s']
emits=collections.defaultdict(dict)
for row in json.loads((ROOT/'rich-timeline.json').read_text())['records']:
    if row['stage']!='codec_gpu_and_copy' or not start<=row['cpu_start_s']<=end:continue
    groups=emits[row['emit_id']]
    jobs=groups.setdefault(row['frame_bucket'],[])
    jobs.extend(zip(row['request_ids'],row['slot_ids'],row['left_frames'],row['valid_frames'],strict=True))
actual=[verify(g) for g in emits.values()]


def engine_case(enabled):
    engine=Engine.__new__(Engine);engine.profiler=None;engine.codec_graphs=graphs
    engine.coalesce_codec=enabled;engine.defer_codec_submit=False
    engine.device_requests=SimpleNamespace(gather_codes=lambda rows,length:rows.clone())
    queued=[];events={};saved_rows=[]
    def submit(codes,rows,callbacks,**kw):
        assert torch.equal(codes,rows)
        saved_rows.append(rows.clone())
        queued.append((rows.clone(),callbacks))
    engine.audio_queue=SimpleNamespace(submit=submit)
    requests=[]
    for slot,length in enumerate([6,8,6,8,12,16,24,32]):
        key=f'old-{slot}';events[key]=[];r=request(slot,events[key].append)
        r.request_id=key;r.frame_count=length;requests.append(r)
    original_tensor=torch.tensor
    tensor=lambda data,**kw:original_tensor(data,dtype=kw.get('dtype'))
    with patch('torch.tensor',side_effect=tensor):
        engine.emit_audio_batch(requests)
        for r,length in zip(requests,[8,12,8,12,16,24,32,64],strict=True):r.frame_count+=length
        engine.emit_audio_batch(requests)
        for r in requests:engine.finish_audio(r)
        # Reuse a slot before callbacks drain; old callbacks must retain old owner.
        events['new-0']=[];fresh=request(0,events['new-0'].append)
        fresh.request_id='new-0';fresh.frame_count=6
        engine.emit_audio_batch([fresh]);engine.finish_audio(fresh)
    for rows,callbacks in queued:
        for (slot,is_fresh,valid,left),(callback,samples) in zip(rows.T.tolist(),callbacks,strict=True):
            assert is_fresh==int(left==0) and samples==valid*2048
            callback(bytes([(slot+left)%256])*(samples*2))
    assert all(v and v[-1] is None and all(isinstance(x,bytes) for x in v[:-1]) for v in events.values())
    assert all(r.pending_audio==0 for r in [*requests,fresh])
    schedule={r.request_id:(r.emitted,r.chunk_index,r.next_emit) for r in [*requests,fresh]}
    return events,schedule,len(queued)

control=engine_case(False);candidate=engine_case(True)
assert control[:2]==candidate[:2]
assert not torch.cuda.is_initialized()
report=dict(passed=True,cuda_initialized=False,adjacent_pair_count_cases=count,real_ledger_emits=len(emits),replanned_calls_before=sum(x[0] for x in actual),replanned_calls_after=sum(x[1] for x in actual),collapsed_groups=sum(x[2] for x in actual),callback_control_batches=control[2],callback_candidate_batches=candidate[2],callback_bytes_lengths_completion_owner_and_ramp_equal=True,observed_ledger_calls=ledger['timeline']['codec_recorded_partition_accounting']['codec_calls'],limitation='Accounting uses archived numeric DP cost table, not the rich trace capture calibration. No GPU timing, numerical waveform or real model-state claim.')
(ROOT/'codec-coalescing-cpu.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
