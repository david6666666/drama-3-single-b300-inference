"""CPU checks of the real codec planner; no model/capture/PCM claim."""
import hashlib
import json
import math
import os
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

os.environ['CUDA_VISIBLE_DEVICES'] = ''
import torch
from drama3.ops.dac_channels_last import DACDecodeGraphs


def build(policy, max_batch=16):
    values={} if policy is None else {'DRAMA3_CODEC_SPLIT_POLICY':policy}
    with patch.dict(os.environ, values, clear=False):
        if policy is None:
            os.environ.pop('DRAMA3_CODEC_SPLIT_POLICY',None)
        return DACDecodeGraphs(SimpleNamespace(receptive_frames=0),10,
                               (6,8,10,12,16,24,32,64),512,max_batch,receptive_frames=0)


def main():
    checks=0
    for maximum in (1,2,4,8,16):
        graph=build('min_launches',maximum)
        # No timing costs exist: this policy must use only legal captured shapes.
        assert not graph.cost_ms
        for frames in graph.frame_buckets:
            sizes=graph.batch_buckets[frames]
            for count in range(131):
                parts=graph.split(frames,count)
                assert all(size in sizes and size*frames<=512 for size in parts)
                assert len(parts)==math.ceil(count/max(sizes))
                jobs=list(range(count));visited=[];offset=0
                for size in parts:
                    selected=jobs[offset:offset+size]
                    assert selected
                    assert len(selected)<=size
                    assert size==next(s for s in sizes if s>=len(selected))
                    visited.extend(selected);offset+=size
                assert visited==jobs
                assert sum(parts)>=count
                assert graph.split(frames,count) is parts
                checks+=1
        # plan() must retain every input exactly once when lengths span buckets.
        frames=[1,6,7,8,9,10,11,12,13,16,17,24,25,32,33,64]*4
        plan=graph.plan(frames)
        indices=[i for group,_ in plan for i in group]
        assert sorted(indices)==list(range(len(frames)))
        for group,trim in plan:
            assert trim==0 and group==sorted(group)
            buckets={graph.frame_bucket(frames[i]) for i in group}
            assert len(buckets)==1
            bucket=buckets.pop()
            assert len(group)<=graph.max_batch_for[bucket]
        checks+=1
    default,explicit,minimal=build(None),build('dp'),build('min_launches')
    for graph in (default,explicit):
        for frames in graph.frame_buckets:
            for size in graph.batch_buckets[frames]:
                graph.cost_ms[size,frames,0]=1.0 if size<=2 else 10.0*size
    assert default.split_policy=='dp'
    for frames in default.frame_buckets:
        for count in range(65):
            assert default.split(frames,count)==explicit.split(frames,count)
            checks+=1
    # A concrete counterexample establishes that the flag changes only the
    # selected partition: DP intentionally prefers two cheap graphs to one.
    assert default.split(6,3)==[1,2]
    assert minimal.split(6,3)==[4]
    assert minimal.split(6,33)==[16,16,1]
    try:
        build('unknown')
    except ValueError:
        pass
    else:
        raise AssertionError('Invalid policy accepted')
    assert not torch.cuda.is_initialized()
    source=Path(DACDecodeGraphs.split.__code__.co_filename)
    result=dict(status='PASS',invariant_cases=checks,source=str(source),
                source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
                cuda_initialized=torch.cuda.is_initialized(),
                scope='Real CPU planner only: legal captures, fewest launches, bounded padding, ordered exact request coverage, cache behavior and unchanged default policy. Does not validate GPU graph/state/PCM.')
    out=Path(__file__).with_name('codec-split-policy-cpu.json')
    out.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    main()
