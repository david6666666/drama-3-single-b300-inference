"""CPU-only route/CTA/resource accounting for native expert pipeline designs."""
from pathlib import Path
import collections,csv,hashlib,json,math
import torch
r=Path('/home/zjy/code/hsliu/artifacts/drama3-ceiling-20261016')
n=Path('/home/zjy/code/hsliu/artifacts/drama3-mixed-20261016/ncu')
old=json.loads((n/'real-moe-metadata.json').read_text())
rows=list(csv.DictReader((n/'real-moe-metrics-base.csv').open()))[1:]
def account(layer,c,provenance):
 active=sum(v>0 for v in c);tiles=sum(math.ceil(v/8) for v in c)
 return dict(layer=layer,provenance=provenance,routes=sum(c),active_experts=active,max_expert_tokens=max(c),expert_token_histogram=dict(collections.Counter(c)),token8_groups=tiles,one_cta_per_expert_sm_coverage_ceiling=min(active/148,1),one_cta_per_token8_group_waves=tiles/148,four_cta_cluster_ctas=4*tiles,four_cta_cluster_waves_on148SM=tiles/(148/4),native_live_fc1_ctas_estimate=8*tiles,native_live_fc2_ctas_estimate=16*tiles,partitions={str(parts):[dict(offset=j*(256//parts),count=256//parts,routes=sum(c[j*(256//parts):(j+1)*(256//parts)]),active=sum(v>0 for v in c[j*(256//parts):(j+1)*(256//parts)]),token8_groups=sum(math.ceil(v/8) for v in c[j*(256//parts):(j+1)*(256//parts)])) for j in range(parts)] for parts in (2,4)})
result=dict(cpu_only=True,cuda_initialized=torch.cuda.is_initialized(),old_real64=[account(z['layer'],z['expert_token_counts'],'Native source7a8; torch.topk recomputation, tie equivalence toFI NOT proven') for z in old['layers']],actual_fi63=[],ncu_launches=[])
x=torch.load(r/'padding-router-b63-native-inputs.pt',map_location='cpu',weights_only=False)
for layer in (0,19,39):
 ids=x[layer]['ids'].long().flatten();assert ids.numel()==512 and int(ids.min())>=0 and int(ids.max())<256
 result['actual_fi63'].append(account(layer,torch.bincount(ids,minlength=256).tolist(),'Exact native FI captured IDs source6ff8d80, batch64 comprises63real+1reservedpadding; notfull64real'))
fields=['Grid Size','Block Size','launch__grid_size','launch__registers_per_thread','launch__shared_mem_per_block','launch__waves_per_multiprocessor','launch__occupancy_limit_registers','launch__occupancy_limit_shared_mem']
result['ncu_launches']=[dict(layer=(0,0,19,19,39,39)[i],projection='FC1' if i%2==0 else 'FC2',**{k:row[k] for k in fields}) for i,row in enumerate(rows)]
result['device_from_archived_ncu']={k:rows[0][k] for k in ['device__attribute_multiprocessor_count','device__attribute_max_shared_memory_per_block_optin','device__attribute_max_shared_memory_per_multiprocessor','device__attribute_max_registers_per_multiprocessor','device__attribute_max_threads_per_multiprocessor']}
result['resident_cluster_estimate']=dict(not_compiled_not_measured=True,cluster_ctas=4,threads_per_cta=256,token_tile=8,fc1_up_gate_channels_per_cta=128,fc2_channels_per_cta=512,k_tile=128,fc1_doublebuffer_weight_bytes=2*2*128*128,fc1_doublebuffer_input_bytes=2*8*128,fc1_fp32_accumulator_bytes=8*256*4,fc1_registers_for_accumulators_per_thread=(8*256)//256,fc1_quantized_bytes_per_cta=8*256,fc1_scales_per_cta_bytes=8*2*4,activation_fragment_bytes=8*128,activation_fragment_scale_bytes=8*4,full_activation_replica_bytes=8*512,full_activation_scale_bytes=8*4*4,fc2_streamed_output_tile=128,fc2_doublebuffer_weight_bytes=2*128*128,fc2_fp32_accumulator_bytes=8*128*4,approx_smem_peak_before_padding_barriers=2*2*128*128+2*8*128+8*256+8*2*4+8*512+8*4*4,mandatory_weight_bytes_per_expert=2*512*2048+2048*512,mandatory_weight_bytes_per_cta=(2*512*2048+2048*512)//4,warning='Resource estimate only; Blackwell MMA accumulator/TMEM minimum shapes, actual compiler registers,TMA descriptors,swizzle,barriers andcluster occupancy requirecompilation. FirststageFP8quantizer notyetverified againstnativecubin.')
result['partition_static_grid_estimates'] = []
for parts in (1, 2, 4):
 local = 256 // parts
 bound = min(local, 512) + max(512-local, 0)//8
 result['partition_static_grid_estimates'].append(dict(partitions=parts,local_experts=local,tile8_max_batch_ctas_per_partition=bound,fc1_ctas_per_partition=8*bound,fc2_ctas_per_partition=16*bound,fc1_ctas_total=parts*8*bound,fc2_ctas_total=parts*16*bound,grid_growth=parts*bound/288,activation_ctas_total=parts*4*32*8,source_derived_not_new_gpu_measurement=True))
for census in (result['old_real64'], result['actual_fi63']):
 for item in census:
  padded = item['token8_groups']*8
  intermediate_bytes = 2*padded*(1024+512) + 2*padded*(8+4)*4
  weight_bytes = item['active_experts']*(2*512*2048+2048*512)
  item['logical_intermediate_global_write_read_bytes'] = intermediate_bytes
  item['active_expert_weight_bytes_excluding_scales'] = weight_bytes
  item['logical_intermediate_vs_active_weights_fraction'] = intermediate_bytes/weight_bytes
  item['traffic_caveat'] = 'Logical padded capacity accounting, not measured DRAM savings; activation only writes actual routed rows and caches may reduce traffic.'
result['files_sha256']={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),n/'real-moe-metadata.json',n/'real-moe-metrics-base.csv',r/'padding-router-b63-native-inputs.pt']}
(r/'expert-pipeline-cpu-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['files_sha256','old_real64','actual_fi63','ncu_launches']},indent=2))
for key in ['old_real64','actual_fi63']:
 for item in result[key]:print(key,{k:v for k,v in item.items() if k not in ['expert_token_histogram']})
