"""Expanded exact-only native FC1 gate. Installed FI and prior artifacts stay immutable."""
import os,sys,json,hashlib,subprocess,traceback,gc
from pathlib import Path
OUT=Path(__file__).resolve().parent; ROOT=OUT.parent; V2=OUT
os.environ.update(CUTE_DSL_ARCH='sm_103a',CUTE_DSL_KEEP='ptx,cubin',FLASHINFER_PRIMS_TS_COMPILE_OPTIONS='--opt-level 2 --gpu-arch sm_103a')
mode=sys.argv[1];os.environ['CUTE_DSL_DUMP_DIR']=str(OUT/('cpu-compile' if mode=='prepare' else 'gpu-compile'))
Path(os.environ['CUTE_DSL_DUMP_DIR']).mkdir(exist_ok=True)
sys.path.insert(0,str(V2));import common as c
import torch
from safetensors import safe_open
from contextlib import ExitStack
from flashinfer.prims_ts.batched_gemm.batched_gemm_run import _compile_for_launch,_launch_arg_tuple
from flashinfer.prims_ts.batched_gemm.batched_gemm_config import make_config
from flashinfer.prims_ts.batched_gemm.batched_gemm_kernel import build_batched_gemm_task_manager
from flashinfer.prims_ts.moe.tensor_adapter import build_fp8_block_scale_launch_io
from flashinfer.tllm_enums import Fp8QuantizationType,ActivationType
import cuda.bindings.driver as cuda_drv
ORACLES=sorted((ROOT/'expert-metadata-rebase').glob('oracle-layer*.pt'))
CAP=2304;CTA=288
report={'status':'PREPARING','mode':mode,'checks':[],'timings_allowed':False,'source_sha':subprocess.check_output(['git','rev-parse','HEAD'],cwd=c.SOURCE,text=True).strip(),'source_status':subprocess.check_output(['git','status','--porcelain'],cwd=c.SOURCE,text=True),'pid':os.getpid()}
def flush():(OUT/('prepare.json' if mode=='prepare' else 'result.json')).write_text(json.dumps(report,indent=2)+'\n')
def chk(name,a,b):
 a=a.contiguous();b=b.contiguous();ok=a.shape==b.shape and a.dtype==b.dtype and torch.equal(a.view(torch.uint8),b.view(torch.uint8))
 row={'name':name,'exact':ok,'shape':list(a.shape),'dtype':str(a.dtype)};report['checks'].append(row);flush()
 if not ok:
  torch.save({'actual':a.cpu(),'expected':b.cpu()},OUT/(name.replace('/','_')+'-mismatch.pt'))
  raise AssertionError(name)
def req(name,ok,detail=None):
 report['checks'].append({'name':name,'exact':bool(ok),'detail':detail});flush()
 if not ok:raise AssertionError(name)
def cfg():
 _,info=c.config();v=make_config(**info['candidate']);m=build_batched_gemm_task_manager(num_experts=256,num_tokens=64,top_k=8,verbose=False,**info['candidate'])
 return v,info

def weights(layer,device,empty=False):
 if empty:return [torch.empty(sh,dtype=dt,device=device) for sh,dt in [((256,1024,2048),torch.float8_e4m3fn),((256,8,16),torch.float32),((256,2048,512),torch.float8_e4m3fn),((256,16,4),torch.float32)]]
 index=json.loads((c.CKPT/'model.safetensors.index.json').read_text())['weight_map']
 def key(e,p,s):return f'model.language_model.layers.{layer}.mlp.experts.{e}.{p}.{s}'
 keys=[key(e,p,s) for e in range(256) for p in ('up_proj','gate_proj','down_proj') for s in ('weight','weight_scale_inv')]
 with ExitStack() as stack:
  handles={f:stack.enter_context(safe_open(str(c.CKPT/f),framework='pt',device='cpu')) for f in sorted({index[k] for k in keys})}
  def t(e,p,s):k=key(e,p,s);return handles[index[k]].get_tensor(k)
  a=torch.stack([torch.cat((t(e,'up_proj','weight'),t(e,'gate_proj','weight')),0) for e in range(256)])
  sa=torch.stack([torch.cat((t(e,'up_proj','weight_scale_inv'),t(e,'gate_proj','weight_scale_inv')),0) for e in range(256)])
  b=torch.stack([t(e,'down_proj','weight') for e in range(256)]);sb=torch.stack([t(e,'down_proj','weight_scale_inv') for e in range(256)])
 return [v.to(device) for v in (a,sa,b,sb)]

def metadata(d):
 n=int(d['global_meta']['ncta']);p=int(d['global_meta']['padded']);mp=d['global_meta']['expanded'].long();ids=d['ids'].long().flatten()
 assert 0<n<=CTA and p==n*8 and len(mp)==512 and mp.unique().numel()==512 and int(mp.min())>=0 and int(mp.max())<p
 assert torch.equal(d['cta'][mp//8].long(),ids)
 tile=torch.zeros(CTA,dtype=torch.int32);tile[:n]=d['cta'];mn=torch.zeros(CTA,dtype=torch.int32);mn[:n]=d['mn']
 route=torch.zeros(CAP+1,dtype=torch.int32);route[mp]=torch.arange(512,dtype=torch.int32)//8
 valid=torch.zeros(CAP,dtype=torch.bool);valid[mp]=True
 for i in range(n):
  rows=torch.where(valid[i*8:(i+1)*8])[0]+i*8
  assert len(rows)>0 and torch.equal(rows,torch.arange(i*8,int(mn[i])))
 hist=torch.bincount(ids,minlength=256)
 return dict(tile=tile,mn=mn,route=route,ncta=torch.tensor([n],dtype=torch.int32),padded=torch.tensor([p],dtype=torch.int32),valid=valid,mapping=mp),{'name':f"L{d['layer']}/{d['scenario']}",'ncta':n,'padded':p,'inactive_experts':int((hist==0).sum()),'count_histogram':{str(i):int((hist==i).sum()) for i in hist.unique().tolist()},'max_routes':int(hist.max()),'fp32_scale_min':float(d['intermediates']['fc1_scale'].min())}

def io_for(v,d,w,device):
 md,_=metadata(d);x={k:t.to(device) for k,t in md.items()};x.update(q=d['q'].to(device),s=d['input_scale'].to(device),w1=w[0],s1=w[1],w2=w[2],s2=w[3],ids=d['ids'].to(device),weights=d['weights'].to(device))
 x.update(fc1=torch.full((CAP,1024),173,dtype=torch.uint8,device=device),fc1scale=torch.full((8*CAP,),-17.,dtype=torch.float32,device=device),act=torch.full((CAP,512),91,dtype=torch.uint8,device=device),actscale=torch.full((4*CAP,),-19.,dtype=torch.float32,device=device),fc2=torch.full((CAP,2048),7.,dtype=torch.bfloat16,device=device))
 io=build_fp8_block_scale_launch_io(fc='fc1',cfg=v,fp8_quantization_type=Fp8QuantizationType.DeepSeekFp8,hidden_states=x['q'],hidden_states_scale=x['s'],gemm1_weights=x['w1'],gemm1_weights_scale=x['s1'],gemm2_weights=x['w2'],gemm2_weights_scale=x['s2'],gemm1_output=x['fc1'],gemm1_output_scale=x['fc1scale'],activation_output=x['act'],activation_output_scale=x['actscale'],gemm2_output=x['fc2'],tile_idx=x['tile'],mn_limit=x['mn'],route_map=x['route'],num_non_exiting_ctas=x['ncta'],total_num_padded_tokens=x['padded'],routed_token_capacity=CAP,activation_type=int(ActivationType.Swiglu),num_experts=256,num_tokens=64,top_k=8,intermediate_size=512,hidden_size=2048)
 return io,x

def expected_check(name,x,expected):
 p=int(x['padded']);mapping=x['mapping'];valid=x['valid'];scale=x['fc1scale'][:p*8].reshape(8,p)
 chk(name+'/fp8_bytes',x['fc1'][mapping],expected['fc1_bytes'].to('cuda'))
 chk(name+'/fp32_scales',scale.T[mapping],expected['fc1_scale'].to('cuda'))
 chk(name+'/padding_bytes',x['fc1'][~valid],torch.full_like(x['fc1'][~valid],173))
 chk(name+'/padding_scales',scale[:,~valid[:p]],torch.full_like(scale[:,~valid[:p]],-17))
 chk(name+'/inactive_scale_capacity',x['fc1scale'][p*8:],torch.full_like(x['fc1scale'][p*8:],-17))

def update(x,d):
 md,_=metadata(d)
 for k,t in md.items():x[k].copy_(t)
 for dst,src in [('q','q'),('s','input_scale'),('ids','ids'),('weights','weights')]:x[dst].copy_(d[src])
 x['fc1'].fill_(173);x['fc1scale'].fill_(-17)

@torch.inference_mode()
def prepare():
 assert os.environ.get('CUDA_VISIBLE_DEVICES')==''
 req('source_frozen',report['source_sha']=='95fcb0ef2662f2caf9bfb7fe6863dc3ad7805b1b' and report['source_status']=='')
 req('v2_exact',json.loads((ROOT/'expert-fc1-native-v2/result.json').read_text())['status']=='ONE_EXPERT_FC1_EXACT_PASS')
 coverage=[]
 for path in ORACLES:
  d=torch.load(path,map_location='cpu',weights_only=False);_,cv=metadata(d);coverage.append(cv)
 report['coverage']=coverage;req('fifteen_native_oracles',len(coverage)==15)
 counts={int(k) for row in coverage for k in row['count_histogram']};req('empty_and_one_to_eight_and_above8',set(range(9))<=counts and max(counts)>8)
 d=torch.load(ORACLES[0],map_location='cpu',weights_only=False);v,info=cfg();w=weights(0,'cpu',empty=True);io,x=io_for(v,d,w,'cpu')
 fn=_compile_for_launch(io,cuda_drv.CUstream(0));(OUT/'cpu-compile/host-module.mlir').write_text(str(fn.ir_module));report['config']=info;report['shape']=io['shape'];req('cuda_uninitialized',not torch.cuda.is_initialized())
 bins=list((OUT/'cpu-compile').glob('*.cubin'));req('one_cubin',len(bins)==1);report['cpu_cubin_sha256']=c.sha(bins[0]);usage=subprocess.check_output(['/usr/local/cuda/bin/cuobjdump','--dump-resource-usage',str(bins[0])],text=True);(OUT/'resource-usage.txt').write_text(usage)
 req('zero_spill','STACK:0' in usage and 'LOCAL:0' in usage);req('actual_shared_within80KiB','constant(71544 : i64)' in str(fn.ir_module) and 'SHARED:2048' in usage);report['shared_bytes']=73592;report['status']='CPU_AOT_PASS';flush()

@torch.inference_mode()
def run():
 prep=json.loads((OUT/'prepare.json').read_text());req('CPU_AOT_PASS',prep['status']=='CPU_AOT_PASS');manifest=json.loads((OUT/'frozen-inputs.json').read_text());req('frozen_hashes',all(c.sha(k)==v for k,v in manifest.items()))
 assert os.environ['CUDA_VISIBLE_DEVICES']=='GPU-bc643dc2-a0d1-5ed6-5ecb-0605ca9f340a'
 req('source_frozen',report['source_sha']==prep['source_sha'] and report['source_status']=='');report['gpu_uuid']=str(torch.cuda.get_device_properties(0).uuid);flush()
 v,info=cfg();report['cases']=[];rng=torch.cuda.get_rng_state().clone()
 for layer in (0,19,39):
  paths=[p for p in ORACLES if p.name.startswith(f'oracle-layer{layer}-')];datasets=[torch.load(p,map_location='cpu',weights_only=False) for p in paths]
  w=weights(layer,'cuda');wbefore=[t.clone() for t in w];io,x=io_for(v,datasets[0],w,'cuda');fn=_compile_for_launch(io,cuda_drv.CUstream(torch.cuda.current_stream().cuda_stream))
  bins=list((OUT/'gpu-compile').glob('*.cubin'));req(f'L{layer}/CPU_GPU_cubin_identical',len(bins)==1 and c.sha(bins[0])==prep['cpu_cubin_sha256'])
  # Capture one reusable graph for all five changing native metadata distributions.
  graph=torch.cuda.CUDAGraph()
  with torch.cuda.graph(graph):fn(*_launch_arg_tuple(io,cuda_drv.CUstream(torch.cuda.current_stream().cuda_stream)))
  for d in datasets:
   name=f"L{layer}/{d['scenario']}";update(x,d);before={k:t.clone() for k,t in x.items() if k not in ('fc1','fc1scale','w1','w2','s1','s2')}
   fn(*_launch_arg_tuple(io,cuda_drv.CUstream(torch.cuda.current_stream().cuda_stream)));torch.cuda.synchronize();expected_check(name+'/eager',x,d['intermediates'])
   x['fc1'].fill_(173);x['fc1scale'].fill_(-17);graph.replay();torch.cuda.synchronize();expected_check(name+'/graph',x,d['intermediates'])
   for k,t in before.items():chk(name+'/untouched/'+k,x[k],t)
   _,cv=metadata(d);report['cases'].append(cv);flush();print(name+' PASS',flush=True)
  # One explicit synthetic all-zero input with original checkpoint weights/scales.
  if layer==0:
   d=next(d for d in datasets if d['scenario']=='real');update(x,d);x['q'].zero_()
   from flashinfer.fused_moe import core as fi
   from flashinfer.fused_moe.shared.inputs import MoeRunnerInputs
   from flashinfer.tllm_enums import DtypeTrtllmGen,RoutingInputMode
   from types import SimpleNamespace
   runtime=fi.get_trtllm_moe_sm100_module();runner=runtime.MoERunner(runtime.moe_op,top_k=8,num_local_experts=256,dtype_act=DtypeTrtllmGen.E4m3,dtype_weights=DtypeTrtllmGen.E4m3,fp8_quantization_type=Fp8QuantizationType.DeepSeekFp8,hidden_size=2048,intermediate_size=512,num_experts=256)
   inp=MoeRunnerInputs(torch.empty((64,2048),dtype=torch.bfloat16,device='cuda'),None,x['ids'],x['weights'],x['q'],x['s'],None,None).to_list()
   kw=dict(routing_bias=None,num_experts=256,n_group=None,topk_group=None,routed_scaling_factor=1.,routing_method_type=4,use_shuffled_weight=False,weight_layout=0,enable_pdl=False,local_expert_offset=0,do_finalize=True,routing_input_mode=RoutingInputMode.UnpackedPrecomputed,gemm1_weights=w[0],gemm1_weights_scale=w[1],gemm2_weights=w[2],gemm2_weights_scale=w[3])
   meta=fi.trtllm_moe_allocate_routing_metadata_multi_tile(x['ids'],num_experts=256,top_k=8,local_expert_offset=0,num_local_experts=256,tile_ns=[8],routing_input_mode=RoutingInputMode.UnpackedPrecomputed,topk_weights=x['weights']);fi.populate_trtllm_moe_routing_metadata_(meta,x['ids'],x['weights']);slot=meta.slots[0];body=SimpleNamespace(tile_n=8,tactic=5);br=runtime.DABodyRunner(runner);ws=tuple(t if isinstance(t,torch.Tensor) else torch.from_dlpack(t) for t in br.prepare_body(inp,body,slot,**kw));br.forward_from_metadata(inp,body,slot,ws,**kw);torch.cuda.synchronize()
   report['synthetic']=[]
   original_amax=float(d['intermediates']['fc1_scale'].max())*448.0
   for label,target in [('zero',0.0),('amax_1e-14',1e-14),('amax_1e-10',1e-10)]:
    update(x,d)
    factor=1.0
    if target==0.0:x['q'].zero_()
    else:
     factor=target/original_amax;x['s'].mul_(factor)
    saved_input={k:x[k].clone() for k in ('q','s','ids','weights','tile','mn','route','ncta','padded')}
    br.forward_from_metadata(inp,body,slot,ws,**kw);torch.cuda.synchronize()
    p=int(slot.total_num_padded_tokens);mp=slot.expanded_idx_to_permuted_idx.long();native={'fc1_bytes':ws[0].reshape(-1,1024)[mp].clone(),'fc1_scale':ws[1].flatten()[:p*8].reshape(8,p).T[mp].clone()}
    torch.save({**{k:t.cpu() for k,t in native.items()},'input_q':x['q'].cpu(),'input_scale':x['s'].cpu(),'input_scale_factor':factor,'target_amax':target,'routing_oracle':'oracle-layer0-real.pt','original_checkpoint_weights_and_scales':True,'native_body_tactic':[8,5]},OUT/f'synthetic-{label}-oracle.pt')
    fn(*_launch_arg_tuple(io,cuda_drv.CUstream(torch.cuda.current_stream().cuda_stream)));torch.cuda.synchronize();expected_check(f'synthetic_{label}/eager',x,native)
    x['fc1'].fill_(173);x['fc1scale'].fill_(-17);graph.replay();torch.cuda.synchronize();expected_check(f'synthetic_{label}/graph',x,native)
    for k,t in saved_input.items():chk(f'synthetic_{label}/untouched/{k}',x[k],t)
    report['synthetic'].append({'name':label,'scale_factor':factor,'target_amax':target,'native_scale_min':float(native['fc1_scale'].min()),'native_scale_max':float(native['fc1_scale'].max()),'observed_amax_estimate':float(native['fc1_scale'].max())*448.0,'native_zero_bytes':bool((native['fc1_bytes']==0).all()),'not_real_workload':True})
    flush();print('synthetic '+label+' PASS',flush=True)
   del runtime,runner,inp,kw,meta,slot,body,br,ws,native
  for i,(a,b) in enumerate(zip(w,wbefore)):chk(f'L{layer}/weights_unchanged/{i}',a,b)
  chk(f'L{layer}/RNG_unchanged',torch.cuda.get_rng_state(),rng)
  del graph,fn,io,x,w,wbefore,before;gc.collect()
 report['status']='EXPANDED_NATIVE_FC1_EXACT_PASS';flush()
try:prepare() if mode=='prepare' else run()
except BaseException as e:report.update(status='EXACT_FAIL' if mode=='run' else 'CPU_AOT_FAIL',error=repr(e),traceback=traceback.format_exc());flush();raise
finally:flush()
