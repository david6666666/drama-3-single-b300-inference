"""Verify the exact baseline BF16 FMA before changing frozen runtime."""
import json,sys
from pathlib import Path
ROOT=Path('/home/zjy/code/hsliu/artifacts/drama3-ceiling-20261016')
sys.path.insert(0,str(ROOT/'source-moe-residual-da91321'/'src'))
import torch,triton
import triton.language as tl
from drama3.kernels import add_norm,combine_experts

@triton.jit
def fused_fma(ROUTED,SHARED,GATE,RESIDUAL,W,OUT,EPS:tl.constexpr,WIDTH:tl.constexpr):
 row=tl.program_id(0)
 col=tl.arange(0,WIDTH)
 routed=tl.load(ROUTED+row*WIDTH+col)
 shared=tl.load(SHARED+row*WIDTH+col)
 gate=tl.sigmoid(tl.load(GATE+row).to(tl.float32)).to(SHARED.dtype.element_ty)
 combined=tl.inline_asm_elementwise(
  "fma.rn.bf16 $0, $1, $2, $3;",constraints="=h,h,h,h",
  args=[shared,gate,routed],dtype=tl.bfloat16,is_pure=True,pack=1,
 ).to(tl.float32)
 value=combined+tl.load(RESIDUAL+row*WIDTH+col).to(tl.float32)
 value=value.to(ROUTED.dtype.element_ty).to(tl.float32)
 tl.store(RESIDUAL+row*WIDTH+col,value)
 value*=tl.rsqrt(tl.sum(value*value,0)/WIDTH+EPS)
 value*=1.+tl.load(W+col).to(tl.float32)
 tl.store(OUT+row*WIDTH+col,value)

report=dict(source='artifact prototype against frozen da91321 baseline',hypothesis='Explicit fma.rn.bf16 restores the actual baseline contracted shared multiplication/routed addition while leaving residual/RMS contraction disabled.',cases=[])
for rows in (1,64):
 data={k:v.cuda() for k,v in torch.load(ROOT/f'moe-residual-diagnostic-inputs-b{rows}.pt',weights_only=True).items()}
 residual=data['residual'].clone()
 expected_residual=residual.clone()
 expected=add_norm(combine_experts(data['routed'],data['shared'],data['gate']),expected_residual,data['weight'],1e-6)
 actual=torch.empty_like(data['routed'])
 kernel=fused_fma[(rows,)](data['routed'],data['shared'],data['gate'],residual,data['weight'],actual,1e-6,2048,num_warps=4,enable_fp_fusion=False)
 row=dict(rows=rows,output_exact=torch.equal(actual,expected),residual_exact=torch.equal(residual,expected_residual),output_differences=int((actual!=expected).sum()),residual_differences=int((residual!=expected_residual).sum()))
 report['cases'].append(row)
 (ROOT/'moe-residual-fma-diagnostic.json').write_text(json.dumps(report,indent=2)+'\n')
 (ROOT/f'moe-residual-explicit-fma-b{rows}.ptx').write_text(kernel.asm['ptx'])
 print(json.dumps(row),flush=True)
