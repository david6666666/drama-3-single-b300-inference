import datetime
import hashlib
import json
import os
import subprocess
import threading
from pathlib import Path

root=Path('/home/zjy/code/hsliu/artifacts/drama3-ceiling-20261016')
source=Path('/home/zjy/code/hsliu/drama3-short-padding-frozen-20261016')
python='/home/zjy/code/hsliu/venvs/codex-drama3-standalone/bin/python'
checkpoint='/home/zjy/.cache/huggingface/hub/models--fishaudio--drama-3/snapshots/e0a9218aa48888270f06ef1ed9ea67622c0e17d2'
corpus='/home/zjy/code/hsliu/artifacts/drama3-b300-20261014/seedtts-en1088-codes/requests.jsonl'
script=root/'validate_short_padding_context.py'
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()
assert sha=='a607dff26c3ca5423746f7eebec4f5f5a88cd4c0'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True)
query=['nvidia-smi','--query-compute-apps=gpu_uuid,pid,process_name,used_gpu_memory','--format=csv,noheader']
processes=subprocess.check_output(query,text=True)
assert 'GPU-40e00845-d89c-1393-2c32-a2dca3ee9442' not in processes
flags=dict(DRAMA3_GDN_STATE_DTYPE='bfloat16',DRAMA3_PACKED_MOE_PROJECTION='1',DRAMA3_PREFILL_CONV='triton',DRAMA3_PREFILL_MOE_TUNED='0',DRAMA3_PREFILL_MOE='flashinfer',DRAMA3_FUSED_MOE_INPUT='1',DRAMA3_SHORT_PADDING_CONTEXT='0')
env={k:v for k,v in os.environ.items() if not k.startswith('DRAMA3_')}
env.update(flags, CUDA_VISIBLE_DEVICES='7', OMP_NUM_THREADS='4', PYTHONPATH=f'{source}/src:{source}/scripts:/home/zjy/code/hsliu/drama3-sources/fish-speech')
cmd=[python,str(script),'--checkpoint',checkpoint,'--corpus',corpus,'--source',str(source),'--output',str(root/'short-padding-validation.json')]
plan=dict(hypothesis='Reserved decode padding rows currently read max_length2048 history. Set only their runtime position to0 and preserve all actual requests and max_kv_len plan2048.',isolated_variable='short_padding_context false/true during graph capture',gate='Exact real outputs and every state outside participating dummy slots; no real slot excluded; mixed teacher/prompt outputs and positions exact.',stop='Any protected mismatch or GPU interference rejects candidate; no fullservice promotion based on isolated timing.',source_sha=sha,source=str(source),validator_sha256=hashlib.sha256(script.read_bytes()).hexdigest(),command=cmd,flags=flags,gpu=7,gpu_uuid='GPU-40e00845-d89c-1393-2c32-a2dca3ee9442',cpu_affinity=sorted(os.sched_getaffinity(0)),omp_threads=4,repetitions='One feasibility experiment, five alternating fixedstate event samples per arm/case after warmup; no statistical serving claim.',before_gpu=processes,storage={p:subprocess.check_output(['findmnt','-T',p,'-no','SOURCE,FSTYPE,TARGET'],text=True).strip() for p in [python,checkpoint,'/home/zjy/.cache/huggingface/hub']})
(root/'short-padding-experiment.json').write_text(json.dumps(plan,indent=2)+'\n')
stop=threading.Event()
def audit():
 with (root/'short-padding-process-audit.jsonl').open('w') as f:
  while not stop.is_set():
   r=subprocess.run(query,text=True,capture_output=True)
   f.write(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),processes=r.stdout.splitlines()))+'\n'); f.flush(); stop.wait(1)
t=threading.Thread(target=audit);t.start()
try:
 with (root/'short-padding-validation.log').open('w') as log:subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
finally:stop.set();t.join()
