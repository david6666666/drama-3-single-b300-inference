"""Six unchanged MajorK FP8 expert GEMMs from real D64/P1280 mixed activations."""
import hashlib
import json
import os
from pathlib import Path
from types import SimpleNamespace

import torch
import torch.nn.functional as F
import triton
from fish_speech.models.text2semantic.fish_omni.generate import build_drama3_prompt
import drama3.model as model_module
from drama3.engine import BatchedPrefillGraph, DecodeGraph, state_pool_size
from drama3.mixed_graph import MixedGraph
from drama3.model import DramaModel
from drama3.runtime_state import DeviceRequests

OUT = Path(__file__).resolve().parent
SOURCE = OUT.parent / 'source-initial'
CORPUS = Path('/home/zjy/code/hsliu/artifacts/drama3-b300-20261014/seedtts-en1088-codes/requests.jsonl')
CHECKPOINT = '/home/zjy/.cache/huggingface/hub/models--fishaudio--drama-3/snapshots/e0a9218aa48888270f06ef1ed9ea67622c0e17d2'
LAYERS = (0, 19, 39)

def flush(report):
    (OUT/'metadata.json').write_text(json.dumps(report, indent=2)+'\n')

@torch.inference_mode()
def main():
    print(json.dumps({'pid':os.getpid(), 'stage':'initialization'}), flush=True)
    assert Path(model_module.__file__).is_relative_to(SOURCE), model_module.__file__
    raw = CORPUS.read_bytes()
    properties = torch.cuda.get_device_properties(0)
    report = dict(pid=os.getpid(), source=str(SOURCE), source_files_sha256={str(p.relative_to(SOURCE)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((SOURCE/'src/drama3').glob('*.py'))}, driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), checkpoint=CHECKPOINT, corpus_sha256=hashlib.sha256(raw).hexdigest(), cuda_visible_devices=os.environ.get('CUDA_VISIBLE_DEVICES'), gpu_name=properties.name, gpu_uuid=str(properties.uuid), torch_version=torch.__version__, env={k:v for k,v in os.environ.items() if k.startswith('DRAMA3_')}, native_contract='BF16 dense/GDN; original 128-block FP8 expert scales; full top-8 MajorK; no precision change', status='INITIALIZING')
    flush(report)
    try:
        samples=[json.loads(row) for row in raw.splitlines()][:64]
        model=DramaModel(CHECKPOINT,slots=state_pool_size(64),max_length=2048)
        assert model.moe_layout == 'major_k' and model.prefill_moe == 'flashinfer'
        assert model.moe_shared_stream is None and not model.tuned_prefill_moe
        prompts=[build_drama3_prompt(s['text'],model.weights.tokenizer,model.config,[s['reference_text']],[torch.tensor(s['reference_codes'])]) for s in samples]
        capacity=triton.cdiv(sum(map(len,prompts[58:])),256)*256
        assert capacity == 1280, capacity
        device=DeviceRequests(model.slots,model.config.eos_token_id,model.max_length)
        prefill=BatchedPrefillGraph(model,8,triton.next_power_of_2(max(map(len,prompts))))
        first=DecodeGraph(model,8,first_frame=True,requests=device)
        decode=DecodeGraph(model,64,requests=device)
        mixed=MixedGraph(model,device,64,8,capacity,max_length=256)
        requests=[SimpleNamespace(slot=i,position=len(p)-1) for i,p in enumerate(prompts)]
        def initialize(i):
            prompt=prompts[i]
            history=F.pad(prompt[-16:,0],(max(0,16-len(prompt)),0),value=-1).cuda()
            device.initialize(i,prompt[-1].cuda(),history,len(prompt)-1,500)
        # Captures can modify persistent states. Real initialization happens last.
        for i in range(64):
            initialize(i)
        for start in range(0,64,8):
            hidden=prefill.run(prompts[start:start+8],list(range(start,start+8)))
            first.run(requests[start:start+8],hidden)
        decode.run(requests)
        for _ in range(7):
            decode.graph.replay()
        torch.cuda.synchronize()
        report['metadata_before_arrival']=device.metadata[:64].cpu().tolist()
        # Simulate physical-slot reuse by six arriving actual corpus prompts.
        for i in range(58,64):
            initialize(i)
        mixed.run(requests[:58],prompts[58:],list(range(58,64)))
        torch.cuda.synchronize()
        report.update(status='PROFILING', prompt_lengths=list(map(len,prompts)), capacity=capacity, max_span=mixed.layout.max_length, decode_slots=mixed.slots[:64].cpu().tolist(), prefill_sequence_slots=mixed.layout.sequence_slots.cpu().tolist(), prefill_boundaries=mixed.layout.boundaries.cpu().tolist(), request_metadata=device.metadata[:64].cpu().tolist(), sampling_step=int(model.sampling_step))
        flush(report)
        begin,end=torch.cuda.Event(enable_timing=True),torch.cuda.Event(enable_timing=True)
        begin.record()
        for _ in range(5):
            mixed.graph.replay()
        end.record();end.synchronize()
        report['mixed_ms']=begin.elapsed_time(end)/5
        from torch.profiler import profile,ProfilerActivity
        with profile(activities=[ProfilerActivity.CPU,ProfilerActivity.CUDA]) as prof:
            for _ in range(3):
                mixed.graph.replay()
            torch.cuda.synchronize()
        prof.export_chrome_trace(str(OUT/'trace.json.gz'))
        (OUT/'table.txt').write_text(prof.key_averages().table(sort_by='self_device_time_total',row_limit=80)+'\n')
        report.update(status='COMPLETE',limitations=['One real 58:6 D64P1280span256 mixed state, three profiler replays; timing diagnostic only.', 'Graph includes shared mixed backbone and teacher-forced prefill tower, excludes new first frame and existing decode tower.','Repeated prompt work resets arriving state as in MixedGraph; decode state continues, without sampling a new frame.'])
        flush(report)
        print(json.dumps({'stage':'complete','mixed_ms':report['mixed_ms']}),flush=True)
    except Exception as exc:
        report.update(status='FAILED',error=repr(exc))
        flush(report)
        raise

if __name__=='__main__':
    main()
