"""Freeze metadata-ready native FC2 exact/single-screen protocol, CPU only."""

import hashlib
import json
import os
import re
import subprocess
import sys
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
GPU = "GPU-bc643dc2-a0d1-5ed6-5ecb-0605ca9f340a"
os.environ["CUDA_VISIBLE_DEVICES"] = ""
sys.argv = [str(OUT / "metadata_driver.py"), "prepare"]
sys.path.insert(0, str(OUT))
import metadata_driver as d
from metadata_ready_graph import run_cpu_tests


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


prep = json.loads((OUT / "driver-prepare.json").read_text())
assert prep["status"] == "CPU_AOT_PASS"
assert prep["source_sha"] == "95fcb0ef2662f2caf9bfb7fe6863dc3ad7805b1b"
assert prep["source_status"] == ""
assert not d.torch.cuda.is_initialized()
standalone = json.loads((OUT / "prepare.json").read_text())
old = json.loads((ROOT / "expert-m128-pdl/prepare.json").read_text())
assert prep["kernels"]["fc1"]["sha256"] == old["kernels"]["fc1"]["sha256"]
assert prep["kernels"]["fc2"]["sha256"] == standalone["kernel"]["sha256"]
graph_checks = run_cpu_tests()
assert graph_checks["status"] == "CPU_TOPOLOGY_AND_READINESS_CONTRACT_PASS"
(OUT / "cpu-graph-guard.json").write_text(json.dumps(graph_checks, indent=2) + "\n")
audit = {
    "status": "CPU_INTEGRATION_PASS",
    "gpu_used": False,
    "kernels": {},
    "graph_checks": len(graph_checks["checks"]),
}
for fc, cfg in d.configs().items():
    expected_waits = 1 if fc == "fc1" else 2
    assert cfg.use_pdl == cfg.use_early_exit == 1
    assert cfg.do_pdl_wait_for_num_non_exiting_ctas == (1 if fc == "fc1" else 0)
    record = prep["kernels"][fc]
    binary = Path(record["cubin"])
    ptx = binary.with_suffix(".ptx").read_text()
    sass_path = OUT / f"driver-resource-{fc}/kernel.sass"
    sass = sass_path.read_text()
    host = Path(record["host"]).read_text()
    assert ptx.count("griddepcontrol.wait;") == expected_waits
    assert ptx.count("griddepcontrol.launch_dependents;") == 2
    assert len(re.findall(r"\bACQBULK\b", sass)) == expected_waits
    assert len(re.findall(r"\bPREEXIT\b", sass)) == 2
    assert "%3 = llvm.mlir.constant(6 : i32)" in host
    id_ptr, value_ptr, one = (216, 217, 29) if fc == "fc1" else (224, 225, 30)
    assert f"llvm.store %3, %{id_ptr}" in host
    assert f"llvm.store %{one}, %{value_ptr}" in host
    assert f"%{one} = llvm.mlir.constant(1 : i32)" in host
    resource = prep["resources"][fc]
    assert resource["total_shared_bytes_per_cta"] <= 81920
    assert (
        resource["stack_bytes"]
        == resource["local_bytes"]
        == resource["sass_spill_ops"]
        == 0
    )
    audit["kernels"][fc] = {
        "cubin_sha256": sha(binary),
        "ptx_sha256": sha(binary.with_suffix(".ptx")),
        "sass_sha256": sha(sass_path),
        "host_sha256": sha(record["host"]),
        "waits": expected_waits,
        "launch_dependents": 2,
        "wait_scope": "global metadata"
        if fc == "fc1"
        else "activation B and combined scales tasks",
        "launch_pdl_attribute": {"id": 6, "value": 1},
        "shared_bytes": resource["total_shared_bytes_per_cta"],
    }
(OUT / "cpu-integration-audit.json").write_text(json.dumps(audit, indent=2) + "\n")
protocol = {
    "status": "FROZEN_NATIVE_METADATA_READY_FC2",
    "source_sha": prep["source_sha"],
    "gpu_uuid": GPU,
    "watchdog_seconds": 600,
    "stages": ["gate", "feasibility"],
    "hypothesis": "A full routing-metadata dependency permits FC2 weight prefetch while original activation waits for FC1. Original B/SF task waits protect all activation consumption. Benefit is unproven.",
    "isolated_change": "Relative to frozen M128 PDL, FC2 uses typed metadata-ready contract with global count wait off and original task-local B/SF waits on; every captured metadata producer gets a DEFAULT full-memory edge to FC2. FC1 global wait, all arithmetic/epilogues/weights/scales/top8/4stage settings unchanged.",
    "baseline": {
        "implementation": "original vendor prepared native complete MoE",
        "tactic": [8, 5],
        "enable_pdl": True,
    },
    "candidate": {
        "implementation": "M128 FC1/native activation/metadata-ready M128 FC2/native ordered finalizer",
        "enable_pdl": True,
        "native_experts": 256,
        "top_k": 8,
    },
    "boundary": {
        "included": [
            "live native routing metadata generation",
            "FC1",
            "original native activation/FP8 boundary",
            "FC2",
            "original ordered top8 finalization",
            "explicit full graph edges",
        ],
        "excluded_common": ["input quantization", "logits to top8 routing"],
        "scope": "Original physical B64 with63 live rows and original padding; layers0,19,39 x5 native routing distributions. No service/model claim.",
    },
    "graph_contract": {
        "full": "Controlled callback node deltas close over the complete capture; all metadata nodes precede FC1; original FC1→activation→FC2→finalizer PROGRAMMATIC edges retain ports1→0; add DEFAULT ports0→0 from every metadata producer to FC2; seal before instantiate, private graph/owners retained.",
        "empty": "Separate gemm_empty_probe; six complete live metadata tensors copied from retained mutable source buffers inside graph. ncta/padded0 then positive restoration then zero again on same graph, fixed nonzero grids. No native activation/finalizer; saved activation/scales ready before invocation. Not a full-MoE timing graph.",
        "eager": "Metadata callback followed by own event completion; single-use permit outside capture, full chain completed before permit release.",
        "limitations": "Trusted callbacks; snapshot verifies topology/launch attributes, not raw kernel argument payloads. No external raw graph mutation; retained storage identity is fixed while tensor contents may change.",
    },
    "exact_before_timing": [
        "all15 own-live-metadata eager/reusedgraph exact five boundaries/finalizer",
        "mapping bijection and original-token/expert ownership",
        "weights/input/RNG/guards/padding/tails unchanged",
        "CPU/GPU CUBIN identical",
        "actual queried full edges and retained programmatic chain",
        "zero-count eager/samegraph no-write/nohang and positive/zero restoration",
    ],
    "feasibility": {
        "orders": ["AB"],
        "warmups": 5,
        "replays": 100,
        "cases": ["L0/real", "L19/real", "L39/real"],
        "gate": "Each complete-call latency reduction>=5% versus native; stop if any fail. One screen is not a formal gain claim.",
        "stress_performance": "NOT_RUN",
        "stress_none_worse5pct": None,
    },
    "formal_timing": {
        "auto_run": False,
        "requires": "Report screening to parent and subsequent authorization",
        "orders": ["AB", "BA", "AB"],
        "cases": 15,
        "gate": "Three real medians each>=5% reduction, twelve stress cases each<=5% regression.",
    },
    "stop": "First semantic/hash/ownership mismatch or timeout; preserve failures. No tolerance relaxation, source mutation during run, cache flushing, clock changes, runtime promotion or unapproved extra stages. On competitor only terminate own process.",
    "cpu_affinity": sorted(os.sched_getaffinity(0)),
    "storage": [
        json.loads(
            subprocess.check_output(["findmnt", "-T", str(path), "--json"], text=True)
        )
        for path in (Path(sys.executable), d.c.CKPT, ROOT)
    ],
    "environment": {
        "CUDA_VISIBLE_DEVICES": GPU,
        "OMP_NUM_THREADS": "4",
        "HF_MODULES_CACHE": str(ROOT / "hf_modules"),
        "HF_HUB_OFFLINE": "1",
        "TRANSFORMERS_OFFLINE": "1",
    },
    "runtime_modified": False,
}
(OUT / "protocol.json").write_text(json.dumps(protocol, indent=2) + "\n")
required = [
    "metadata_driver.py",
    "metadata_gate.py",
    "launch.py",
    "prepare_protocol.py",
    "metadata_ready_config.py",
    "metadata_ready_kernel.py",
    "metadata_ready_graph.py",
    "body_common.py",
    "gmem_c_resources_m128_body.py",
    "driver-prepare.json",
    "prepare.json",
    "cpu-graph-guard.json",
    "cpu-integration-audit.json",
    "cpu-wait-placement.json",
    "protocol.json",
    "CPU-CONTRACT.md",
]
assert all((OUT / name).is_file() for name in required), "complete gate/launcher first"
files = {
    Path(name)
    for name in json.loads((ROOT / "expert-m128-pdl/frozen-inputs.json").read_text())
}
files.update(OUT / name for name in required)
for fc, record in prep["kernels"].items():
    files.update(
        [
            Path(record["cubin"]),
            Path(record["cubin"]).with_suffix(".ptx"),
            Path(record["host"]),
        ]
    )
    files.update((OUT / f"driver-resource-{fc}").glob("*"))
files.update(
    Path(module.__file__)
    for name, module in sys.modules.copy().items()
    if name.startswith(
        (
            "flashinfer.prims_ts",
            "cutlass.experimental.task_scheduling",
            "cutlass.pipeline",
        )
    )
    and getattr(module, "__file__", None)
    and str(module.__file__).endswith(".py")
)
(OUT / "frozen-inputs.json").write_text(
    json.dumps(
        {str(path): sha(path) for path in sorted(files) if path.is_file()}, indent=2
    )
    + "\n"
)
assert not d.torch.cuda.is_initialized()
print("CPU_METADATA_READY_PROTOCOL_FROZEN", len(files), flush=True)
