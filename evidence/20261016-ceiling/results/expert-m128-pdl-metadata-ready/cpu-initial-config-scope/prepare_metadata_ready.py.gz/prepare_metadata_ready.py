"""GPU-free compile and rejected-contract checks; no runtime entry point."""

import os
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
os.environ.update(
    CUTE_DSL_ARCH="sm_103a",
    CUTE_DSL_KEEP="ptx,cubin",
    FLASHINFER_PRIMS_TS_COMPILE_OPTIONS="--opt-level 2 --gpu-arch sm_103a",
    CUTE_DSL_DUMP_DIR=str(OUT / "cpu-compile"),
)
(OUT / "cpu-compile").mkdir(exist_ok=True)
import dataclasses
import importlib.util
import json
import subprocess
import sys
import traceback

import body_common as c
import cuda.bindings.driver as drv
import torch
from cutlass import cute
from cutlass.cutlass_dsl import BaseDSL
from flashinfer.prims_ts.batched_gemm.batched_gemm_config import BatchedGemmConfig
from flashinfer.prims_ts.batched_gemm.batched_gemm_config import (
    validate_config as validate_native_config,
)
from flashinfer.prims_ts.batched_gemm.batched_gemm_run import (
    _compile_arg_tuple,
    _cute_compile_options,
)
from flashinfer.prims_ts.cutlass_dsl import task_scheduling_scope
from flashinfer.prims_ts.moe.tensor_adapter import build_fp8_block_scale_launch_io
from flashinfer.tllm_enums import ActivationType, Fp8QuantizationType
from metadata_ready_config import (
    make_metadata_ready_fc2,
    validate_io,
    validate_metadata_ready_fc2,
)

REPORT = {
    "status": "PREPARING",
    "gpu_allowed": False,
    "checks": [],
    "source_sha": subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=c.SOURCE, text=True
    ).strip(),
}


def flush():
    (OUT / "prepare.json").write_text(json.dumps(REPORT, indent=2) + "\n")


def check(name, condition, detail=None):
    REPORT["checks"].append({"name": name, "pass": bool(condition), "detail": detail})
    flush()
    if not condition:
        raise AssertionError(name)


def reject(name, fn):
    try:
        fn()
    except (ValueError, TypeError) as exc:
        check(name, True, str(exc))
    else:
        check(name, False)


def launch_io():
    d = torch.load(
        ROOT / "expert-metadata-rebase/oracle-layer0-real.pt",
        map_location="cpu",
        weights_only=False,
    )
    md, _ = c.metadata(d)
    w1, s1, w2, s2 = c.weights(0, "cpu", empty=True)
    return build_fp8_block_scale_launch_io(
        fc="fc2",
        cfg=make_metadata_ready_fc2(),
        fp8_quantization_type=Fp8QuantizationType.DeepSeekFp8,
        hidden_states=d["q"],
        hidden_states_scale=d["input_scale"],
        gemm1_weights=w1,
        gemm1_weights_scale=s1,
        gemm2_weights=w2,
        gemm2_weights_scale=s2,
        gemm1_output=torch.empty((2304, 1024), dtype=torch.uint8),
        gemm1_output_scale=torch.empty(8 * 2304),
        activation_output=torch.empty((2304, 512), dtype=torch.uint8),
        activation_output_scale=torch.empty(4 * 2304),
        gemm2_output=torch.empty((2304, 2048), dtype=torch.bfloat16),
        tile_idx=md["tile"],
        mn_limit=md["mn"],
        route_map=md["route"],
        num_non_exiting_ctas=md["ncta"],
        total_num_padded_tokens=md["padded"],
        routed_token_capacity=2304,
        activation_type=int(ActivationType.Swiglu),
        num_experts=256,
        num_tokens=64,
        top_k=8,
        intermediate_size=512,
        hidden_size=2048,
    )


def run():
    check("cuda_hidden", os.environ.get("CUDA_VISIBLE_DEVICES") == "")
    check(
        "source_frozen",
        REPORT["source_sha"] == "95fcb0ef2662f2caf9bfb7fe6863dc3ad7805b1b"
        and subprocess.check_output(
            ["git", "status", "--porcelain"], cwd=c.SOURCE, text=True
        )
        == "",
    )
    native_file = Path(sys.modules[validate_native_config.__module__].__file__)
    native_sha = c.sha(native_file)
    cfg = make_metadata_ready_fc2()
    validate_metadata_ready_fc2(cfg, (2048, 2304, 512))
    check(
        "bounded_config_accepted",
        cfg.use_early_exit == 1 and cfg.do_pdl_wait_for_num_non_exiting_ctas == 0,
    )
    raw = BatchedGemmConfig(
        **{f.name: getattr(cfg, f.name) for f in dataclasses.fields(BatchedGemmConfig)}
    )
    reject(
        "generic_validator_still_rejects_unsafe_raw_config",
        lambda: validate_native_config(raw),
    )
    reject("untyped_config_rejected", lambda: validate_metadata_ready_fc2(raw))
    for key, bad in {
        "metadata_ready_by_full_dependency": 0,
        "use_early_exit": 0,
        "use_pdl": 0,
        "do_pdl_wait_for_num_non_exiting_ctas": 1,
        "route_act": 1,
        "tile_scheduler": 0,
        "num_stages_a": 8,
        "dtype_c": 7,
        "mma_m": 64,
        "tile_n": 16,
    }.items():
        changed = dataclasses.replace(cfg, **{key: bad})
        reject(
            "reject_" + key,
            lambda changed=changed: validate_metadata_ready_fc2(changed),
        )
    io = launch_io()
    REPORT["io_shape"] = list(io["shape"])
    REPORT["early_exit_extent"] = io["launch_early_exit_max_token_ctas"]
    flush()
    validate_io(io)
    reject(
        "wrong_shape_rejected",
        lambda: validate_io({**io, "shape": (2048, 2304, 512, 256, 32)}),
    )
    reject(
        "wrong_extent_rejected",
        lambda: validate_io({**io, "launch_early_exit_max_token_ctas": 0}),
    )
    module_name = "flashinfer.prims_ts.batched_gemm.metadata_ready_kernel"
    spec = importlib.util.spec_from_file_location(
        module_name, OUT / "metadata_ready_kernel.py"
    )
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    with task_scheduling_scope(), BaseDSL.enable_pyir():
        fn = cute.compile(
            module.gemm,
            *_compile_arg_tuple(io, drv.CUstream(0)),
            options=_cute_compile_options(),
        )
    bins = list((OUT / "cpu-compile").glob("*.cubin"))
    check("one_cubin", len(bins) == 1)
    binary = bins[0]
    host = OUT / "cpu-compile/fc2-host.mlir"
    host.write_text(str(fn.ir_module))
    sys.path.insert(0, str(ROOT / "expert-resident-chain"))
    from resource_audit import audit

    REPORT["kernel"] = {
        "cubin": str(binary),
        "sha256": c.sha(binary),
        "host": str(host),
    }
    REPORT["resources"] = audit(
        binary, binary.with_suffix(".ptx"), host, OUT / "resource-fc2", cluster_size=1
    )
    REPORT["config"] = dataclasses.asdict(io["cfg"])
    check("native_validator_source_unchanged", c.sha(native_file) == native_sha)
    check(
        "native_validator_function_unchanged",
        sys.modules[validate_native_config.__module__].validate_config
        is validate_native_config,
    )
    check("cuda_uninitialized", not torch.cuda.is_initialized())
    REPORT["status"] = "CPU_AOT_PASS"
    flush()


if __name__ == "__main__":
    try:
        run()
    except Exception:
        REPORT["status"] = "CPU_PREPARE_FAIL"
        REPORT["traceback"] = traceback.format_exc()
        flush()
        raise
