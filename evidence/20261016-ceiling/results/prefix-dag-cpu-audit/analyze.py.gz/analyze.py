"""CPU derivation from frozen prefix/admission records; no new prompt construction."""
from pathlib import Path
import hashlib,json
ROOT=Path('/home/zjy/code/hsliu/artifacts/drama3-ceiling-20261016')
OUT=ROOT/'prefix-dag-cpu-audit';OUT.mkdir(exist_ok=True)
paths=[ROOT/'reference-prefix/per-request.json',ROOT/'reference-prefix/admission-proxy.json',ROOT/'reference-prefix/alignment-boundary-proof.json',ROOT/'current-pipeline-service-ledger.json',ROOT/'native-row-reuse-exact-v2/capture-result.json',ROOT/'native-row-reuse-exact-v2/result.json']
rows,proxy,aligned,ledger,capture,exact=[json.loads(p.read_text()) for p in paths]
assert exact['status']=='PASS';seen=set();offset=0;groups=[]
tot={k:0 for k in ('same_group_reference_rows','same_group_reference_teacher_safe_rows','common25_additional_backbone_rows','common24_additional_teacher_rows','same_group_c64_rows','same_group_c128_rows','ready_c64_rows','ready_c128_rows')}
for group,n in enumerate(proxy['group_sizes']):
 rr=rows[offset:offset+n];local=set();d=0;c64=c128=0
 for row in rr:
  key=row['prefix_sha256'];P=row['prefix_rows'];b64=(P-1)//64*64;b128=(P-1)//128*128
  if key in local:
   d+=P;c64+=b64;c128+=b128
   tot['same_group_reference_rows']+=P;tot['same_group_reference_teacher_safe_rows']+=P-1
   tot['same_group_c64_rows']+=b64;tot['same_group_c128_rows']+=b128
  elif key in seen:
   tot['ready_c64_rows']+=b64;tot['ready_c128_rows']+=b128
  local.add(key)
 extra=25*(len(local)-1);tot['common25_additional_backbone_rows']+=extra;tot['common24_additional_teacher_rows']+=24*(len(local)-1)
 groups.append(dict(group=group,first_request=offset,requests=n,unique_reference=len(local),backbone_alias_rows=d+extra,c64_reference_rows=c64,c128_reference_rows=c128))
 offset+=n;seen.update(local)
assert offset==1088 and tot['same_group_reference_rows']==proxy['same_group_duplicate_rows']
assert tot['same_group_c128_rows']==aligned['aligned_proxy']['same_group']['saved_rows']
assert tot['ready_c128_rows']==aligned['aligned_proxy']['ready_proxy']['saved_rows']
assert groups[190]['backbone_alias_rows']==capture['cases'][0]['alias_count']==661
assert groups[192]['backbone_alias_rows']==capture['cases'][2]['alias_count']==531
mixed_s=proxy['mixed_backbone_and_teacher_span_s'];den=proxy['full_prompt_rows'];window=ledger['time']['raw_request_window_s']
scenarios={'aligned128_same_group':tot['same_group_c128_rows'],'aligned128_ready_plus_same_group':tot['same_group_c128_rows']+tot['ready_c128_rows'],'aligned64_same_group':tot['same_group_c64_rows'],'arbitrary_prefix_and_common25_backbone_same_group':tot['same_group_reference_rows']+tot['common25_additional_backbone_rows'],'arbitrary_prefix_and_common24_teacher_same_group':tot['same_group_reference_teacher_safe_rows']+tot['common24_additional_teacher_rows']}
budgets={k:dict(rows=v,prompt_row_fraction=v/den,optimistic_linear_mixed_seconds=mixed_s*v/den,window_fraction=mixed_s*v/den/window) for k,v in scenarios.items()}
per_layer_h32=32*128*128*4
full_fork_payload=30*per_layer_h32+30*8192*3*2+(10+13)*128*2*2*256*2
assert full_fork_payload==aligned['FP32_C128_snapshot_bytes']
result=dict(status='CPU_DAG_FEASIBILITY_ONLY_NO_GPU_OR_IMPLEMENTATION',source='e7cda1eba083603b88e1f2e89688e1ff2ced7fc2',input_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},totals=tot,groups=groups,budgets=budgets,
 assumptions=['Same group identities are FIFO proxy; token totals matched all196 mixed events but actual request IDs were not recorded.','common25 fact is inherited from prior prompt-byte audit; current real40layer MoE alias cases prove those inputs, not whole-prefill DAG states.','Teacher key requires next-row lookahead: shared25 gives conservative24 unless extra proof.','All linear time projections charge old decode and fixed MoE weights as if proportional; optimistic estimates, not measured savings or strict roofline.','No future target inputs, warmup cache or request waiting allowed.'],
 state_bytes=dict(fp32_recurrent_per_owner_per_layer=per_layer_h32,full_c128_fork_payload=full_fork_payload,all30_gdn_fp32_per_branch=30*per_layer_h32,layer_scratch_example_8owners_8branches=16*per_layer_h32),
 same_run_time=dict(raw_window_s=window,mixed_and_teacher_s=mixed_s,pure_prefill_s=ledger['timeline']['stage']['prefill']['gpu_event_ms']['sum']/1000,model_all_mixed_and_prefill_s=mixed_s+ledger['timeline']['stage']['prefill']['gpu_event_ms']['sum']/1000,required_reduction_to_6765_s=ledger['reference_budget']['actual_time_reduction_to_target_s']),
 numerical_contract='C128 and C64 checkpoint boundaries still require export/continuation exactness; arbitrary25/P split changes original64chunk reduction grouping and must not be passed off as the already validated MoE reuse.')
(OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n');(OUT/'analyze.py').write_text(Path(__file__).read_text());print(json.dumps({k:result[k] for k in ('totals','budgets','state_bytes','same_run_time')},indent=2))
