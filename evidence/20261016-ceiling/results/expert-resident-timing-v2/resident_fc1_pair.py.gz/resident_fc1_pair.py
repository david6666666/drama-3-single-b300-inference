# SPDX-License-Identifier: Apache-2.0
# Correctness-only resident FC1 pair: up/gate native FP8 boundaries stay in SMEM.
import flashinfer.prims_ts.batched_gemm.batched_gemm_kernel as _native
globals().update({k:v for k,v in vars(_native).items() if not k.startswith('__')})
from resident_stage import resident_stage_body

@cute.kernel
def resident_fc1_pair_kernel(
    tma_a_desc: cutlass.GridConstant[cuda.TensorMap],
    tma_b_desc: cutlass.GridConstant[cuda.TensorMap],
    tma_c_desc: cutlass.GridConstant[cuda.TensorMap],
    tma_sfa_desc: cutlass.GridConstant[cuda.TensorMap],
    tma_sfb_desc: cutlass.GridConstant[cuda.TensorMap],
    c_tensor: cute.Tensor,
    sf_c_tensor: cute.Tensor,
    bias_tensor: cute.Tensor,
    scale_c_tensor: cute.Tensor,
    scale_gate_tensor: cute.Tensor,
    gemm1_alpha_tensor: cute.Tensor,
    gemm1_beta_tensor: cute.Tensor,
    gemm1_clamp_limit_tensor: cute.Tensor,
    per_token_sf_a_tensor: cute.Tensor,
    per_token_sf_b_tensor: cute.Tensor,
    tile_idx_tensor: cute.Tensor,
    route_map_tensor: cute.Tensor,
    mn_limit_tensor: cute.Tensor,
    num_non_exiting_ctas_tensor: cute.Tensor,
    total_num_padded_tokens_tensor: cute.Tensor,
    act_tensor: cute.Tensor,
    sfa_gmem_tensor: cute.Tensor,
    sfb_gmem_tensor: cute.Tensor,
    problem_m: cutlass.Int32,
    problem_n: cutlass.Int32,
    problem_k: cutlass.Int32,
    num_tokens: cutlass.Int32,
    num_experts: cutlass.Int32,
    tile_sched_params: object,
    cfg: cutlass.Constexpr[BatchedGemmConfig],
    early_exit_max_token_ctas: cutlass.Int32,
) -> None:
    # One shared allocation is borrowed by each fully-drained native stage.
    resident_base = cutlass.Array(cutlass.Uint8, 78080,
        space=cutlass.AddressSpace.smem, alignment=1024)
    tid, _, _ = cute.arch.thread_idx()
    rank = cute.arch.block_idx_in_cluster()
    raw = cutlass.Array(resident_base.data_ptr(), dtype=cutlass.Uint8,
        shape=(78080,), addrspace=3)
    for segment in cutlass.range_constexpr(5):
        i = tid + Int32(segment * 512)
        if i < Int32(2112):
            raw.subview(Int32(72704) + i).store(cutlass.Uint8(173))
    prims.barrier_cta_sync()
    tmem_ptr = cute.make_ptr(cutlass.Int32,resident_base.data_ptr()+78016,cutlass.AddressSpace.smem)
    if cute.arch.warp_idx() == 0:
        cute.arch.alloc_tmem(32,tmem_ptr,is_two_cta=False)
        cute.arch.relinquish_tmem_alloc_permit(is_two_cta=False)
    prims.barrier_cta_sync()
    tmem_value = cutlass.Array(resident_base.data_ptr()+78016,dtype=cutlass.Int32,shape=(1,),addrspace=3).load()
    for phase in cutlass.range_constexpr(2):
        resident_stage_body(
            tma_a_desc,
            tma_b_desc,
            tma_c_desc,
            tma_sfa_desc,
            tma_sfb_desc,
            c_tensor,
            sf_c_tensor,
            bias_tensor,
            scale_c_tensor,
            scale_gate_tensor,
            gemm1_alpha_tensor,
            gemm1_beta_tensor,
            gemm1_clamp_limit_tensor,
            per_token_sf_a_tensor,
            per_token_sf_b_tensor,
            tile_idx_tensor,
            route_map_tensor,
            mn_limit_tensor,
            num_non_exiting_ctas_tensor,
            total_num_padded_tokens_tensor,
            act_tensor,
            sfa_gmem_tensor,
            sfb_gmem_tensor,
            problem_m,
            problem_n,
            problem_k,
            num_tokens,
            num_experts,
            tile_sched_params,
            cfg,
            early_exit_max_token_ctas,
            resident_base,
            phase,
            tmem_value,
        )
        # Includes producer/MMA/epilogue drain; outer retains TMEM allocation.
        prims.tcgen05_fence(prims.Tcgen05Fence.BEFORE_THREAD_SYNC)
        prims.barrier_cta_sync()
    # Debug boundary export is explicit; it will be removable after full chain
    # correctness. It does not serve as activation input in the resident chain.
    valid_rows = cutlass.make_array_view(mn_limit_tensor).load(idx=Int32(0),vector_size=1)[0]
    fc1 = cutlass.Array(resident_base.data_ptr() + 72704,
        dtype=cutlass.Uint8,shape=(2048,),addrspace=3)
    sf = cutlass.Array(resident_base.data_ptr() + 74752,
        dtype=cutlass.Float32,shape=(16,),addrspace=3)
    out = cutlass.Array(cutlass.make_array_view(c_tensor).data_ptr(),dtype=cutlass.Uint8)
    osf = cutlass.make_array_view(sf_c_tensor)
    for segment in cutlass.range_constexpr(4):
        i = tid + Int32(segment * 512)
        token = i // Int32(256)
        col = i % Int32(256)
        logical = rank * Int32(128) + (col % Int32(128)) + (col // Int32(128)) * Int32(512)
        if token < valid_rows:
            out.subview(token * Int32(1024) + logical).store(fc1.subview(i).load())
    if tid < Int32(16):
        token = tid % Int32(8)
        block = rank + (tid // Int32(8)) * Int32(4)
        if token < valid_rows:
            osf.store(sf.subview(tid).load(),idx=block * Int32(8) + token,vector_size=1,alignment=4)
    prims.barrier_cta_sync()
    prims.tcgen05_fence(prims.Tcgen05Fence.BEFORE_THREAD_SYNC)
    if cute.arch.warp_idx() == 0:
        prims.tcgen05_dealloc(prims.make_tmem_ptr(tmem_value,cutlass.Float32),32,group=cfg.cta_group)
    prims.barrier_cta_sync()
