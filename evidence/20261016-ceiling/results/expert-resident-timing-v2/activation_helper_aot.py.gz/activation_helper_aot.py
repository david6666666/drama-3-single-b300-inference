"""CPU-only fake-tensor AOT of the shared DSL helper; no CUDA context/launch."""
import os,sys,json,hashlib,traceback,time
from pathlib import Path
OUT=Path(__file__).resolve().parent
os.environ['CUTE_DSL_ARCH']='sm_103a'
os.environ['CUTE_DSL_KEEP']='ptx,cubin'
os.environ['CUTE_DSL_DUMP_DIR']=str(OUT/'activation-helper-aot')
os.environ['CUTE_DSL_CACHE_DIR']=str(OUT/'activation-helper-cache')
sys.path.insert(0,'/home/zjy/code/hsliu/venvs/codex-drama3-vllm/lib/python3.12/site-packages/nvidia_cutlass_dsl/dsl_packages')
import torch,cutlass
import cutlass.cute as cute
from cutlass import Uint8,Float32,Int32
from cutlass.utils import SmemAllocator
from cutlass.cute.runtime import make_fake_tensor
import cuda.bindings.driver as cuda_drv
from activation_shared_dsl import activation_shared_8x128

class Probe:
    @cute.kernel
    def kernel(self,q:cute.Tensor,s:cute.Tensor,n:cute.Tensor,y:cute.Tensor,ys:cute.Tensor):
        tid,_,_=cute.arch.thread_idx();group,_,_=cute.arch.block_idx()
        smem=SmemAllocator()
        sx=smem.allocate_tensor(Uint8,cute.make_layout((8,256),stride=(256,1)),16)
        ss=smem.allocate_tensor(Float32,cute.make_layout((2,8),stride=(8,1)),16)
        sy=smem.allocate_tensor(Uint8,cute.make_layout((8,128),stride=(128,1)),16)
        sysf=smem.allocate_tensor(Float32,cute.make_layout((8,)),16)
        for i in cutlass.range_constexpr(4):
            index=tid+Int32(512*i);sx[index//Int32(256),index%Int32(256)]=q[group,index//Int32(256),index%Int32(256)]
        if tid<Int32(16):ss[tid//Int32(8),tid%Int32(8)]=s[group,tid//Int32(8),tid%Int32(8)]
        for i in cutlass.range_constexpr(2):
            index=tid+Int32(512*i);sy[index//Int32(128),index%Int32(128)]=Uint8(165)
        if tid<Int32(8):sysf[tid]=Float32(-17.)
        cute.arch.sync_threads()
        activation_shared_8x128(sx,ss,sy,sysf,n[group],tid)
        cute.arch.sync_threads()
        for i in cutlass.range_constexpr(2):
            index=tid+Int32(512*i);y[group,index//Int32(128),index%Int32(128)]=sy[index//Int32(128),index%Int32(128)]
        if tid<Int32(8):ys[group,tid]=sysf[tid]
    @cute.jit
    def __call__(self,q:cute.Tensor,s:cute.Tensor,n:cute.Tensor,y:cute.Tensor,ys:cute.Tensor,stream:cuda_drv.CUstream):
        self.kernel(q,s,n,y,ys).launch(grid=(64,1,1),block=(512,1,1),stream=stream)

report=dict(status='PREPARING',gpu_launched=False,source_sha256=hashlib.sha256((OUT/'activation_shared_dsl.py').read_bytes()).hexdigest(),harness_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
def save(): (OUT/'activation-helper-aot-result.json').write_text(json.dumps(report,indent=2)+'\n')
try:
 assert os.environ.get('CUDA_VISIBLE_DEVICES')==''
 assert not torch.cuda.is_initialized()
 q=make_fake_tensor(Uint8,(64,8,256),(2048,256,1),assumed_align=16)
 s=make_fake_tensor(Float32,(64,2,8),(16,8,1),assumed_align=16)
 n=make_fake_tensor(Int32,(64,),(1,),assumed_align=16)
 y=make_fake_tensor(Uint8,(64,8,128),(1024,128,1),assumed_align=16)
 ys=make_fake_tensor(Float32,(64,8),(8,1),assumed_align=16)
 start=time.monotonic();fn=cute.compile(Probe(),q,s,n,y,ys,cuda_drv.CUstream(0),options='--gpu-arch sm_103a --opt-level 2')
 report.update(status='CPU_AOT_PASS',seconds=time.monotonic()-start,kernel_info=str(fn.kernel_info),cuda_initialized=torch.cuda.is_initialized())
 assert not report['cuda_initialized']
 (OUT/'activation-helper-aot').mkdir(exist_ok=True)
 (OUT/'activation-helper-aot/host.mlir').write_text(str(fn.ir_module))
 report['artifacts']={str(p.relative_to(OUT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (OUT/'activation-helper-aot').rglob('*') if p.is_file()}
except BaseException:
 report.update(status='CPU_AOT_FAIL',error=traceback.format_exc(),cuda_initialized=torch.cuda.is_initialized());raise
finally:save()
print(json.dumps(report,indent=2))
