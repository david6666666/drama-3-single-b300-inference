"""Coordinator-only watchdog and sampled process audit; never auto-authorizes GPU."""
import json
import os
import signal
import subprocess
import time
from pathlib import Path

OUT = Path(__file__).resolve().parent
PYTHON = '/home/zjy/code/hsliu/venvs/codex-drama3-standalone/bin/python'


def compute_apps(gpu_uuid):
    result = subprocess.run(['nvidia-smi',
        '--query-compute-apps=gpu_uuid,pid,process_name,used_gpu_memory',
        '--format=csv,noheader'], text=True, capture_output=True, timeout=10, check=False)
    return {'returncode': result.returncode,
            'matching_lines': [line for line in result.stdout.splitlines() if gpu_uuid in line],
            'stderr': result.stderr}


def main():
    protocol = json.loads((OUT / 'full-protocol.json').read_text())
    gpu = protocol['gpu_uuid']
    timeout = int(protocol.get('watchdog_seconds', 300))
    assert gpu and 30 <= timeout <= 900
    pre = compute_apps(gpu)
    assert pre['returncode'] == 0 and not pre['matching_lines'], pre
    command = [PYTHON, str(OUT / 'run_full_gate.py')]
    env = os.environ.copy()
    env['CUDA_VISIBLE_DEVICES'] = gpu
    report = {'command': command, 'gpu_uuid': gpu, 'timeout_seconds': timeout,
              'timings_allowed': False, 'status': 'STARTING', 'pre': pre,
              'process_audit_scope': 'sampled every 2s, not continuous exclusivity proof'}
    result_path = OUT / 'full-launch-result.json'
    def flush():
        result_path.write_text(json.dumps(report, indent=2) + '\n')
    flush()
    with (OUT / 'full-gpu.log').open('w') as log, (OUT / 'full-process-audit.jsonl').open('w') as audit:
        child = subprocess.Popen(command, env=env, stdout=log,
                                 stderr=subprocess.STDOUT, start_new_session=True)
        report['pid'] = child.pid
        start = time.monotonic()
        flush()
        try:
            while child.poll() is None:
                elapsed = time.monotonic() - start
                audit.write(json.dumps({'elapsed_seconds': elapsed, **compute_apps(gpu)}) + '\n')
                audit.flush()
                if elapsed > timeout:
                    report['status'] = 'WATCHDOG_TIMEOUT'
                    os.killpg(child.pid, signal.SIGKILL)
                    child.wait()
                    break
                time.sleep(2)
            if report['status'] != 'WATCHDOG_TIMEOUT':
                report['status'] = 'CHILD_EXITED'
            report['returncode'] = child.returncode
        finally:
            if child.poll() is None:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait()
            report['post'] = compute_apps(gpu)
            flush()
    if report['status'] == 'WATCHDOG_TIMEOUT' or report.get('returncode') != 0:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
