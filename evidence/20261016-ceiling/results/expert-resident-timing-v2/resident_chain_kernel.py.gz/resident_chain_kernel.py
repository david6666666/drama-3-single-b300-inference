# SPDX-License-Identifier: Apache-2.0
import flashinfer.prims_ts.batched_gemm.batched_gemm_kernel as _native
globals().update({k:v for k,v in vars(_native).items() if not k.startswith('__')})
from resident_stage import resident_stage_body
from resident_fc2_stage import resident_fc2_stage_body
from activation_shared_dsl import activation_shared_8x128
from resident_dsm_gather import resident_dsm_gather

@cute.kernel
def resident_chain_kernel(
    tma_a_desc: cutlass.GridConstant[cuda.TensorMap],
    tma_b_desc: cutlass.GridConstant[cuda.TensorMap],
    tma_c_desc: cutlass.GridConstant[cuda.TensorMap],
    tma_sfa_desc: cutlass.GridConstant[cuda.TensorMap],
    tma_sfb_desc: cutlass.GridConstant[cuda.TensorMap],
    c_tensor: cute.Tensor,
    sf_c_tensor: cute.Tensor,
    bias_tensor: cute.Tensor,
    scale_c_tensor: cute.Tensor,
    scale_gate_tensor: cute.Tensor,
    gemm1_alpha_tensor: cute.Tensor,
    gemm1_beta_tensor: cute.Tensor,
    gemm1_clamp_limit_tensor: cute.Tensor,
    per_token_sf_a_tensor: cute.Tensor,
    per_token_sf_b_tensor: cute.Tensor,
    tile_idx_tensor: cute.Tensor,
    route_map_tensor: cute.Tensor,
    mn_limit_tensor: cute.Tensor,
    num_non_exiting_ctas_tensor: cute.Tensor,
    total_num_padded_tokens_tensor: cute.Tensor,
    act_tensor: cute.Tensor,
    sfa_gmem_tensor: cute.Tensor,
    sfb_gmem_tensor: cute.Tensor,
    problem_m: cutlass.Int32,
    problem_n: cutlass.Int32,
    problem_k: cutlass.Int32,
    num_tokens: cutlass.Int32,
    num_experts: cutlass.Int32,
    tile_sched_params: object,
    cfg: cutlass.Constexpr[BatchedGemmConfig],
    early_exit_max_token_ctas: cutlass.Int32,
    fc2_tma_a_desc: cutlass.GridConstant[cuda.TensorMap],
    fc2_tma_b_desc: cutlass.GridConstant[cuda.TensorMap],
    fc2_tma_c_desc: cutlass.GridConstant[cuda.TensorMap],
    fc2_tma_sfa_desc: cutlass.GridConstant[cuda.TensorMap],
    fc2_tma_sfb_desc: cutlass.GridConstant[cuda.TensorMap],
    fc2_c_tensor: cute.Tensor,
    fc2_sf_c_tensor: cute.Tensor,
    fc2_bias_tensor: cute.Tensor,
    fc2_scale_c_tensor: cute.Tensor,
    fc2_scale_gate_tensor: cute.Tensor,
    fc2_gemm1_alpha_tensor: cute.Tensor,
    fc2_gemm1_beta_tensor: cute.Tensor,
    fc2_gemm1_clamp_limit_tensor: cute.Tensor,
    fc2_per_token_sf_a_tensor: cute.Tensor,
    fc2_per_token_sf_b_tensor: cute.Tensor,
    fc2_tile_idx_tensor: cute.Tensor,
    fc2_route_map_tensor: cute.Tensor,
    fc2_mn_limit_tensor: cute.Tensor,
    fc2_num_non_exiting_ctas_tensor: cute.Tensor,
    fc2_total_num_padded_tokens_tensor: cute.Tensor,
    fc2_act_tensor: cute.Tensor,
    fc2_sfa_gmem_tensor: cute.Tensor,
    fc2_sfb_gmem_tensor: cute.Tensor,
    fc2_problem_m: cutlass.Int32,
    fc2_problem_n: cutlass.Int32,
    fc2_problem_k: cutlass.Int32,
    fc2_num_tokens: cutlass.Int32,
    fc2_num_experts: cutlass.Int32,
    fc2_tile_sched_params: object,
    fc2_cfg: cutlass.Constexpr[BatchedGemmConfig],
    fc2_early_exit_max_token_ctas: cutlass.Int32,
    activation_out: cute.Tensor,
    activation_sf_out: cute.Tensor
):
    _, token_tile, _ = cute.arch.block_idx()
    tile_count = cutlass.make_array_view(num_non_exiting_ctas_tensor).load(idx=Int32(0),vector_size=1)[0]
    padded_rows = cutlass.make_array_view(total_num_padded_tokens_tensor).load(idx=Int32(0),vector_size=1)[0]
    if token_tile < tile_count:
        resident_base = cutlass.Array(cutlass.Uint8, 78080,
            space=cutlass.AddressSpace.smem, alignment=1024)
        tid, _, _ = cute.arch.thread_idx()
        rank = cute.arch.block_idx_in_cluster()
        raw = cutlass.Array(resident_base.data_ptr(), dtype=cutlass.Uint8,
            shape=(78080,), addrspace=3)
        for segment in cutlass.range_constexpr(5):
            i = tid + Int32(segment * 512)
            if i < Int32(2112):
                raw.subview(Int32(72704) + i).store(cutlass.Uint8(173))
        prims.barrier_cta_sync()
        tmem_ptr = cute.make_ptr(cutlass.Int32,resident_base.data_ptr()+78016,cutlass.AddressSpace.smem)
        if cute.arch.warp_idx() == 0:
            cute.arch.alloc_tmem(32,tmem_ptr,is_two_cta=False)
            cute.arch.relinquish_tmem_alloc_permit(is_two_cta=False)
        prims.barrier_cta_sync()
        tmem_value = cutlass.Array(resident_base.data_ptr()+78016,dtype=cutlass.Int32,shape=(1,),addrspace=3).load()
        for phase in cutlass.range_constexpr(2):
            resident_stage_body(
                tma_a_desc,
                tma_b_desc,
                tma_c_desc,
                tma_sfa_desc,
                tma_sfb_desc,
                c_tensor,
                sf_c_tensor,
                bias_tensor,
                scale_c_tensor,
                scale_gate_tensor,
                gemm1_alpha_tensor,
                gemm1_beta_tensor,
                gemm1_clamp_limit_tensor,
                per_token_sf_a_tensor,
                per_token_sf_b_tensor,
                tile_idx_tensor,
                route_map_tensor,
                mn_limit_tensor,
                num_non_exiting_ctas_tensor,
                total_num_padded_tokens_tensor,
                act_tensor,
                sfa_gmem_tensor,
                sfb_gmem_tensor,
                problem_m,
                problem_n,
                problem_k,
                num_tokens,
                num_experts,
                tile_sched_params,
                cfg,
                early_exit_max_token_ctas,
                resident_base,
                phase,
                tmem_value,
            )
            # Includes producer/MMA/epilogue drain; outer retains TMEM allocation.
            prims.tcgen05_fence(prims.Tcgen05Fence.BEFORE_THREAD_SYNC)
            prims.barrier_cta_sync()
        # Zero-debug path keeps every native shared arithmetic boundary.
        valid_rows = min(max(cutlass.make_array_view(mn_limit_tensor).load(idx=token_tile,vector_size=1)[0] - token_tile*Int32(8),Int32(0)),Int32(8))
        prims.barrier_cta_sync()
        # Existing FP8 bytes and FP32 scale boundaries are consumed directly from
        # pinned shared memory, before the full activation aliases FC1 storage.
        local_act = cutlass.Array(resident_base.data_ptr()+76928,dtype=cutlass.Uint8,shape=(1024,),addrspace=3)
        local_sf = cutlass.Array(resident_base.data_ptr()+77952,dtype=cutlass.Float32,shape=(8,),addrspace=3)
        full_act = cutlass.Array(resident_base.data_ptr()+72704,dtype=cutlass.Uint8,shape=(4096,),addrspace=3)
        full_sf = cutlass.Array(resident_base.data_ptr()+76800,dtype=cutlass.Float32,shape=(32,),addrspace=3)
        x = cute.make_tensor(cute.make_ptr(cutlass.Uint8,resident_base.data_ptr()+72704,cutlass.AddressSpace.smem),cute.make_layout((8,256),stride=(256,1)))
        xs = cute.make_tensor(cute.make_ptr(cutlass.Float32,resident_base.data_ptr()+74752,cutlass.AddressSpace.smem),cute.make_layout((2,8),stride=(8,1)))
        y = cute.make_tensor(cute.make_ptr(cutlass.Uint8,resident_base.data_ptr()+76928,cutlass.AddressSpace.smem),cute.make_layout((8,128),stride=(128,1)))
        ys = cute.make_tensor(cute.make_ptr(cutlass.Float32,resident_base.data_ptr()+77952,cutlass.AddressSpace.smem),cute.make_layout((8,),stride=(1,)))
        activation_shared_8x128(x,xs,y,ys,valid_rows,tid)
        resident_dsm_gather(local_act,local_sf,full_act,full_sf,valid_rows,tid)
        # No global activation debug export; FC2 consumes shared full_act/full_sf.
        prims.barrier_cta_sync()
        for phase in cutlass.range_constexpr(4):
            resident_fc2_stage_body(
                fc2_tma_a_desc,
                fc2_tma_b_desc,
                fc2_tma_c_desc,
                fc2_tma_sfa_desc,
                fc2_tma_sfb_desc,
                fc2_c_tensor,
                fc2_sf_c_tensor,
                fc2_bias_tensor,
                fc2_scale_c_tensor,
                fc2_scale_gate_tensor,
                fc2_gemm1_alpha_tensor,
                fc2_gemm1_beta_tensor,
                fc2_gemm1_clamp_limit_tensor,
                fc2_per_token_sf_a_tensor,
                fc2_per_token_sf_b_tensor,
                fc2_tile_idx_tensor,
                fc2_route_map_tensor,
                fc2_mn_limit_tensor,
                fc2_num_non_exiting_ctas_tensor,
                fc2_total_num_padded_tokens_tensor,
                fc2_act_tensor,
                fc2_sfa_gmem_tensor,
                fc2_sfb_gmem_tensor,
                fc2_problem_m,
                fc2_problem_n,
                fc2_problem_k,
                fc2_num_tokens,
                fc2_num_experts,
                fc2_tile_sched_params,
                fc2_cfg,
                fc2_early_exit_max_token_ctas,
                resident_base, phase, tmem_value, full_act, full_sf,
            )
            prims.tcgen05_fence(prims.Tcgen05Fence.BEFORE_THREAD_SYNC)
            prims.barrier_cta_sync()
        prims.barrier_cta_sync()
        prims.tcgen05_fence(prims.Tcgen05Fence.BEFORE_THREAD_SYNC)
        if cute.arch.warp_idx() == 0:
            prims.tcgen05_dealloc(prims.make_tmem_ptr(tmem_value,cutlass.Float32),32,group=cfg.cta_group)
        prims.barrier_cta_sync()
