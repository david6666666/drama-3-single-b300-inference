"""Complete prepared-MoE implementation A/B, matched q/ids/routeweights boundary.

Both arms include live native metadata + all expert arithmetic + native ordered
finalizer. Common input quantization and logits-to-top8 routing are excluded.
Native production PDL=True is retained; candidate PDL=False is a limitation.
"""
import gc
import hashlib
import json
import os
import statistics
import traceback
from pathlib import Path
from types import SimpleNamespace

OUT = Path(__file__).resolve().parent
os.environ.update(CUTE_DSL_ARCH='sm_103a', CUTE_DSL_KEEP='ptx,cubin',
                  CUTE_DSL_DUMP_DIR=str(OUT / 'timing-gpu-compile'))
(OUT / 'timing-gpu-compile').mkdir(exist_ok=True)
import chain_common as c
import torch
import validate_chain as v
from flashinfer.fused_moe import core as fi
from flashinfer.fused_moe.shared.inputs import MoeRunnerInputs
from flashinfer.tllm_enums import DtypeTrtllmGen, Fp8QuantizationType, RoutingInputMode


def tensor_hash(tensor):
    return hashlib.sha256(tensor.detach().contiguous().view(torch.uint8).cpu().numpy().tobytes()).hexdigest()


def as_torch(value):
    return value if isinstance(value, torch.Tensor) else torch.from_dlpack(value)


def metadata(ids, weights):
    result = fi.trtllm_moe_allocate_routing_metadata_multi_tile(
        ids, num_experts=256, top_k=8, local_expert_offset=0, num_local_experts=256,
        tile_ns=[8], routing_input_mode=RoutingInputMode.UnpackedPrecomputed,
        topk_weights=weights)
    fi.populate_trtllm_moe_routing_metadata_(result, ids, weights)
    return result


def slot_tensors(meta):
    slot = meta.slots[0]
    return {name: as_torch(value) for name, value in {
        'padded': slot.total_num_padded_tokens,
        'mapping': slot.expanded_idx_to_permuted_idx,
        'route': slot.permuted_idx_to_token_idx,
        'tile': slot.cta_idx_xy_to_batch_idx,
        'mn': slot.cta_idx_xy_to_mn_limit,
        'ncta': slot.num_non_exiting_ctas}.items()}


def make_native(runtime, q, sf, ids, route_weights, weights, rec, layer):
    runner = runtime.MoERunner(runtime.moe_op, top_k=8, num_local_experts=256,
        dtype_act=DtypeTrtllmGen.E4m3, dtype_weights=DtypeTrtllmGen.E4m3,
        fp8_quantization_type=Fp8QuantizationType.DeepSeekFp8,
        hidden_size=2048, intermediate_size=512, num_experts=256)
    inputs = MoeRunnerInputs(torch.empty((64, 2048), device='cuda', dtype=torch.bfloat16),
                             None, ids, route_weights, q, sf, None, None).to_list()
    tactic = runner.get_factorized_tactic_space(inputs).anchor(8).tactic
    rec.require(f'L{layer}/native_tactic', tuple(tactic) == (8, 5), list(tactic))
    kw = {'routing_bias': None, 'num_experts': 256, 'n_group': None, 'topk_group': None,
        'routed_scaling_factor': 1.0, 'routing_method_type': 4, 'use_shuffled_weight': False,
        'weight_layout': 0, 'enable_pdl': True, 'local_expert_offset': 0, 'do_finalize': True,
        'routing_input_mode': RoutingInputMode.UnpackedPrecomputed,
        'gemm1_weights': weights['w1'], 'gemm1_weights_scale': weights['sf1'],
        'gemm2_weights': weights['w2'], 'gemm2_weights_scale': weights['sf2']}
    meta = metadata(ids, route_weights)
    body = SimpleNamespace(tile_n=8, tactic=5)
    runner_body = runtime.DABodyRunner(runner)
    workspace = tuple(as_torch(t) for t in runner_body.prepare_body(inputs, body, meta.slots[0], **kw))
    def call():
        fi.populate_trtllm_moe_routing_metadata_(meta, ids, route_weights)
        runner_body.forward_from_metadata(inputs, body, meta.slots[0], workspace, **kw)
        return inputs[0]
    return {'call': call, 'output': inputs[0], 'meta': meta, 'workspace': workspace,
                'owned': (runner, runner_body, inputs, body, kw)}


def live_metadata(rec, name, fields, dataset):
    """Native route coordinates, never output-value-based reordering.

    Each populate may legally choose a different within-expert permutation.
    Validate the arm's own current bijection/ownership, then read that same map.
    """
    snapshot = {key: value.detach().cpu().clone() for key, value in fields.items()}
    mapping = snapshot['mapping'].long()
    padded, ncta = int(snapshot['padded']), int(snapshot['ncta'])
    rec.require(name + '/bounds_bijection', mapping.shape == (512,)
        and mapping.unique().numel() == 512 and 0 < ncta <= c.CTA
        and padded == 8 * ncta <= c.CAP
        and bool(((mapping >= 0) & (mapping < padded)).all()))
    rec.exact(name + '/expert_ownership', snapshot['tile'][mapping // 8].long(),
              dataset['ids'].flatten().long())
    rec.exact(name + '/original_token_ownership', snapshot['route'][mapping].long(),
              torch.arange(512, dtype=torch.long) // 8)
    valid = torch.zeros(c.CAP, dtype=torch.bool)
    valid[mapping] = True
    rows = torch.arange(c.CAP)
    groups = rows // 8
    prefix = (groups < ncta) & (rows < snapshot['mn'][groups].long())
    rec.exact(name + '/absolute_mn_prefix', valid, prefix)
    counts = torch.bincount(mapping // 8, minlength=ncta)
    rec.exact(name + '/mn_count', snapshot['mn'][:ncta].long() - torch.arange(ncta) * 8, counts)
    archive = dataset['global_meta']['expanded'].long()
    provenance = OUT / 'timing-gate/metadata-provenance'
    provenance.mkdir(parents=True, exist_ok=True)
    path = provenance / (name.replace('/', '_') + '.pt')
    torch.save(dict(snapshot, archived_mapping=archive), path)
    rec.report.setdefault('metadata_provenance', []).append({
        'name': name, 'path': str(path), 'sha256': c.contract.sha(path),
        'different_from_archived_mapping': int((mapping != archive).sum()),
        'ncta': ncta, 'padded': padded})
    rec.flush()
    return mapping, valid


def candidate_check(rec, name, candidate, dataset, fields):
    mapping, valid = live_metadata(rec, name + '/resident_metadata', fields, dataset)
    mapping, valid = mapping.to('cuda'), valid.to('cuda')
    rec.exact(name + '/fc2', candidate.outputs['fc2'][mapping], dataset['intermediates']['fc2_bf16'])
    rec.exact(name + '/fc2_padding_tail', candidate.outputs['fc2'][~valid],
              torch.full_like(candidate.outputs['fc2'][~valid], 7.))
    for key, (_, _, sentinel) in c.contract.BOUNDARIES.items():
        if key != 'fc2':
            rec.exact(name + '/zero_debug/' + key, candidate.outputs[key],
                      torch.full_like(candidate.outputs[key], sentinel))


def graph_for(call):
    stream = torch.cuda.Stream()
    stream.wait_stream(torch.cuda.current_stream())
    with torch.cuda.stream(stream):
        for _ in range(2):
            call()
    torch.cuda.current_stream().wait_stream(stream)
    torch.cuda.synchronize()
    graph = torch.cuda.CUDAGraph()
    with torch.cuda.graph(graph, pool=torch.cuda.graph_pool_handle(), stream=stream):
        call()
    return graph, stream


def load_inputs(case, dataset):
    for destination, source in (('q', 'q'), ('sf', 'input_scale'), ('ids', 'ids'), ('weights', 'weights')):
        case[destination].copy_(dataset[source])


def empty_gate(rec, case, layer):
    """Same captured candidate BODY graph, then ncta0; no empty finalizer."""
    candidate = case['candidate']
    body_graph, body_stream = graph_for(lambda: candidate.launch(v._stream()))
    fields = slot_tensors(case['candidate_meta'])
    saved = {key: tensor.clone() for key, tensor in fields.items()}
    readonly = {key: case[key].clone() for key in ('q', 'sf', 'ids', 'weights')}
    fields['ncta'].zero_()
    fields['padded'].zero_()
    expected = {key: tensor.clone() for key, tensor in fields.items()}
    for mode, call in (('eager', lambda: candidate.launch(v._stream())), ('graph', body_graph.replay)):
        v._initialize_full(candidate.outputs)
        call()
        torch.cuda.synchronize()
        for key, (_, _, sentinel) in c.contract.BOUNDARIES.items():
            rec.exact(f'L{layer}/empty/{mode}/{key}', candidate.outputs[key],
                      torch.full_like(candidate.outputs[key], sentinel))
        for key, tensor in fields.items():
            rec.exact(f'L{layer}/empty/{mode}/metadata/{key}', tensor, expected[key])
        rec.exact(f'L{layer}/empty/{mode}/rng', torch.cuda.get_rng_state(), case['rng'])
        for key, value in readonly.items():
            rec.exact(f'L{layer}/empty/{mode}/input/{key}', case[key], value)
    for key, tensor in fields.items():
        tensor.copy_(saved[key])
    del body_graph, body_stream


@torch.inference_mode()
def main():
    protocol = json.loads((OUT / 'timing-protocol.json').read_text())
    expected_gpu = protocol['gpu_uuid']
    assert os.environ.get('CUDA_VISIBLE_DEVICES') == expected_gpu
    rec = v.Recorder(OUT / 'timing-gate')
    cases = []
    try:
        v._preflight(rec, OUT / 'timing-frozen-inputs.json', expected_gpu)
        prepared = json.loads((OUT / 'timing-aot-result.json').read_text())
        rec.require('cpu_aot', prepared['status'] == 'CPU_AOT_PASS')
        rec.report.update(boundary=protocol['boundary'], pdl=protocol['pdl'],
                          continuation=protocol['continuation'], raw_timing=[], medians=[])
        runtime = fi.get_trtllm_moe_sm100_module()
        rng = torch.cuda.get_rng_state().clone()
        for layer in (0, 19, 39):
            paths = sorted(c.contract.ORACLE_DIR.glob(f'oracle-layer{layer}-*.pt'))
            datasets = [c.contract.load_oracle(path) for path in paths]
            rec.require(f'L{layer}/five_scenarios', len(datasets) == 5)
            first = datasets[0]
            weights = {key: value.cuda() for key, value in c.load_weights(layer).items()}
            weight_hashes = {key: tensor_hash(value) for key, value in weights.items()}
            q, sf, ids, route_weights = [first[key].cuda() for key in ('q', 'input_scale', 'ids', 'weights')]
            native = make_native(runtime, q, sf, ids, route_weights, weights, rec, layer)
            candidate_meta = metadata(ids, route_weights)
            fields = slot_tensors(candidate_meta)
            payload = dict(q=q, input_sf=sf, ids=ids, route_weights=route_weights,
                valid=c.contract.metadata(first)['valid'].cuda(), **weights, **fields)
            candidate = c.build_full_chain(payload, debug_boundaries=False)
            bins = list((OUT / 'timing-gpu-compile').glob('*.cubin'))
            rec.require(f'L{layer}/cubin_identity', len(bins) == 1 and c.contract.sha(bins[0]) == prepared['cubin_sha256'])
            c.contract.require_disjoint_outputs(candidate.outputs, candidate.immutable_tensors)
            native_fields = slot_tensors(native['meta'])
            native_ptrs = {t.untyped_storage().data_ptr() for t in (*native_fields.values(), *native['workspace']) if t.numel()}
            candidate_ptrs = {t.untyped_storage().data_ptr() for t in (*fields.values(), *candidate.outputs.values()) if t.numel()}
            rec.require(f'L{layer}/independent_scratch', not native_ptrs.intersection(candidate_ptrs))
            output = torch.empty((64, 2048), dtype=torch.bfloat16, device='cuda')
            def candidate_call(candidate=candidate, meta=candidate_meta, ids=ids, rw=route_weights,
                               fields=fields, output=output):
                fi.populate_trtllm_moe_routing_metadata_(meta, ids, rw)
                candidate.launch(v._stream())
                v.native_finalize(candidate.outputs['fc2'], rw, fields['mapping'], fields['padded'], output)
                return output
            callables = {'native': native['call'], 'resident': candidate_call}
            graphs, streams = {}, {}
            for name, call in callables.items():
                graphs[name], streams[name] = graph_for(call)
            case = {'layer': layer, 'datasets': datasets, 'weights_tensors': weights, 'weight_hashes': weight_hashes,
                'q': q, 'sf': sf, 'ids': ids, 'weights': route_weights, 'native': native, 'candidate': candidate,
                'candidate_meta': candidate_meta, 'output': output, 'callables': callables, 'graphs': graphs,
                'streams': streams, 'rng': rng}
            for dataset in datasets:
                name = f"L{layer}/{dataset['scenario']}"
                load_inputs(case, dataset)
                readonly = {key: case[key].clone() for key in ('q', 'sf', 'ids', 'weights')}
                for mode in ('eager', 'graph'):
                    v._initialize_full(candidate.outputs)
                    for arm in ('native', 'resident'):
                        (callables[arm] if mode == 'eager' else graphs[arm].replay)()
                        torch.cuda.synchronize()
                        actual = native['output'] if arm == 'native' else output
                        rec.exact(f'{name}/{mode}/{arm}/routed', actual, dataset['routed'])
                    candidate_check(rec, name + '/' + mode, candidate, dataset, fields)
                    native_mapping, _ = live_metadata(rec, name + '/' + mode + '/native_metadata', native_fields, dataset)
                    rec.exact(f'{name}/{mode}/native_fc2', native['workspace'][4].reshape(-1, 2048)[native_mapping.to('cuda')], dataset['intermediates']['fc2_bf16'])
                    for key, value in readonly.items():
                        rec.exact(f'{name}/{mode}/input/{key}', case[key], value)
                    rec.exact(f'{name}/{mode}/rng', torch.cuda.get_rng_state(), rng)
                rec.report['cases'].append(name)
                rec.flush()
            empty_gate(rec, case, layer)
            for key, value in weights.items():
                rec.require(f'L{layer}/weights_unchanged/{key}', tensor_hash(value) == weight_hashes[key])
            cases.append(case)
            print(f'L{layer} full parity + empty PASS', flush=True)
        rec.report.update(status='TIMING', passed=False, timings_allowed=True, all_exact=True)
        rec.flush()
        for case in cases:
            for dataset in case['datasets']:
                name = f"L{case['layer']}/{dataset['scenario']}"
                load_inputs(case, dataset)
                v._initialize_full(case['candidate'].outputs)
                rows = []
                for repetition, order in enumerate((('native', 'resident'), ('resident', 'native'), ('native', 'resident'))):
                    row = {'case': name, 'repetition': repetition, 'order': list(order), 'replays': protocol['replays'], 'ms': {}}
                    for arm in order:
                        graph = case['graphs'][arm]
                        for _ in range(protocol['warmups']):
                            graph.replay()
                        torch.cuda.synchronize()
                        begin, end = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
                        begin.record()
                        for _ in range(protocol['replays']):
                            graph.replay()
                        end.record()
                        end.synchronize()
                        row['ms'][arm] = begin.elapsed_time(end) / protocol['replays']
                        actual = case['native']['output'] if arm == 'native' else case['output']
                        rec.exact(f'{name}/timed{repetition}/{arm}/routed', actual, dataset['routed'])
                    rows.append(row)
                    rec.report['raw_timing'].append(row)
                    rec.flush()
                median = {arm: statistics.median(row['ms'][arm] for row in rows) for arm in ('native', 'resident')}
                reduction = 1.0 - median['resident'] / median['native']
                primary = dataset['scenario'] == 'real'
                rec.report['medians'].append({'case': name, 'primary_real': primary, 'median_ms': median,
                    'latency_reduction': reduction, 'case_continuation_pass': reduction >= (.05 if primary else -.05)})
                candidate_check(rec, name + '/after_timing', case['candidate'], dataset, slot_tensors(case['candidate_meta']))
                live_metadata(rec, name + '/after_timing/native_metadata', slot_tensors(case['native']['meta']), dataset)
                for key, source in (('q', 'q'), ('sf', 'input_scale'), ('ids', 'ids'), ('weights', 'weights')):
                    rec.exact(f'{name}/after_timing/input/{key}', case[key], dataset[source])
                rec.exact(f'{name}/after_timing/rng', torch.cuda.get_rng_state(), rng)
                rec.flush()
        for case in cases:
            for key, value in case['weights_tensors'].items():
                rec.require(f"L{case['layer']}/after_timing/weight/{key}", tensor_hash(value) == case['weight_hashes'][key])
        medians = rec.report['medians']
        rec.require('all15_timed', len(medians) == 15 and sum(row['primary_real'] for row in medians) == 3)
        passed = all(row['case_continuation_pass'] for row in medians)
        rec.report.update(status='LOCAL_CONTINUATION_PASS' if passed else 'LOCAL_CONTINUATION_FAIL',
                          passed=passed, all_exact=True, runtime_promoted=False)
    except BaseException as exc:
        rec.report.update(status='FAIL', passed=False, error=repr(exc), traceback=traceback.format_exc())
        raise
    finally:
        rec.flush()
    print(json.dumps({'status': rec.report['status'], 'checks': len(rec.report['checks'])}), flush=True)
    del cases
    gc.collect()


if __name__ == '__main__':
    main()
