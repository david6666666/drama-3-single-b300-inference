"""Full native metadata extension of the frozen exact single-expert chain."""
from pathlib import Path
import ast
OUT=Path(__file__).resolve().parent
SINGLE=OUT.parent/'expert-resident-chain-v2'
# The original native C coordinates are global padded token rows. Convert only
# the pinned shared destination to the current eight-row cluster-local tile.
s=(SINGLE/'resident_gmem_c.py').read_text()
old='return (m_row // Int32(512)) * Int32(8) + n_col'
assert s.count(old)==1;s=s.replace(old,'return (m_row // Int32(512)) * Int32(8) + n_col % Int32(8)')
old='flat_idx0 = n_col * Int32(256) + (m_row0 // Int32(512)) * Int32(128) + m_row0 % Int32(128)'
assert s.count(old)==1;s=s.replace(old,'flat_idx0 = (n_col % Int32(8)) * Int32(256) + (m_row0 // Int32(512)) * Int32(128) + m_row0 % Int32(128)')
(OUT/'resident_gmem_c.py').write_text(s)
s=(SINGLE/'resident_chain_host.py').read_text()
s=s.replace('cute.make_layout((4096,), stride=(1,))','cute.make_layout((1179648,), stride=(1,))').replace('cute.make_layout((32,), stride=(1,))','cute.make_layout((9216,), stride=(1,))')
s=s.replace('grid=[4,1,1], block=[512,1,1], cluster=[4,1,1]','grid=[4,288,1], block=[512,1,1], cluster=[4,1,1]')
(OUT/'resident_chain_host.py').write_text(s)
s=(SINGLE/'resident_chain_kernel.py').read_text()
n=next(x for x in ast.parse(s).body if isinstance(x,ast.FunctionDef) and x.name=='resident_chain_kernel')
header=''.join(s.splitlines(True)[:n.body[0].lineno-1]);body=''.join(s.splitlines(True)[n.body[0].lineno-1:n.end_lineno])
old='valid_rows = cutlass.make_array_view(mn_limit_tensor).load(idx=Int32(0),vector_size=1)[0]'
assert body.count(old)==1;body=body.replace(old,'valid_rows = min(max(cutlass.make_array_view(mn_limit_tensor).load(idx=token_tile,vector_size=1)[0] - token_tile*Int32(8),Int32(0)),Int32(8))')
for old,new in [
 ('out.subview(token * Int32(1024) + logical)', 'out.subview((token_tile*Int32(8)+token) * Int32(1024) + logical)'),
 ('idx=block * Int32(8) + token','idx=block * padded_rows + token_tile*Int32(8) + token'),
 ('idx=row*Int32(512)+rank*Int32(128)+channel','idx=(token_tile*Int32(8)+row)*Int32(512)+rank*Int32(128)+channel'),
 ('idx=rank*Int32(8)+tid','idx=rank*padded_rows+token_tile*Int32(8)+tid')]:
 assert body.count(old)==1,old;body=body.replace(old,new)
# Every CTA in the physical four-CTA cluster shares blockIdx.y. Inactive
# metadata capacity skips the entire TMEM/DSM lifecycle uniformly; it never
# reads stale per-tile metadata or calls a partial cluster barrier.
prefix='''    _, token_tile, _ = cute.arch.block_idx()
    tile_count = cutlass.make_array_view(num_non_exiting_ctas_tensor).load(idx=Int32(0),vector_size=1)[0]
    padded_rows = cutlass.make_array_view(total_num_padded_tokens_tensor).load(idx=Int32(0),vector_size=1)[0]
    if token_tile < tile_count:
'''
s=header+prefix+''.join('    '+line if line.strip() else line for line in body.splitlines(True))
(OUT/'resident_chain_kernel.py').write_text(s)
for f in ['resident_gmem_c.py','resident_chain_host.py','resident_chain_kernel.py']:ast.parse((OUT/f).read_text())
print('FULL_GENERATOR_CPU_PARSE_PASS')
