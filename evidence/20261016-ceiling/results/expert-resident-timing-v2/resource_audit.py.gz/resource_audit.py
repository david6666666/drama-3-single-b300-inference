"""CPU-only actual launch/CUBIN resource audit for the resident-chain coordinator."""
import json
import re
import subprocess
from pathlib import Path

from validation_contract import sha


def dynamic_shared_from_ir(text):
    """Read the CUlaunchConfig.sharedMemBytes store, not the largest constant.

    Reject unfamiliar/ambiguous host IR rather than inferring resource use from
    the task manager allocator, which omits compiler/runtime additions.
    """
    constants = {name: int(value) for name, value in re.findall(
        r'(%[\w.]+) = llvm\.mlir\.constant\((\d+) : i64\)', text)}
    shape = '!llvm.struct<(array<3 x i32>, array<3 x i32>, i64, ptr, ptr, i32)>'
    pointers = []
    for line in text.splitlines():
        if shape in line and 'llvm.getelementptr' in line and '[0, 2]' in line:
            pointers.append(line.strip().split(' = ')[0])
    values, evidence = [], []
    for pointer in pointers:
        pattern = rf'llvm\.store (%[\w.]+), {re.escape(pointer)} : i64, !llvm.ptr'
        for value in re.findall(pattern, text):
            if value in constants:
                values.append(constants[value])
                evidence.append({'constant': value, 'config_pointer': pointer,
                                 'dynamic_shared_bytes': constants[value]})
    assert len(set(values)) == 1 and values, ('Unrecognized or ambiguous launch IR', evidence)
    return values[0], evidence


def audit(cubin, ptx, host_ir, output_dir, *, smem_limit_bytes=80 * 1024,
          cluster_size, cluster_evidence=None):
    """No GPU interaction. cluster_evidence must be validated by the coordinator.

    This audit confirms per-CTA resource fit, never resident occupancy or speed.
    A caller must provide the exact host launch cluster evidence separately;
    isolated cluster1 component evidence cannot qualify a cluster4 chain.
    """
    cubin, ptx, host_ir = map(Path, (cubin, ptx, host_ir))
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    usage = subprocess.check_output(['/usr/local/cuda/bin/cuobjdump', '--dump-resource-usage', str(cubin)], text=True)
    sass = subprocess.check_output(['/usr/local/cuda/bin/cuobjdump', '--dump-sass', str(cubin)], text=True)
    (output_dir / 'resource-usage.txt').write_text(usage)
    (output_dir / 'kernel.sass').write_text(sass)
    entries = re.findall(r'REG:(\d+) STACK:(\d+) SHARED:(\d+) LOCAL:(\d+)', usage)
    assert len(entries) == 1, ('Require one entry to associate host launch resources', entries)
    registers, stack, static, local = map(int, entries[0])
    dynamic, dynamic_evidence = dynamic_shared_from_ir(host_ir.read_text())
    text = ptx.read_text()
    local_ops = re.findall(r'\b(?:ld|st)\.local\b', text)
    spill_ops = re.findall(r'\b(?:LDL|STL)\b', sass)
    assert not local and not stack and not local_ops and not spill_ops
    assert dynamic + static <= smem_limit_bytes
    assert cluster_size in (1, 4)
    if cluster_size == 4:
        assert cluster_evidence, 'Require actual cluster4 launch evidence; component audit is insufficient'
        evidence_path = Path(cluster_evidence['path'])
        assert sha(evidence_path) == cluster_evidence['sha256']
        assert cluster_evidence['literal'] in evidence_path.read_text()
    result = {'status': 'CPU_RESOURCE_PASS',
              'cubin_sha256': sha(cubin), 'ptx_sha256': sha(ptx), 'host_ir_sha256': sha(host_ir),
              'dynamic_shared_bytes': dynamic, 'static_shared_bytes': static,
              'total_shared_bytes_per_cta': dynamic + static, 'limit_bytes_per_cta': smem_limit_bytes,
              'dynamic_shared_evidence': dynamic_evidence, 'stack_bytes': stack,
              'local_bytes': local, 'ptx_local_ops': len(local_ops), 'sass_spill_ops': len(spill_ops),
              'base_registers': registers,
              'setmaxnreg_limits': sorted(set(re.findall(r'setmaxnreg\.(?:inc|dec)\.sync\.aligned\.u32\s+(\d+)', text))),
              'cluster_size': cluster_size, 'cluster_evidence': cluster_evidence,
              'limitations': ['Resource fit does not prove occupancy or concurrent residency.',
                              'Dynamic SETMAXNREG limits require complete warp-role resource accounting.',
                              'Independent FC1/FC2 resource counts cannot be added to infer composite buffer lifetime.'],
              'gpu_used': False, 'timing_allowed': False}
    (output_dir / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    return result
