"""CPU-only smoke compile for borrowed allocation; never launches a kernel."""
import os
from pathlib import Path
import sys
import json
import hashlib
import traceback
OUT = Path(__file__).resolve().parent
os.environ.update(CUTE_DSL_ARCH='sm_103a', CUTE_DSL_KEEP='ptx,cubin',
                  CUTE_DSL_DUMP_DIR=str(OUT/'resident-allocator-aot'),
                  CUTE_DSL_CACHE_DIR=str(OUT/'resident-allocator-cache'))
sys.path.insert(0, '/home/zjy/code/hsliu/venvs/codex-drama3-vllm/lib/python3.12/site-packages/nvidia_cutlass_dsl/dsl_packages')
import torch
import cutlass
import cutlass.cute as cute
from cutlass.experimental.task_scheduling.memory import SmemAllocation
from cutlass.cute.runtime import make_fake_tensor
import cuda.bindings.driver as cuda_drv
from resident_resources import BorrowedSmemAllocator

class Probe:
    @cute.kernel
    def kernel(self, output: cute.Tensor):
        base = cutlass.Array(cutlass.Uint8, 72768, space=cutlass.AddressSpace.smem, alignment=1024)
        allocator = BorrowedSmemAllocator(base, reserved_bytes=72704)
        allocation = SmemAllocation('smoke', dtype=cutlass.Int32, count=32, alignment=128)
        allocator.add(allocation)
        allocator.compute_layout()
        returned = allocator.allocate()
        assert returned is base
        values = allocator.get(allocation)
        tid, _, _ = cute.arch.thread_idx()
        values[tid] = output[tid]
        cute.arch.sync_threads()
        output[tid] = values[cutlass.Int32(31)-tid]

    @cute.jit
    def __call__(self, output: cute.Tensor, stream: cuda_drv.CUstream):
        self.kernel(output).launch(grid=(1,1,1), block=(32,1,1), stream=stream)

r = {'status': 'PREPARING', 'gpu_launched': False,
     'source_sha256': hashlib.sha256((OUT/'resident_resources.py').read_bytes()).hexdigest()}
try:
    assert os.environ.get('CUDA_VISIBLE_DEVICES') == '' and not torch.cuda.is_initialized()
    output = make_fake_tensor(cutlass.Int32, (32,), (1,), assumed_align=16)
    fn = cute.compile(Probe(), output, cuda_drv.CUstream(0), options='--gpu-arch sm_103a --opt-level 2')
    (OUT/'resident-allocator-aot').mkdir(exist_ok=True)
    (OUT/'resident-allocator-aot/host.mlir').write_text(str(fn.ir_module))
    r.update(status='CPU_AOT_PASS', cuda_initialized=torch.cuda.is_initialized(), kernel_info=str(fn.kernel_info))
    assert not r['cuda_initialized']
except BaseException:
    r.update(status='CPU_AOT_FAIL', error=traceback.format_exc())
    raise
finally:
    (OUT/'resident-allocator-aot-result.json').write_text(json.dumps(r, indent=2)+'\n')
print(json.dumps(r, indent=2))
