"""Artifact-only resident FC2 operands; original arithmetic/UMMA descriptors.

Inputs are explicit caller-owned cutlass.Array objects in shared memory:
shared_act: Uint8[8*512] in token-major logical E4M3-byte order,
shared_sf: Float32[4*8] in (K128 block, token) order.
They must contain the current fixed token tile and remain live until every FC2
consumer completes. The caller owns the outer cluster publish/read-complete
barriers. The adapters introduce no DSM access, allocation, or CTA barrier.

Always pair these resources with resident_pipeline_configs. Plain STS must not
use the original TMA transaction-byte or cp.async-only publication protocol.
"""
# SPDX-License-Identifier: Apache-2.0
# Narrow adapters of FlashInfer SmemBResource/SmemDeepSeekSfAbResource. Original
# Apache-2.0 resource consumers, descriptors, and accumulation are inherited.
from dataclasses import dataclass
from typing import Any
import cutlass
import cutlass.cute as cute
from cutlass import Float32, Int32, Uint8
from cutlass import pipeline
from cutlass.experimental.task_scheduling.resources import (
    PipelineConfig, StageInfo, producer_work,
)
from cutlass.experimental.task_scheduling.enums import SignalingThreads
from flashinfer.prims_ts.batched_gemm.smem_ab_resources import SmemBResource
from flashinfer.prims_ts.batched_gemm.smem_deepseek_sf_resources import (
    SmemDeepSeekSfAbResource,
)


def validate_resident_fc2_config(cfg):
    """Reject unsupported geometry instead of guessing a new byte layout."""
    assert cfg.has_deepseek_fp8 and cfg.is_fp8_mma and cfg.is_swap_ab
    assert cfg.cluster_m == 1 and not cfg.has_gather and not cfg.has_tma_route
    assert (cfg.tile_n, cfg.tile_k, cfg.dtype_b_smem_bits) == (8, 128, 8)
    assert cfg.num_bytes_b_smem_per_stage == 1024
    assert cfg.num_load_b_warps == 1 and cfg.num_load_sfab_warps == 1
    assert cfg.num_dsfp8_act_sfs_per_stage == 32


def resident_pipeline_configs(cfg, original):
    """Keep native stages/consumer ownership, replace only producer protocols."""
    validate_resident_fc2_config(cfg)
    result = dict(original)
    result['smem_b'] = PipelineConfig.create_async_umma_pipeline_cfg(
        num_stages=cfg.num_stages_b,
        producer_group=pipeline.CooperativeGroup(pipeline.Agent.Thread, 32),
        consumer_group=pipeline.CooperativeGroup(pipeline.Agent.Thread),
        cta_layout_vmnk=(1, 1, 1, 1),
        producer_signaling_threads=SignalingThreads.All,
        consumer_signaling_threads=SignalingThreads.CtaLeader,
        producer_op=pipeline.PipelineOp.AsyncThread,
    )
    # The one weight scale is a synchronous FP32 load below. Ordinary shared
    # stores now participate in release/acquire ordering, not cp.async-only
    # completion. Consumer and K-block order are exactly the native ones.
    result['smem_dsfp8_sfab'] = PipelineConfig.create_async_async_pipeline_cfg(
        num_stages=cfg.num_stages_smem_sfa,
        producer_group=pipeline.CooperativeGroup(pipeline.Agent.Thread, 32),
        consumer_group=pipeline.CooperativeGroup(
            pipeline.Agent.Thread, cfg.num_epilogue_warps * 32),
        cta_layout_vmnk=(1, 1, 1, 1),
        producer_op=pipeline.PipelineOp.AsyncThread,
    )
    return result


@cute.jit
def stage_resident_b_tile(shared_act, stage_base, k_begin: Int32,
                          valid_rows: Int32, local_tid: Int32):
    """One warp copies 64 × 16B chunks into the original s128b stage."""
    for iteration in cutlass.range_constexpr(2):
        copy_index = local_tid + Int32(iteration * 32)
        row = copy_index // Int32(8)
        chunk = copy_index % Int32(8)
        # Same 128-byte row swizzle as native SmemGatherResource.
        destination = (row * Int32(128) + chunk * Int32(16)) ^ (row * Int32(16))
        values = cutlass.vector.full([16], 0, Uint8)
        if row < valid_rows:
            source = row * Int32(512) + k_begin + chunk * Int32(16)
            values = shared_act.load(idx=source, vector_size=16)
        stage_base.store(values, idx=destination)
    # UMMA is an async-proxy reader; each publishing thread fences its STS.
    cute.arch.fence_view_async_shared()


@cute.jit
def stage_resident_sf_tile(shared_sf, stage_base, weight_scales,
                           weight_offset: Int32, k_block: Int32,
                           valid_rows: Int32, local_tid: Int32):
    """Fill native 32 activation scales + one FP32 weight scale stage."""
    stage_float = cutlass.Array(stage_base.data_ptr(), dtype=Float32,
                                shape=(33,), addrspace=3)
    value = Float32(0.0)
    if local_tid < valid_rows:
        value = shared_sf.load(idx=k_block * Int32(8) + local_tid,
                               vector_size=1)[0]
    stage_float.store(value, idx=local_tid)
    if local_tid == Int32(0):
        weight = weight_scales.load(idx=weight_offset, vector_size=1)[0]
        stage_float.store(weight, idx=Int32(32))
    # SF consumers use ordinary LDS after AsyncThread barrier acquire. No
    # cp.async remains in this resource, so no hidden completion wait is needed.


@dataclass(kw_only=True)
class ResidentSmemBResource(SmemBResource):
    shared_act: Any = None

    def __post_init__(self):
        validate_resident_fc2_config(self.cfg)
        super().__post_init__()

    @producer_work
    @cute.jit
    def load_b_tile(self, stage_info: StageInfo, *, coord_b_k: Int32,
                    coord_b_mn: Int32, coord_b_l: Int32, mn_limit: Int32):
        tid, _, _ = cute.arch.thread_idx()
        local_tid = tid - Int32(self.cfg.load_b_warp_idx * 32)
        # GmemBResource._load_tile_metadata has already converted its
        # absolute mn_limit to a local row count. coord_b_mn remains the
        # global tile base, so subtracting it again empties every tile>=1.
        rows = min(max(mn_limit, Int32(0)), Int32(8))
        stage = self.smem_buf.subview(Int32(1024) * stage_info.stage_idx)
        stage_resident_b_tile(self.shared_act, stage, coord_b_k, rows, local_tid)


@dataclass(kw_only=True)
class ResidentDeepSeekSfAbResource(SmemDeepSeekSfAbResource):
    shared_sf: Any = None

    def __post_init__(self):
        validate_resident_fc2_config(self.cfg)
        super().__post_init__()

    @producer_work
    @cute.jit
    def load_sfab_tile(self, stage_info: StageInfo):
        tid, _, _ = cute.arch.thread_idx()
        local_tid = tid - Int32(self.cfg.load_sfab_warp_idx * 32)
        k_block = stage_info.loop_offset
        weight_offset = (
            self.dsfp8_expert_idx * self.dsfp8_num_weight_tiles
            + self.dsfp8_weight_tile_idx
        ) * self.dsfp8_num_k_blocks + k_block
        stage = self.smem_buf.subview(
            self.cfg.num_bytes_dsfp8_sfab_per_stage * stage_info.stage_idx)
        stage_resident_sf_tile(self.shared_sf, stage, self.sfa_gmem_base,
                               weight_offset, k_block,
                               self.dsfp8_token_limit, local_tid)
