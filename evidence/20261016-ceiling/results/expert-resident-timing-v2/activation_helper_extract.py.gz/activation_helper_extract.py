"""Extract embedded offline fatbin from the generated host MLIR, no CUDA API."""
import hashlib,json,re,subprocess
from pathlib import Path
root=Path(__file__).resolve().parent;out=root/'activation-helper-aot'
text=(out/'host.mlir').read_text()
m=re.search(r'@kernels_binary\("((?:[^"\\]|\\.)*)"\)',text)
assert m
value=m.group(1);data=bytearray();i=0
while i<len(value):
 if value[i]=='\\':
  if re.fullmatch('[0-9A-Fa-f]{2}',value[i+1:i+3]):data.append(int(value[i+1:i+3],16));i+=3
  else:data.append(ord(value[i+1]));i+=2
 else:data.append(ord(value[i]));i+=1
assert data[:4]==bytes.fromhex('50ed55ba')
(out/'kernel.fatbin').write_bytes(data)
for flag,name in [('--dump-resource-usage','resources.txt'),('--dump-sass','kernel.sass')]:
 p=subprocess.run(['/usr/local/cuda/bin/cuobjdump',flag,str(out/'kernel.fatbin')],text=True,capture_output=True)
 (out/name).write_text(p.stdout+p.stderr);assert p.returncode==0
result=json.loads((root/'activation-helper-aot-result.json').read_text());result['artifacts']={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.rglob('*') if p.is_file()};result['resource_output']=(out/'resources.txt').read_text();result['binary_extraction']='CPU decoded @kernels_binary MLIR string to fatbin, then cuobjdump. No CUDA runtime initialization.'
(root/'activation-helper-aot-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(result['resource_output'])
