import hashlib,json,statistics
from pathlib import Path
from datetime import datetime,timezone
p=Path('/home/zjy/code/hsliu/artifacts/drama3-ceiling-20261016/expert-resident-timing-v2')
source=p/'timing-gate/result.json'; d=json.loads(source.read_text()); protocol=json.loads((p/'timing-protocol.json').read_text())
rows=[]
for old in d['medians']:
 raw=[r for r in d['raw_timing'] if r['case']==old['case']]
 assert len(raw)==3
 assert [r['repetition'] for r in raw]==[0,1,2]
 assert [r['order'] for r in raw]==protocol['timing_order']
 assert all(r['replays']==100 for r in raw)
 med={a:statistics.median(r['ms'][a] for r in raw) for a in ('native','resident')}
 assert med==old['median_ms']
 reduction=1-med['resident']/med['native']; primary=old['case'].endswith('/real')
 assert reduction==old['latency_reduction']
 passed=reduction >= (.05 if primary else -.05)
 assert passed==old['case_continuation_pass']
 rows.append(dict(case=old['case'],primary=primary,median_ms=med,latency_change_percent=-100*reduction,continuation_pass=passed,raw=raw))
assert len(rows)==15 and sum(r['primary'] for r in rows)==3
checks=d['checks']; assert len(checks)==1262 and all(r['exact'] for r in checks)
assert d['status']=='LOCAL_CONTINUATION_FAIL' and not d['passed'] and not d['runtime_promoted']
assert not any(r['continuation_pass'] for r in rows)
provenance=d['metadata_provenance']
for item in provenance:
 path=Path(item['path']); assert hashlib.sha256(path.read_bytes()).hexdigest()==item['sha256']
audit={'status':'INDEPENDENT_CPU_RECOMPUTATION_PASS_CANDIDATE_CONTINUATION_FAIL','generated_at_utc':datetime.now(timezone.utc).isoformat(),'gpu_used':False,'source_sha':d['source_sha'],'inputs':{str(source):hashlib.sha256(source.read_bytes()).hexdigest(),str(p/'timing-protocol.json'):hashlib.sha256((p/'timing-protocol.json').read_bytes()).hexdigest()},'checks':len(checks),'all_recorded_exact':True,'raw_timing_rows':len(d['raw_timing']),'case_medians':rows,'original_failure_preserved':str(p.parent/'expert-resident-timing/timing-gate/result.json'),'metadata_artifact_hashes_checked':len(provenance),'metadata_archive_difference_min':min(r['different_from_archived_mapping'] for r in provenance),'metadata_archive_difference_max':max(r['different_from_archived_mapping'] for r in provenance),'runtime_promoted':False,'limits':['Three real B64 fixtures are 63 live plus one native padding row; no extrapolation to all40 layers or service.','Input quantization/logits routing excluded in both arms.','Native PDL=True; resident PDL=False; complete implementation A/B.','Source PTX register hints are not physical allocation; compiled SASS is authoritative.','This independent pass recomputes saved evidence and reads checker implementation; it does not rerun CUDA.']}
(p/'independent-review.json').write_text(json.dumps(audit,indent=2)+'\n')
lines=['# Resident zero-debug 完整调用独立复核','', '结论：**1262 项已记录精确检查通过，但局部续行门槛失败，所有 15 个场景均回退。不得进入整模型或服务晋级。** 本复核只读取、复算已保存证据，没有重新运行 GPU 或改变执行过的脚本/阈值。','', '## 原始计时复算','', '| 场景 | native 中位数 ms | resident 中位数 ms | 延迟变化 |', '|---|---:|---:|---:|']
for r in rows:lines.append(f"| {r['case']} | {r['median_ms']['native']:.9f} | {r['median_ms']['resident']:.9f} | +{r['latency_change_percent']:.3f}% |")
lines += ['', '逐项重新计算 45 条原始记录：每项 3 次 AB/BA/AB，每臂每次 100 次 graph replay、5 次 warmup，全部中位数与原报告相等。三个 real 场景各自至少降低 5% 的门槛都未达到；12 个压力场景也全部超过允许的 5% 回退。机器复核和原始三重复保存在 `independent-review.json`，无跨场景平均掩盖失败。','', '## 校验器修正与所有权','', '第一版 `../expert-resident-timing/timing-gate/result.json` 的 exact FAIL 原样保留。它错误地把归档物理排列用于当前 native populate 的输出；当时两臂最终 routed 输出已精确。v2 使用每臂自己的 current expanded→permuted metadata，先验证双射、expert、原 token、absolute mn 的有效前缀，再逐位比较归档 logical expanded 输出。没有按输出数值寻找排列或放宽误差。90 份实际 metadata 快照哈希全部核对；相对归档排列差异为 65–434/512，直接证明不能假定固定物理行顺序。','', '源码锚点：`timing_driver.py:83` 的 live_metadata；`:121` 的 FC2/zero-debug sentinel 检查；`:152` 的同 body graph ncta0 gate；`:210` 独立存储；`:262` 计时；`:281` 中位数与冻结门槛。eager、复用 graph、empty、四个删除的 global debug 输出 sentinel、inactive FC2、输入/完整权重/RNG、CPU/GPU CUBIN 身份全部有记录。','', '## 比较边界与资源','', '输入是相同原生 E4M3 q、FP32 scale、top8 ids 和 BF16 route weights；两臂完整调用均含 live metadata、FC1、原生 activation/FP8 边界、FC2、ordered-top8 native finalizer。两臂共同排除 input quant 和 logits→top8。native PDL=True 保留，resident PDL=False 是候选实现局限，不能称只改 MMA 的单变量实验。MoE 没有递归状态；每场景相同输入、独立 workspace、每次重建 metadata，计时不靠不同输出长度。','', '实际 CUBIN `7e19a1b5b1fc048682abe3b8ce22e33adc535e3c0ebbcceada43b7f74ae6f1d1`；host launch 的 dynamic shared 78464 + static 1024 = 79488 B/CTA；stack/local/spill=0。**撤回用 160/48 PTX hints 相加成 53248 寄存器来推断驻留 CTA 数的解释**：resident SASS 无 USETMAXREG，实际 header REG32。见 `../register-lowering-audit/result.json` 与 `../expert-resident-timing/register-hint-independent-audit.json`。shared fit、无 spill、source hint 均不是 achieved occupancy 证据。','', '这只是三个真实 B64（63 live+1 padding）层及 12 个人工路由压力场景；并未测全部 40 层、codec 重叠、当前混合调度或服务吞吐。精度通过不等于性能目标达到，局部失败也不是目标 6765 fps 在硬件上不可能的证明。','']
(p/'independent-review.md').write_text('\n'.join(lines))
print(json.dumps({'status':audit['status'],'checks':len(checks),'timings':len(rows),'metadata_hashes':len(provenance)}))
