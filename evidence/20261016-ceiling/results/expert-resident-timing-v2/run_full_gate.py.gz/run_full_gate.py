"""Coordinator-only frozen full-chain exact gate; no timing/service benchmark."""
import hashlib
import json
import os
from pathlib import Path

OUT = Path(__file__).resolve().parent
os.environ.update(CUTE_DSL_ARCH='sm_103a', CUTE_DSL_KEEP='ptx,cubin',
                  CUTE_DSL_DUMP_DIR=str(OUT / 'full-gpu-compile'))
(OUT / 'full-gpu-compile').mkdir(exist_ok=True)
import chain_common as c
import validate_chain


def main():
    protocol = json.loads((OUT / 'full-protocol.json').read_text())
    expected = protocol['gpu_uuid']
    assert expected and os.environ.get('CUDA_VISIBLE_DEVICES') == expected
    prepared = json.loads((OUT / 'full-aot-result.json').read_text())
    assert prepared['status'] == 'CPU_AOT_PASS'
    cpu_cubin = prepared['cubin_sha256']
    def build(data, debug_boundaries=True):
        candidate = c.build_full_chain(data, debug_boundaries)
        bins = list((OUT / 'full-gpu-compile').glob('*.cubin'))
        assert len(bins) == 1
        actual = hashlib.sha256(bins[0].read_bytes()).hexdigest()
        assert actual == cpu_cubin, ('CPU/GPU compiler identity', actual, cpu_cubin)
        return candidate
    result = validate_chain.run_full(build, c.load_weights, OUT / 'full-gate',
                                     OUT / 'full-frozen-inputs.json', expected)
    result['cpu_gpu_cubin_sha256'] = cpu_cubin
    (OUT / 'full-gate/result.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'status': result['status'], 'checks': len(result['checks']), 'passed': result['passed']}))


if __name__ == '__main__':
    main()
