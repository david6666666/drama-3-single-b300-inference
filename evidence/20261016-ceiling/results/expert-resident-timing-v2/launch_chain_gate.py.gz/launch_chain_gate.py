"""Bounded watchdog for the authorized isolated GPU2 correctness gate."""
import os,subprocess,json,time
from pathlib import Path
OUT=Path(__file__).resolve().parent
command=['/home/zjy/code/hsliu/venvs/codex-drama3-standalone/bin/python',str(OUT/'run_chain_gate.py')]
env=os.environ.copy();env['CUDA_VISIBLE_DEVICES']='GPU-bc643dc2-a0d1-5ed6-5ecb-0605ca9f340a'
report={'command':command,'gpu_uuid':env['CUDA_VISIBLE_DEVICES'],'timeout_seconds':180,'timings_allowed':False,'status':'STARTING'}
(OUT/'chain-launch-result.json').write_text(json.dumps(report,indent=2)+'\n')
try:
 with (OUT/'chain-gpu.log').open('w') as log:
  result=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 report.update(status='CHILD_EXITED',returncode=result.returncode)
except subprocess.TimeoutExpired:
 report.update(status='WATCHDOG_TIMEOUT',returncode=None)
finally:
 (OUT/'chain-launch-result.json').write_text(json.dumps(report,indent=2)+'\n')
if report['status']=='WATCHDOG_TIMEOUT' or report.get('returncode')!=0:raise SystemExit(1)
